import bench.tritonbench_g.context_attn_fwd.Proofs.Program

namespace VeriTile.Bench.Repairs.ContextAttnFwd
open VeriTile.Triton
abbrev Storage := VeriTile.Bench.TritonBenchG.ContextAttnFwd.Storage
abbrev Layout := VeriTile.Bench.TritonBenchG.ContextAttnFwd.Formula.Layout
abbrev Regions := VeriTile.Bench.TritonBenchG.ContextAttnFwd.Program.Regions

/-- Exact original floating source after bounded INT64 index transport.
All checked source addresses, masks and loaded metadata are bound separately.
No floating instruction, dot operand, finite sentinel or reduction is changed. -/
noncomputable def kernel (p : Layout) (r : Regions) (storage : Storage) (scale : ℝ) : ComputeKernel :=
  VeriTile.Bench.TritonBenchG.ContextAttnFwd.Program.kernel p r storage Bool.false scale

theorem actual_source (p : Layout) (r : Regions) (scale : ℝ) :
    kernel p r .fp32 scale =
      VeriTile.Bench.TritonBenchG.ContextAttnFwd.Program.kernel p r .fp32 Bool.false scale := rfl
end VeriTile.Bench.Repairs.ContextAttnFwd
