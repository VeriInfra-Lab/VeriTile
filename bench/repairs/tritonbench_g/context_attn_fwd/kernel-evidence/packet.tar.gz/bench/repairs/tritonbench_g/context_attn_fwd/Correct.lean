import bench.repairs.tritonbench_g.context_attn_fwd.Proofs.Entry
import bench.repairs.tritonbench_g.context_attn_fwd.KernelOnly

namespace VeriTile.Bench.Repairs.ContextAttnFwd.PublicKernel
alias correct_real := KernelOnly.mathematical_real
alias shared_source := KernelOnly.shared_source
#axiomsClean correct_real
#axiomsClean shared_source
end VeriTile.Bench.Repairs.ContextAttnFwd.PublicKernel
