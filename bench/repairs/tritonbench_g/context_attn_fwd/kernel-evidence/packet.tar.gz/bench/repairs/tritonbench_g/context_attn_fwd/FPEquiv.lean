import bench.repairs.tritonbench_g.context_attn_fwd.Proofs.Task
import bench.repairs.tritonbench_g.context_attn_fwd.KernelOnly

namespace VeriTile.Bench.Repairs.ContextAttnFwd.PublicKernel
alias correct_fp32 := KernelOnly.native_tensor
alias input_tensor := KernelOnly.input_tensor
#axiomsClean correct_fp32
#axiomsClean input_tensor
end VeriTile.Bench.Repairs.ContextAttnFwd.PublicKernel
