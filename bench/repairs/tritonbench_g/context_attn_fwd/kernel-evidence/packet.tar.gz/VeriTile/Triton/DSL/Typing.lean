/-
VeriTile.Triton.DSL.Typing

Macro-time dtype, shape, and environment helpers for Triton DSL expansion.
-/

import VeriTile.Triton.Core
import VeriTile.Triton.DSL.Syntax

open Lean

namespace VeriTile.Triton.DSL

inductive DInfo where
  | real
  | fp32
  | fp16
  | bf16
  | f8e4
  | f8e5
  | int
  /-- Known signed-byte storage width. Arithmetic uses the existing Int channel
  and deliberately drops this provenance before any later bitcast. -/
  | int8
  /-- Known native signed int32 storage, retained through reads and copies.
  Mathematical integer arithmetic drops this provenance. -/
  | int32
  | nat
  | bool
  | ptr
  | blockPtr
  | floatVar : String → DInfo
  deriving BEq, Inhabited

inductive SInfo where
  | dims : List (TSyntax `term) → SInfo
  deriving Inhabited

abbrev Env := List (String × DInfo × SInfo × Option DInfo)

def termKey (t : TSyntax `term) : String :=
  toString t.raw

namespace SInfo

def scalar : SInfo := .dims []

def vec (n : TSyntax `term) : SInfo := .dims [n]

end SInfo

def termListEq : List (TSyntax `term) → List (TSyntax `term) → Bool
  | [], [] => Bool.true
  | a :: as, b :: bs => (termKey a == termKey b) && termListEq as bs
  | _, _ => Bool.false

def SInfo.eq : SInfo → SInfo → Bool
  | SInfo.dims a, SInfo.dims b => termListEq a b

def eraseNth {α : Type} : List α → Nat → MacroM (List α)
  | [], _ => Macro.throwError "internal error: eraseNth index out of bounds"
  | _ :: xs, 0 => pure xs
  | x :: xs, n + 1 => return x :: (← eraseNth xs n)

def setNthOne : List (TSyntax `term) → Nat → MacroM (List (TSyntax `term))
  | [], _ => Macro.throwError "internal error: setNthOne index out of bounds"
  | _ :: xs, 0 => do
      let oneLit : TSyntax `term ← `((1 : Nat))
      pure (oneLit :: xs)
  | x :: xs, n + 1 => return x :: (← setNthOne xs n)

def DInfo.term : DInfo → MacroM (TSyntax `term)
  | .real => `(TileDType.real)
  | .fp32 => `(TileDType.fp32)
  | .fp16 => `(TileDType.fp16)
  | .bf16 => `(TileDType.bf16)
  | .f8e4 => `(TileDType.f8e4)
  | .f8e5 => `(TileDType.f8e5)
  | .int | .int8 | .int32 => `(TileDType.int)
  | .nat => `(TileDType.nat)
  | .bool => `(TileDType.bool)
  | .ptr => `(TileDType.ptr)
  | .blockPtr => `(TileDType.blockPtr)
  | .floatVar name => do
      let t : TSyntax `term := ⟨mkIdent (Name.mkSimple name)⟩
      `(($t).toTileDType)

def DInfo.floatProof : DInfo → MacroM (TSyntax `term)
  | .real => `(FloatDType.real)
  | .fp32 => `(FloatDType.fp32)
  | .fp16 => `(FloatDType.fp16)
  | .bf16 => `(FloatDType.bf16)
  | .f8e4 => `(FloatDType.f8e4)
  | .f8e5 => `(FloatDType.f8e5)
  | .int | .int8 | .int32 => Macro.throwError "tl.cast: signed integer casts are not modeled yet"
  | .nat => Macro.throwError "tl.cast: Nat casts are not modeled yet; use tl.toReal for Nat to real"
  | .bool => Macro.throwError "tl.cast: Bool casts are not supported"
  | .ptr => Macro.throwError "tl.cast: pointer casts are not supported"
  | .blockPtr => Macro.throwError "tl.cast: block pointer casts are not supported"
  | .floatVar name => pure ⟨mkIdent (Name.mkSimple name)⟩

def SInfo.term : SInfo → MacroM (TSyntax `term)
  | SInfo.dims ds => do
      let rec go : List (TSyntax `term) → MacroM (TSyntax `term)
        | [] => `(([] : TileShape))
        | d :: rest => do
            let tail ← go rest
            `($d :: $tail)
      go ds

def DInfo.numericProof : DInfo → MacroM (TSyntax `term)
  | .real => `(NumericDType.real)
  | .fp32 => `(NumericDType.fp32)
  | .fp16 => `(NumericDType.fp16)
  | .bf16 => `(NumericDType.bf16)
  | .f8e4 => `(NumericDType.f8e4)
  | .f8e5 => `(NumericDType.f8e5)
  | .int => `(NumericDType.int)
  | .int8 => Macro.throwError "arithmetic: int8 storage width must be erased before integer arithmetic"
  | .int32 => Macro.throwError "arithmetic: int32 storage width must be erased before integer arithmetic"
  | .nat => `(NumericDType.nat)
  | .bool => Macro.throwError "arithmetic on Bool values is not supported"
  | .ptr => Macro.throwError "arithmetic on pointer values is not supported; use pointer + Nat offset"
  | .blockPtr => Macro.throwError "arithmetic on block pointers is not supported; use tl.advance"
  | .floatVar name => do
      let t : TSyntax `term := ⟨mkIdent (Name.mkSimple name)⟩
      `(FloatDType.numericDType $t)

def DInfo.integralProof : DInfo → MacroM (TSyntax `term)
  | .int => `(IntegralDType.int)
  | .int8 => Macro.throwError "integer arithmetic: int8 storage width must be erased first"
  | .int32 => Macro.throwError "integer arithmetic: int32 storage width must be erased first"
  | .nat => `(IntegralDType.nat)
  | .real => Macro.throwError "integer division/remainder on Real values is not supported"
  | .fp32 => Macro.throwError "integer division/remainder on floating values is not supported"
  | .fp16 => Macro.throwError "integer division/remainder on floating values is not supported"
  | .bf16 => Macro.throwError "integer division/remainder on floating values is not supported"
  | .f8e4 => Macro.throwError "integer division/remainder on floating values is not supported"
  | .f8e5 => Macro.throwError "integer division/remainder on floating values is not supported"
  | .bool => Macro.throwError "integer division/remainder on Bool values is not supported"
  | .ptr => Macro.throwError "integer division/remainder on pointer values is not supported"
  | .blockPtr => Macro.throwError "integer division/remainder on block pointers is not supported"
  | .floatVar _ => Macro.throwError "integer division/remainder on floating values is not supported"

def DInfo.comparableProof : DInfo → MacroM (TSyntax `term)
  | .real => `(ComparableDType.real)
  | .fp32 => `(ComparableDType.fp32)
  | .fp16 => `(ComparableDType.fp16)
  | .bf16 => `(ComparableDType.bf16)
  | .f8e4 => `(ComparableDType.f8e4)
  | .f8e5 => `(ComparableDType.f8e5)
  | .int | .int8 | .int32 => `(ComparableDType.int)
  | .nat => `(ComparableDType.nat)
  | .bool => Macro.throwError "comparison on Bool values is not supported"
  | .ptr => Macro.throwError "comparison on pointer values is not supported"
  | .blockPtr => Macro.throwError "comparison on block pointers is not supported"
  | .floatVar name => do
      let t : TSyntax `term := ⟨mkIdent (Name.mkSimple name)⟩
      `(FloatDType.comparableDType $t)

def expandDType : TSyntax `tritonDType → MacroM DInfo
  | `(tritonDType| tl.float64) => pure .real
  | `(tritonDType| tl.float32) => pure .fp32
  | `(tritonDType| tl.float16) => pure .fp16
  | `(tritonDType| tl.bfloat16) => pure .bf16
  | `(tritonDType| tl.float8e4nv) => pure .f8e4
  | `(tritonDType| tl.float8e5) => pure .f8e5
  | `(tritonDType| tl.int1) => pure .bool
  | `(tritonDType| tl.int8) => pure .int
  | `(tritonDType| tl.int16) => pure .int
  | `(tritonDType| tl.int32) => pure .int
  | `(tritonDType| tl.int64) => pure .int
  | `(tritonDType| tl.uint8) => pure .nat
  | `(tritonDType| tl.uint16) => pure .nat
  | `(tritonDType| tl.uint32) => pure .nat
  | `(tritonDType| tl.uint64) => pure .nat
  | `(tritonDType| OUT_DTYPE) => pure (.floatVar "out_dtype")
  | `(tritonDType| DTYPE) => pure (.floatVar "dtype")
  | _ => Macro.throwUnsupported

def expandDTypeIdent (name : Name) : MacroM DInfo :=
  match name.toString with
  | "tl.float64" => pure .real
  | "tl.float32" => pure .fp32
  | "tl.float16" => pure .fp16
  | "tl.bfloat16" => pure .bf16
  | "tl.float8e4nv" => pure .f8e4
  | "tl.float8e5" => pure .f8e5
  | "tl.int1" => pure .bool
  | "tl.int8" => pure .int
  | "tl.int16" => pure .int
  | "tl.int32" => pure .int
  | "tl.int64" => pure .int
  | "tl.uint8" => pure .nat
  | "tl.uint16" => pure .nat
  | "tl.uint32" => pure .nat
  | "tl.uint64" => pure .nat
  | _ => Macro.throwUnsupported

def expandDTypeExpr : TSyntax `tritonExpr → MacroM DInfo
  | `(tritonExpr| $name:ident) => expandDTypeIdent name.getId
  | _ => Macro.throwUnsupported

/-- Numerical casts retain the existing mathematical integer model. Only a
storage declaration/load supplies native integer-width provenance. -/
def expandStorageDType (dt : TSyntax `tritonDType) : MacroM DInfo :=
  match dt with
  | `(tritonDType| tl.int8) => pure .int8
  | `(tritonDType| tl.int32) => pure .int32
  | _ => expandDType dt

def expandStorageDTypeExpr (dt : TSyntax `tritonExpr) : MacroM DInfo :=
  match dt with
  | `(tritonExpr| $name:ident) =>
      if name.getId.toString == "tl.int8" then pure .int8
      else if name.getId.toString == "tl.int32" then pure .int32
      else expandDTypeExpr dt
  | _ => expandDTypeExpr dt

def lookupEnv (env : Env) (name : String) : MacroM (DInfo × SInfo) := do
  match env.find? (fun entry => entry.1 == name) with
  | some (_, dtype, shape, _) => pure (dtype, shape)
  | none => Macro.throwError ("unknown Triton identifier `" ++ name ++ "`")

def lookupComputeDType? (env : Env) (name : String) : Option DInfo :=
  match env.find? (fun entry => entry.1 == name) with
  | some (_, _, _, computeDType?) => computeDType?
  | none => none

def ensureDType (expected actual : DInfo) (ctx : String) : MacroM Unit := do
  unless expected == actual do
    Macro.throwError (ctx ++ ": dtype mismatch")

def ensureShape (expected actual : SInfo) (ctx : String) : MacroM Unit := do
  unless expected.eq actual do
    Macro.throwError (ctx ++ ": shape mismatch")

/-- Recognize a dim term as the literal `1`, tolerating common syntactic
wrappings (`1`, `(1)`, `(1 : Nat)`, `((1 : Nat))`, ...) so that unit-dim
broadcasts fire regardless of how the dim was emitted. -/
partial def termIsOne (t : TSyntax `term) : Bool :=
  match t with
  | `($n:num) => n.getNat == 1
  | `(($e:term)) => termIsOne e
  | `(($e:term : $_:term)) => termIsOne e
  | _ => Bool.false

def broadcastTerm (a b : SInfo) (ctx : String) :
    MacroM (TSyntax `term × SInfo) := do
  match a, b with
  | SInfo.dims [], SInfo.dims [] => pure (← `(Broadcast.nil), SInfo.dims [])
  | SInfo.dims [], SInfo.dims (_ :: _) => pure (← `(Broadcast.scalarL), b)
  | SInfo.dims (_ :: _), SInfo.dims [] => pure (← `(Broadcast.scalarR), a)
  | SInfo.dims (ad :: ads), SInfo.dims (bd :: bds) =>
      if (ad :: ads).length < (bd :: bds).length then
        let (subBc, subShape) ← broadcastTerm (SInfo.dims (ad :: ads)) (SInfo.dims bds) ctx
        match subShape with
        | SInfo.dims outRest => pure (← `(Broadcast.leadL $subBc), SInfo.dims (bd :: outRest))
      else if (ad :: ads).length > (bd :: bds).length then
        let (subBc, subShape) ← broadcastTerm (SInfo.dims ads) (SInfo.dims (bd :: bds)) ctx
        match subShape with
        | SInfo.dims outRest => pure (← `(Broadcast.leadR $subBc), SInfo.dims (ad :: outRest))
      else
      let (subBc, subShape) ← broadcastTerm (SInfo.dims ads) (SInfo.dims bds) ctx
      if termKey ad == termKey bd then
        match subShape with
        | SInfo.dims outRest => pure (← `(Broadcast.consSame $subBc), SInfo.dims (ad :: outRest))
      else if termIsOne ad then
        match subShape with
        | SInfo.dims outRest => pure (← `(Broadcast.consL $subBc), SInfo.dims (bd :: outRest))
      else if termIsOne bd then
        match subShape with
        | SInfo.dims outRest => pure (← `(Broadcast.consR $subBc), SInfo.dims (ad :: outRest))
      else
        Macro.throwError (ctx ++ ": incompatible shapes")

def coerceShape (e : TSyntax `term) (src target : SInfo) (ctx : String) :
    MacroM (TSyntax `term) := do
  if src.eq target then
    pure e
  else
    let (bc, outShape) ← broadcastTerm src target ctx
    ensureShape target outShape ctx
    match src with
    | SInfo.dims [] =>
        let st ← target.term
        `(Op.broadcast $e $st)
    | _ =>
        let st ← target.term
        `(Op.remap $st (Broadcast.leftIndex $bc) $e)

end VeriTile.Triton.DSL
