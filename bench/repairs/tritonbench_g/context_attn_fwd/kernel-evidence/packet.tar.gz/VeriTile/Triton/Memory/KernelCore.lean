/-
VeriTile.Triton.Memory.KernelCore

The **unified KernelIO core**: one vectorized, channel-typed IO signature
(`UKernelIO`) whose single assembly lemma (`UKernelIO.ImplementsAt.intro`)
carries the flat-memory bridge for the *entire* concrete KernelIO family.

The concrete structs in `Memory/KernelSpec.lean` (`KernelIO₂`, the
`Masked*`/`Masked2D*` variants, …) remain the public, named-field statement
surface — their `Implements` definitions are untouched. What changes is the
*proof architecture*: each concrete `Implements.intro` is a corollary of the
core's, obtained by embedding the struct into `UKernelIO` (a `toU` value)
and converting the core triple back into the struct's vocabulary. The
flattening bridge (`exec_flatten` + `flattenState_readMem` + `decode_sound`)
is therefore proved **once**, here.

Design:

* **Channels.** Every input is a typed channel (`ChanTy`: float / bool /
  nat / int). Float channels pin values through the family's existing
  `readMem` convention; typed channels through the operational
  `readMemValue` view that `tl.load` itself uses.
* **Arities.** Each channel has its own lane count (`iarity`/`oarity`/
  `sarity`). A scalar metadata slot is a 1-lane channel; the concrete
  family's uniform-`B` tiles set every arity to `B`.
* **Value-dependent windows.** Every window/mask takes the full context
  `vals` of pinned input values, so a data window may depend on a loaded
  scalar — the data-dependent genre (LightLLM `start_loc`/`seq_len`
  metadata, cross_entropy labels, gather/scatter indices).
* **Simultaneous pinning.** `Implements` quantifies one `vals : io.Ctx` and
  pins all channels at once. Instances keep this non-vacuous by using
  *causal* windows (each channel's window depends only on earlier
  channels' values), so every launch state determines a unique context —
  the concrete skins' shapes (static data windows + scalar slots with
  pid-affine cells) are causal by construction.
* **Allocation list.** `bufs` (the region list handed to the allocator) is
  decoupled from the channel roles, so in-place kernels (`out = in2`) keep
  the `MaskedKernelIO₃ₓ₂` duplicate-region wiring.
* **Scratch.** Private working buffers are value-contract-free output-like
  channels: allocated, writable, excluded from the frame, absent from the
  postcondition.
-/
import VeriTile.Triton.Memory.Denotation

namespace VeriTile.Triton

/-! ## Channel types -/

/-- Element type of a `UKernelIO` input channel. -/
inductive ChanTy where
  | float
  | bool
  | nat
  | int
  deriving DecidableEq, Repr

namespace ChanTy

/-- Mathematical carrier of each channel type. -/
abbrev carrier : ChanTy → Type
  | .float => ℝ
  | .bool  => Bool
  | .nat   => Nat
  | .int   => Int

/-- Channel read: what a launch state holds at a region/address on this
channel. Float channels use the finite-fallback `readMem` (the family's
existing ℝ input convention); typed channels use the operational
`readMemValue` view that `tl.load` itself uses. -/
def read : (t : ChanTy) → BlockState → RegionName → Nat → t.carrier
  | .float => fun s r a => s.readMem r a
  | .bool  => fun s r a => s.readMemValue .bool r a
  | .nat   => fun s r a => s.readMemValue .nat r a
  | .int   => fun s r a => s.readMemValue .int r a

/-- Channel reads commute with the flattening at in-bounds addresses, on
every channel type. This is the read-back step of the bridge, generalized
from the float-only `flattenState_readMem` to the whole `ChanTy` family; it
is what lets an *output* channel be typed. -/
theorem read_flattenState (t : ChanTy) (A : FlatAlloc) (hd : A.Disjoint)
    (s : BlockState) {r : RegionName} (hr : r ∈ A.regions) {o : Nat}
    (ho : o < A.extent r) :
    t.read (A.flattenState s) A.flat (A.addr r o) = t.read s r o := by
  cases t with
  | float => exact A.flattenState_readMem hd s hr ho
  | bool => exact A.flattenState_readMemValue hd s hr ho .bool ⟨by decide, by decide⟩
  | nat => exact A.flattenState_readMemValue hd s hr ho .nat ⟨by decide, by decide⟩
  | int => exact A.flattenState_readMemValue hd s hr ho .int ⟨by decide, by decide⟩

end ChanTy

/-! ## The core signature -/

/-- The unified, vectorized KernelIO signature. Arities and channel types
are *fields* (never part of a name); every window and mask takes the full
pinned-input context, so windows may depend on loaded values. This struct
is proof infrastructure — headline statements live on the concrete
named-field family in `Memory/KernelSpec.lean`. -/
structure UKernelIO where
  /-- The kernel being specified. -/
  kernel : ComputeKernel
  /-- The contract executes only a successfully projected kernel. The default
  discharges transparent supported kernels; abstract kernels need a witness. -/
  projection : kernel.toAlgorithm? = Except.ok kernel.toAlgKernel := by
    first | rfl | simp [ComputeKernel.toAlgKernel]
  /-- Number of input channels. -/
  nIn : Nat
  /-- Number of output channels. -/
  nOut : Nat
  /-- Number of scratch (private working) channels. -/
  nScr : Nat
  /-- The allocation list: exactly the regions handed to the allocator
  (`A.regions`). Decoupled from the channel roles so duplicate-region
  (in-place) wiring is expressible. -/
  bufs : List RegionName
  /-- Each input channel's element type. -/
  ity : Fin nIn → ChanTy
  /-- Each input channel's lane count (scalar slots are 1-lane). -/
  iarity : Fin nIn → Nat
  /-- Each input channel's buffer. -/
  ibuf : Fin nIn → RegionName
  /-- Each output channel's element type. Symmetric to `ity`: the
  postcondition reads output channel `o` back through `(oty o).read`, so a
  kernel whose store is `.to(tl.int8)`-style typed can state a *true* value
  contract. `.float` reads are definitionally `readMem`, so every skin that
  sets `oty := fun _ => .float` keeps its `Implements` statement unchanged. -/
  oty : Fin nOut → ChanTy
  /-- Each output channel's lane count. -/
  oarity : Fin nOut → Nat
  /-- Each output channel's buffer. -/
  obuf : Fin nOut → RegionName
  /-- Output buffers are allocated (needed to read the postcondition back
  through the flattening). -/
  obuf_mem : ∀ o, obuf o ∈ bufs
  /-- Each scratch channel's lane count. -/
  sarity : Fin nScr → Nat
  /-- Each scratch channel's buffer. -/
  sbuf : Fin nScr → RegionName
  /-- Input channel `i`'s per-lane read address — may depend on the pinned
  values of every channel (the data-dependent genre). -/
  iwin : (i : Fin nIn) → (∀ k, Fin (iarity k) → (ity k).carrier) →
    Nat → Nat → Nat → Fin (iarity i) → Nat
  /-- Input channel `i`'s read-active lanes. -/
  imask : (i : Fin nIn) → (∀ k, Fin (iarity k) → (ity k).carrier) →
    Nat → Nat → Nat → Fin (iarity i) → Prop
  /-- Output channel `o`'s per-lane write address. -/
  owin : (o : Fin nOut) → (∀ k, Fin (iarity k) → (ity k).carrier) →
    Nat → Nat → Nat → Fin (oarity o) → Nat
  /-- Output channel `o`'s write-active lanes. -/
  omask : (o : Fin nOut) → (∀ k, Fin (iarity k) → (ity k).carrier) →
    Nat → Nat → Nat → Fin (oarity o) → Prop
  /-- Scratch channel `t`'s per-lane write address. -/
  swin : (t : Fin nScr) → (∀ k, Fin (iarity k) → (ity k).carrier) →
    Nat → Nat → Nat → Fin (sarity t) → Nat
  /-- Scratch channel `t`'s write-active lanes. -/
  smask : (t : Fin nScr) → (∀ k, Fin (iarity k) → (ity k).carrier) →
    Nat → Nat → Nat → Fin (sarity t) → Prop

namespace UKernelIO

/-- The pinned-input context: one carrier value per channel per lane. -/
abbrev Ctx (io : UKernelIO) : Type :=
  ∀ k : Fin io.nIn, Fin (io.iarity k) → (io.ity k).carrier

/-- Pointwise flat-memory contract. A caller may first constrain the initial
state's grid dimensions and program IDs. It retains successful execution,
typed output observations and the complete output/scratch memory frame. -/
def ImplementsAt (io : UKernelIO) (s₀ : BlockState) (vals : io.Ctx)
    (f : (o : Fin io.nOut) → Fin (io.oarity o) →
      (io.oty o).carrier) :
    Prop :=
  ∀ A : FlatAlloc,
    A.Disjoint →
    A.regions = io.bufs →
    (∀ r, r ∉ A.regions → A.extent r = 0) →
    s₀.undef = (fun _ _ => 0) →
    (∀ (i : Fin io.nIn) (j : Fin (io.iarity i)), io.imask i vals (s₀.pids 0) (s₀.pids 1) (s₀.pids 2) j →
      io.iwin i vals (s₀.pids 0) (s₀.pids 1) (s₀.pids 2) j < A.extent (io.ibuf i)) →
    (∀ (o : Fin io.nOut) (j : Fin (io.oarity o)), io.omask o vals (s₀.pids 0) (s₀.pids 1) (s₀.pids 2) j →
      io.owin o vals (s₀.pids 0) (s₀.pids 1) (s₀.pids 2) j < A.extent (io.obuf o)) →
    (∀ (t : Fin io.nScr) (j : Fin (io.sarity t)), io.smask t vals (s₀.pids 0) (s₀.pids 1) (s₀.pids 2) j →
      io.swin t vals (s₀.pids 0) (s₀.pids 1) (s₀.pids 2) j < A.extent (io.sbuf t)) →
    (∀ (i : Fin io.nIn) (j : Fin (io.iarity i)), io.imask i vals (s₀.pids 0) (s₀.pids 1) (s₀.pids 2) j →
      (io.ity i).read s₀ (io.ibuf i) (io.iwin i vals (s₀.pids 0) (s₀.pids 1) (s₀.pids 2) j) = vals i j) →
    ∃ s',
      exec (A.flattenKernel io.kernel.toAlgKernel) (A.flattenState s₀)
        = some s'
      ∧ (∀ (o : Fin io.nOut) (j : Fin (io.oarity o)),
          io.omask o vals (s₀.pids 0) (s₀.pids 1) (s₀.pids 2) j →
          (io.oty o).read s' A.flat
              (A.addr (io.obuf o) (io.owin o vals (s₀.pids 0) (s₀.pids 1) (s₀.pids 2) j))
            = f o j)
      ∧ (∀ r' o',
          (r' ≠ A.flat ∨
            ((∀ (o : Fin io.nOut) (j : Fin (io.oarity o)),
                io.omask o vals (s₀.pids 0) (s₀.pids 1) (s₀.pids 2) j →
                o' ≠ A.addr (io.obuf o) (io.owin o vals (s₀.pids 0) (s₀.pids 1) (s₀.pids 2) j)) ∧
             (∀ (t : Fin io.nScr) (j : Fin (io.sarity t)),
                io.smask t vals (s₀.pids 0) (s₀.pids 1) (s₀.pids 2) j →
                o' ≠ A.addr (io.sbuf t) (io.swin t vals (s₀.pids 0) (s₀.pids 1) (s₀.pids 2) j)))) →
          s'.mem r' o' = (A.flattenState s₀).mem r' o')

/-- `io.Implements3D f` — the channel-typed masked Hoare triple. For any
context `vals` the launch state holds on every input channel (channel-typed,
at the `vals`-dependent windows), the translated kernel terminates, every
write-active lane of every output channel holds `f pid₀ pid₁ pid₂ vals o j`, and every
flat cell outside the declared output/scratch windows is unchanged. -/
def Implements3D (io : UKernelIO)
    (f : Nat → Nat → Nat → io.Ctx → (o : Fin io.nOut) → Fin (io.oarity o) →
      (io.oty o).carrier) :
    Prop :=
  ∀ A : FlatAlloc,
    A.Disjoint →
    A.regions = io.bufs →
    (∀ r, r ∉ A.regions → A.extent r = 0) →
  ∀ pid₀ pid₁ pid₂ : Nat,
  ∀ (vals : io.Ctx) (s₀ : BlockState),
    s₀.pids 0 = pid₀ →
    s₀.pids 1 = pid₁ →
    s₀.pids 2 = pid₂ →
    s₀.undef = (fun _ _ => 0) →
    (∀ (i : Fin io.nIn) (j : Fin (io.iarity i)), io.imask i vals pid₀ pid₁ pid₂ j →
      io.iwin i vals pid₀ pid₁ pid₂ j < A.extent (io.ibuf i)) →
    (∀ (o : Fin io.nOut) (j : Fin (io.oarity o)), io.omask o vals pid₀ pid₁ pid₂ j →
      io.owin o vals pid₀ pid₁ pid₂ j < A.extent (io.obuf o)) →
    (∀ (t : Fin io.nScr) (j : Fin (io.sarity t)), io.smask t vals pid₀ pid₁ pid₂ j →
      io.swin t vals pid₀ pid₁ pid₂ j < A.extent (io.sbuf t)) →
    (∀ (i : Fin io.nIn) (j : Fin (io.iarity i)), io.imask i vals pid₀ pid₁ pid₂ j →
      (io.ity i).read s₀ (io.ibuf i) (io.iwin i vals pid₀ pid₁ pid₂ j) = vals i j) →
    ∃ s',
      exec (A.flattenKernel io.kernel.toAlgKernel) (A.flattenState s₀)
        = some s'
      ∧ (∀ (o : Fin io.nOut) (j : Fin (io.oarity o)),
          io.omask o vals pid₀ pid₁ pid₂ j →
          (io.oty o).read s' A.flat
              (A.addr (io.obuf o) (io.owin o vals pid₀ pid₁ pid₂ j))
            = f pid₀ pid₁ pid₂ vals o j)
      ∧ (∀ r' o',
          (r' ≠ A.flat ∨
            ((∀ (o : Fin io.nOut) (j : Fin (io.oarity o)),
                io.omask o vals pid₀ pid₁ pid₂ j →
                o' ≠ A.addr (io.obuf o) (io.owin o vals pid₀ pid₁ pid₂ j)) ∧
             (∀ (t : Fin io.nScr) (j : Fin (io.sarity t)),
                io.smask t vals pid₀ pid₁ pid₂ j →
                o' ≠ A.addr (io.sbuf t) (io.swin t vals pid₀ pid₁ pid₂ j)))) →
          s'.mem r' o' = (A.flattenState s₀).mem r' o')

/-- The existing three-coordinate contract is exactly the family of pointwise
contracts. Fixing a state changes the binder order, not its memory guarantees. -/
theorem implements3D_iff_at (io : UKernelIO)
    (f : Nat → Nat → Nat → io.Ctx → (o : Fin io.nOut) → Fin (io.oarity o) → (io.oty o).carrier) :
    io.Implements3D f ↔ ∀ (s : BlockState) (vals : io.Ctx),
      io.ImplementsAt s vals (f (s.pids 0) (s.pids 1) (s.pids 2) vals) := by
  constructor
  · intro h s vals A hd hr hc
    exact h A hd hr hc (s.pids 0) (s.pids 1) (s.pids 2) vals s rfl rfl rfl
  · intro h A hd hr hc p₀ p₁ p₂ vals s h₀ h₁ h₂
    subst h₀
    subst h₁
    subst h₂
    exact h s vals A hd hr hc

/-- Backward-compatible formula interface for kernels whose formula is
independent of the third grid coordinate. All three coordinates still index
input/output windows and are universally quantified. -/
def Implements (io : UKernelIO)
    (f : Nat → Nat → io.Ctx → (o : Fin io.nOut) → Fin (io.oarity o) → (io.oty o).carrier) : Prop :=
  io.Implements3D (fun p₀ p₁ _ => f p₀ p₁)

@[inherit_doc] scoped infix:25 " ⊨ᵤ " => UKernelIO.Implements

/-- Shared flattening assembly at a fixed initial state. The existing undef
pin is available to both safety and execution proofs. -/
theorem ImplementsAt.intro (io : UKernelIO) (s₀ : BlockState) (vals : io.Ctx)
    {f : (o : Fin io.nOut) → Fin (io.oarity o) →
      (io.oty o).carrier}
    (hok : (io.kernel.toAlgKernel).FlattenOk)
    (hts : ∀ (bounds : RegionBounds),
      s₀.undef = (fun _ _ => 0) →
      (∀ (i : Fin io.nIn) (j : Fin (io.iarity i)),
        io.imask i vals (s₀.pids 0) (s₀.pids 1) (s₀.pids 2) j →
        (io.ity i).read s₀ (io.ibuf i) (io.iwin i vals (s₀.pids 0) (s₀.pids 1) (s₀.pids 2) j)
          = vals i j) →
      (∀ (i : Fin io.nIn) (j : Fin (io.iarity i)),
        io.imask i vals (s₀.pids 0) (s₀.pids 1) (s₀.pids 2) j →
        io.iwin i vals (s₀.pids 0) (s₀.pids 1) (s₀.pids 2) j < bounds (io.ibuf i)) →
      (∀ (o : Fin io.nOut) (j : Fin (io.oarity o)),
        io.omask o vals (s₀.pids 0) (s₀.pids 1) (s₀.pids 2) j →
        io.owin o vals (s₀.pids 0) (s₀.pids 1) (s₀.pids 2) j < bounds (io.obuf o)) →
      (∀ (t : Fin io.nScr) (j : Fin (io.sarity t)),
        io.smask t vals (s₀.pids 0) (s₀.pids 1) (s₀.pids 2) j →
        io.swin t vals (s₀.pids 0) (s₀.pids 1) (s₀.pids 2) j < bounds (io.sbuf t)) →
      Kernel.TraceSafe bounds (io.kernel.toAlgKernel) s₀)
    (hrun :
      s₀.undef = (fun _ _ => 0) →
      (∀ (i : Fin io.nIn) (j : Fin (io.iarity i)),
        io.imask i vals (s₀.pids 0) (s₀.pids 1) (s₀.pids 2) j →
        (io.ity i).read s₀ (io.ibuf i) (io.iwin i vals (s₀.pids 0) (s₀.pids 1) (s₀.pids 2) j)
          = vals i j) →
      ∃ s1, exec (io.kernel.toAlgKernel) s₀ = some s1
        ∧ (∀ (o : Fin io.nOut) (j : Fin (io.oarity o)),
            io.omask o vals (s₀.pids 0) (s₀.pids 1) (s₀.pids 2) j →
            (io.oty o).read s1 (io.obuf o)
                (io.owin o vals (s₀.pids 0) (s₀.pids 1) (s₀.pids 2) j)
              = f o j)
        ∧ (∀ r o',
            (∀ (oc : Fin io.nOut) (j : Fin (io.oarity oc)),
              io.omask oc vals (s₀.pids 0) (s₀.pids 1) (s₀.pids 2) j →
              r ≠ io.obuf oc ∨ o' ≠ io.owin oc vals (s₀.pids 0) (s₀.pids 1) (s₀.pids 2) j) →
            (∀ (t : Fin io.nScr) (j : Fin (io.sarity t)),
              io.smask t vals (s₀.pids 0) (s₀.pids 1) (s₀.pids 2) j →
              r ≠ io.sbuf t ∨ o' ≠ io.swin t vals (s₀.pids 0) (s₀.pids 1) (s₀.pids 2) j) →
            s1.mem r o' = s₀.mem r o')) :
    io.ImplementsAt s₀ vals f := by
  intro A hd hregs hcov hu hib hob hsb hpins
  obtain ⟨s1, hexec, hval, hframe⟩ := hrun hu hpins
  have hts' : Kernel.TraceSafe A.extent (io.kernel.toAlgKernel) s₀ :=
    hts A.extent hu hpins hib hob hsb
  have hbridge := A.exec_flatten hd hcov _ s₀ hts' hok hu
  refine ⟨A.flattenState s1, ?_, ?_, ?_⟩
  · rw [hbridge, hexec, Option.map_some]
  · intro o j hj
    have hmem : io.obuf o ∈ A.regions := by
      rw [hregs]; exact io.obuf_mem o
    have hlt : io.owin o vals (s₀.pids 0) (s₀.pids 1) (s₀.pids 2) j
        < A.extent (io.obuf o) := hob o j hj
    rw [(io.oty o).read_flattenState A hd s1 hmem hlt]
    exact hval o j hj
  · intro r' o' hcond
    by_cases hr : r' = A.flat
    · subst hr
      show (A.flattenState s1).mem A.flat o'
          = (A.flattenState s₀).mem A.flat o'
      simp only [FlatAlloc.flattenState]
      unfold FlatAlloc.readFlat
      cases hdec : A.decode o' with
      | none => rfl
      | some p =>
          obtain ⟨r, o⟩ := p
          obtain ⟨hrmem, hoeq, holt⟩ := A.decode_sound hdec
          show A.trCell (s1.mem r o) = A.trCell (s₀.mem r o)
          refine congrArg A.trCell
            (hframe r o (fun oc j hj => ?_) (fun t j hj => ?_))
          · by_cases hro : r = io.obuf oc
            · subst hro
              refine Or.inr fun hoj => ?_
              rcases hcond with hflat | hn
              · exact hflat rfl
              · exact hn.1 oc j hj (by rw [hoeq, hoj])
            · exact Or.inl hro
          · by_cases hrs : r = io.sbuf t
            · subst hrs
              refine Or.inr fun hoj => ?_
              rcases hcond with hflat | hn
              · exact hflat rfl
              · exact hn.2 t j hj (by rw [hoeq, hoj])
            · exact Or.inl hrs
    · simp only [FlatAlloc.flattenState, if_neg hr]

/-- Three-coordinate assembly reuses the pointwise flattening bridge.
The obligations are the family's usual three, with the channel-typed pin
hypothesis threaded through both `hts` and `hrun` (value-dependent windows
need the pinned values to state their bounds).

`hrun` additionally receives the **`undef` pin** `s₀.undef = fun _ _ => 0`
that `Implements` hypothesises. Without it, a kernel whose masked loads lack
an `other=` default reads `s₀.undef` at masked-off lanes; if the kernel then
reduces across the tile, the value stored at an *active* lane depends on
`undef` at *inactive* lanes and no `⊨`-shaped contract is provable. Since
this is a hypothesis the consumer *discharges*, handing it over strictly
weakens the obligation — skins that do not need it simply ignore the binder. -/
theorem Implements3D.intro (io : UKernelIO)
    {f : Nat → Nat → Nat → io.Ctx → (o : Fin io.nOut) → Fin (io.oarity o) →
      (io.oty o).carrier}
    (hok : (io.kernel.toAlgKernel).FlattenOk)
    (hts : ∀ (bounds : RegionBounds) (s : BlockState) (vals : io.Ctx),
      (∀ (i : Fin io.nIn) (j : Fin (io.iarity i)),
        io.imask i vals (s.pids 0) (s.pids 1) (s.pids 2) j →
        (io.ity i).read s (io.ibuf i) (io.iwin i vals (s.pids 0) (s.pids 1) (s.pids 2) j)
          = vals i j) →
      (∀ (i : Fin io.nIn) (j : Fin (io.iarity i)),
        io.imask i vals (s.pids 0) (s.pids 1) (s.pids 2) j →
        io.iwin i vals (s.pids 0) (s.pids 1) (s.pids 2) j < bounds (io.ibuf i)) →
      (∀ (o : Fin io.nOut) (j : Fin (io.oarity o)),
        io.omask o vals (s.pids 0) (s.pids 1) (s.pids 2) j →
        io.owin o vals (s.pids 0) (s.pids 1) (s.pids 2) j < bounds (io.obuf o)) →
      (∀ (t : Fin io.nScr) (j : Fin (io.sarity t)),
        io.smask t vals (s.pids 0) (s.pids 1) (s.pids 2) j →
        io.swin t vals (s.pids 0) (s.pids 1) (s.pids 2) j < bounds (io.sbuf t)) →
      Kernel.TraceSafe bounds (io.kernel.toAlgKernel) s)
    (hrun : ∀ (s₀ : BlockState) (vals : io.Ctx),
      s₀.undef = (fun _ _ => 0) →
      (∀ (i : Fin io.nIn) (j : Fin (io.iarity i)),
        io.imask i vals (s₀.pids 0) (s₀.pids 1) (s₀.pids 2) j →
        (io.ity i).read s₀ (io.ibuf i) (io.iwin i vals (s₀.pids 0) (s₀.pids 1) (s₀.pids 2) j)
          = vals i j) →
      ∃ s1, exec (io.kernel.toAlgKernel) s₀ = some s1
        ∧ (∀ (o : Fin io.nOut) (j : Fin (io.oarity o)),
            io.omask o vals (s₀.pids 0) (s₀.pids 1) (s₀.pids 2) j →
            (io.oty o).read s1 (io.obuf o)
                (io.owin o vals (s₀.pids 0) (s₀.pids 1) (s₀.pids 2) j)
              = f (s₀.pids 0) (s₀.pids 1) (s₀.pids 2) vals o j)
        ∧ (∀ r o',
            (∀ (oc : Fin io.nOut) (j : Fin (io.oarity oc)),
              io.omask oc vals (s₀.pids 0) (s₀.pids 1) (s₀.pids 2) j →
              r ≠ io.obuf oc ∨ o' ≠ io.owin oc vals (s₀.pids 0) (s₀.pids 1) (s₀.pids 2) j) →
            (∀ (t : Fin io.nScr) (j : Fin (io.sarity t)),
              io.smask t vals (s₀.pids 0) (s₀.pids 1) (s₀.pids 2) j →
              r ≠ io.sbuf t ∨ o' ≠ io.swin t vals (s₀.pids 0) (s₀.pids 1) (s₀.pids 2) j) →
            s1.mem r o' = s₀.mem r o')) :
    io.Implements3D f := by
  intro A hd hregs hcov pid₀ pid₁ pid₂ vals s₀ hpid₀ hpid₁ hpid₂ hu hib hob hsb hpins
  subst hpid₀
  subst hpid₁
  subst hpid₂
  exact ImplementsAt.intro io s₀ vals hok
    (fun bounds _ => hts bounds s₀ vals) (hrun s₀ vals)
    A hd hregs hcov hu hib hob hsb hpins

/-- The existing two-coordinate formula interface reuses the same bridge. -/
theorem Implements.intro (io : UKernelIO)
    {f : Nat → Nat → io.Ctx → (o : Fin io.nOut) → Fin (io.oarity o) →
      (io.oty o).carrier}
    (hok : (io.kernel.toAlgKernel).FlattenOk)
    (hts : ∀ (bounds : RegionBounds) (s : BlockState) (vals : io.Ctx),
      (∀ (i : Fin io.nIn) (j : Fin (io.iarity i)),
        io.imask i vals (s.pids 0) (s.pids 1) (s.pids 2) j →
        (io.ity i).read s (io.ibuf i) (io.iwin i vals (s.pids 0) (s.pids 1) (s.pids 2) j)
          = vals i j) →
      (∀ (i : Fin io.nIn) (j : Fin (io.iarity i)),
        io.imask i vals (s.pids 0) (s.pids 1) (s.pids 2) j →
        io.iwin i vals (s.pids 0) (s.pids 1) (s.pids 2) j < bounds (io.ibuf i)) →
      (∀ (o : Fin io.nOut) (j : Fin (io.oarity o)),
        io.omask o vals (s.pids 0) (s.pids 1) (s.pids 2) j →
        io.owin o vals (s.pids 0) (s.pids 1) (s.pids 2) j < bounds (io.obuf o)) →
      (∀ (t : Fin io.nScr) (j : Fin (io.sarity t)),
        io.smask t vals (s.pids 0) (s.pids 1) (s.pids 2) j →
        io.swin t vals (s.pids 0) (s.pids 1) (s.pids 2) j < bounds (io.sbuf t)) →
      Kernel.TraceSafe bounds (io.kernel.toAlgKernel) s)
    (hrun : ∀ (s₀ : BlockState) (vals : io.Ctx),
      s₀.undef = (fun _ _ => 0) →
      (∀ (i : Fin io.nIn) (j : Fin (io.iarity i)),
        io.imask i vals (s₀.pids 0) (s₀.pids 1) (s₀.pids 2) j →
        (io.ity i).read s₀ (io.ibuf i) (io.iwin i vals (s₀.pids 0) (s₀.pids 1) (s₀.pids 2) j)
          = vals i j) →
      ∃ s1, exec (io.kernel.toAlgKernel) s₀ = some s1
        ∧ (∀ (o : Fin io.nOut) (j : Fin (io.oarity o)),
            io.omask o vals (s₀.pids 0) (s₀.pids 1) (s₀.pids 2) j →
            (io.oty o).read s1 (io.obuf o)
                (io.owin o vals (s₀.pids 0) (s₀.pids 1) (s₀.pids 2) j)
              = f (s₀.pids 0) (s₀.pids 1) vals o j)
        ∧ (∀ r o',
            (∀ (oc : Fin io.nOut) (j : Fin (io.oarity oc)),
              io.omask oc vals (s₀.pids 0) (s₀.pids 1) (s₀.pids 2) j →
              r ≠ io.obuf oc ∨ o' ≠ io.owin oc vals (s₀.pids 0) (s₀.pids 1) (s₀.pids 2) j) →
            (∀ (t : Fin io.nScr) (j : Fin (io.sarity t)),
              io.smask t vals (s₀.pids 0) (s₀.pids 1) (s₀.pids 2) j →
              r ≠ io.sbuf t ∨ o' ≠ io.swin t vals (s₀.pids 0) (s₀.pids 1) (s₀.pids 2) j) →
            s1.mem r o' = s₀.mem r o')) :
    io.Implements f := by
  exact Implements3D.intro io hok hts hrun

end UKernelIO

end VeriTile.Triton
