/-
VeriTile.Triton.DSL.Expansion.Memory

Memory-surface expansion helpers.
-/

import VeriTile.Triton.DSL.Expansion.Common
import VeriTile.Triton.Core.SignedCast

open Lean

namespace VeriTile.Triton.DSL

private def numArrayAsNatListTerm (axes : TSyntaxArray `num) :
    MacroM (TSyntax `term) := do
  let axisTerms : Array (TSyntax `term) :=
    axes.map fun n => (⟨n.raw⟩ : TSyntax `term)
  let rec go : List (TSyntax `term) → MacroM (TSyntax `term)
    | [] => `(([] : List Nat))
    | d :: rest => do
        let tail ← go rest
        `(($d : Nat) :: $tail)
  go axisTerms.toList

private def expandLoadOtherAs? (dtype : DInfo) (e : TSyntax `tritonExpr) :
    MacroM (Option EOut) := do
  match dtype with
  | .nat =>
      match e with
      | `(tritonExpr| $n:num) =>
          pure (some ⟨← `(Op.constNat $n), .nat, SInfo.scalar, none, none⟩)
      | `(tritonExpr| 0.0) =>
          pure (some ⟨← `(Op.constNat 0), .nat, SInfo.scalar, none, none⟩)
      | _ => pure none
  | .int | .int8 | .int32 =>
      match e with
      | `(tritonExpr| $n:num) =>
          if dtype == .int8 && n.getNat ≥ 128 then
            Macro.throwError "tl.load: int8 other must fit the signed byte range"
          if dtype == .int32 && n.getNat ≥ 2147483648 then
            Macro.throwError "tl.load: int32 other must fit the signed int32 range"
          let t : TSyntax `term := ⟨Syntax.mkNumLit (toString n.getNat)⟩
          pure (some ⟨← `(Op.constInt ($t : Int)), dtype, SInfo.scalar, none, none⟩)
      | `(tritonExpr| -$n:num) =>
          if dtype == .int8 && n.getNat > 128 then
            Macro.throwError "tl.load: int8 other must fit the signed byte range"
          if dtype == .int32 && n.getNat > 2147483648 then
            Macro.throwError "tl.load: int32 other must fit the signed int32 range"
          let t : TSyntax `term := ⟨Syntax.mkNumLit (toString n.getNat)⟩
          pure (some ⟨← `(Op.constInt (-($t : Int))), dtype, SInfo.scalar, none, none⟩)
      | `(tritonExpr| 0.0) =>
          pure (some ⟨← `(Op.constInt 0), dtype, SInfo.scalar, none, none⟩)
      | `(tritonExpr| $($t:term)) =>
          -- A dynamic integer is not certified to fit the pointer element
          -- type. Keep its wide carrier until the implicit load conversion.
          pure (some ⟨← `(Op.constInt $t), .int, SInfo.scalar, none, none⟩)
      | _ => pure none
  | .bool =>
      match e with
      | `(tritonExpr| 0) =>
          pure (some ⟨← `(Op.constBool Bool.false), .bool, SInfo.scalar, none, none⟩)
      | `(tritonExpr| 1) =>
          pure (some ⟨← `(Op.constBool Bool.true), .bool, SInfo.scalar, none, none⟩)
      | `(tritonExpr| 0.0) =>
          pure (some ⟨← `(Op.constBool Bool.false), .bool, SInfo.scalar, none, none⟩)
      | `(tritonExpr| 1.0) =>
          pure (some ⟨← `(Op.constBool Bool.true), .bool, SInfo.scalar, none, none⟩)
      | `(tritonExpr| $($t:term)) =>
          pure (some ⟨← `(Op.constBool $t), .bool, SInfo.scalar, none, none⟩)
      | _ => pure none
  | _ =>
      pure none

private partial def isNoneSyntax (stx : Syntax) : Bool :=
  match stx with
  | Syntax.atom _ val => val == "None"
  | Syntax.ident _ _ name _ => name == `None
  | Syntax.node _ _ args => args.any isNoneSyntax
  | _ => Bool.false

private def isNoneExpr (e : TSyntax `tritonExpr) : Bool :=
  isNoneSyntax e.raw

private def dtypeName : DInfo → String
  | .real => "real"
  | .fp32 => "fp32"
  | .fp16 => "fp16"
  | .bf16 => "bf16"
  | .f8e4 => "f8e4"
  | .f8e5 => "f8e5"
  | .int => "int"
  | .int8 => "int8"
  | .int32 => "int32"
  | .nat => "nat"
  | .bool => "bool"
  | .ptr => "ptr"
  | .blockPtr => "blockPtr"
  | .floatVar name => name

partial def expandLoad (expandExpr : ExprExpander)
    (expandStaticPtrExpr : StaticPtrExpander) (env : Env)
    (p : TSyntax `tritonExpr) (kwargs : TSyntaxArray `tritonMemKwarg)
    (defaultDType : Option DInfo := none)
    (positionalMask : Option (TSyntax `tritonExpr) := none) :
    MacroM EOut := do
  let mut maskTerm : Option (TSyntax `term × SInfo) := none
  match positionalMask with
  | none => pure ()
  | some mask => do
      let mask' ← expandExpr env mask
      ensureDType .bool mask'.dtype "tl.load mask"
      maskTerm := some (mask'.term, mask'.shape)
  let mut otherSyntax : Option (TSyntax `tritonExpr) := none
  let mut dtype? : Option DInfo := none
  let mut boundaryCheck? : Option (TSyntax `term) := none
  let mut paddingOption? : Option String := none
  let mut padding : TSyntax `term ← `(PaddingOption.unspecified)
  for kw in kwargs do
    match kw with
    | `(tritonMemKwarg| boundary_check=$axes:term) =>
        if boundaryCheck?.isSome then
          Macro.throwError "tl.load: duplicate `boundary_check=` kwarg"
        boundaryCheck? := some axes
    | `(tritonMemKwarg| boundary_check=($axes:term)) =>
        if boundaryCheck?.isSome then
          Macro.throwError "tl.load: duplicate `boundary_check=` kwarg"
        boundaryCheck? := some axes
    | `(tritonMemKwarg| boundary_check=([$axes:num,*] : $_ty:term)) =>
        if boundaryCheck?.isSome then
          Macro.throwError "tl.load: duplicate `boundary_check=` kwarg"
        boundaryCheck? := some (← numArrayAsNatListTerm axes)
    | `(tritonMemKwarg| boundary_check=($axes:num,*)) =>
        if boundaryCheck?.isSome then
          Macro.throwError "tl.load: duplicate `boundary_check=` kwarg"
        boundaryCheck? := some (← numArrayAsNatListTerm axes)
    | `(tritonMemKwarg| padding_option=$value:str) =>
        if paddingOption?.isSome then
          Macro.throwError "tl.load: duplicate `padding_option=` kwarg"
        paddingOption? := some value.getString
        padding := ← paddingOptionTerm value.getString
    | `(tritonMemKwarg| eviction_policy="evict_last") =>
        pure ()
    | `(tritonMemKwarg| eviction_policy="evict_first") =>
        -- Cache-eviction hint only; no semantic content.
        pure ()
    | `(tritonMemKwarg| $name:ident = $dt:tritonDType) =>
        unless name.getId.getString! == "dtype" do
          Macro.throwError
            ("tl.load: unknown kwarg `" ++ name.getId.toString ++
             "`. Only `mask`, `other`, `dtype`, `boundary_check`, `padding_option`, and `eviction_policy` are recognized.")
        if dtype?.isSome then
          Macro.throwError "tl.load: duplicate `dtype=` kwarg"
        dtype? := some (← expandStorageDType dt)
    | `(tritonMemKwarg| $name:ident = $val:tritonExpr) =>
        match name.getId.getString! with
        | "mask"  =>
            let val' ← expandExpr env val
            ensureDType .bool val'.dtype "tl.load mask"
            maskTerm := some (val'.term, val'.shape)
        | "other" =>
            otherSyntax := some val
        | "dtype" =>
            if dtype?.isSome then
              Macro.throwError "tl.load: duplicate `dtype=` kwarg"
            dtype? := some (← expandStorageDTypeExpr val)
        | unknown =>
            let msg : String :=
              "tl.load: unknown kwarg `" ++ unknown ++
              "`. Only `mask`, `other`, `dtype`, `boundary_check`, `padding_option`, and `eviction_policy` are recognized."
            Macro.throwError msg
    | _ => Macro.throwUnsupported
  let explicitOrDefaultDType := dtype?.orElse (fun _ => defaultDType)
  let loadDType (spDType? : Option DInfo := none) : DInfo :=
    explicitOrDefaultDType.orElse (fun _ => spDType?) |>.getD .real
  let mkLoadOutWithDType (outDType : DInfo) (mem mask : TSyntax `term)
      (shape : SInfo) (block : Bool) : MacroM EOut := do
    if !block && paddingOption?.any (fun value => !value.isEmpty) then
      Macro.throwError "tl.load: nonempty `padding_option` requires a block pointer"
    -- Ordinary pointer loads do not use padding. Retain their existing AST.
    let loadPadding ← if block then pure padding else `(PaddingOption.zero)
    match outDType with
    | .fp32 =>
        let algTerm ← `(Op.load TileDType.real $mem $mask $loadPadding)
        pure ⟨algTerm, .real, shape,
          some (← fp32ComputeLoadExpr mem mask loadPadding), some .fp32⟩
    | .real =>
        let algTerm ← `(Op.load TileDType.real $mem $mask $loadPadding)
        if dtype? == some .real then
          pure ⟨algTerm, .real, shape, some (← fp64ComputeExpr algTerm), some .real⟩
        else pure ⟨algTerm, .real, shape, none, none⟩
    | _ =>
        let dt ← outDType.term
        pure ⟨← `(Op.load $dt $mem $mask $loadPadding), outDType, shape, none, none⟩
  let staticPtr? ←
    if boundaryCheck?.isSome then
      pure none
    else
      expandStaticPtrExpr env p
  let outDType := loadDType (staticPtr?.bind (fun sp => sp.regionDType?))
  let mkLoadOut (mem mask : TSyntax `term) (shape : SInfo) (block : Bool := Bool.false) : MacroM EOut := do
    mkLoadOutWithDType outDType mem mask shape block
  if let some boundaryCheck := boundaryCheck? then
    if maskTerm.isSome || otherSyntax.isSome then
      Macro.throwError "tl.load: block-pointer `boundary_check` cannot be combined with `mask` or `other`"
    let p' ← expandExpr env p
    ensureDType .blockPtr p'.dtype "tl.load block pointer"
    return ← mkLoadOut (← `(MemAccess.blockPtr $p'.term $boundaryCheck)) (← `(MaskOpt.none)) p'.shape Bool.true
  let otherIsNone := otherSyntax.any isNoneExpr
  let otherTerm ←
    match otherSyntax with
    | none => pure none
    | some other => do
        if isNoneExpr other then
          pure none
        else do
          let other' ←
            match ← expandLoadOtherAs? outDType other with
            | some out => pure out
            | none => expandExpr env other
          -- Triton converts `other` to the pointer element dtype, including
          -- signed integer narrowing before a masked value enters the program.
          -- fp32 uses the existing real-carrier compute-load representation.
          let other' ← match outDType with
            | .fp16 | .bf16 | .f8e4 | .f8e5 | .floatVar _ =>
                coerceFloatOperand outDType other'
            | .int8 | .int32 => do
                if other'.dtype == outDType then pure other'
                else do
                  let value ← match other'.dtype with
                    | .int | .int8 | .int32 => pure other'.term
                    | .nat => `(Op.castNatToInt $other'.term)
                    | .bool => `(Op.boolToInt $other'.term)
                    | _ => Macro.throwError "tl.load: signed integer other requires an integer or Bool expression"
                  let width : TSyntax `term ← if outDType == .int8 then `(8) else `(32)
                  -- A constant has no evaluation effects. Fold its signed
                  -- bit interpretation; retain the explicit operation for
                  -- runtime expressions and register references.
                  let narrowed ← match value with
                    | `(Op.constInt $literal) =>
                        `(Op.constInt ((BitVec.ofInt $width $literal).toInt))
                    | _ => `(Op.intToSigned $width $value)
                  pure ⟨narrowed, outDType, other'.shape, none, none⟩
            | _ => pure other'
          pure (some (other'.term, other'.dtype, other'.shape, other'.computeDType?))
  if let some (_, otherDType, _, _) := otherTerm then
    unless otherDType == outDType || (outDType == .fp32 && otherDType == .real) do
      Macro.throwError
        ("tl.load other: dtype must match load result dtype (load " ++
          dtypeName outDType ++ ", other " ++ dtypeName otherDType ++ ")")
  match maskTerm, otherTerm with
  | none, none =>
      if otherIsNone then
        Macro.throwError
          "tl.load: `other=None` requires `mask=`. (Triton: `other` is meaningful only when some lanes are masked off.)"
      match staticPtr? with
      | some sp =>
          let r := sp.region
          let off := sp.offset
          mkLoadOut (← `(MemAccess.region $r $off)) (← `(MaskOpt.none)) sp.shape
      | none =>
          let p' ← expandExpr env p
          if p'.dtype == .blockPtr then
            mkLoadOut (← `(MemAccess.blockPtr $p'.term ([] : List Nat))) (← `(MaskOpt.none)) p'.shape Bool.true
          else
            ensureDType .ptr p'.dtype "tl.load pointer"
            mkLoadOut (← `(MemAccess.ptr $p'.term)) (← `(MaskOpt.none)) p'.shape
  | some (m, mShape), none =>
      match staticPtr? with
      | some sp =>
          let r := sp.region
          let off := sp.offset
          let m' ← coerceShape m mShape sp.shape "tl.load mask"
          mkLoadOut (← `(MemAccess.region $r $off)) (← `(MaskOpt.mask $m')) sp.shape
      | none =>
          let p' ← expandExpr env p
          ensureDType .ptr p'.dtype "tl.load pointer"
          let m' ← coerceShape m mShape p'.shape "tl.load mask"
          mkLoadOut (← `(MemAccess.ptr $p'.term)) (← `(MaskOpt.mask $m')) p'.shape
  | some (m, mShape), some (o, _, oShape, _) =>
      match staticPtr? with
      | some sp =>
          let r := sp.region
          let off := sp.offset
          let m' ← coerceShape m mShape sp.shape "tl.load mask"
          let o' ← coerceShape o oShape sp.shape "tl.load other"
          mkLoadOut (← `(MemAccess.region $r $off)) (← `(MaskOpt.maskOther $m' $o')) sp.shape
      | none =>
          let p' ← expandExpr env p
          ensureDType .ptr p'.dtype "tl.load pointer"
          let m' ← coerceShape m mShape p'.shape "tl.load mask"
          let o' ← coerceShape o oShape p'.shape "tl.load other"
          mkLoadOut (← `(MemAccess.ptr $p'.term)) (← `(MaskOpt.maskOther $m' $o')) p'.shape
  | none, some _ =>
      Macro.throwError
        "tl.load: `other=` requires `mask=`. (Triton: `other` is meaningful only when some lanes are masked off.)"

partial def expandStore (expandExpr : ExprExpander)
    (expandStaticPtrExpr : StaticPtrExpander) (env : Env)
    (p v : TSyntax `tritonExpr) (kwargs : TSyntaxArray `tritonMemKwarg)
    (positionalMask : Option (TSyntax `tritonExpr) := none) :
    MacroM StmtExpansion := do
  let mut maskTerm : Option (TSyntax `term × SInfo) := none
  match positionalMask with
  | none => pure ()
  | some mask => do
      let mask' ← expandExpr env mask
      ensureDType .bool mask'.dtype "tl.store mask"
      maskTerm := some (mask'.term, mask'.shape)
  let mut dtype? : Option DInfo := none
  let mut boundaryCheck? : Option (TSyntax `term) := none
  let mut evictionPolicySeen := Bool.false
  for kw in kwargs do
    match kw with
    | `(tritonMemKwarg| eviction_policy="evict_last")
    | `(tritonMemKwarg| eviction_policy="evict_first") =>
        if evictionPolicySeen then
          Macro.throwError "tl.store: duplicate `eviction_policy=` kwarg"
        -- These source cache hints do not change memory semantics.
        evictionPolicySeen := Bool.true
    | `(tritonMemKwarg| eviction_policy=$policy:str) =>
        unless policy.getString == "evict_first" || policy.getString == "evict_last" do
          Macro.throwError "tl.store: eviction_policy requires literal evict_first or evict_last"
        if evictionPolicySeen then
          Macro.throwError "tl.store: duplicate `eviction_policy=` kwarg"
        evictionPolicySeen := Bool.true
    | `(tritonMemKwarg| boundary_check=$axes:term) =>
        if boundaryCheck?.isSome then
          Macro.throwError "tl.store: duplicate `boundary_check=` kwarg"
        boundaryCheck? := some axes
    | `(tritonMemKwarg| boundary_check=($axes:term)) =>
        if boundaryCheck?.isSome then
          Macro.throwError "tl.store: duplicate `boundary_check=` kwarg"
        boundaryCheck? := some axes
    | `(tritonMemKwarg| boundary_check=([$axes:num,*] : $_ty:term)) =>
        if boundaryCheck?.isSome then
          Macro.throwError "tl.store: duplicate `boundary_check=` kwarg"
        boundaryCheck? := some (← numArrayAsNatListTerm axes)
    | `(tritonMemKwarg| boundary_check=($axes:num,*)) =>
        if boundaryCheck?.isSome then
          Macro.throwError "tl.store: duplicate `boundary_check=` kwarg"
        boundaryCheck? := some (← numArrayAsNatListTerm axes)
    | `(tritonMemKwarg| padding_option=$_:str) =>
        Macro.throwError "tl.store: `padding_option` is only valid on tl.load"
    | `(tritonMemKwarg| $name:ident = $dt:tritonDType) =>
        unless name.getId.getString! == "dtype" do
          Macro.throwError
            ("tl.store: unknown kwarg `" ++ name.getId.toString ++
             "`. Only `mask`, `dtype`, and `boundary_check` are recognized (Triton's tl.store has no `other`; see issue #16).")
        if dtype?.isSome then
          Macro.throwError "tl.store: duplicate `dtype=` kwarg"
        dtype? := some (← expandDType dt)
    | `(tritonMemKwarg| $name:ident = $kval:tritonExpr) =>
        match name.getId.getString! with
        | "mask"  =>
            if maskTerm.isSome then
              Macro.throwError "tl.store: duplicate `mask=` kwarg"
            let kval' ← expandExpr env kval
            ensureDType .bool kval'.dtype "tl.store mask"
            maskTerm := some (kval'.term, kval'.shape)
        | "dtype" =>
            if dtype?.isSome then
              Macro.throwError "tl.store: duplicate `dtype=` kwarg"
            dtype? := some (← expandDTypeExpr kval)
        | "eviction_policy" =>
            Macro.throwError "tl.store: eviction_policy requires literal evict_first or evict_last"
        | unknown =>
            let msg : String :=
              "tl.store: unknown kwarg `" ++ unknown ++
              "`. Only `mask`, `dtype`, and `boundary_check` are recognized (Triton's tl.store has no `other`; see issue #16)."
            Macro.throwError msg
    | _ => Macro.throwUnsupported
  let storeExpected := dtype?.getD .real
  let v' ←
    match ← expandLeanAntiquoteAs? storeExpected v with
    | some out => pure out
    | none => expandExpr env v
  let v' := v'.forgetStorageWidth
  let valueExpr ←
    match v'.computeTerm with
    | some ce => pure ce
    | none => `(ComputeExpr.alg $v'.term)
  let storeDType := dtype?.getD v'.dtype
  unless storeDType == v'.dtype do
    Macro.throwError "tl.store: `dtype=` must match the value dtype"
  if let some boundaryCheck := boundaryCheck? then
    if maskTerm.isSome then
      Macro.throwError "tl.store: block-pointer `boundary_check` cannot be combined with `mask`"
    let p' ← expandExpr env p
    ensureDType .blockPtr p'.dtype "tl.store block pointer"
    let vTerm ← coerceShape v'.term v'.shape p'.shape "tl.store value"
    let sh ← p'.shape.term
    let dt ← storeDType.term
    let valueExpr' ←
      match v'.computeTerm with
      | some _ => pure valueExpr
      | none => `(ComputeExpr.alg $vTerm)
    return (← `(Stmt.store $dt $sh (MemAccess.blockPtr $p'.term $boundaryCheck) $vTerm MaskOpt.none),
      ← `(ComputeStmt.store $dt $sh (MemAccess.blockPtr $p'.term $boundaryCheck) $valueExpr' MaskOpt.none),
      env, v'.computeTerm.isSome)
  match maskTerm with
  | none =>
      match ← expandStaticPtrExpr env p with
      | some sp =>
          let vTerm ← coerceShape v'.term v'.shape sp.shape "tl.store value"
          let r := sp.region
          let off := sp.offset
          let sh ← sp.shape.term
          let dt ← storeDType.term
          let valueExpr' ←
            match v'.computeTerm with
            | some _ => pure valueExpr
            | none => `(ComputeExpr.alg $vTerm)
          pure (← `(Stmt.store $dt $sh (MemAccess.region $r $off) $vTerm MaskOpt.none),
            ← `(ComputeStmt.store $dt $sh (MemAccess.region $r $off) $valueExpr' MaskOpt.none),
            env, v'.computeTerm.isSome)
      | none =>
          let p' ← expandExpr env p
          if p'.dtype == .blockPtr then
            let vTerm ← coerceShape v'.term v'.shape p'.shape "tl.store value"
            let sh ← p'.shape.term
            let dt ← storeDType.term
            let valueExpr' ←
              match v'.computeTerm with
              | some _ => pure valueExpr
              | none => `(ComputeExpr.alg $vTerm)
            pure (← `(Stmt.store $dt $sh (MemAccess.blockPtr $p'.term ([] : List Nat)) $vTerm MaskOpt.none),
              ← `(ComputeStmt.store $dt $sh (MemAccess.blockPtr $p'.term ([] : List Nat)) $valueExpr' MaskOpt.none),
              env, v'.computeTerm.isSome)
          else
            ensureDType .ptr p'.dtype "tl.store pointer"
            let vTerm ← coerceShape v'.term v'.shape p'.shape "tl.store value"
            let sh ← p'.shape.term
            let dt ← storeDType.term
            let valueExpr' ←
              match v'.computeTerm with
              | some _ => pure valueExpr
              | none => `(ComputeExpr.alg $vTerm)
            pure (← `(Stmt.store $dt $sh (MemAccess.ptr $p'.term) $vTerm MaskOpt.none),
              ← `(ComputeStmt.store $dt $sh (MemAccess.ptr $p'.term) $valueExpr' MaskOpt.none),
              env, v'.computeTerm.isSome)
  | some (m, mShape) =>
      match ← expandStaticPtrExpr env p with
      | some sp =>
          let vTerm ← coerceShape v'.term v'.shape sp.shape "tl.store value"
          let m' ← coerceShape m mShape sp.shape "tl.store mask"
          let r := sp.region
          let off := sp.offset
          let sh ← sp.shape.term
          let dt ← storeDType.term
          let valueExpr' ←
            match v'.computeTerm with
            | some _ => pure valueExpr
            | none => `(ComputeExpr.alg $vTerm)
          pure (← `(Stmt.store $dt $sh (MemAccess.region $r $off) $vTerm (MaskOpt.mask $m')),
            ← `(ComputeStmt.store $dt $sh (MemAccess.region $r $off) $valueExpr' (MaskOpt.mask $m')),
            env, v'.computeTerm.isSome)
      | none =>
          let p' ← expandExpr env p
          ensureDType .ptr p'.dtype "tl.store pointer"
          let vTerm ← coerceShape v'.term v'.shape p'.shape "tl.store value"
          let m' ← coerceShape m mShape p'.shape "tl.store mask"
          let sh ← p'.shape.term
          let dt ← storeDType.term
          let valueExpr' ←
            match v'.computeTerm with
            | some _ => pure valueExpr
            | none => `(ComputeExpr.alg $vTerm)
            pure (← `(Stmt.store $dt $sh (MemAccess.ptr $p'.term) $vTerm (MaskOpt.mask $m')),
              ← `(ComputeStmt.store $dt $sh (MemAccess.ptr $p'.term) $valueExpr' (MaskOpt.mask $m')),
              env, v'.computeTerm.isSome)

partial def expandAtomicAdd (expandExpr : ExprExpander)
    (expandStaticPtrExpr : StaticPtrExpander) (env : Env)
    (p v : TSyntax `tritonExpr) (kwargs : TSyntaxArray `tritonMemKwarg) :
    MacroM StmtExpansion := do
  let mut maskTerm : Option (TSyntax `term × SInfo) := none
  let mut dtype? : Option DInfo := none
  for kw in kwargs do
    match kw with
    | `(tritonMemKwarg| boundary_check=$_:term) =>
        Macro.throwError "tl.atomic_add: `boundary_check=` is not supported; block-pointer atomics are deferred"
    | `(tritonMemKwarg| padding_option=$_:str) =>
        Macro.throwError "tl.atomic_add: `padding_option` is only valid on tl.load"
    | `(tritonMemKwarg| $name:ident = $dt:tritonDType) =>
        unless name.getId.getString! == "dtype" do
          Macro.throwError
            ("tl.atomic_add: unknown kwarg `" ++ name.getId.toString ++
             "`. Only `mask` and `dtype` are recognized.")
        if dtype?.isSome then
          Macro.throwError "tl.atomic_add: duplicate `dtype=` kwarg"
        dtype? := some (← expandDType dt)
    | `(tritonMemKwarg| $name:ident = $kval:tritonExpr) =>
        match name.getId.getString! with
        | "mask" =>
            let kval' ← expandExpr env kval
            ensureDType .bool kval'.dtype "tl.atomic_add mask"
            maskTerm := some (kval'.term, kval'.shape)
        | "dtype" =>
            if dtype?.isSome then
              Macro.throwError "tl.atomic_add: duplicate `dtype=` kwarg"
            dtype? := some (← expandDTypeExpr kval)
        | unknown =>
            Macro.throwError
              ("tl.atomic_add: unknown kwarg `" ++ unknown ++
               "`. Only `mask` and `dtype` are recognized.")
    | _ => Macro.throwUnsupported
  let atomicExpected := dtype?.getD .real
  let v' ←
    match ← expandLeanAntiquoteAs? atomicExpected v with
    | some out => pure out
    | none => expandExpr env v
  let v' := v'.forgetStorageWidth
  let valueExpr ←
    match v'.computeTerm with
    | some ce => pure ce
    | none => `(ComputeExpr.alg $v'.term)
  let atomicDType := dtype?.getD v'.dtype
  unless atomicDType == v'.dtype do
    Macro.throwError "tl.atomic_add: `dtype=` must match the value dtype"
  let hnum ← atomicDType.numericProof
  match maskTerm with
  | none =>
      match ← expandStaticPtrExpr env p with
      | some sp =>
          let vTerm ← coerceShape v'.term v'.shape sp.shape "tl.atomic_add value"
          let sh ← sp.shape.term
          let valueExpr' ←
            match v'.computeTerm with
            | some _ => pure valueExpr
            | none => `(ComputeExpr.alg $vTerm)
          pure (← `(Stmt.atomicAdd $hnum $sh (MemAccess.region $sp.region $sp.offset) $vTerm MaskOpt.none),
            ← `(ComputeStmt.atomicAdd $hnum $sh (MemAccess.region $sp.region $sp.offset) $valueExpr' MaskOpt.none),
            env, v'.computeTerm.isSome)
      | none =>
          let p' ← expandExpr env p
          ensureDType .ptr p'.dtype "tl.atomic_add pointer"
          let vTerm ← coerceShape v'.term v'.shape p'.shape "tl.atomic_add value"
          let sh ← p'.shape.term
          let valueExpr' ←
            match v'.computeTerm with
            | some _ => pure valueExpr
            | none => `(ComputeExpr.alg $vTerm)
          pure (← `(Stmt.atomicAdd $hnum $sh (MemAccess.ptr $p'.term) $vTerm MaskOpt.none),
            ← `(ComputeStmt.atomicAdd $hnum $sh (MemAccess.ptr $p'.term) $valueExpr' MaskOpt.none),
            env, v'.computeTerm.isSome)
  | some (m, mShape) =>
      match ← expandStaticPtrExpr env p with
      | some sp =>
          let vTerm ← coerceShape v'.term v'.shape sp.shape "tl.atomic_add value"
          let m' ← coerceShape m mShape sp.shape "tl.atomic_add mask"
          let sh ← sp.shape.term
          let valueExpr' ←
            match v'.computeTerm with
            | some _ => pure valueExpr
            | none => `(ComputeExpr.alg $vTerm)
          pure (← `(Stmt.atomicAdd $hnum $sh (MemAccess.region $sp.region $sp.offset) $vTerm (MaskOpt.mask $m')),
            ← `(ComputeStmt.atomicAdd $hnum $sh (MemAccess.region $sp.region $sp.offset) $valueExpr' (MaskOpt.mask $m')),
            env, v'.computeTerm.isSome)
      | none =>
          let p' ← expandExpr env p
          ensureDType .ptr p'.dtype "tl.atomic_add pointer"
          let vTerm ← coerceShape v'.term v'.shape p'.shape "tl.atomic_add value"
          let m' ← coerceShape m mShape p'.shape "tl.atomic_add mask"
          let sh ← p'.shape.term
          let valueExpr' ←
            match v'.computeTerm with
            | some _ => pure valueExpr
            | none => `(ComputeExpr.alg $vTerm)
          pure (← `(Stmt.atomicAdd $hnum $sh (MemAccess.ptr $p'.term) $vTerm (MaskOpt.mask $m')),
            ← `(ComputeStmt.atomicAdd $hnum $sh (MemAccess.ptr $p'.term) $valueExpr' (MaskOpt.mask $m')),
            env, v'.computeTerm.isSome)

end VeriTile.Triton.DSL
