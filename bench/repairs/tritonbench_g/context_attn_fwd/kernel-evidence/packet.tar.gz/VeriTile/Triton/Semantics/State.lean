/-
VeriTile.Triton.Semantics.State

Execution state, register updates, memory writes, and readback lemmas.
-/

import VeriTile.Triton.Semantics.Scalar

namespace VeriTile.Triton

/-- A typed register file. The same register name can only be observed at the
    dtype/shape requested by the typed AST node that references it. -/
abbrev RegFile :=
  (dtype : TileDType) → (shape : TileShape) → RegName → Option (Tile dtype shape)

/-- Dynamically typed scalar memory cell.

Memory is typed at the cell boundary, while proof-facing Real contracts continue
to use `BlockState.readMem` / `BlockState.writeMem`. -/
abbrev MemCell := Sigma TileCarrier

namespace MemCell

def of (dtype : TileDType) (value : TileCarrier dtype) : MemCell :=
  ⟨dtype, value⟩

def real (value : ℝ) : MemCell :=
  of .real (some value)

instance (n : Nat) : OfNat MemCell n where
  ofNat := real n

def readAs (cell : MemCell) (dtype : TileDType) : Option (TileCarrier dtype) :=
  match cell with
  | ⟨cellDType, value⟩ =>
      if h : cellDType = dtype then
        some (cast (by rw [h]) value)
      else
        none

@[simp] theorem readAs_of_same (dtype : TileDType) (value : TileCarrier dtype) :
    (MemCell.of dtype value).readAs dtype = some value := by
  cases dtype <;> rfl

def eraseDType : MemCell → MemCell
  | ⟨.real, value⟩ => of .real value
  | ⟨.fp32, value⟩ => of .real (FloatDType.fp32.toWithBot value)
  | ⟨.fp16, value⟩ => of .real (FloatDType.fp16.toWithBot value)
  | ⟨.bf16, value⟩ => of .real (FloatDType.bf16.toWithBot value)
  | ⟨.f8e4, value⟩ => of .real (FloatDType.f8e4.toWithBot value)
  | ⟨.f8e5, value⟩ => of .real (FloatDType.f8e5.toWithBot value)
  | ⟨.int, value⟩ => of .int value
  | ⟨.nat, value⟩ => of .nat value
  | ⟨.bool, value⟩ => of .bool value
  | ⟨.ptr, value⟩ => of .ptr value
  | ⟨.blockPtr, value⟩ => of .blockPtr value

@[simp] theorem readAs_real_real (value : ℝ) :
    (MemCell.real value).readAs .real = some (some value : WithBot ℝ) := rfl

@[simp] theorem eraseDType_real (value : ℝ) :
    (MemCell.real value).eraseDType = MemCell.real value := rfl

end MemCell

/-- Extensible read-modify-write event payload used by atomic traces and
single-cell RMW semantics. -/
structure RMWEvent where
  cell : RegionName × Nat
  op : RMWOp
  input : MemCell
  extraInput : Option MemCell := none
  observed : Option MemCell := none
  result : Option MemCell := none

namespace RMWEvent

def region (event : RMWEvent) : RegionName :=
  event.cell.1

def offset (event : RMWEvent) : Nat :=
  event.cell.2

def value (event : RMWEvent) : MemCell :=
  event.input

def withObservedResult (event : RMWEvent) (old : MemCell) : RMWEvent :=
  { event with observed := some old, result := some old }

end RMWEvent

namespace RMWOp

/--
Apply one linearized single-cell RMW event.

This is algorithm-layer semantics. In particular, CAS compares `MemCell`s by
mathematical equality, not by a hardware bit-pattern predicate. Bit-level
fidelity stays in the compute-gap/testing layer.
-/
noncomputable def apply : RMWOp → MemCell → RMWEvent → Option (MemCell × RMWEvent) := by
  classical
  intro op old event
  cases op with
  | xchg =>
      exact some (event.input, event.withObservedResult old)
  | cas =>
      match event.extraInput with
      | none => exact none
      | some replacement =>
          let event' := event.withObservedResult old
          if old = event.input then
            exact some (replacement, event')
          else
            exact some (old, event')
  | add => exact none
  | max => exact none
  | min => exact none

@[simp] theorem apply_xchg (old input : MemCell) (cell : RegionName × Nat) :
    RMWOp.apply .xchg old
        { cell := cell, op := .xchg, input := input } =
      some (input,
        { cell := cell, op := .xchg, input := input,
          observed := some old, result := some old }) := rfl

@[simp] theorem apply_cas_missing_replacement
    (old cmp : MemCell) (cell : RegionName × Nat) :
    RMWOp.apply .cas old
        { cell := cell, op := .cas, input := cmp } = none := rfl

theorem apply_cas_success
    (old replacement : MemCell) (cell : RegionName × Nat) :
    RMWOp.apply .cas old
        { cell := cell, op := .cas, input := old,
          extraInput := some replacement } =
      some (replacement,
        { cell := cell, op := .cas, input := old,
          extraInput := some replacement,
          observed := some old, result := some old }) := by
  simp [apply, RMWEvent.withObservedResult]

theorem apply_cas_failure
    (old cmp replacement : MemCell) (cell : RegionName × Nat)
    (h : old ≠ cmp) :
    RMWOp.apply .cas old
        { cell := cell, op := .cas, input := cmp,
          extraInput := some replacement } =
      some (old,
        { cell := cell, op := .cas, input := cmp,
          extraInput := some replacement,
          observed := some old, result := some old }) := by
  simp [apply, RMWEvent.withObservedResult, if_neg h]

end RMWOp

namespace RMWTrace

/--
Apply a per-cell linearization list.

The input list is the chosen linearization order. The returned list is in the
same order, with `observed` / `result` fields filled by `RMWOp.apply`.
-/
noncomputable def applyLinearized :
    MemCell → List RMWEvent → Option (MemCell × List RMWEvent)
  | initial, [] => some (initial, [])
  | initial, event :: events => do
      let (cell', event') ← RMWOp.apply event.op initial event
      let (final, events') ← applyLinearized cell' events
      some (final, event' :: events')

@[simp] theorem applyLinearized_nil (initial : MemCell) :
    applyLinearized initial [] = some (initial, []) := rfl

@[simp] theorem applyLinearized_cons
    (initial next final : MemCell)
    (event event' : RMWEvent) (events events' : List RMWEvent)
    (hStep : RMWOp.apply event.op initial event = some (next, event'))
    (hTail : applyLinearized next events = some (final, events')) :
    applyLinearized initial (event :: events) =
      some (final, event' :: events') := by
  simp [applyLinearized, hStep, hTail]

theorem applyLinearized_xchg_two
    (old first second : MemCell) (cell : RegionName × Nat) :
    applyLinearized old
        [ { cell := cell, op := .xchg, input := first }
        , { cell := cell, op := .xchg, input := second } ] =
      some (second,
        [ { cell := cell, op := .xchg, input := first,
            observed := some old, result := some old }
        , { cell := cell, op := .xchg, input := second,
            observed := some first, result := some first } ]) := by
  simp [applyLinearized]

theorem applyLinearized_cas_success
    (old replacement : MemCell) (cell : RegionName × Nat) :
    applyLinearized old
        [ { cell := cell, op := .cas, input := old,
            extraInput := some replacement } ] =
      some (replacement,
        [ { cell := cell, op := .cas, input := old,
            extraInput := some replacement,
            observed := some old, result := some old } ]) := by
  simp [applyLinearized, RMWOp.apply_cas_success]

theorem applyLinearized_cas_failure
    (old cmp replacement : MemCell) (cell : RegionName × Nat)
    (h : old ≠ cmp) :
    applyLinearized old
        [ { cell := cell, op := .cas, input := cmp,
            extraInput := some replacement } ] =
      some (old,
        [ { cell := cell, op := .cas, input := cmp,
            extraInput := some replacement,
            observed := some old, result := some old } ]) := by
  simp [applyLinearized, RMWOp.apply_cas_failure, h]

end RMWTrace

/--
A block-level execution state.

`regs` is typed directly; there is no dynamically tagged runtime value.
`undef` models Triton's masked load with `other=None`.
-/
structure BlockState where
  mem   : RegionName → Nat → MemCell
  regs  : RegFile
  /-- Per-axis program IDs. `pids axis` is the value of
  `tl.program_id(axis)`. Total over `Nat`; out-of-range axes default to `0`
  (or whatever the launch model picks). FA-1's batch/head launch grid uses
  axes 0/1/2 for `(q_block, head, batch)`. -/
  pids  : Nat → Nat
  undef : RegionName → Nat → ℝ := fun _ _ => 0
  /-- Per-axis launch-grid dimensions (#92). `numPids axis` is the value of
  `tl.num_programs(axis)`. Total over `Nat`; unspecified/out-of-rank axes are
  `1` (a launch runs exactly one program along any axis it does not span),
  mirroring the `pids` total-function style. Launchers are responsible for
  setting this to the actual grid dimensions when instantiating per-program
  states (see `BlockState.withGridIndex` / #88). -/
  numPids : Nat → Nat := fun _ => 1

instance : Inhabited BlockState :=
  ⟨{ mem := fun _ _ => MemCell.real 0
   , regs := fun _ _ _ => none
   , pids := fun _ => 0
   , undef := fun _ _ => 0 }⟩

namespace BlockState

/-- Backward-compatible single-axis program id: equals `pids 0`. -/
@[reducible] def pid (s : BlockState) : Nat := s.pids 0

@[simp] theorem pid_eq (s : BlockState) : s.pid = s.pids 0 := rfl

@[ext] theorem ext {s t : BlockState}
    (hmem : ∀ region offset, s.mem region offset = t.mem region offset)
    (hregs : ∀ dtype shape name, s.regs dtype shape name = t.regs dtype shape name)
    (hpids : ∀ axis, s.pids axis = t.pids axis)
    (hundef : ∀ region offset, s.undef region offset = t.undef region offset)
    (hnum : ∀ axis, s.numPids axis = t.numPids axis) :
    s = t := by
  cases s
  cases t
  simp only at hmem hregs hpids hundef hnum
  congr
  · exact funext fun region => funext fun offset => hmem region offset
  · exact funext fun dtype => funext fun shape => funext fun name => hregs dtype shape name
  · exact funext hpids
  · exact funext fun region => funext fun offset => hundef region offset
  · exact funext hnum

/-- Update a register binding.

Triton assignment replaces the variable binding by name. Therefore writing
`name` at a new dtype/shape clears stale slots for the same name at every other
typed register view. -/
def setReg (s : BlockState) (name : RegName)
    (dtype : TileDType) (shape : TileShape) (v : Tile dtype shape) : BlockState :=
  { s with regs := fun dtype' shape' name' =>
      if _ : name' = name then
        if hd : dtype' = dtype then
          if hs : shape' = shape then some (castTile hd hs v) else none
        else none
      else s.regs dtype' shape' name' }

@[simp] theorem setReg_same (s : BlockState) (name : RegName)
    (dtype : TileDType) (shape : TileShape) (v : Tile dtype shape) :
    (s.setReg name dtype shape v).regs dtype shape name = some v := by
  simp [setReg]

@[simp] theorem setReg_ne_name (s : BlockState) (name name' : RegName)
    (dtype dtype' : TileDType) (shape shape' : TileShape) (v : Tile dtype shape)
    (h : name' ≠ name) :
    (s.setReg name dtype shape v).regs dtype' shape' name' =
      s.regs dtype' shape' name' := by
  simp [setReg, h]

@[simp] theorem setReg_ne_dtype (s : BlockState) (name name' : RegName)
    (dtype dtype' : TileDType) (shape shape' : TileShape) (v : Tile dtype shape)
    (hName : name' = name) (h : dtype' ≠ dtype) :
    (s.setReg name dtype shape v).regs dtype' shape' name' =
      none := by
  simp [setReg, hName, h]

@[simp] theorem setReg_ne_shape (s : BlockState) (name name' : RegName)
    (dtype dtype' : TileDType) (shape shape' : TileShape) (v : Tile dtype shape)
    (hName : name' = name) (hDType : dtype' = dtype) (h : shape' ≠ shape) :
    (s.setReg name dtype shape v).regs dtype' shape' name' =
      none := by
  simp [setReg, hName, hDType, h]

@[simp] theorem setReg_mem (s : BlockState) (name : RegName)
    (dtype : TileDType) (shape : TileShape) (v : Tile dtype shape)
    (region : RegionName) (offset : Nat) :
    (s.setReg name dtype shape v).mem region offset = s.mem region offset := rfl

@[simp] theorem setReg_pids (s : BlockState) (name : RegName)
    (dtype : TileDType) (shape : TileShape) (v : Tile dtype shape) :
    (s.setReg name dtype shape v).pids = s.pids := rfl

@[simp] theorem setReg_pid (s : BlockState) (name : RegName)
    (dtype : TileDType) (shape : TileShape) (v : Tile dtype shape) :
    (s.setReg name dtype shape v).pid = s.pid := rfl

@[simp] theorem setReg_undef (s : BlockState) (name : RegName)
    (dtype : TileDType) (shape : TileShape) (v : Tile dtype shape)
    (region : RegionName) (offset : Nat) :
    (s.setReg name dtype shape v).undef region offset = s.undef region offset := rfl

@[simp] theorem setReg_numPids (s : BlockState) (name : RegName)
    (dtype : TileDType) (shape : TileShape) (v : Tile dtype shape) :
    (s.setReg name dtype shape v).numPids = s.numPids := rfl

/-- Write a single scalar to memory. -/
def writeMem (s : BlockState) (region : RegionName) (offset : Nat) (v : ℝ) : BlockState :=
  { s with mem := fun r o =>
      if r = region ∧ o = offset then MemCell.real v else s.mem r o }

/-- Write a typed floating scalar to memory. Stores use Triton's finite fallback
for `⊥`, matching the previous Real-only semantics. -/
def writeMemAs (s : BlockState) (dtype : FloatDType)
    (region : RegionName) (offset : Nat) (v : TileCarrier dtype.toTileDType) : BlockState :=
  { s with mem := fun r o =>
      if r = region ∧ o = offset then
        MemCell.of dtype.toTileDType (dtype.ofReal (dtype.storeValue v))
      else
        s.mem r o }

/-- Write a typed scalar to memory.

Floating channels use the same finite fallback for `⊥` as the legacy Real
path. Non-floating channels write their carrier exactly. -/
def writeMemTyped (s : BlockState) (dtype : TileDType)
    (region : RegionName) (offset : Nat) (v : TileCarrier dtype) : BlockState :=
  match dtype with
  | .real => s.writeMemAs .real region offset v
  | .fp32 => s.writeMemAs .fp32 region offset v
  | .fp16 => s.writeMemAs .fp16 region offset v
  | .bf16 => s.writeMemAs .bf16 region offset v
  | .f8e4 => s.writeMemAs .f8e4 region offset v
  | .f8e5 => s.writeMemAs .f8e5 region offset v
  | .int =>
      { s with mem := fun r o =>
          if r = region ∧ o = offset then MemCell.of .int v else s.mem r o }
  | .nat =>
      { s with mem := fun r o =>
          if r = region ∧ o = offset then MemCell.of .nat v else s.mem r o }
  | .bool =>
      { s with mem := fun r o =>
          if r = region ∧ o = offset then MemCell.of .bool v else s.mem r o }
  | .ptr =>
      { s with mem := fun r o =>
          if r = region ∧ o = offset then MemCell.of .ptr v else s.mem r o }
  | .blockPtr =>
      { s with mem := fun r o =>
          if r = region ∧ o = offset then MemCell.of .blockPtr v else s.mem r o }

/-- Write a dynamically typed cell exactly. Used by order-sensitive atomics
whose replacement value is already packaged as a `MemCell`. -/
def writeCell (s : BlockState) (region : RegionName) (offset : Nat)
    (cell : MemCell) : BlockState :=
  { s with mem := fun r o =>
      if r = region ∧ o = offset then cell else s.mem r o }

@[simp] theorem writeCell_regs (s : BlockState) (region : RegionName)
    (offset : Nat) (cell : MemCell) (dtype : TileDType) (shape : TileShape)
    (name : RegName) :
    (s.writeCell region offset cell).regs dtype shape name = s.regs dtype shape name := rfl

@[simp] theorem writeCell_pids (s : BlockState) (region : RegionName)
    (offset : Nat) (cell : MemCell) :
    (s.writeCell region offset cell).pids = s.pids := rfl

@[simp] theorem writeCell_pid (s : BlockState) (region : RegionName)
    (offset : Nat) (cell : MemCell) :
    (s.writeCell region offset cell).pid = s.pid := rfl

@[simp] theorem writeMem_regs (s : BlockState) (region : RegionName)
    (offset : Nat) (v : ℝ) (dtype : TileDType) (shape : TileShape)
    (name : RegName) :
    (s.writeMem region offset v).regs dtype shape name = s.regs dtype shape name := rfl

@[simp] theorem writeMem_pids (s : BlockState) (region : RegionName)
    (offset : Nat) (v : ℝ) :
    (s.writeMem region offset v).pids = s.pids := rfl

@[simp] theorem writeMem_pid (s : BlockState) (region : RegionName)
    (offset : Nat) (v : ℝ) :
    (s.writeMem region offset v).pid = s.pid := rfl

@[simp] theorem writeMem_undef (s : BlockState) (region : RegionName)
    (offset : Nat) (v : ℝ) (r : RegionName) (o : Nat) :
    (s.writeMem region offset v).undef r o = s.undef r o := rfl

@[simp] theorem writeMem_numPids (s : BlockState) (region : RegionName)
    (offset : Nat) (v : ℝ) :
    (s.writeMem region offset v).numPids = s.numPids := rfl

@[simp] theorem writeMemAs_regs (s : BlockState) (dtype : FloatDType)
    (region : RegionName) (offset : Nat) (v : TileCarrier dtype.toTileDType)
    (dtype' : TileDType) (shape : TileShape) (name : RegName) :
    (s.writeMemAs dtype region offset v).regs dtype' shape name =
      s.regs dtype' shape name := rfl

@[simp] theorem writeMemAs_pids (s : BlockState) (dtype : FloatDType)
    (region : RegionName) (offset : Nat) (v : TileCarrier dtype.toTileDType) :
    (s.writeMemAs dtype region offset v).pids = s.pids := rfl

@[simp] theorem writeMemAs_pid (s : BlockState) (dtype : FloatDType)
    (region : RegionName) (offset : Nat) (v : TileCarrier dtype.toTileDType) :
    (s.writeMemAs dtype region offset v).pid = s.pid := rfl

@[simp] theorem writeMemAs_undef (s : BlockState) (dtype : FloatDType)
    (region : RegionName) (offset : Nat) (v : TileCarrier dtype.toTileDType)
    (r : RegionName) (o : Nat) :
    (s.writeMemAs dtype region offset v).undef r o = s.undef r o := rfl

@[simp] theorem writeMemAs_numPids (s : BlockState) (dtype : FloatDType)
    (region : RegionName) (offset : Nat) (v : TileCarrier dtype.toTileDType) :
    (s.writeMemAs dtype region offset v).numPids = s.numPids := rfl

@[simp] theorem writeMemTyped_regs (s : BlockState) (dtype : TileDType)
    (region : RegionName) (offset : Nat) (v : TileCarrier dtype)
    (dtype' : TileDType) (shape : TileShape) (name : RegName) :
    (s.writeMemTyped dtype region offset v).regs dtype' shape name =
      s.regs dtype' shape name := by
  cases dtype <;> rfl

@[simp] theorem writeMemTyped_pids (s : BlockState) (dtype : TileDType)
    (region : RegionName) (offset : Nat) (v : TileCarrier dtype) :
    (s.writeMemTyped dtype region offset v).pids = s.pids := by
  cases dtype <;> rfl

@[simp] theorem writeMemTyped_pid (s : BlockState) (dtype : TileDType)
    (region : RegionName) (offset : Nat) (v : TileCarrier dtype) :
    (s.writeMemTyped dtype region offset v).pid = s.pid := by
  cases dtype <;> rfl

@[simp] theorem writeMemTyped_undef (s : BlockState) (dtype : TileDType)
    (region : RegionName) (offset : Nat) (v : TileCarrier dtype)
    (r : RegionName) (o : Nat) :
    (s.writeMemTyped dtype region offset v).undef r o = s.undef r o := by
  cases dtype <;> rfl

@[simp] theorem writeMemTyped_numPids (s : BlockState) (dtype : TileDType)
    (region : RegionName) (offset : Nat) (v : TileCarrier dtype) :
    (s.writeMemTyped dtype region offset v).numPids = s.numPids := by
  cases dtype <;> rfl

/-- Read a single scalar from memory. -/
@[inline] def readMem (s : BlockState) (region : RegionName) (offset : Nat) : ℝ :=
  match (s.mem region offset).readAs .real with
  | some (some value) => value
  | _ => 0

/-- Read a typed floating scalar from memory. Mismatched cells read as zero,
which preserves the existing total-memory behavior at the proof surface. -/
@[inline] def readMemAs (s : BlockState) (dtype : FloatDType)
    (region : RegionName) (offset : Nat) : TileCarrier dtype.toTileDType :=
  match (s.mem region offset).readAs dtype.toTileDType with
  | some value => dtype.ofReal (dtype.storeValue value)
  | none => dtype.ofReal 0

/-- Read a typed scalar cell exactly. Unlike `readMem` / `readMemAs`, this keeps
dtype mismatch observable. Use this for typed-memory examples and tests rather
than projecting `BlockState.mem` directly. -/
@[inline] def readMemTyped (s : BlockState) (dtype : TileDType)
    (region : RegionName) (offset : Nat) : Option (TileCarrier dtype) :=
  (s.mem region offset).readAs dtype

def defaultCarrier : (dtype : TileDType) → TileCarrier dtype
  | .real => some 0
  | .fp32 => some 0
  | .fp16 => some 0
  | .bf16 => some 0
  | .f8e4 => some 0
  | .f8e5 => some 0
  | .int => 0
  | .nat => 0
  | .bool => false
  | .ptr => ("", 0)
  | .blockPtr =>
      { region := "", baseOffset := 0, parentShape := [], blockShape := [],
        strides := [], offsets := [] }

/-- Unspecified block-load lanes are drawn from the state's oracle, without a
memory read. Integer/boolean carriers project the same oracle into their value
domain. Pointer-valued loads retain the model's default pointer restriction. -/
noncomputable def unspecifiedValue (s : BlockState) (dtype : TileDType)
    (region : RegionName) (offset : Nat) : TileCarrier dtype :=
  match dtype with
  | .real => some (s.undef region offset)
  | .fp32 => FloatDType.fp32.ofReal (s.undef region offset)
  | .fp16 => FloatDType.fp16.ofReal (s.undef region offset)
  | .bf16 => FloatDType.bf16.ofReal (s.undef region offset)
  | .f8e4 => FloatDType.f8e4.ofReal (s.undef region offset)
  | .f8e5 => FloatDType.f8e5.ofReal (s.undef region offset)
  | .int => Int.floor (s.undef region offset)
  | .nat => Nat.floor (s.undef region offset)
  | .bool => decide (s.undef region offset ≠ 0)
  | d => defaultCarrier d

/-- The padding policy belongs to a load, not to the pointer or to a store. -/
noncomputable def paddingValue (s : BlockState) (dtype : TileDType)
    (padding : PaddingOption) (region : RegionName) (offset : Nat) : TileCarrier dtype :=
  match padding with
  | .zero => defaultCarrier dtype
  | .unspecified => s.unspecifiedValue dtype region offset

@[simp] theorem paddingValue_zero (s : BlockState) (dtype : TileDType)
    (region : RegionName) (offset : Nat) :
    s.paddingValue dtype .zero region offset = defaultCarrier dtype := rfl

theorem paddingValue_of_undef_zero (s : BlockState) (dtype : TileDType)
    (padding : PaddingOption) (region : RegionName) (offset : Nat)
    (h : s.undef = fun _ _ => 0) :
    s.paddingValue dtype padding region offset = defaultCarrier dtype := by
  cases padding with
  | zero => rfl
  | unspecified =>
      cases dtype <;> simp [paddingValue, unspecifiedValue, h, defaultCarrier,
        FloatDType.ofReal]

theorem paddingValue_congr (s t : BlockState) (dtype : TileDType)
    (padding : PaddingOption) (region : RegionName) (offset : Nat)
    (h : s.undef = t.undef) :
    s.paddingValue dtype padding region offset = t.paddingValue dtype padding region offset := by
  cases padding with
  | zero => rfl
  | unspecified => cases dtype <;> simp only [paddingValue, unspecifiedValue, h]

def rmwReturnedValue (dtype : TileDType) (event : RMWEvent) : TileCarrier dtype :=
  match event.result with
  | some cell =>
      match cell.readAs dtype with
      | some value => value
      | none => defaultCarrier dtype
  | none => defaultCarrier dtype

/-- Apply one order-sensitive RMW to a concrete memory cell, returning the
updated state, returned old value, and populated event. -/
noncomputable def atomicRMWAt (s : BlockState) (op : RMWOp) (dtype : TileDType)
    (region : RegionName) (offset : Nat)
    (input : TileCarrier dtype) (extraInput : Option (TileCarrier dtype)) :
    Option (BlockState × TileCarrier dtype × RMWEvent) := do
  let event : RMWEvent :=
    { cell := (region, offset)
      op := op
      input := MemCell.of dtype input
      extraInput := extraInput.map (MemCell.of dtype) }
  let (nextCell, event') ← RMWOp.apply op (s.mem region offset) event
  let ret := rmwReturnedValue dtype event'
  some (s.writeCell region offset nextCell, ret, event')

theorem atomicRMWAt_pid
    {s s' : BlockState} {op : RMWOp} {dtype : TileDType}
    {region : RegionName} {offset : Nat}
    {input : TileCarrier dtype} {extraInput : Option (TileCarrier dtype)}
    {ret : TileCarrier dtype} {event : RMWEvent}
    (h : s.atomicRMWAt op dtype region offset input extraInput =
      some (s', ret, event)) :
    s'.pid = s.pid := by
  unfold atomicRMWAt at h
  cases hApply : RMWOp.apply op (s.mem region offset)
      { cell := (region, offset), op := op, input := MemCell.of dtype input,
        extraInput := extraInput.map (MemCell.of dtype) } with
  | none => simp [hApply] at h
  | some out =>
      rcases out with ⟨nextCell, event'⟩
      simp [hApply] at h
      rcases h with ⟨rfl, _hret, _hevent⟩
      simp

/-- Read a typed scalar for operational `tl.load`. Floating channels keep the
current finite-fallback semantics; non-floating channels read exact typed cells
and use the dtype default on mismatch. -/
@[inline] def readMemValue (s : BlockState) (dtype : TileDType)
    (region : RegionName) (offset : Nat) : TileCarrier dtype :=
  match dtype with
  | .real => s.readMemAs .real region offset
  | .fp32 => s.readMemAs .fp32 region offset
  | .fp16 => s.readMemAs .fp16 region offset
  | .bf16 => s.readMemAs .bf16 region offset
  | .f8e4 => s.readMemAs .f8e4 region offset
  | .f8e5 => s.readMemAs .f8e5 region offset
  | .int =>
      match s.readMemTyped .int region offset with
      | some value => value
      | none => defaultCarrier .int
  | .nat =>
      match s.readMemTyped .nat region offset with
      | some value => value
      | none => defaultCarrier .nat
  | .bool =>
      match s.readMemTyped .bool region offset with
      | some value => value
      | none => defaultCarrier .bool
  | .ptr =>
      match s.readMemTyped .ptr region offset with
      | some value => value
      | none => defaultCarrier .ptr
  | .blockPtr =>
      match s.readMemTyped .blockPtr region offset with
      | some value => value
      | none => defaultCarrier .blockPtr

@[simp] theorem setReg_readMem (s : BlockState) (name : RegName)
    (dtype : TileDType) (shape : TileShape) (v : Tile dtype shape)
    (region : RegionName) (offset : Nat) :
    (s.setReg name dtype shape v).readMem region offset = s.readMem region offset := rfl

@[simp] theorem setReg_readMemAs (s : BlockState) (name : RegName)
    (regDType : TileDType) (shape : TileShape) (v : Tile regDType shape)
    (memDType : FloatDType) (region : RegionName) (offset : Nat) :
    (s.setReg name regDType shape v).readMemAs memDType region offset =
      s.readMemAs memDType region offset := rfl

@[simp] theorem setReg_readMemTyped (s : BlockState) (name : RegName)
    (regDType : TileDType) (shape : TileShape) (v : Tile regDType shape)
    (memDType : TileDType) (region : RegionName) (offset : Nat) :
    (s.setReg name regDType shape v).readMemTyped memDType region offset =
      s.readMemTyped memDType region offset := rfl

@[simp] theorem setReg_readMemValue (s : BlockState) (name : RegName)
    (regDType : TileDType) (shape : TileShape) (v : Tile regDType shape)
    (memDType : TileDType) (region : RegionName) (offset : Nat) :
    (s.setReg name regDType shape v).readMemValue memDType region offset =
      s.readMemValue memDType region offset := by
  cases memDType <;> rfl

@[simp] theorem readMemValue_real (s : BlockState) (region : RegionName) (offset : Nat) :
    s.readMemValue .real region offset = some (s.readMem region offset) := by
  unfold readMemValue
  unfold readMemAs readMem
  cases h : (s.mem region offset).readAs .real with
  | none => simp [h]
  | some value =>
      cases value
      · simp [h]
        change some (0 : ℝ) = some 0
        rfl
      · rename_i value
        simp [h]
        change some value = some value
        rfl

@[simp] theorem readMemAs_real (s : BlockState) (region : RegionName) (offset : Nat) :
    s.readMemAs .real region offset = some (s.readMem region offset) := by
  unfold readMemAs readMem
  cases h : (s.mem region offset).readAs .real with
  | none => simp [h]
  | some value =>
      cases value
      · simp [h]
        change some (0 : ℝ) = some 0
        rfl
      · rename_i value
        simp [h]
        change some value = some value
        rfl

@[simp] theorem writeMemTyped_nat_readMemValue_nat (s : BlockState)
    (region : RegionName) (offset : Nat) (v : TileCarrier TileDType.nat)
    (r : RegionName) (o : Nat) :
    (s.writeMemTyped .nat region offset v).readMemValue .nat r o =
      if r = region ∧ o = offset then v else s.readMemValue .nat r o := by
  unfold writeMemTyped readMemValue readMemTyped
  by_cases h : r = region ∧ o = offset
  · rcases h with ⟨rfl, rfl⟩
    simp
  · simp [h]

@[simp] theorem writeMemTyped_int_readMemValue_int (s : BlockState)
    (region : RegionName) (offset : Nat) (v : TileCarrier TileDType.int)
    (r : RegionName) (o : Nat) :
    (s.writeMemTyped .int region offset v).readMemValue .int r o =
      if r = region ∧ o = offset then v else s.readMemValue .int r o := by
  unfold writeMemTyped readMemValue readMemTyped
  by_cases h : r = region ∧ o = offset
  · rcases h with ⟨rfl, rfl⟩
    simp
  · simp [h]

/-- `writeMemTyped .int` at a different region or offset leaves `readMem`
unaffected. Same-cell case is excluded because the original cell could have
been a `.real` cell whose value `readMem` would have returned. -/
theorem writeMemTyped_int_readMem_of_ne (s : BlockState)
    (region : RegionName) (offset : Nat) (v : TileCarrier TileDType.int)
    (r : RegionName) (o : Nat) (hne : ¬(r = region ∧ o = offset)) :
    (s.writeMemTyped .int region offset v).readMem r o = s.readMem r o := by
  unfold writeMemTyped readMem
  simp [hne]

/-- `writeMemTyped .nat` at a different region or offset leaves `readMem`
unaffected. -/
theorem writeMemTyped_nat_readMem_of_ne (s : BlockState)
    (region : RegionName) (offset : Nat) (v : TileCarrier TileDType.nat)
    (r : RegionName) (o : Nat) (hne : ¬(r = region ∧ o = offset)) :
    (s.writeMemTyped .nat region offset v).readMem r o = s.readMem r o := by
  unfold writeMemTyped readMem
  simp [hne]

/-- `writeMemTyped .nat` at a different region or offset leaves `readMemValue
.int` unaffected. -/
theorem writeMemTyped_nat_readMemValue_int_of_ne (s : BlockState)
    (region : RegionName) (offset : Nat) (v : TileCarrier TileDType.nat)
    (r : RegionName) (o : Nat) (hne : ¬(r = region ∧ o = offset)) :
    (s.writeMemTyped .nat region offset v).readMemValue .int r o =
      s.readMemValue .int r o := by
  unfold writeMemTyped readMemValue readMemTyped
  simp [hne]

/-- `writeMemTyped .int` at a different region or offset leaves `readMemValue
.nat` unaffected. -/
theorem writeMemTyped_int_readMemValue_nat_of_ne (s : BlockState)
    (region : RegionName) (offset : Nat) (v : TileCarrier TileDType.int)
    (r : RegionName) (o : Nat) (hne : ¬(r = region ∧ o = offset)) :
    (s.writeMemTyped .int region offset v).readMemValue .nat r o =
      s.readMemValue .nat r o := by
  unfold writeMemTyped readMemValue readMemTyped
  simp [hne]

@[simp] theorem writeMem_readMem (s : BlockState) (region : RegionName)
    (offset : Nat) (v : ℝ) (r : RegionName) (o : Nat) :
    (s.writeMem region offset v).readMem r o =
      if r = region ∧ o = offset then v else s.readMem r o := by
  unfold writeMem readMem
  by_cases h : r = region ∧ o = offset
  · rcases h with ⟨rfl, rfl⟩
    dsimp
    rw [if_pos (show r = r ∧ o = o from ⟨rfl, rfl⟩),
      if_pos (show r = r ∧ o = o from ⟨rfl, rfl⟩)]
    change (match (MemCell.real v).readAs .real with
      | some (some value) => value
      | _ => 0) = v
    rfl
  · simp [h]

/-- Cross-region specialization of `writeMem_readMem`. When the read region is
known to differ from the write region (a hypothesis common in multi-store
kernel proofs), the readback is unchanged regardless of the offset. -/
theorem writeMem_readMem_of_ne_region (s : BlockState) (region : RegionName)
    (offset : Nat) (v : ℝ) (r : RegionName) (o : Nat) (h : r ≠ region) :
    (s.writeMem region offset v).readMem r o = s.readMem r o := by
  rw [writeMem_readMem, if_neg]
  rintro ⟨hR, _⟩
  exact h hR

/-- Same-region different-offset specialization of `writeMem_readMem`. When
the read offset is known to differ from the write offset, the readback is
unchanged. Use for intra-region multi-store kernels (rotary embeddings,
spherical harmonics) where stores at offset `+ k₁, +k₂, ...` with distinct
`kᵢ` don't disturb each other. -/
theorem writeMem_readMem_of_ne_offset (s : BlockState) (region : RegionName)
    (offset : Nat) (v : ℝ) (r : RegionName) (o : Nat) (h : o ≠ offset) :
    (s.writeMem region offset v).readMem r o = s.readMem r o := by
  rw [writeMem_readMem, if_neg]
  rintro ⟨_, hO⟩
  exact h hO

@[simp] theorem writeMemAs_readMemAs (s : BlockState) (dtype : FloatDType)
    (region : RegionName) (offset : Nat) (v : TileCarrier dtype.toTileDType)
    (r : RegionName) (o : Nat) :
    (s.writeMemAs dtype region offset v).readMemAs dtype r o =
      if r = region ∧ o = offset then dtype.ofReal (dtype.storeValue v)
      else s.readMemAs dtype r o := by
  unfold writeMemAs readMemAs
  by_cases h : r = region ∧ o = offset
  · rcases h with ⟨rfl, rfl⟩
    dsimp
    rw [if_pos (show r = r ∧ o = o from ⟨rfl, rfl⟩),
      if_pos (show r = r ∧ o = o from ⟨rfl, rfl⟩)]
    change (match (MemCell.of dtype.toTileDType
        (dtype.ofReal (dtype.storeValue v))).readAs dtype.toTileDType with
      | some value => dtype.ofReal (dtype.storeValue value)
      | none => dtype.ofReal 0) = dtype.ofReal (dtype.storeValue v)
    cases dtype <;> rfl
  · simp [h]

@[simp] theorem writeMemAs_real (s : BlockState)
    (region : RegionName) (offset : Nat) (v : TileCarrier FloatDType.real.toTileDType) :
    s.writeMemAs .real region offset v = s.writeMem region offset (FloatDType.real.storeValue v) := by
  unfold writeMemAs writeMem
  rfl

@[simp] theorem writeMemTyped_real (s : BlockState)
    (region : RegionName) (offset : Nat) (v : TileCarrier TileDType.real) :
    s.writeMemTyped .real region offset v =
      s.writeMem region offset (FloatDType.real.storeValue v) := by
  unfold writeMemTyped
  simp

private theorem foldl_writeMem_preserves {α : Type} {region : RegionName}
    (offsetFn : α → Nat) (valueFn : α → ℝ) (o : Nat) (l : List α) :
    ∀ (s : BlockState), (∀ k ∈ l, offsetFn k ≠ o) →
      ((l.foldl (fun acc k => acc.writeMem region (offsetFn k) (valueFn k)) s).readMem region o)
      = s.readMem region o := by
  induction l with
  | nil => intros; rfl
  | cons hd tl ih =>
    intro s h
    have hhd : offsetFn hd ≠ o := h hd (List.mem_cons_self)
    have htl : ∀ k ∈ tl, offsetFn k ≠ o :=
      fun k hk => h k (List.mem_cons_of_mem hd hk)
    rw [List.foldl_cons, ih _ htl]
    rw [writeMem_readMem]
    show (if region = region ∧ o = offsetFn hd then valueFn hd else s.readMem region o)
        = s.readMem region o
    rw [if_neg]
    rintro ⟨_, h_eq⟩
    exact hhd h_eq.symm

theorem scatter_readback_list {α : Type} {region : RegionName}
    (l : List α) (s : BlockState) (offsetFn : α → Nat) (valueFn : α → ℝ)
    (i : α) (h_nodup : l.Nodup) (h_mem : i ∈ l)
    (h_inj : Function.Injective offsetFn) :
    (l.foldl
       (fun acc k => acc.writeMem region (offsetFn k) (valueFn k)) s).readMem region (offsetFn i)
    = valueFn i := by
  obtain ⟨l₁, l₂, hl⟩ := List.append_of_mem h_mem
  rw [hl] at h_nodup
  rw [List.nodup_append, List.nodup_cons] at h_nodup
  obtain ⟨_, ⟨hi_notin_l2, _⟩, _⟩ := h_nodup
  rw [hl, List.foldl_append, List.foldl_cons]
  have h_not_in : ∀ k ∈ l₂, offsetFn k ≠ offsetFn i := fun k hk heq => by
    have hki : k = i := h_inj heq
    subst hki
    exact hi_notin_l2 hk
  rw [foldl_writeMem_preserves offsetFn valueFn (offsetFn i) l₂ _ h_not_in]
  rw [writeMem_readMem]
  show (if region = region ∧ offsetFn i = offsetFn i then valueFn i else _)
      = valueFn i
  exact if_pos ⟨rfl, rfl⟩

theorem scatter_readback {region : RegionName} {n : Nat}
    (s : BlockState) (offsetFn : Fin n → Nat) (valueFn : Fin n → ℝ)
    (h_inj : Function.Injective offsetFn) (i : Fin n) :
    ((List.finRange n).foldl
       (fun acc k => acc.writeMem region (offsetFn k) (valueFn k)) s).readMem region (offsetFn i)
      = valueFn i := by
  exact scatter_readback_list (List.finRange n) s offsetFn valueFn
    i (List.nodup_finRange n) (List.mem_finRange i) h_inj

theorem scatter_readback_nd {region : RegionName} {shape : TileShape}
    (s : BlockState) (offsetFn : TileIndex shape → Nat)
    (valueFn : TileIndex shape → ℝ)
    (h_inj : Function.Injective offsetFn) (i : TileIndex shape) :
    ((TileShape.allIndices shape).foldl
       (fun acc k => acc.writeMem region (offsetFn k) (valueFn k)) s).readMem region (offsetFn i)
    = valueFn i :=
  scatter_readback_list (TileShape.allIndices shape) s offsetFn valueFn
    i (TileShape.allIndices_nodup shape) (TileShape.mem_allIndices shape i) h_inj

private theorem foldl_writeMem_masked_preserves {α : Type} {region : RegionName}
    (offsetFn : α → Nat) (valueFn : α → ℝ) (mask : α → Bool) (o : Nat) (l : List α) :
    ∀ (s : BlockState), (∀ k ∈ l, mask k = true → offsetFn k ≠ o) →
      ((l.foldl
          (fun acc k =>
            if mask k then acc.writeMem region (offsetFn k) (valueFn k) else acc) s).readMem region o)
      = s.readMem region o := by
  induction l with
  | nil => intros; rfl
  | cons hd tl ih =>
    intro s h
    rw [List.foldl_cons]
    have htl : ∀ k ∈ tl, mask k = true → offsetFn k ≠ o :=
      fun k hk hmk => h k (List.mem_cons_of_mem hd hk) hmk
    by_cases hmaskhd : mask hd = true
    · have hhd : offsetFn hd ≠ o := h hd (List.mem_cons_self) hmaskhd
      simp only [hmaskhd, if_true]
      rw [ih _ htl]
      rw [writeMem_readMem]
      show (if region = region ∧ o = offsetFn hd then valueFn hd else s.readMem region o)
          = s.readMem region o
      rw [if_neg]
      rintro ⟨_, h_eq⟩
      exact hhd h_eq.symm
    · have hmaskhd' : mask hd = false := by
        rcases hmaskFalse : mask hd
        · rfl
        · exact absurd hmaskFalse hmaskhd
      simp only [hmaskhd', if_false, Bool.false_eq_true]
      exact ih _ htl

theorem scatter_readback_masked_list {α : Type} {region : RegionName}
    (l : List α) (s : BlockState)
    (offsetFn : α → Nat) (valueFn : α → ℝ) (mask : α → Bool)
    (i : α) (h_nodup : l.Nodup) (h_mem : i ∈ l)
    (h_inj : Function.Injective offsetFn) :
    (l.foldl
       (fun acc k =>
         if mask k then acc.writeMem region (offsetFn k) (valueFn k) else acc) s).readMem region (offsetFn i)
    = if mask i then valueFn i else s.readMem region (offsetFn i) := by
  obtain ⟨l₁, l₂, hl⟩ := List.append_of_mem h_mem
  rw [hl] at h_nodup
  rw [List.nodup_append, List.nodup_cons] at h_nodup
  obtain ⟨_, ⟨hi_notin_l2, _⟩, hl1_disj⟩ := h_nodup
  rw [hl, List.foldl_append, List.foldl_cons]
  have h_l1_not_in : ∀ k ∈ l₁, mask k = true → offsetFn k ≠ offsetFn i := by
    intro k hk _hmk heq
    have hki : k = i := h_inj heq
    rw [hki] at hk
    exact (hl1_disj i hk i (List.mem_cons_self)) rfl
  have h_l2_not_in : ∀ k ∈ l₂, mask k = true → offsetFn k ≠ offsetFn i := by
    intro k hk _hmk heq
    have hki : k = i := h_inj heq
    subst hki
    exact hi_notin_l2 hk
  rw [foldl_writeMem_masked_preserves offsetFn valueFn mask (offsetFn i) l₂ _ h_l2_not_in]
  by_cases hmi : mask i = true
  · simp only [hmi, if_true]
    rw [writeMem_readMem]
    show (if region = region ∧ offsetFn i = offsetFn i then valueFn i else _)
        = valueFn i
    exact if_pos ⟨rfl, rfl⟩
  · have hmi' : mask i = false := by
      rcases hmiFalse : mask i
      · rfl
      · exact absurd hmiFalse hmi
    simp only [hmi', if_false, Bool.false_eq_true]
    rw [foldl_writeMem_masked_preserves offsetFn valueFn mask (offsetFn i) l₁ _ h_l1_not_in]

theorem scatter_readback_masked {region : RegionName} {n : Nat}
    (s : BlockState) (offsetFn : Fin n → Nat) (valueFn : Fin n → ℝ)
    (mask : Fin n → Bool)
    (h_inj : Function.Injective offsetFn) (i : Fin n) :
    ((List.finRange n).foldl
       (fun acc k =>
         if mask k then acc.writeMem region (offsetFn k) (valueFn k) else acc) s).readMem region (offsetFn i)
    = if mask i then valueFn i else s.readMem region (offsetFn i) :=
  scatter_readback_masked_list (List.finRange n) s offsetFn valueFn mask
    i (List.nodup_finRange n) (List.mem_finRange i) h_inj

theorem scatter_readback_masked_nd {region : RegionName} {shape : TileShape}
    (s : BlockState) (offsetFn : TileIndex shape → Nat)
    (valueFn : TileIndex shape → ℝ) (mask : TileIndex shape → Bool)
    (h_inj : Function.Injective offsetFn) (i : TileIndex shape) :
    ((TileShape.allIndices shape).foldl
       (fun acc k =>
         if mask k then acc.writeMem region (offsetFn k) (valueFn k) else acc) s).readMem region (offsetFn i)
    = if mask i then valueFn i else s.readMem region (offsetFn i) :=
  scatter_readback_masked_list (TileShape.allIndices shape) s offsetFn valueFn mask
    i (TileShape.allIndices_nodup shape) (TileShape.mem_allIndices shape i) h_inj

theorem scatter_readback_prop_masked {region : RegionName} {n : Nat}
    (s : BlockState) (offsetFn : Fin n → Nat) (valueFn : Fin n → ℝ)
    (P : Fin n → Prop) [DecidablePred P]
    (h_inj : Function.Injective offsetFn) (i : Fin n) :
    ((List.finRange n).foldl
       (fun acc k => if P k then acc.writeMem region (offsetFn k) (valueFn k) else acc) s).readMem region (offsetFn i)
    = if P i then valueFn i else s.readMem region (offsetFn i) := by
  have h := scatter_readback_masked (region := region) s offsetFn valueFn
              (fun k => decide (P k)) h_inj i
  simp only [decide_eq_true_eq] at h
  exact h

theorem scatter_readback_prop_masked_nd {region : RegionName} {shape : TileShape}
    (s : BlockState) (offsetFn : TileIndex shape → Nat)
    (valueFn : TileIndex shape → ℝ) (P : TileIndex shape → Prop) [DecidablePred P]
    (h_inj : Function.Injective offsetFn) (i : TileIndex shape) :
    ((TileShape.allIndices shape).foldl
       (fun acc k => if P k then acc.writeMem region (offsetFn k) (valueFn k) else acc) s).readMem region (offsetFn i)
    = if P i then valueFn i else s.readMem region (offsetFn i) := by
  have h := scatter_readback_masked_nd (region := region) s offsetFn valueFn
              (fun k => decide (P k)) h_inj i
  simp only [decide_eq_true_eq] at h
  exact h

private theorem foldl_writeMemTyped_nat_masked_preserves {α : Type} {region : RegionName}
    (offsetFn : α → Nat) (valueFn : α → Nat) (mask : α → Bool) (o : Nat) (l : List α) :
    ∀ (s : BlockState), (∀ k ∈ l, mask k = true → offsetFn k ≠ o) →
      BlockState.readMemValue ((l.foldl
          (fun acc k =>
            if mask k then acc.writeMemTyped .nat region (offsetFn k) (valueFn k) else acc) s))
          .nat region o
      = s.readMemValue .nat region o := by
  induction l with
  | nil => intros; rfl
  | cons hd tl ih =>
    intro s h
    rw [List.foldl_cons]
    have htl : ∀ k ∈ tl, mask k = true → offsetFn k ≠ o :=
      fun k hk hmk => h k (List.mem_cons_of_mem hd hk) hmk
    by_cases hmaskhd : mask hd = true
    · have hhd : offsetFn hd ≠ o := h hd (List.mem_cons_self) hmaskhd
      simp only [hmaskhd, if_true]
      rw [ih _ htl]
      rw [writeMemTyped_nat_readMemValue_nat]
      show (if region = region ∧ o = offsetFn hd then valueFn hd
          else s.readMemValue TileDType.nat region o) =
        s.readMemValue TileDType.nat region o
      rw [if_neg]
      rintro ⟨_, h_eq⟩
      exact hhd h_eq.symm
    · have hmaskhd' : mask hd = false := by
        rcases hmaskFalse : mask hd
        · rfl
        · exact absurd hmaskFalse hmaskhd
      simp only [hmaskhd', if_false, Bool.false_eq_true]
      exact ih _ htl

theorem scatter_readback_nat_prop_masked_nd {region : RegionName} {shape : TileShape}
    (s : BlockState) (offsetFn : TileIndex shape → Nat)
    (valueFn : TileIndex shape → Nat) (P : TileIndex shape → Prop) [DecidablePred P]
    (h_inj : Function.Injective offsetFn) (i : TileIndex shape) :
    BlockState.readMemValue ((TileShape.allIndices shape).foldl
       (fun acc k =>
         if P k then acc.writeMemTyped .nat region (offsetFn k) (valueFn k) else acc) s)
      .nat region (offsetFn i)
    = if P i then valueFn i else s.readMemValue .nat region (offsetFn i) := by
  let l := TileShape.allIndices shape
  obtain ⟨l₁, l₂, hl⟩ := List.append_of_mem (TileShape.mem_allIndices shape i)
  have h_nodup := TileShape.allIndices_nodup shape
  change BlockState.readMemValue ((l.foldl
       (fun acc k =>
         if P k then acc.writeMemTyped .nat region (offsetFn k) (valueFn k) else acc) s))
      .nat region (offsetFn i)
    = if P i then valueFn i else s.readMemValue .nat region (offsetFn i)
  rw [hl] at h_nodup
  rw [List.nodup_append, List.nodup_cons] at h_nodup
  obtain ⟨_, ⟨hi_notin_l2, _⟩, hl1_disj⟩ := h_nodup
  have hl' : l = l₁ ++ i :: l₂ := by
    simpa [l] using hl
  rw [hl', List.foldl_append, List.foldl_cons]
  have h_l1_not_in : ∀ k ∈ l₁, decide (P k) = true → offsetFn k ≠ offsetFn i := by
    intro k hk _hmk heq
    have hki : k = i := h_inj heq
    rw [hki] at hk
    exact (hl1_disj i hk i (List.mem_cons_self)) rfl
  have h_l2_not_in : ∀ k ∈ l₂, decide (P k) = true → offsetFn k ≠ offsetFn i := by
    intro k hk _hmk heq
    have hki : k = i := h_inj heq
    subst hki
    exact hi_notin_l2 hk
  have hstep :
      (fun (acc : BlockState) k =>
        if P k then acc.writeMemTyped .nat region (offsetFn k) (valueFn k) else acc)
        =
      (fun (acc : BlockState) k =>
        if decide (P k) then acc.writeMemTyped .nat region (offsetFn k) (valueFn k) else acc) := by
    funext acc k
    by_cases hk : P k <;> simp [hk]
  rw [hstep]
  rw [foldl_writeMemTyped_nat_masked_preserves offsetFn valueFn (fun k => decide (P k))
    (offsetFn i) l₂ _ h_l2_not_in]
  by_cases hPi : P i
  · simp only [hPi, if_true]
    rw [writeMemTyped_nat_readMemValue_nat]
    show (if region = region ∧ offsetFn i = offsetFn i then valueFn i else _) = valueFn i
    exact if_pos ⟨rfl, rfl⟩
  · simp only [hPi, if_false]
    rw [foldl_writeMemTyped_nat_masked_preserves offsetFn valueFn (fun k => decide (P k))
      (offsetFn i) l₁]
    exact h_l1_not_in

/-- A foldl of `writeMem` (real channel) at masked locations, with all writes
going to regions disjoint from `R`, leaves `readMem R off` unchanged. -/
theorem foldl_writeMem_prop_masked_readMem_other_region {α : Type}
    (regionFn : α → RegionName) (offsetFn : α → Nat) (valueFn : α → ℝ)
    (P : α → Prop) [DecidablePred P] (l : List α) (s : BlockState)
    (R : RegionName) (off : Nat)
    (h_other : ∀ k, k ∈ l → P k → R ≠ regionFn k) :
    BlockState.readMem ((l.foldl
        (fun acc k =>
          if P k then acc.writeMem (regionFn k) (offsetFn k) (valueFn k) else acc) s))
      R off
      = s.readMem R off := by
  induction l generalizing s with
  | nil => rfl
  | cons hd tl ih =>
      rw [List.foldl_cons]
      have htl : ∀ k, k ∈ tl → P k → R ≠ regionFn k :=
        fun k hk hPk => h_other k (List.mem_cons_of_mem hd hk) hPk
      by_cases hhd : P hd
      · simp only [hhd, if_true]
        rw [ih _ htl]
        rw [writeMem_readMem]
        rw [if_neg]
        rintro ⟨hR, _⟩
        exact (h_other hd (List.mem_cons_self) hhd) hR
      · simp only [hhd, if_false]
        exact ih _ htl

/-- Specialization of `foldl_writeMem_prop_masked_readMem_other_region` to
the case where all writes target the same constant `region`. Practical
shortcut for multi-store kernels (e.g. adam updates `p` then `exp_avg`): when
proving the second store's readback, the first store's foldl can be stripped
by `h : R ≠ region`. -/
theorem foldl_writeMem_const_region_prop_masked_readMem_other {α : Type}
    (region : RegionName) (offsetFn : α → Nat) (valueFn : α → ℝ)
    (P : α → Prop) [DecidablePred P] (l : List α) (s : BlockState)
    (R : RegionName) (off : Nat) (hRR : R ≠ region) :
    BlockState.readMem ((l.foldl
        (fun acc k =>
          if P k then acc.writeMem region (offsetFn k) (valueFn k) else acc) s))
      R off
      = s.readMem R off :=
  foldl_writeMem_prop_masked_readMem_other_region
    (regionFn := fun _ => region) offsetFn valueFn P l s R off
    (fun _ _ _ => hRR)

/-- Bool-predicate variant of
`foldl_writeMem_const_region_prop_masked_readMem_other`.

Higher-order `simp`/`rw` against the `Prop`-predicate form fails when `P` is
a complex masking λ because `[DecidablePred P]` synthesis runs *after*
pattern unification. This variant takes `P : α → Bool` directly, which
matches the `if (decide ...) then ... else ...` form `simp` normalises to,
without needing to synthesise a `Decidable` instance.

Targeted at multi-store surfaces (layer-norm forward with
`STORE_RESIDUAL_OUT=true`, etc.) where reads of one region must commute
past a masked foldl-scatter to another region. -/
theorem foldl_writeMem_const_region_bool_masked_readMem_other {α : Type}
    (region : RegionName) (offsetFn : α → Nat) (valueFn : α → ℝ)
    (P : α → Bool) (l : List α) (s : BlockState)
    (R : RegionName) (off : Nat) (hRR : R ≠ region) :
    BlockState.readMem ((l.foldl
        (fun acc k =>
          if P k then acc.writeMem region (offsetFn k) (valueFn k) else acc) s))
      R off
      = s.readMem R off := by
  induction l generalizing s with
  | nil => rfl
  | cons hd tl ih =>
      rw [List.foldl_cons]
      by_cases hhd : P hd = true
      · simp only [hhd, if_true]
        rw [ih]
        rw [writeMem_readMem]
        rw [if_neg]
        rintro ⟨hR, _⟩
        exact hRR hR
      · have : (P hd) = false := by
          cases hP : P hd <;> simp_all
        simp only [this]
        exact ih _

/-- Intra-region offset-disjointness companion to
`foldl_writeMem_const_region_prop_masked_readMem_other`. When all writes
in the foldl target the same `region` but at offsets disjoint from a given
read offset `off`, the foldl doesn't disturb `readMem region off`.

Use for kernels where multiple stores write to the SAME region at non-
overlapping offset sets — e.g. rotary embeddings (Q first-half offsets vs
Q second-half offsets) or fifth-order spherical harmonics (Y00..Y10 outputs
at different col offsets within the same output region). -/
theorem foldl_writeMem_same_region_disjoint_offsets_readMem {α : Type}
    (region : RegionName) (offsetFn : α → Nat) (valueFn : α → ℝ)
    (P : α → Prop) [DecidablePred P] (l : List α) (s : BlockState)
    (off : Nat) (hOff : ∀ k, k ∈ l → P k → off ≠ offsetFn k) :
    BlockState.readMem ((l.foldl
        (fun acc k =>
          if P k then acc.writeMem region (offsetFn k) (valueFn k) else acc) s))
      region off
      = s.readMem region off := by
  induction l generalizing s with
  | nil => rfl
  | cons hd tl ih =>
      rw [List.foldl_cons]
      have htl : ∀ k, k ∈ tl → P k → off ≠ offsetFn k :=
        fun k hk hPk => hOff k (List.mem_cons_of_mem hd hk) hPk
      by_cases hhd : P hd
      · simp only [hhd, if_true]
        rw [ih _ htl]
        rw [writeMem_readMem]
        rw [if_neg]
        rintro ⟨_, hOffEq⟩
        exact (hOff hd (List.mem_cons_self) hhd) hOffEq
      · simp only [hhd, if_false]
        exact ih _ htl

theorem foldl_writeMemTyped_natAt_prop_masked_readMem_other_region {α : Type}
    (regionFn : α → RegionName) (offsetFn : α → Nat) (valueFn : α → Nat)
    (P : α → Prop) [DecidablePred P] (l : List α) (s : BlockState)
    (R : RegionName) (off : Nat)
    (h_other : ∀ k, k ∈ l → P k → R ≠ regionFn k) :
    BlockState.readMem ((l.foldl
        (fun acc k =>
          if P k then acc.writeMemTyped .nat (regionFn k) (offsetFn k) (valueFn k) else acc) s))
      R off
      = s.readMem R off := by
  induction l generalizing s with
  | nil => rfl
  | cons hd tl ih =>
      rw [List.foldl_cons]
      have htl : ∀ k, k ∈ tl → P k → R ≠ regionFn k :=
        fun k hk hPk => h_other k (List.mem_cons_of_mem hd hk) hPk
      by_cases hhd : P hd
      · simp only [hhd, if_true]
        rw [ih _ htl]
        unfold readMem
        change (match
            (if R = regionFn hd ∧ off = offsetFn hd then
              MemCell.of TileDType.nat (valueFn hd)
            else s.mem R off).readAs TileDType.real with
          | some (some value) => value
          | _ => 0) =
          match (s.mem R off).readAs TileDType.real with
          | some (some value) => value
          | _ => 0
        rw [if_neg]
        rintro ⟨hR, _⟩
        exact (h_other hd (List.mem_cons_self) hhd) hR
      · simp only [hhd, if_false]
        exact ih _ htl

theorem scatter_readback_prop_masked_list_of_true {α : Type} {region : RegionName}
    (l : List α) (s : BlockState)
    (offsetFn : α → Nat) (valueFn : α → ℝ) (P : α → Prop) [DecidablePred P]
    (i : α) (h_nodup : l.Nodup) (h_mem : i ∈ l) (hPi : P i)
    (h_no_collision :
      ∀ k, k ∈ l → P k → offsetFn k = offsetFn i → k = i) :
    (l.foldl
       (fun acc k => if P k then acc.writeMem region (offsetFn k) (valueFn k) else acc) s).readMem region (offsetFn i)
    = valueFn i := by
  obtain ⟨l₁, l₂, hl⟩ := List.append_of_mem h_mem
  rw [hl] at h_nodup
  rw [List.nodup_append, List.nodup_cons] at h_nodup
  obtain ⟨_, ⟨hi_notin_l2, _⟩, _⟩ := h_nodup
  rw [hl, List.foldl_append, List.foldl_cons]
  have h_l2_not_in : ∀ k ∈ l₂, decide (P k) = true → offsetFn k ≠ offsetFn i := by
    intro k hk hPkDec heq
    have hPk : P k := by simpa only [decide_eq_true_eq] using hPkDec
    have hki : k = i :=
      h_no_collision k (by
        rw [hl]
        exact List.mem_append_right l₁ (List.mem_cons_of_mem i hk)) hPk heq
    subst hki
    exact hi_notin_l2 hk
  simp only [hPi, if_true]
  let st : BlockState :=
    (List.foldl
      (fun acc k => if P k then acc.writeMem region (offsetFn k) (valueFn k) else acc)
      s l₁).writeMem region (offsetFn i) (valueFn i)
  have hpres :=
    foldl_writeMem_masked_preserves (region := region) offsetFn valueFn (fun k => decide (P k))
      (offsetFn i) l₂ st h_l2_not_in
  have hstep :
      (fun (acc : BlockState) k => if P k then acc.writeMem region (offsetFn k) (valueFn k) else acc)
        =
      (fun (acc : BlockState) k =>
        if decide (P k) then acc.writeMem region (offsetFn k) (valueFn k) else acc) := by
    funext acc k
    by_cases hk : P k <;> simp [hk]
  change (List.foldl
      (fun acc k => if P k then acc.writeMem region (offsetFn k) (valueFn k) else acc)
      st l₂).readMem region (offsetFn i) = valueFn i
  rw [show List.foldl
      (fun acc k => if P k then acc.writeMem region (offsetFn k) (valueFn k) else acc)
      st l₂ =
    List.foldl
      (fun acc k => if decide (P k) then acc.writeMem region (offsetFn k) (valueFn k) else acc)
      st l₂ by
        rw [hstep]]
  rw [hpres]
  simp [BlockState.readMem, BlockState.writeMem, st]

theorem scatter_readback_prop_masked_nd_of_true {region : RegionName} {shape : TileShape}
    (s : BlockState) (offsetFn : TileIndex shape → Nat)
    (valueFn : TileIndex shape → ℝ) (P : TileIndex shape → Prop) [DecidablePred P]
    (i : TileIndex shape) (hPi : P i)
    (h_no_collision :
      ∀ k, P k → offsetFn k = offsetFn i → k = i) :
    ((TileShape.allIndices shape).foldl
       (fun acc k => if P k then acc.writeMem region (offsetFn k) (valueFn k) else acc) s).readMem region (offsetFn i)
    = valueFn i :=
  scatter_readback_prop_masked_list_of_true (TileShape.allIndices shape) s offsetFn valueFn P
    i (TileShape.allIndices_nodup shape) (TileShape.mem_allIndices shape i) hPi
    (fun k _hk hPk heq => h_no_collision k hPk heq)

theorem foldl_writeMem_prop_masked_readMem_base_ext {α : Type}
    (region : RegionName) (offsetFn : α → Nat) (valueFn : α → ℝ)
    (P : α → Prop) [DecidablePred P] (R : RegionName) (off : Nat)
    (l : List α) (s t : BlockState)
    (hmem : ∀ region offset, s.mem region offset = t.mem region offset) :
    ((l.foldl
        (fun acc k => if P k then acc.writeMem region (offsetFn k) (valueFn k) else acc)
        s).readMem R off) =
      ((l.foldl
        (fun acc k => if P k then acc.writeMem region (offsetFn k) (valueFn k) else acc)
        t).readMem R off) := by
  induction l generalizing s t with
  | nil =>
      simp [readMem, hmem]
  | cons hd tl ih =>
      rw [List.foldl_cons]
      by_cases hP : P hd
      · simp [hP]
        apply ih
        intro region' offset'
        simp [writeMem, hmem]
      · simp [hP]
        exact ih s t hmem

theorem scatter_preserves_other_region {α : Type}
    (region : RegionName) (offsetFn : α → Nat) (valueFn : α → ℝ)
    (R : RegionName) (h_ne : R ≠ region) (off : Nat) :
    ∀ (l : List α) (s : BlockState),
      ((l.foldl (fun acc k => acc.writeMem region (offsetFn k) (valueFn k)) s).readMem R off)
      = s.readMem R off := by
  intro l
  induction l with
  | nil => intros; rfl
  | cons hd tl ih =>
    intro s
    rw [List.foldl_cons, ih]
    show (s.writeMem region (offsetFn hd) (valueFn hd)).readMem R off = s.readMem R off
    rw [writeMem_readMem]
    show (if R = region ∧ off = offsetFn hd then valueFn hd else s.readMem R off)
        = s.readMem R off
    rw [if_neg]
    rintro ⟨h_R, _⟩
    exact h_ne h_R

theorem scatter_prop_masked_preserves_other_region {α : Type}
    (region : RegionName) (offsetFn : α → Nat) (valueFn : α → ℝ)
    (P : α → Prop) [DecidablePred P]
    (R : RegionName) (h_ne : R ≠ region) (off : Nat) :
    ∀ (l : List α) (s : BlockState),
      ((l.foldl
        (fun acc k => if P k then acc.writeMem region (offsetFn k) (valueFn k) else acc)
        s).readMem R off) = s.readMem R off := by
  intro l
  induction l with
  | nil => intros; rfl
  | cons hd tl ih =>
    intro s
    rw [List.foldl_cons, ih]
    by_cases hP : P hd
    · simp only [hP, if_true]
      rw [writeMem_readMem]
      show (if R = region ∧ off = offsetFn hd then valueFn hd else s.readMem R off)
          = s.readMem R off
      rw [if_neg]
      rintro ⟨h_R, _⟩
      exact h_ne h_R
    · simp [hP]

theorem scatter_prop_masked_preserves_other_offset {α : Type}
    (region : RegionName) (offsetFn : α → Nat) (valueFn : α → ℝ)
    (P : α → Prop) [DecidablePred P] (off : Nat)
    (h_ne : ∀ k, P k → offsetFn k ≠ off) :
    ∀ (l : List α) (s : BlockState),
      ((l.foldl
        (fun acc k => if P k then acc.writeMem region (offsetFn k) (valueFn k) else acc)
        s).readMem region off) = s.readMem region off := by
  intro l
  induction l with
  | nil => intros; rfl
  | cons hd tl ih =>
    intro s
    rw [List.foldl_cons, ih]
    by_cases hP : P hd
    · simp only [hP, if_true]
      rw [writeMem_readMem]
      show (if region = region ∧ off = offsetFn hd then valueFn hd else s.readMem region off)
          = s.readMem region off
      rw [if_neg]
      rintro ⟨_, h_off⟩
      exact h_ne hd hP h_off.symm
    · simp [hP]

@[simp] theorem foldl_writeMem_regs {α : Type}
    (region : RegionName) (offsetFn : α → Nat) (valueFn : α → ℝ)
    (l : List α) (s : BlockState) (dtype : TileDType) (shape : TileShape)
    (name : RegName) :
    ((l.foldl (fun acc k => acc.writeMem region (offsetFn k) (valueFn k)) s).regs
      dtype shape name) = s.regs dtype shape name := by
  induction l generalizing s with
  | nil => rfl
  | cons hd tl ih =>
      rw [List.foldl_cons, ih]
      rfl

@[simp] theorem foldl_writeMem_dependent_regs {α : Type}
    (region : RegionName) (offsetFn : α → Nat)
    (valueFn : BlockState → α → ℝ)
    (l : List α) (s : BlockState) (dtype : TileDType) (shape : TileShape)
    (name : RegName) :
    ((l.foldl (fun acc k => acc.writeMem region (offsetFn k) (valueFn acc k)) s).regs
      dtype shape name) = s.regs dtype shape name := by
  induction l generalizing s with
  | nil => rfl
  | cons hd tl ih =>
      rw [List.foldl_cons, ih]
      rfl

theorem foldl_writeMem_pid {α : Type}
    (region : RegionName) (offsetFn : α → Nat) (valueFn : α → ℝ)
    (l : List α) (s : BlockState) :
    ((l.foldl (fun acc k => acc.writeMem region (offsetFn k) (valueFn k)) s).pid)
      = s.pid := by
  induction l generalizing s with
  | nil => rfl
  | cons hd tl ih =>
      rw [List.foldl_cons, ih]
      simp

theorem foldl_writeMem_masked_pid {α : Type}
    (region : RegionName) (offsetFn : α → Nat) (valueFn : α → ℝ)
    (mask : α → Bool) (l : List α) (s : BlockState) :
    ((l.foldl
        (fun acc k =>
          if mask k then acc.writeMem region (offsetFn k) (valueFn k) else acc) s).pid)
      = s.pid := by
  induction l generalizing s with
  | nil => rfl
  | cons hd tl ih =>
      rw [List.foldl_cons, ih]
      by_cases hmask : mask hd
      · simp [hmask]
      · simp [hmask]

theorem foldl_writeMem_prop_masked_pid {α : Type}
    (region : RegionName) (offsetFn : α → Nat) (valueFn : α → ℝ)
    (P : α → Prop) [DecidablePred P] (l : List α) (s : BlockState) :
    ((l.foldl
        (fun acc k =>
          if P k then acc.writeMem region (offsetFn k) (valueFn k) else acc)
        s).pid) = s.pid := by
  induction l generalizing s with
  | nil => rfl
  | cons hd tl ih =>
      rw [List.foldl_cons, ih]
      by_cases hP : P hd
      · simp [hP]
      · simp [hP]

theorem foldl_writeMem_prop_masked_pids {α : Type}
    (region : RegionName) (offsetFn : α → Nat) (valueFn : α → ℝ)
    (P : α → Prop) [DecidablePred P] (l : List α) (s : BlockState) :
    ((l.foldl
        (fun acc k =>
          if P k then acc.writeMem region (offsetFn k) (valueFn k) else acc)
        s).pids) = s.pids := by
  induction l generalizing s with
  | nil => rfl
  | cons hd tl ih =>
      rw [List.foldl_cons, ih]
      by_cases hP : P hd
      · simp [hP]
      · simp [hP]

theorem foldl_writeMemAt_pid {α : Type}
    (regionFn : α → RegionName) (offsetFn : α → Nat) (valueFn : α → ℝ)
    (l : List α) (s : BlockState) :
    ((l.foldl (fun acc k => acc.writeMem (regionFn k) (offsetFn k) (valueFn k)) s).pid)
      = s.pid := by
  induction l generalizing s with
  | nil => rfl
  | cons hd tl ih =>
      rw [List.foldl_cons, ih]
      simp

theorem foldl_writeMemAt_masked_pid {α : Type}
    (regionFn : α → RegionName) (offsetFn : α → Nat) (valueFn : α → ℝ)
    (mask : α → Bool) (l : List α) (s : BlockState) :
    ((l.foldl
        (fun acc k =>
          if mask k then acc.writeMem (regionFn k) (offsetFn k) (valueFn k) else acc) s).pid)
      = s.pid := by
  induction l generalizing s with
  | nil => rfl
  | cons hd tl ih =>
      rw [List.foldl_cons, ih]
      by_cases hmask : mask hd
      · simp [hmask]
      · simp [hmask]

theorem foldl_writeMemAs_pid {α : Type} (dtype : FloatDType)
    (region : RegionName) (offsetFn : α → Nat)
    (valueFn : α → TileCarrier dtype.toTileDType)
    (l : List α) (s : BlockState) :
    ((l.foldl (fun acc k => acc.writeMemAs dtype region (offsetFn k) (valueFn k)) s).pid)
      = s.pid := by
  induction l generalizing s with
  | nil => rfl
  | cons hd tl ih =>
      rw [List.foldl_cons, ih]
      simp

theorem foldl_writeMemAs_masked_pid {α : Type} (dtype : FloatDType)
    (region : RegionName) (offsetFn : α → Nat)
    (valueFn : α → TileCarrier dtype.toTileDType)
    (mask : α → Bool) (l : List α) (s : BlockState) :
    ((l.foldl
        (fun acc k =>
          if mask k then acc.writeMemAs dtype region (offsetFn k) (valueFn k) else acc) s).pid)
      = s.pid := by
  induction l generalizing s with
  | nil => rfl
  | cons hd tl ih =>
      rw [List.foldl_cons, ih]
      by_cases hmask : mask hd
      · simp [hmask]
      · simp [hmask]

theorem foldl_writeMemAsAt_pid {α : Type} (dtype : FloatDType)
    (regionFn : α → RegionName) (offsetFn : α → Nat)
    (valueFn : α → TileCarrier dtype.toTileDType)
    (l : List α) (s : BlockState) :
    ((l.foldl (fun acc k => acc.writeMemAs dtype (regionFn k) (offsetFn k) (valueFn k)) s).pid)
      = s.pid := by
  induction l generalizing s with
  | nil => rfl
  | cons hd tl ih =>
      rw [List.foldl_cons, ih]
      simp

theorem foldl_writeMemAsAt_masked_pid {α : Type} (dtype : FloatDType)
    (regionFn : α → RegionName) (offsetFn : α → Nat)
    (valueFn : α → TileCarrier dtype.toTileDType)
    (mask : α → Bool) (l : List α) (s : BlockState) :
    ((l.foldl
        (fun acc k =>
          if mask k then acc.writeMemAs dtype (regionFn k) (offsetFn k) (valueFn k) else acc) s).pid)
      = s.pid := by
  induction l generalizing s with
  | nil => rfl
  | cons hd tl ih =>
      rw [List.foldl_cons, ih]
      by_cases hmask : mask hd
      · simp [hmask]
      · simp [hmask]

theorem foldl_writeMemTyped_pid {α : Type} (dtype : TileDType)
    (region : RegionName) (offsetFn : α → Nat)
    (valueFn : α → TileCarrier dtype)
    (l : List α) (s : BlockState) :
    ((l.foldl (fun acc k => acc.writeMemTyped dtype region (offsetFn k) (valueFn k)) s).pid)
      = s.pid := by
  induction l generalizing s with
  | nil => rfl
  | cons hd tl ih =>
      rw [List.foldl_cons, ih]
      simp

@[simp] theorem foldl_writeMem_masked_regs {α : Type}
    (region : RegionName) (offsetFn : α → Nat)
    (valueFn : α → ℝ)
    (mask : α → Bool) (l : List α) (s : BlockState)
    (dtype : TileDType) (shape : TileShape) (name : RegName) :
    ((l.foldl
        (fun acc k => if mask k then acc.writeMem region (offsetFn k) (valueFn k) else acc) s).regs
        dtype shape name)
      = s.regs dtype shape name := by
  induction l generalizing s with
  | nil => rfl
  | cons hd tl ih =>
      rw [List.foldl_cons, ih]
      by_cases hmask : mask hd
      · simp [hmask]
      · simp [hmask]

@[simp] theorem foldl_writeMem_prop_masked_regs {α : Type}
    (region : RegionName) (offsetFn : α → Nat)
    (valueFn : α → ℝ)
    (P : α → Prop) [DecidablePred P] (l : List α) (s : BlockState)
    (dtype : TileDType) (shape : TileShape) (name : RegName) :
    ((l.foldl
        (fun acc k => if P k then acc.writeMem region (offsetFn k) (valueFn k) else acc) s).regs
        dtype shape name)
      = s.regs dtype shape name := by
  induction l generalizing s with
  | nil => rfl
  | cons hd tl ih =>
      rw [List.foldl_cons, ih]
      by_cases hmask : P hd
      · simp [hmask]
      · simp [hmask]

@[simp] theorem foldl_writeMem_prop_masked_setReg_same {α : Type}
    (region : RegionName) (offsetFn : α → Nat)
    (valueFn : α → ℝ)
    (P : α → Prop) [DecidablePred P] (l : List α) (s : BlockState)
    (name : RegName) (dtype : TileDType) (shape : TileShape)
    (v : Tile dtype shape) :
    ((l.foldl
        (fun acc k => if P k then acc.writeMem region (offsetFn k) (valueFn k) else acc)
        (s.setReg name dtype shape v)).regs dtype shape name) =
      some v := by
  rw [foldl_writeMem_prop_masked_regs]
  simp

@[simp] theorem foldl_writeMemTyped_regs {α : Type} (dtype : TileDType)
    (region : RegionName) (offsetFn : α → Nat)
    (valueFn : α → TileCarrier dtype)
    (l : List α) (s : BlockState)
    (dtype' : TileDType) (shape : TileShape) (name : RegName) :
    ((l.foldl (fun acc k => acc.writeMemTyped dtype region (offsetFn k) (valueFn k)) s).regs
        dtype' shape name)
      = s.regs dtype' shape name := by
  induction l generalizing s with
  | nil => rfl
  | cons hd tl ih =>
      rw [List.foldl_cons, ih]
      simp

theorem foldl_writeMemTyped_masked_pid {α : Type} (dtype : TileDType)
    (region : RegionName) (offsetFn : α → Nat)
    (valueFn : α → TileCarrier dtype)
    (mask : α → Bool) (l : List α) (s : BlockState) :
    ((l.foldl
        (fun acc k =>
          if mask k then acc.writeMemTyped dtype region (offsetFn k) (valueFn k) else acc) s).pid)
      = s.pid := by
  induction l generalizing s with
  | nil => rfl
  | cons hd tl ih =>
      rw [List.foldl_cons, ih]
      by_cases hmask : mask hd
      · simp [hmask]
      · simp [hmask]

@[simp] theorem foldl_writeMemTyped_masked_regs {α : Type} (dtype : TileDType)
    (region : RegionName) (offsetFn : α → Nat)
    (valueFn : α → TileCarrier dtype)
    (mask : α → Bool) (l : List α) (s : BlockState)
    (dtype' : TileDType) (shape : TileShape) (name : RegName) :
    ((l.foldl
        (fun acc k =>
          if mask k then acc.writeMemTyped dtype region (offsetFn k) (valueFn k) else acc) s).regs
        dtype' shape name)
      = s.regs dtype' shape name := by
  induction l generalizing s with
  | nil => rfl
  | cons hd tl ih =>
      rw [List.foldl_cons, ih]
      by_cases hmask : mask hd
      · simp [hmask]
      · simp [hmask]

theorem foldl_writeMemTypedAt_pid {α : Type} (dtype : TileDType)
    (regionFn : α → RegionName) (offsetFn : α → Nat)
    (valueFn : α → TileCarrier dtype)
    (l : List α) (s : BlockState) :
    ((l.foldl (fun acc k => acc.writeMemTyped dtype (regionFn k) (offsetFn k) (valueFn k)) s).pid)
      = s.pid := by
  induction l generalizing s with
  | nil => rfl
  | cons hd tl ih =>
      rw [List.foldl_cons, ih]
      simp

theorem foldl_writeMemTypedAt_masked_pid {α : Type} (dtype : TileDType)
    (regionFn : α → RegionName) (offsetFn : α → Nat)
    (valueFn : α → TileCarrier dtype)
    (mask : α → Bool) (l : List α) (s : BlockState) :
    ((l.foldl
        (fun acc k =>
          if mask k then acc.writeMemTyped dtype (regionFn k) (offsetFn k) (valueFn k) else acc) s).pid)
      = s.pid := by
  induction l generalizing s with
  | nil => rfl
  | cons hd tl ih =>
      rw [List.foldl_cons, ih]
      by_cases hmask : mask hd
      · simp [hmask]
      · simp [hmask]

@[simp] theorem foldl_writeMemTypedAt_masked_regs {α : Type} (dtype : TileDType)
    (regionFn : α → RegionName) (offsetFn : α → Nat)
    (valueFn : α → TileCarrier dtype)
    (mask : α → Bool) (l : List α) (s : BlockState)
    (dtype' : TileDType) (shape : TileShape) (name : RegName) :
    ((l.foldl
        (fun acc k =>
          if mask k then acc.writeMemTyped dtype (regionFn k) (offsetFn k) (valueFn k) else acc) s).regs
        dtype' shape name)
      = s.regs dtype' shape name := by
  induction l generalizing s with
  | nil => rfl
  | cons hd tl ih =>
      rw [List.foldl_cons, ih]
      by_cases hmask : mask hd
      · simp [hmask]
      · simp [hmask]

/-! ### Whole-memory (cell-level) frame toolkit for scatter stores

Used by the `ComputeRefine.Refines_without_Rounding` writes-equality surface: two kernels
that scatter the same offsets with pointwise-equal values leave equal
memories, and every cell they do not hit is preserved. -/

/-- Cell-level characterization of a single scalar write (definitional). -/
theorem writeMem_mem (s : BlockState) (region : RegionName) (offset : Nat)
    (v : ℝ) (r : RegionName) (o : Nat) :
    (s.writeMem region offset v).mem r o =
      if r = region ∧ o = offset then MemCell.real v else s.mem r o := rfl

/-- Pointwise-mem congruence for unmasked `writeMem` scatters: same offsets,
pointwise-equal values, bases agreeing at the observed cell — equal cells.
No injectivity needed. -/
theorem foldl_writeMem_mem_congr {α : Type} {region : RegionName}
    (l : List α) (offsetFn : α → Nat) (vL vR : α → ℝ)
    (hv : ∀ k ∈ l, vL k = vR k) (r : RegionName) (o : Nat) :
    ∀ (sL sR : BlockState), sL.mem r o = sR.mem r o →
      ((l.foldl (fun acc k => acc.writeMem region (offsetFn k) (vL k)) sL).mem r o
        = (l.foldl (fun acc k => acc.writeMem region (offsetFn k) (vR k)) sR).mem r o) := by
  induction l with
  | nil => intro sL sR h; exact h
  | cons hd tl ih =>
      intro sL sR h
      rw [List.foldl_cons, List.foldl_cons]
      refine ih (fun k hk => hv k (List.mem_cons_of_mem hd hk)) _ _ ?_
      rw [writeMem_mem, writeMem_mem, hv hd (List.mem_cons_self), h]

/-- An unmasked `writeMem` scatter into `region` leaves every other region's
cells untouched. -/
theorem foldl_writeMem_mem_preserve_other_region {α : Type} {region : RegionName}
    (offsetFn : α → Nat) (valueFn : α → ℝ) (l : List α)
    (r : RegionName) (hr : r ≠ region) (o : Nat) :
    ∀ s : BlockState,
      ((l.foldl (fun acc k => acc.writeMem region (offsetFn k) (valueFn k)) s).mem r o)
        = s.mem r o := by
  induction l with
  | nil => intro s; rfl
  | cons hd tl ih =>
      intro s
      rw [List.foldl_cons, ih, writeMem_mem,
        if_neg (fun hc => hr hc.1)]

/-- An unmasked `writeMem` scatter preserves every offset it does not hit. -/
theorem foldl_writeMem_mem_preserve_unhit {α : Type} {region : RegionName}
    (offsetFn : α → Nat) (valueFn : α → ℝ) (l : List α)
    (o : Nat) (ho : ∀ k ∈ l, offsetFn k ≠ o) :
    ∀ s : BlockState,
      ((l.foldl (fun acc k => acc.writeMem region (offsetFn k) (valueFn k)) s).mem region o)
        = s.mem region o := by
  induction l with
  | nil => intro s; rfl
  | cons hd tl ih =>
      intro s
      rw [List.foldl_cons, ih (fun k hk => ho k (List.mem_cons_of_mem hd hk)),
        writeMem_mem, if_neg (fun hc => ho hd (List.mem_cons_self) hc.2.symm)]

end BlockState

end VeriTile.Triton

/-! ## Fresh-launch register reset (#447 Phase C.5)

A real kernel launch starts from an empty register file: registers never
survive across launches, only global memory (and the launch environment —
program ids, grid dimensions, undef) does. `BlockState.resetRegs` is that
fresh-launch state; the honest multi-launch pipeline semantics
(`VeriTile.Triton.Float.Pipeline`) resets registers before every stage. -/

namespace VeriTile.Triton

namespace BlockState

/-- Fresh-launch state: clear every register binding; keep memory, program
ids, the undef environment, and the launch-grid dimensions. -/
def resetRegs (s : BlockState) : BlockState :=
  { s with regs := fun _ _ _ => none }

@[simp] theorem resetRegs_mem (s : BlockState) (region : RegionName) (offset : Nat) :
    s.resetRegs.mem region offset = s.mem region offset := rfl

@[simp] theorem resetRegs_regs (s : BlockState) (dtype : TileDType)
    (shape : TileShape) (name : RegName) :
    s.resetRegs.regs dtype shape name = none := rfl

@[simp] theorem resetRegs_pids (s : BlockState) : s.resetRegs.pids = s.pids := rfl

@[simp] theorem resetRegs_pid (s : BlockState) : s.resetRegs.pid = s.pid := rfl

@[simp] theorem resetRegs_undef (s : BlockState) (region : RegionName) (offset : Nat) :
    s.resetRegs.undef region offset = s.undef region offset := rfl

@[simp] theorem resetRegs_numPids (s : BlockState) : s.resetRegs.numPids = s.numPids := rfl

@[simp] theorem resetRegs_readMem (s : BlockState) (region : RegionName) (offset : Nat) :
    s.resetRegs.readMem region offset = s.readMem region offset := rfl

@[simp] theorem resetRegs_readMemAs (s : BlockState) (dtype : FloatDType)
    (region : RegionName) (offset : Nat) :
    s.resetRegs.readMemAs dtype region offset = s.readMemAs dtype region offset := rfl

@[simp] theorem resetRegs_readMemTyped (s : BlockState) (dtype : TileDType)
    (region : RegionName) (offset : Nat) :
    s.resetRegs.readMemTyped dtype region offset = s.readMemTyped dtype region offset := rfl

@[simp] theorem resetRegs_readMemValue (s : BlockState) (dtype : TileDType)
    (region : RegionName) (offset : Nat) :
    s.resetRegs.readMemValue dtype region offset = s.readMemValue dtype region offset := by
  cases dtype <;> rfl

end BlockState

end VeriTile.Triton
