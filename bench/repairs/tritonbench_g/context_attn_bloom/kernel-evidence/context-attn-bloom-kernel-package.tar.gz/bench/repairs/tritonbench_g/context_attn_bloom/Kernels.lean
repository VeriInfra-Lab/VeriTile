import bench.tritonbench_g.context_attn_bloom.Kernels

/-! Canonical source-only entry for the direct checked Bloom repair.

The selected source is the original FP32 floating body, including its finite
causal sentinel and guarded normalized accumulator recurrence. Python widens
only integer indices and metadata loads; the checked native bounds establish
their exactness. This entry imports the original source translation directly,
without the historical `Whole001.Kernels` proof-layer dependencies.
-/
namespace VeriTile.Bench.Repairs.ContextAttnBloomSource

/-- The original typed source specialized to the repaired FP32 storage domain. -/
noncomputable abbrev kernel :=
  VeriTile.Bench.TritonBenchG.ContextAttnBloom.original
    VeriTile.Bench.TritonBenchG.ContextAttnBloom.Storage.fp32

end VeriTile.Bench.Repairs.ContextAttnBloomSource
