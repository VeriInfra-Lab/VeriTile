# Direct checked Bloom context attention

`context_attn_bloom_repaired.py` executes the original floating kernel directly
on the supplied output. Only program IDs, aranges, signed metadata loads, and
page loads are widened to int64. The finite `-1e8` score mask, natural exponential,
normalized accumulator recurrence, accumulator-scale guard, casts, dot operations,
and padded-channel masks retain the original AST.

The supported domain is ordinary, resolved, contiguous CUDA FP32 payload tensors:
Q/Out `[T,H,D]`, K/V `[C,Hkv,D]`, `16 <= D <= 256`, integral grouped heads, four
contiguous int32 metadata vectors, and a canonical contiguous int32 page table.
Read storage may alias. The entire output backing allocation must be separate
from all reads, including separately constructed overlapping storage objects.
The wrapper checks actual metadata/page values, packed intervals, capacity,
alignment, byte storage extents, CUDA grid limits, and conservative bounds for
all formed pointers, including masked row/channel/table tails. It computes the
actual maximum uncached length and skips empty work. No floating tensor is copied
or staged. The call returns `None` and restores the caller's device context.

`Kernels.lean` is the canonical source-only entry. It imports the original
source translation directly and exposes `ContextAttnBloomSource.kernel`,
specialized to original FP32 storage. It does not import the historical
`Whole001.Kernels` helper or its proof-layer dependencies.

`Correct.lean` exposes `Checked.whole_mathematical_real`. Its independent
arbitrary-Real target is a prefix numerator/denominator recurrence with the
original guarded retention of the old accumulator. That guard and the finite
sentinel are observable semantics; ideal strict causal softmax is a different
function. The exact scalar table records the original Python ordered host
expression followed by FP32 launch conversion for every admitted width.

`FPEquiv.lean` exposes `CheckedTensor.whole_tensor_fp32` and its explicit
instruction-local transport theorem `whole_tensor_if_local`.
`FPReference` independently defines gathered tiles and the full normalized
floating recurrence from initial arrays and scalar metadata. Constructive
prelude/body/loop/epilogue/grid theorems connect the complete typed source to it.
The byte and Tensor results cover raw initial FP32/int32 bytes, unique stores,
full output-backing and input frames, logical Tensor readback, output object
identity, empty calls, `None`, and device context restoration.

The native graph keeps explicit SM80 m16n8k8 TF32 chains, the live PV accumulator,
normalizer FMA contraction, exp2 lowering of natural exp through raw log2(e)
constant `0x3FB8AA3B`, and complete ordered reduction trees. `Bytes.Profile`
contains the structural compiler plan and physical final-store owner. This is
an explicit external compiler-profile correspondence boundary, and its choices
are consumed by native evaluation. No claim of a selected compiled artifact or
compiler verification is made. Numerical interpretation is deferred only at the
nine individual instruction families in `Native.WordISA`; `Returned.LocalLaws`
quantifies over all primitive operands, not over tile or output results.

The restored `Whole001` files preserve their historical APIs. Historical
staging and output-agreement entry points are not the canonical repaired API.
The original benchmark Python and original proof files are unchanged.

Validation: `python check_contract.py` executes the actual Triton CPU
interpreter with explicitly labeled CUDA metadata/device-context facades. It
checks the floating AST, both tile branches, grouped heads, gathered/duplicate
pages, prompt cache, padded width 96, multiple tiles, frames, aliases, empty
calls, finite-sentinel behavior, the observable guarded-accumulator case
(`1 + 7/128` versus `71/128`), invalid inputs, and every host scalar constant.
CUDA hardware is unavailable; these checks are not GPU execution validation.
