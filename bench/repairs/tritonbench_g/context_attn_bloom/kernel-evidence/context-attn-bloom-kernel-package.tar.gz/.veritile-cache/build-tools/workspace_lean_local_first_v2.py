"""Compile only requested task modules into workspace storage; existing cache is read-only."""
import hashlib,json,os,subprocess,sys,fcntl
from pathlib import Path
ROOT=Path('/mnt/VerifiableAILab/VerifiableAILab/zenan.li/VeriTile')
OUT=ROOT/'.veritile-cache/kernel-build/lib/lean'
PACKAGES=Path('/tmp/veritile-tritonbench-lake/packages')
# Resolve local-only package/toolchain namespaces before probing CPFS. Repository
# overrides still precede the baseline, and collisions fail closed.
PACKAGE_LIBS=[PACKAGES/x/'.lake/build/lib/lean' for x in ['Cli','batteries','Qq','aesop','proofwidgets','importGraph','LeanSearchClient','plausible','mathlib']]
TOOLCHAIN_LIB=Path('/tmp/veritile-lean-toolchain/lib/lean')
def root_names(path):
 return {p.name.split('.',1)[0] for p in path.iterdir()} if path.is_dir() else set()
REPO_NAMES=root_names(OUT)|root_names(ROOT/'.lake/build/lib/lean')
for local_root in [TOOLCHAIN_LIB,*PACKAGE_LIBS]:
 assert not (root_names(local_root)&REPO_NAMES),('namespace overlap',local_root)
LIBS=[str(p) for p in [*PACKAGE_LIBS,TOOLCHAIN_LIB,OUT,ROOT/'.lake/build/lib/lean']]

ENV=os.environ.copy();ENV.update(LEAN_PATH=':'.join(LIBS),LEAN_NUM_THREADS='2')
LEAN='/tmp/veritile-lean-toolchain/bin/lean'

BASE=ROOT/'.lake/build/lib/lean'
def owned_family(out, name):
 # A build owns the entire module output family, including files Lean has
 # not emitted yet. Concurrent namespace mirroring must never recreate a
 # baseline symlink that the compiler could follow while writing.
 stem=name.split('.',1)[0]
 marker=out/(stem+'.workspace-owned')
 primary=out/(stem+'.olean')
 receipt=out/(stem+'.workspace-build.json')
 return marker.exists() or (primary.is_file() and not primary.is_symlink()) or (receipt.is_file() and not receipt.is_symlink())
def mirror_cached_slow(base, out):
 out.mkdir(parents=True,exist_ok=True)
 if not base.is_dir():return
 for child in base.iterdir():
  target=out/child.name
  if not child.is_dir() and owned_family(out,child.name):continue
  if not os.path.lexists(target):
   target.symlink_to(child.absolute(),target_is_directory=child.is_dir())
  elif child.is_dir() and target.is_dir() and not target.is_symlink():
   mirror_cached_slow(child,target)
def mirror_cached(base, out):
 # Still performs a full mirror under overlay.lock on every call. There is no
 # persistent completeness sentinel or baseline cache. The baseline is read-only
 # and writers create family ownership under that same lock before Lean runs.
 out.mkdir(parents=True,exist_ok=True)
 if not base.is_dir():return
 try:
  with os.scandir(base) as scan: children=list(scan)
  with os.scandir(out) as scan: existing={entry.name:entry for entry in scan}
  # An unexpected baseline ownership marker can change ownership mid-mirror.
  # Preserve the original operation-by-operation behavior for that directory.
  if any(entry.name.endswith('.workspace-owned') for entry in children):
   return mirror_cached_slow(base,out)
  owners=set()
  for name,entry in existing.items():
   stem=name.split('.',1)[0]
   if name==stem+'.workspace-owned':
    if not entry.is_symlink() or os.path.exists(entry.path):owners.add(stem)
   elif name in (stem+'.olean',stem+'.workspace-build.json'):
    if not entry.is_symlink() and entry.is_file():owners.add(stem)
  children=[(entry,entry.is_dir()) for entry in children]
 except OSError:
  # No mirror writes occurred before this point. Re-enumerate with the original
  # algorithm; its errors still fail the build instead of omitting imports.
  return mirror_cached_slow(base,out)
 for child,is_directory in children:
  target=out/child.name
  if not is_directory and child.name.split('.',1)[0] in owners:continue
  entry=existing.get(child.name)
  if entry is None:
   target.symlink_to(Path(child.path).absolute(),target_is_directory=is_directory)
  elif is_directory and not entry.is_symlink() and entry.is_dir():
   mirror_cached(Path(child.path),target)
def writable_parent(rel):
 node=OUT
 for part in rel.parts:
  node=node/part
  if node.is_symlink():
   origin=node.resolve()
   assert origin.is_dir(),node
   node.unlink();node.mkdir()
   mirror_cached(origin,node)
  else:node.mkdir(exist_ok=True)
 return node
OUT.mkdir(parents=True,exist_ok=True)
with open(OUT.parent/'overlay.lock','w') as lock:
 fcntl.flock(lock,fcntl.LOCK_EX)
 mirror_cached(BASE,OUT)
 fcntl.flock(lock,fcntl.LOCK_UN)

def sha(p):return hashlib.sha256(p.read_bytes()).hexdigest()
if len(sys.argv)>1 and sys.argv[1]=='--check':
 raise SystemExit(subprocess.call([LEAN,'-s','32768','--root='+str(ROOT),*sys.argv[2:]],cwd=ROOT,env=ENV))
for name in sys.argv[1:]:
 rel=Path(name) if name.endswith('.lean') else Path(name.replace('.','/')+'.lean')
 src=ROOT/rel
 assert src.is_file() and src.resolve().is_relative_to(ROOT),src
 rel=src.relative_to(ROOT)
 with open(OUT.parent/'overlay.lock','w') as lock:
  fcntl.flock(lock,fcntl.LOCK_EX)
  parent=writable_parent(rel.parent)
  target=parent/rel.with_suffix('.olean').name
  target.with_suffix('.workspace-owned').touch()
  for old_link in parent.glob(target.stem+'.*'):
   if old_link.is_symlink():old_link.unlink()
  fcntl.flock(lock,fcntl.LOCK_UN)
 initial=sha(src)
 cmd=[LEAN,'-s','32768','--root='+str(ROOT),str(src),'-o',str(target),'-i',str(target.with_suffix('.ilean'))]
 code=subprocess.call(cmd,cwd=ROOT,env=ENV)
 if code:raise SystemExit(code)
 assert sha(src)==initial,('source changed during compile',src)
 objects={str(p):sha(p) for p in target.parent.glob(target.stem+'.*') if p.is_file() and not p.name.endswith('.workspace-build.json')}
 record={'source':str(rel),'source_sha256':initial,'exit_code':0,'objects':objects,'lean_path':LIBS}
 target.with_suffix('.workspace-build.json').write_text(json.dumps(record,indent=2)+'\n')
 print(json.dumps({'module':str(rel),'exit_code':0,'output':str(target)},ensure_ascii=False),flush=True)
