"""Freeze the checked kernel revision after its complete task build succeeds."""
from pathlib import Path
import gzip,hashlib,io,json,tarfile
ROOT=Path.cwd();TASK=ROOT/'bench/repairs/tritonbench_g/context_attn_bloom';CACHE=ROOT/'.veritile-cache/task-deliveries/context_attn_bloom';EVIDENCE=TASK/'kernel-evidence';OVERLAY=ROOT/'.veritile-cache/kernel-build/lib/lean'
def sha(p):return hashlib.sha256(p.read_bytes()).hexdigest()
def pin(p):return {'path':str(p.relative_to(ROOT)),'sha256':sha(p)}
def write(name,data):
 p=EVIDENCE/name;p.write_text(json.dumps(data,indent=2)+'\n');return p
def verify(record):
 p=ROOT/record['path'];assert sha(p)==record['sha256'],record['path'];return p
log=(CACHE/'full-task-build.log').read_text()
assert ': error' not in log and 'sorryAx' not in log and 'DISALLOWED' not in log
rows=[json.loads(line) for line in log.splitlines() if line.startswith('{"module":')]
assert len(rows)==37 and len({row['module'] for row in rows})==37
assert {ROOT/row['module'] for row in rows}==set(TASK.rglob('*.lean'))
receipts=[]
for row in rows:
 assert row['exit_code']==0
 src=ROOT/row['module'];receipt=(OVERLAY/row['module']).with_suffix('.workspace-build.json')
 data=json.loads(receipt.read_text());assert data['exit_code']==0 and data['source_sha256']==sha(src)
 for name,wanted in data['objects'].items():
  obj=Path(name);assert obj.is_relative_to(OVERLAY) and obj.is_file() and not obj.is_symlink()
  assert sha(obj)==wanted,name
 receipts.append({'module':row['module'],'receipt':pin(receipt),'source_sha256':data['source_sha256'],'objects_verified':len(data['objects'])})
review_log=(CACHE/'review-fix-build.log').read_text()
assert ': error' not in review_log and 'sorryAx' not in review_log and 'DISALLOWED' not in review_log
review_rows=[json.loads(line) for line in review_log.splitlines() if line.startswith('{"module":')]
assert [r['module'] for r in review_rows]==['bench/repairs/tritonbench_g/context_attn_bloom/Proofs/KernelProfile.lean','bench/repairs/tritonbench_g/context_attn_bloom/KernelOnly.lean']
statement=(CACHE/'statement-audit.log').read_text()
assert ': error' not in statement and 'sorryAx' not in statement and 'DISALLOWED' not in statement
assert 'KernelOnly.native_tensor' in statement and 'WordISA' in statement
build=write('build-evidence.json',{'status':'pass','driver':pin(ROOT/'.veritile-cache/build-tools/workspace_lean_local_first_v2.py'),'task_modules_freshly_rebuilt':37,'log':pin(CACHE/'full-task-build.log'),'review_fix_rebuilt_modules':2,'review_fix_log':pin(CACHE/'review-fix-build.log'),'final_revision_builds':'35 unchanged modules retain the full-task build receipts; KernelProfile and KernelOnly receipts are from the later review-fix build.','statement_audit':pin(CACHE/'statement-audit.log'),'receipts':receipts,'sandbox_note':'The sandbox could not start Lean. The reviewed driver was authorized outside the sandbox and wrote only workspace overlay objects and task logs. No toolchain/core/Lake/baseline-cache edit.'})
source_audit=json.load(open(EVIDENCE/'source-and-profile-audit.json'))
verify(source_audit['selected_source']);verify(source_audit['original_source']);verify(source_audit['input_scope']);verify(source_audit['native_resource_issue'])
for p in source_audit['retained_files']+source_audit['new_formal_sources']:verify(p)
for row in source_audit['compatibility_import']:verify(row['after'])
probe=json.load(open(CACHE/'native-probe.json'));topology=json.load(open(CACHE/'native-topology-audit.json'))
verify(probe['source']);verify(probe['probe']);verify(topology['audit']);verify(topology['probe'])
assert len(probe['profiles'])==10 and len(topology['profiles'])==10
for p in probe['profiles']:
 for artifact in p['artifacts']:verify(artifact)
closure=json.load(open(EVIDENCE/'import-source-pins.json'))
for p in closure['repository_Lean_sources']:verify(p)
files=set(TASK.glob('*.lean'))|set(TASK.glob('*.py'))|set(TASK.glob('*.md'))|set(TASK.glob('Proofs/*.lean'))|set(TASK.glob('Whole001/*.lean'))
files.update(ROOT/p['path'] for p in closure['repository_Lean_sources'])
files.add(ROOT/source_audit['original_source']['path'])
files.update([EVIDENCE/'source-and-profile-audit.json',EVIDENCE/'import-source-pins.json',EVIDENCE/'resource-audit.json',build])
files.update(CACHE/name for name in ['entry.json','baseline-rebuild-order.json','native_probe.py','native-probe.json','native-probe.log','audit_native.py','native-topology-audit.json','native-topology-audit.log','cpu-check.log','full-task-build.log','review-fix-build.log','StatementAudit.lean','statement-audit.log','freeze_delivery.py'])
files.update(CACHE/'native'/f"{p['label']}.{ext}" for p in probe['profiles'] for ext in ('ttir','ttgir','llir','ptx'))
files.add(ROOT/'.veritile-cache/build-tools/workspace_lean_local_first_v2.py')
files.update(verify(r['receipt']) for r in receipts)
files.add(ROOT/'lean-toolchain')
manifest=write('frozen-files.json',{'files':[pin(p) for p in sorted(files)],'file_count':len(files),'source_closure_count':len(closure['repository_Lean_sources']),'contains':'Sources, source-closure pins, evidence, offline compiler artifacts, reviewed build driver, and task receipt manifests. Lean/Mathlib binaries and GPU execution are external.'})
files.add(manifest)
archive=EVIDENCE/'context-attn-bloom-kernel-package.tar.gz'
with archive.open('wb') as raw:
 with gzip.GzipFile(filename='',mode='wb',fileobj=raw,mtime=0) as compressed:
  with tarfile.open(fileobj=compressed,mode='w') as tar:
   for p in sorted(files):
    data=p.read_bytes();info=tarfile.TarInfo(str(p.relative_to(ROOT)));info.size=len(data);info.mtime=0;info.mode=0o644
    tar.addfile(info,io.BytesIO(data))
ns='VeriTile.Bench.Repairs.ContextAttnBloomWhole001.'
delivery=write('delivery.json',{
 'task':'context_attn_bloom','status':'kernel_semantics_package_ready_for_review_with_native_resource_exclusion','acceptance_class':'kernel_semantics_verified_with_deferred_numerics_and_known_native_resource_limit','selected_source':pin(TASK/'context_attn_bloom_repaired.py'),'public_entry':pin(TASK/'KernelOnly.lean'),'scope':pin(TASK/'KernelScope.md'),
 'prior_revision':{'delivery':pin(CACHE/'revision-001/delivery.json'),'archive':pin(CACHE/'revision-001/context-attn-bloom-kernel-package.tar.gz'),'review_fix':'Narrow QK seed form to exclude PV carry times literal guard; add pv_literal_factor_order.'},
 'theorems':{k:ns+v for k,v in {'shared_source':'KernelOnly.shared_source','real':'KernelOnly.mathematical_real','native_tensor_and_full_frame':'KernelOnly.native_tensor','input_tensor':'KernelOnly.input_tensor','fixed_profile_payload_independence':'KernelNative.selector_payload_independent','future_tile_PV_operand_order':'KernelNative.pv_literal_factor_order','ordered_reduction_coverage':'KernelNative.reduction_complete','fixed_K8_feature_coverage':'Native.dot_feature_covered'}.items()},
 'resource_audit':pin(EVIDENCE/'resource-audit.json'),'whole_admitted_domain_SM80_execution_established':False,'source_and_profile_audit':pin(EVIDENCE/'source-and-profile-audit.json'),'build':pin(build),'frozen_files':pin(manifest),'archive':pin(archive),
 'evidence':{'CPU':{'ordinary_cases':17,'empty_cases':2,'focused_semantics_cases':2,'actual_interpreter_invocations':17,'rejection_cases':19,'launch_constants':241,'log':pin(CACHE/'cpu-check.log')},'compiler':{'target':'CUDA SM80','triton_version':probe['triton_version'],'profiles':10,'actual_wrapper_AST_and_native_binder':True,'probe':pin(CACHE/'native-probe.json')},'native_topology':{'all_profiles_passed':10,'max_coordinates_checked':sum(p['max_replicas_checked'] for p in topology['profiles']),'sum_replicas_checked':sum(p['sum_replicas_checked'] for p in topology['profiles']),'ordered_tree_shared_routes_operand_order_live_seeds_and_K8_coverage':True,'audit':pin(CACHE/'native-topology-audit.json')}},
 'boundaries':{'native_numerical_ports':['literal32','addRN','subRN','mulRN','divFull','maxNum','ex2Approx','fmaRN','one-coordinate fixed m16n8k8 TF32 MMA'],'compiler':'Fixed payload-independent SM80 patterns supported by ten representative actual-wrapper/native-binder compiler artifacts; compiler internals are not proved. Initial 0 + -inf constant folding requires only that scalar-add identity.','launch_scalar':'FP32 ABI signature plus the independently checked 241-entry bit table, connected by LaunchScale.Bound.','ordinary_interfaces':['initial signed metadata observation','Tensor layout laws','physical byte-window/storage binding','region roles and labels','checked geometry and native bounds'],'whole_kernel_or_dot_correctness_premise':False,'caller_supplied_native_plan':False,'gpu_execution':False,'full_launcher_execution':False,'known_nonlaunchable_SM80_sample':'b128-d256 requires 327680 shared bytes, exceeding SM80 opt-in capacity; artifact retained only for structural checking','real_to_FP_error_bound':False},
 'preservation':{'selected_python_and_guards_unchanged':True,'existing_definitions_and_theorems_unchanged':True,'only_historical_file_edit':'One dependency import in Whole001/FPCore.lean to avoid duplicate generated shared-interpreter equations.','core_Lake_ledger_edited':False,'host_task_added':False,'primitive_experiment_added':False}})
print(json.dumps({'delivery':pin(delivery),'archive_bytes':archive.stat().st_size,'frozen_file_count':len(files),'fresh_modules':37},indent=2))
