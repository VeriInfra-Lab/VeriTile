"""Actual checked Bloom wrapper/JIT specialization and offline SM80 artifacts."""
import ast
import contextlib
import copy
import hashlib
import json
import os
from pathlib import Path
import sys
import types

sys.dont_write_bytecode = True
ROOT = Path(__file__).resolve().parents[3]
HERE = Path(__file__).resolve().parent
SOURCE = ROOT / 'bench/repairs/tritonbench_g/context_attn_bloom/context_attn_bloom_repaired.py'
os.environ.pop('TRITON_INTERPRET', None)
os.environ['TRITON_CACHE_DIR'] = str(HERE / 'native-cache')
os.environ['TMPDIR'] = str(HERE / 'tmp')

def pin(path):
    return {'path': str(path.relative_to(ROOT)), 'sha256': hashlib.sha256(path.read_bytes()).hexdigest()}

def main():
    import torch
    import triton
    import triton.language as tl
    from triton._C.libtriton import native_specialize_impl
    from triton.compiler import ASTSource
    from triton.backends.compiler import GPUTarget
    from triton.backends.nvidia.compiler import CUDABackend

    torch.set_num_threads(1)
    (HERE / 'tmp').mkdir(exist_ok=True)
    output = HERE / 'native'
    output.mkdir(exist_ok=True)
    tree = ast.parse(SOURCE.read_text())
    node = next(n for n in tree.body if isinstance(n, ast.FunctionDef) and n.name == '_fwd_kernel')
    module = types.ModuleType('context_bloom_kernel_probe')
    module.__file__ = str(SOURCE)
    module.__dict__.update(torch=torch, triton=triton, tl=tl)
    sys.modules[module.__name__] = module
    exec(compile(ast.Module([copy.deepcopy(node)], []), str(SOURCE), 'exec'), module.__dict__)
    kernel = module._fwd_kernel
    actual = ast.parse(kernel.src).body[0]
    assert ast.dump(actual.args) == ast.dump(node.args)
    assert [ast.dump(n) for n in actual.body] == [ast.dump(n) for n in node.body]

    class Tensor:
        def __init__(self, value):
            self.value = value
            self.device = torch.device('cuda:0')
            self.is_cuda = True
        def __getattr__(self, name):
            return getattr(self.value, name)

    target = GPUTarget('cuda', 80, 32)
    backend = CUDABackend(target)
    records = []
    for block in (64, 128):
        for width in (16, 32, 64, 96, 256):
            length, prompt = block + 1, 7
            heads, kv_heads = 2, 1
            rows, cache_rows = length + 2, length + prompt
            q = torch.zeros(rows, heads, width)
            k = torch.zeros(cache_rows, kv_heads, width)
            v = torch.zeros_like(k)
            backing = torch.zeros(rows + 2, heads, width)
            o = backing[1:-1]
            req = torch.tensor([0], dtype=torch.int32)
            starts = torch.tensor([1], dtype=torch.int32)
            seq = torch.tensor([cache_rows], dtype=torch.int32)
            prompts = torch.tensor([prompt], dtype=torch.int32)
            pages = torch.arange(cache_rows, dtype=torch.int32)[None, :]
            captured = {}
            events = []
            @contextlib.contextmanager
            def device(owner):
                assert owner == torch.device('cuda:0')
                events.append('device-enter')
                try:
                    yield
                finally:
                    events.append('device-exit')
            class Launch:
                def __getitem__(self, grid):
                    def call(*args, **kwargs):
                        captured.update(grid=grid, args=args, kwargs=kwargs)
                        events.append('launch')
                    return call
            facade = types.SimpleNamespace(Tensor=Tensor, strided=torch.strided,
                float32=torch.float32, int32=torch.int32,
                cuda=types.SimpleNamespace(device=device,
                    get_device_name=lambda _: 'Tesla profile' if block == 64 else 'SM80 profile'))
            nodes = []
            for n in tree.body:
                if isinstance(n, ast.Assign):
                    nodes.append(copy.deepcopy(n))
                elif isinstance(n, ast.FunctionDef) and n.name != '_fwd_kernel':
                    n = copy.deepcopy(n)
                    n.decorator_list = []
                    nodes.append(n)
            ns = {'torch': facade, 'triton': triton, '_fwd_kernel': Launch()}
            exec(compile(ast.Module(nodes, []), str(SOURCE), 'exec'), ns)
            raw = [q, k, v, o, req, starts, seq, prompts]
            supplied = [Tensor(x) for x in raw]
            assert ns['context_attention_fwd'](*supplied, length + 3, Tensor(pages)) is None
            assert events == ['device-enter', 'launch', 'device-exit']
            assert captured['grid'] == (1, heads, 2)
            assert [x.value for x in captured['args'][:3]] == raw[:3]
            values = [x.value if isinstance(x, Tensor) else x for x in captured['args']]
            kwargs = {name: (value.value if isinstance(value, Tensor) else value)
                      for name, value in captured['kwargs'].items()}
            bound = dict(zip(kernel.arg_names, values))
            bound.update({k: v for k, v in kwargs.items() if k in kernel.arg_names})
            assert set(bound) == set(kernel.arg_names)
            bound = {name: bound[name] for name in kernel.arg_names}
            specialized = [('constexpr', bound[p.name]) if p.is_constexpr else
                native_specialize_impl(backend, bound[p.name], p.is_const,
                    not p.do_not_specialize, not p.do_not_specialize_on_alignment)
                for p in kernel.params]
            options = {k: kwargs[k] for k in ('num_warps', 'num_stages')}
            _, signature, constants, attrs = kernel._pack_args(backend, options, bound, specialized, None)
            assert signature['stride_qd'] == 'constexpr'
            assert signature['sm_scale'] == 'fp32'
            for name in ('head_dim', 'BLOCK_M', 'BLOCK_DMODEL', 'BLOCK_N'):
                assert constants[(kernel.arg_names.index(name),)] == bound[name]
            compiled = triton.compile(ASTSource(kernel, signature=signature, constexprs=constants, attrs=attrs),
                                     target=target, options=options)
            label = f'b{block}-d{width}'
            artifacts = []
            for ext in ('ttir', 'ttgir', 'llir', 'ptx'):
                p = output / f'{label}.{ext}'
                p.write_text(compiled.asm[ext])
                artifacts.append(pin(p))
            records.append({'label': label, 'width': width, 'block': block,
                'uncached_length': length, 'prompt': prompt, 'grid': captured['grid'],
                'events': events, 'owner_device': 'cuda:0', 'output_storage_offset': o.storage_offset(),
                'source_arguments': {name: value for name, value in bound.items()
                    if not isinstance(value, torch.Tensor)},
                'signature': signature,
                'constants': {kernel.arg_names[k[0]]: v for k, v in constants.items()},
                'attrs': {kernel.arg_names[k[0]]: v for k, v in attrs.items()},
                'options': options, 'metadata': {**compiled.metadata._asdict(), 'target': str(target)},
                'artifacts': artifacts, 'status': 'offline_compile_pass'})
            print(label, 'PASS', flush=True)
    record = {'source': pin(SOURCE), 'probe': pin(Path(__file__)), 'target': 'CUDA SM80',
        'triton_version': triton.__version__, 'profiles': records,
        'scope': 'Unchanged actual wrapper AST and unchanged actual JIT body/signature; real CPU storage with CUDA metadata/context/submission facade; normal native specialization; offline compiler only.',
        'gpu_execution': False, 'full_launcher': False}
    (HERE / 'native-probe.json').write_text(json.dumps(record, indent=2) + '\n')

if __name__ == '__main__':
    main()
