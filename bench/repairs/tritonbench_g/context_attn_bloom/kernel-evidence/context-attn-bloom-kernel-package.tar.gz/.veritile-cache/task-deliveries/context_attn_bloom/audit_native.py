"""Static all-thread ordered-tree audit of the saved actual SM80 PTX.
No floating primitive evaluation or kernel-result oracle is used.
"""
import hashlib,json,re
from pathlib import Path
HERE=Path(__file__).resolve().parent
ROOT=HERE.parents[2]
def pin(p):return {'path':str(p.relative_to(ROOT)),'sha256':hashlib.sha256(p.read_bytes()).hexdigest()}
def chain(xs):
 t=xs[0]
 for x in xs[1:]:t=(t,x)
 return t
def butterfly(xs,masks):
 for mask in masks:xs=[(x,xs[i^mask]) for i,x in enumerate(xs)]
 return xs
def expected(n,cross,row,col):
 if not cross:
  local=[chain([(row,8*k+2*lane+j) for k in range(n//8) for j in (0,1)]) for lane in range(4)]
  return butterfly(local,(2,1))[col%8//2]
 warps=[]
 for warp in range(8):
  local=[chain([(row,64*k+8*warp+2*lane+j) for k in range(n//64) for j in (0,1)]) for lane in range(4)]
  warps.append(butterfly(local,(2,1))[0])
 return butterfly(warps,(4,2,1))[0]
def isleaf(x):return isinstance(x,tuple) and len(x)==2 and isinstance(x[0],int)
def audit(profile):
 path=HERE/'native'/f"{profile['label']}.ptx"
 lines=path.read_text().splitlines()
 ttgir=(HERE/'native'/f"{profile['label']}.ttgir").read_text()
 wm,wn=map(int,re.search(r'warpsPerCTA = \[(\d+), (\d+)\], instrShape',ttgir).groups())
 threads=32*wm*wn;n=profile['block'];cross=wn==8
 assert cross==(profile['width']>128 or (profile['width']>64 and n==64))
 env={'%tid.x':list(range(threads))};shared={};source=0;destinations={};avec={};bvec={};checks={'max':0,'sum':0};tree_regs=set();qk_count=0;pv_count=0;seen_pv=set();scaled_acc=set();alpha=set();beta=set();probability=set();scaled_mass={};mass={};p_scale={};retention_div={};retention=set();guarded=set();max_coordinates=set();orientations={'qk_scale':0,'normalizer_fma':0,'probability_scale':0,'retention':0,'accumulator_scale':0}
 def get(name,t):
  name=name.strip()
  if name in env:return env[name][t]
  if name.startswith('0f'):return None
  if name in ('global_smem','global_smem+0'):return 0
  try:return int(name,0)
  except ValueError:return None
 def address(expr,t):
  atoms=expr.strip('[] ').replace(' ','').split('+')
  vals=[get(a,t) for a in atoms]
  assert all(isinstance(v,int) for v in vals),(profile['label'],expr,t,vals)
  return sum(vals)
 def execute(op,args,pred):
  nonlocal qk_count,pv_count
  if op.startswith('mma.'):
   groups=re.findall(r'\{([^}]*)\}',args);out,a,b,seed=[tuple(v.strip() for v in g.split(',')) for g in groups]
   assert out==seed,('live MMA seed',out,seed)
   if source==50:
    if out not in seen_pv:
     assert set(out)<=scaled_acc,(profile['label'],'first PV seed is live scaled accumulator',out)
     seen_pv.add(out)
    pv_count+=1;return
   qk_count+=1
   if out not in destinations:
    assert all(get(reg,0)==0 for reg in seed),(profile['label'],'QK zero seed',seed)
    if a not in avec:avec[a]=len(avec)
    if b not in bvec:bvec[b]=len(bvec)
    mg,ng=avec[a],bvec[b]
    destinations[out]=(mg,ng)
    for j,d in enumerate(out):
     env[d]=[((t//32%wm)*16+mg*16*wm+(t%32)//4+(j//2)*8,
              (t//32//wm)*8+ng*8*wn+(t%4)*2+j%2) for t in range(threads)]
   return
  args=[a.strip() for a in args.split(',')]
  if op=='bar.sync' or op.startswith(('bra','ret','st.global','ld.global','ldmatrix')):return
  if op.startswith(('st.shared','ld.shared')) and source in (35,37):
   assert op.endswith('.b32'),op
   for t in range(threads):
    if pred:
     pval=get(pred.lstrip('!'),t)
     assert pval is not None,(pred,t)
     if not (bool(pval) ^ pred.startswith('!')):continue
    if op.startswith('st'):
     at=address(args[0],t);val=get(args[1],t)
     assert isinstance(val,tuple),(args,t,val)
     shared[at]=val
    else:
     at=address(args[1],t)
     assert at in shared,(profile['label'],at,args,t)
     env.setdefault(args[0],[None]*threads)[t]=shared[at]
     tree_regs.add(args[0])
   return
  if len(args)<2 or not args[0].startswith('%'):return
  d=args[0];src=args[1:]
  if op.startswith('shfl.sync.bfly') and source in (35,37):
   mask=int(src[1]);env[d]=[get(src[0],(t//32)*32+((t%32)^mask)) for t in range(threads)];return
  if op in ('max.f32','add.f32') and source in (35,37):
   vals=[]
   for t in range(threads):
    a,b=[get(x,t) for x in src];assert isinstance(a,tuple) and isinstance(b,tuple),(profile['label'],source,op,args,t,a,b)
    vals.append((a,b))
   env[d]=vals;tree_regs.add(d);return
  if op=='sub.f32' and source==36:
   vals=[]
   for t in range(threads):
    score,tree=[get(x,t) for x in src];assert isleaf(score),(src,t,score)
    assert tree==expected(n,cross,*score),(profile['label'],'max',score,t)
    vals.append(score);checks['max']+=1;max_coordinates.add(score)
   env[d]=vals;return
  if op=='mul.f32' and source==41:
   # Rounded localMass * beta is kept separate from the following FMA.
   if src[0] in tree_regs:
    for t in range(threads):
     tree=get(src[0],t)
     def first(x):return x if isleaf(x) else first(x[0])
     row,col=first(tree)
     assert tree==expected(n,cross,row,col),(profile['label'],'sum',row,col,t)
     checks['sum']+=1
  if op=='mul.f32' and source==33:
   assert src[1] in {reg for group in destinations for reg in group}
   orientations['qk_scale']+=1
  if op=='ex2.approx.f32':
   if source==36:probability.add(d)
   if source==39:alpha.add(d)
   if source==40:beta.add(d)
  if op=='mul.f32' and source==41:
   assert src[0] in tree_regs and src[1] in beta,(profile['label'],'localMass * beta',src)
   scaled_mass[d]=(src[0],src[1])
  if op=='fma.rn.f32' and source==41:
   assert src[1] in alpha and src[2] in scaled_mass,(profile['label'],'fma(oldMass,alpha,localMass*beta)',src)
   mass[d]=(src[0],src[1],scaled_mass[src[2]][1]);orientations['normalizer_fma']+=1
  if op=='div.full.f32' and source==42:
   assert src[1] in mass and src[0]==mass[src[1]][2]
   p_scale[d]=src[1]
  if op=='mul.f32' and source==43:
   assert src[0] in probability and src[1] in p_scale,(profile['label'],'p * probability_scale',src)
   orientations['probability_scale']+=1
  if op=='div.full.f32' and source==44:
   assert src[1] in mass and src[0]==mass[src[1]][0]
   retention_div[d]=mass[src[1]][1]
  if op=='mul.f32' and source==44:
   assert src[1] in retention_div and src[0]==retention_div[src[1]]
   retention.add(d);orientations['retention']+=1
  if op=='selp.f32' and source==45:
   assert src[0]=='0f3F800000' and src[1] in retention
   guarded.add(d)
  if op=='mul.f32' and source==46:
   assert d==src[0] and src[1] in guarded,(profile['label'],'old accumulator * guarded factor',src)
   scaled_acc.add(d);orientations['accumulator_scale']+=1
  vals=[]
  for t in range(threads):
   v=[get(x,t) for x in src]
   if op in ('mul.f32','selp.f32') and source in (33,34,36):
    labels=[x for x in v if isleaf(x)]
    vals.append(labels[0] if len(labels)==1 else None);continue
   if op=='ex2.approx.f32' and source==36:vals.append(v[0]);continue
   if any(x is None for x in v):vals.append(None);continue
   try:
    if op.startswith(('mov.','cvt.','cvta.')):z=v[0]
    elif op.startswith('add.') and all(isinstance(x,int) for x in v):z=v[0]+v[1]
    elif op.startswith('sub.') and all(isinstance(x,int) for x in v):z=v[0]-v[1]
    elif op.startswith('mul.lo'):z=v[0]*v[1]
    elif op.startswith('mad.lo'):z=v[0]*v[1]+v[2]
    elif op.startswith('shl.'):z=v[0]<<v[1]
    elif op.startswith('shr.'):z=v[0]>>v[1]
    elif op.startswith('and.'):z=v[0]&v[1]
    elif op.startswith('or.'):z=v[0]|v[1]
    elif op.startswith('xor.'):z=v[0]^v[1]
    elif op.startswith('bfe.'):z=(v[0]>>v[1])&((1<<v[2])-1)
    elif op.startswith('setp.eq.'):z=int(v[0]==v[1])
    elif op.startswith('setp.ne.'):z=int(v[0]!=v[1])
    elif op.startswith('setp.lt.'):z=int(v[0]<v[1])
    elif op.startswith('setp.ge.'):z=int(v[0]>=v[1])
    elif op.startswith('selp.'):z=v[0] if v[2] else v[1]
    else:z=None
   except TypeError:z=None
   vals.append(z)
  env[d]=vals
 for line in lines:
  loc=re.search(r'context_attn_bloom_repaired.py:(\d+):',line)
  if loc:source=int(loc.group(1))
  m=re.match(r'\s*(?:@(!?%p\d+)\s+)?([a-z][a-z0-9_.]*)\s+(.*);',line)
  if m:execute(m.group(2),m.group(3),m.group(1))
 assert max_coordinates=={(r,c) for r in range(n) for c in range(n)}
 assert all(orientations.values()),orientations
 assert checks['max']==n*n,(profile['label'],checks)
 assert checks['sum']==n*4 if not cross else checks['sum']==n*32,(profile['label'],checks)
 # Every logical MMA output has one K8 instruction for each covered feature block.
 padded=profile['constants']['BLOCK_DMODEL']
 assert qk_count==n*n//(16*8*wm*wn)*(padded//8),(qk_count,n,padded,wm,wn)
 assert pv_count==n*padded//(16*8*wm*wn)*(n//8),(pv_count,n,padded,wm,wn)
 return {'label':profile['label'],'warps_M_N':[wm,wn],'max_replicas_checked':checks['max'],'sum_replicas_checked':checks['sum'],'scalar_orientation_sites':orientations,'pv_live_seed_groups':len(seen_pv),'qk_k8_instructions':qk_count,'pv_k8_instructions':pv_count,'ptx':pin(path),'status':'ordered_tree_and_K8_coverage_pass'}
def main():
 probe=json.load(open(HERE/'native-probe.json'))
 results=[]
 for p in probe['profiles']:
  result=audit(p);results.append(result);print(result['label'],'PASS',flush=True)
 (HERE/'native-topology-audit.json').write_text(json.dumps({'audit':pin(Path(__file__)),'probe':pin(HERE/'native-probe.json'),'profiles':results,'scope':'Static per-thread symbolic PTX reduction topology and K8 instruction coverage; no primitive numerical experiments or GPU execution.'},indent=2)+'\n')
if __name__=='__main__':main()
