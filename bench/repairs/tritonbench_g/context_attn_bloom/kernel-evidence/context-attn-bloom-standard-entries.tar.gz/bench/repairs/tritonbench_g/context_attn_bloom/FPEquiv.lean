import bench.repairs.tritonbench_g.context_attn_bloom.Proofs.Task
import bench.repairs.tritonbench_g.context_attn_bloom.KernelOnly

namespace VeriTile.Bench.Repairs.ContextAttnBloomWhole001.PublicKernel

/-- Standard native entry for original Tensor values, output bytes, and frames. -/
alias correct_fp32 := KernelOnly.native_tensor
alias input_tensor := KernelOnly.input_tensor

#axiomsClean correct_fp32
#axiomsClean input_tensor

end VeriTile.Bench.Repairs.ContextAttnBloomWhole001.PublicKernel
