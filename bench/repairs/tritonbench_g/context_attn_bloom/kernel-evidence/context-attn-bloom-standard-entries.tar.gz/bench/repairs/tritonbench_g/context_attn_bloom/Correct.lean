import bench.repairs.tritonbench_g.context_attn_bloom.Proofs.CheckedReal
import bench.repairs.tritonbench_g.context_attn_bloom.KernelOnly

namespace VeriTile.Bench.Repairs.ContextAttnBloomWhole001.PublicKernel

/-- Standard Real entry for the shared kernel and its independent target. -/
alias correct_real := KernelOnly.mathematical_real
alias shared_source := KernelOnly.shared_source

#axiomsClean correct_real
#axiomsClean shared_source

end VeriTile.Bench.Repairs.ContextAttnBloomWhole001.PublicKernel
