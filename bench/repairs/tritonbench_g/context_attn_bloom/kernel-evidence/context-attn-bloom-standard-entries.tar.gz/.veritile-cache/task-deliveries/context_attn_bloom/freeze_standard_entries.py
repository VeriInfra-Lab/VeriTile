"""Freeze only the standard-entry delta over the immutable accepted package."""
from pathlib import Path
import gzip
import hashlib
import io
import json
import re
import tarfile

ROOT = Path.cwd()
TASK = ROOT / 'bench/repairs/tritonbench_g/context_attn_bloom'
CACHE = ROOT / '.veritile-cache/task-deliveries/context_attn_bloom'
EVIDENCE = TASK / 'kernel-evidence'
OVERLAY = ROOT / '.veritile-cache/kernel-build/lib/lean'
NS = 'VeriTile.Bench.Repairs.ContextAttnBloomWhole001.'

def sha(path):
    return hashlib.sha256(path.read_bytes()).hexdigest()

def pin(path):
    return {'path': str(path.relative_to(ROOT)), 'sha256': sha(path)}

def verify(record):
    path = ROOT / record['path']
    assert sha(path) == record['sha256'], record['path']
    return path

def write(name, data):
    path = EVIDENCE / name
    path.write_text(json.dumps(data, indent=2) + '\n')
    return path

base_expected = {
    'delivery.json': '8c9321c5ce96560d773b801b68f415075ac30e9438c742f4c68efd912d56c932',
    'context-attn-bloom-kernel-package.tar.gz': '73b5b398be0e804ea0830d9aefa43f0423d329133bef50eadb146bd694867261',
    'independent-review.json': 'ea36a004857a07e1adda380a71129e2fdd24a3ea3420627bd06f3299fcb3f09f',
    'independent-verification.json': '7516444ab127a11e70214becd4fa3906afdc6e022f6d42eb5e94ee5ac9f93dc5',
}
for name, expected in base_expected.items():
    assert sha(EVIDENCE / name) == expected, name
base = json.loads((EVIDENCE / 'delivery.json').read_text())
manifest_path = verify(base['frozen_files'])
base_files = {row['path']: row for row in json.loads(manifest_path.read_text())['files']}
modules = [TASK / name for name in ('Correct.lean', 'FPEquiv.lean')]
receipts = [(OVERLAY / p.relative_to(ROOT)).with_suffix('.workspace-build.json') for p in modules]
replaced_paths = {str(p.relative_to(ROOT)) for p in modules + receipts}
assert replaced_paths <= base_files.keys()
for path, row in base_files.items():
    if path not in replaced_paths:
        verify(row)

log = CACHE / 'standard-entry-build.log'
log_text = log.read_text()
assert ': error' not in log_text and 'sorryAx' not in log_text and 'DISALLOWED' not in log_text
rows = [json.loads(line) for line in log_text.splitlines() if line.startswith('{"module":')]
assert [r['module'] for r in rows] == [str(p.relative_to(ROOT)) for p in modules]
assert all(row['exit_code'] == 0 for row in rows)
assert log_text.count('axiom footprint ⊆ standard base') == 4

aliases = {
    'Correct.lean': {'correct_real': 'mathematical_real', 'shared_source': 'shared_source'},
    'FPEquiv.lean': {'correct_fp32': 'native_tensor', 'input_tensor': 'input_tensor'},
}
historical_import = {
    'Correct.lean': 'import bench.repairs.tritonbench_g.context_attn_bloom.Proofs.CheckedReal\n',
    'FPEquiv.lean': 'import bench.repairs.tritonbench_g.context_attn_bloom.Proofs.Task\n',
}
delta_files = set(modules + receipts + [log, Path(__file__).resolve()])
build_rows = []
links = []
for source, receipt in zip(modules, receipts):
    text = source.read_text()
    assert text.startswith(historical_import[source.name])
    assert hashlib.sha256(historical_import[source.name].encode()).hexdigest() == base_files[str(source.relative_to(ROOT))]['sha256']
    for public, target in aliases[source.name].items():
        assert f'alias {public} := KernelOnly.{target}\n' in text
        assert f'#axiomsClean {public}\n' in text
        links.append({'entry_file': pin(source), 'public': NS + 'PublicKernel.' + public,
                      'accepted_endpoint': NS + 'KernelOnly.' + target, 'form': 'direct Lean alias'})
    data = json.loads(receipt.read_text())
    assert data['source'] == str(source.relative_to(ROOT)) and data['source_sha256'] == sha(source)
    assert data['exit_code'] == 0
    objects = []
    for name, expected in data['objects'].items():
        path = Path(name)
        assert path.is_relative_to(OVERLAY) and path.is_file() and not path.is_symlink()
        assert sha(path) == expected, name
        delta_files.add(path)
        objects.append(pin(path))
    ilean = receipt.with_name(source.stem + '.ilean')
    imports = re.findall(r'^import\s+(\S+)\s*$', text, re.M)
    assert imports == [row[0] for row in json.loads(ilean.read_text())['directImports']]
    build_rows.append({'source': pin(source), 'receipt': pin(receipt), 'objects': objects,
                       'source_direct_imports_equal_ilean': True})

entries = {
    'Contract': {'file': pin(TASK / 'Contract.lean'), 'role': 'Checked input conditions and their Boolean checker equivalence.',
                 'declarations': [NS + 'Checked.InputContract', NS + 'Checked.checkInputs', NS + 'Checked.checkInputs_iff']},
    'Kernels': {'file': pin(TASK / 'Kernels.lean'), 'role': 'Shared typed source specialized to FP32 storage.',
                'declarations': ['VeriTile.Bench.Repairs.ContextAttnBloomSource.kernel']},
    'Correct': {'file': pin(TASK / 'Correct.lean'), 'role': 'Public shared-source and independent mathematical Real conclusions.',
                'declarations': [NS + 'PublicKernel.correct_real', NS + 'PublicKernel.shared_source']},
    'FPEquiv': {'file': pin(TASK / 'FPEquiv.lean'), 'role': 'Public native original-Tensor/byte result, input read connection, and full frames.',
                'declarations': [NS + 'PublicKernel.correct_fp32', NS + 'PublicKernel.input_tensor']},
}
link_file = write('standard-entry-links.json', {
    'standard_entries': entries, 'alias_links': links,
    'accepted_proof_file': base['public_entry'],
    'semantic_or_domain_change': False,
    'historical_imports_retained': True,
    'added_source_content': 'Only KernelOnly imports, namespace, four direct aliases, documentation, and four axiom audits.',
})
delta_files.add(link_file)

review = json.loads((EVIDENCE / 'independent-verification.json').read_text())
old_object_pins = {}
for row in review['effective_objects']:
    if row['source']['path'] in replaced_paths:
        for field in ('effective_object', 'ilean'):
            old_object_pins[row[field]['path']] = row[field]
replacements = [{'before': base_files[path], 'after': pin(ROOT / path)} for path in sorted(replaced_paths)]
object_replacements = [{'before': old, 'after': pin(ROOT / path)} for path, old in sorted(old_object_pins.items())]
delta_manifest = write('standard-entry-frozen-files.json', {
    'composition': 'Apply these path replacements to the immutable accepted base. All other base source/evidence pins remain current. Historical base audit records retain their original hashes and are interpreted with this explicit overlay.',
    'base_frozen_files': base['frozen_files'],
    'base_manifest_replacements': replacements,
    'base_review_object_replacements': object_replacements,
    'unchanged_base_file_pins_verified': len(base_files) - len(replaced_paths),
    'files': [pin(p) for p in sorted(delta_files)],
    'file_count': len(delta_files),
})
delta_files.add(delta_manifest)
archive = EVIDENCE / 'context-attn-bloom-standard-entries.tar.gz'
with archive.open('wb') as raw:
    with gzip.GzipFile(filename='', mode='wb', fileobj=raw, mtime=0) as compressed:
        with tarfile.open(fileobj=compressed, mode='w') as tar:
            for path in sorted(delta_files):
                data = path.read_bytes()
                info = tarfile.TarInfo(str(path.relative_to(ROOT)))
                info.size, info.mtime, info.mode = len(data), 0, 0o644
                tar.addfile(info, io.BytesIO(data))
delivery = write('standard-entry-delivery.json', {
    'task': 'context_attn_bloom',
    'status': 'standard_kernel_entries_ready_for_focused_independent_review',
    'scope': 'Thin standard-file re-exports of the previously accepted kernel-only conclusions.',
    'accepted_base': {name: pin(EVIDENCE / name) for name in base_expected},
    'selected_source': base['selected_source'],
    'standard_entries': entries,
    'alias_links': pin(link_file),
    'delta_manifest': pin(delta_manifest),
    'delta_archive': pin(archive),
    'build': {'driver': pin(ROOT / '.veritile-cache/build-tools/workspace_lean_local_first_v2.py'),
              'log': pin(log), 'exit_code': 0, 'modules_rebuilt': 2, 'axiom_checks': 4, 'current_receipts': build_rows,
              'remaining_task_receipts': 'The other 35 accepted receipts are unchanged and their frozen pins were verified.',
              'dependency_boundary': 'Retains the accepted reused-cache boundary; no transitive cold rebuild.'},
    'preservation': {'accepted_delivery_archive_review_and_verification_unchanged': True,
                     'selected_python_guards_domain_and_proved_semantics_unchanged': True,
                     'existing_theorems_unchanged': True,
                     'unchanged_base_file_pins_verified': len(base_files) - len(replaced_paths),
                     'historical_evidence_recopied': False, 'CPU_compiler_or_numerics_rerun': False,
                     'GPU_execution': False, 'core_Lake_ledger_edited': False},
    'inherited_boundaries': base['boundaries'],
    'resource_audit': base['resource_audit'],
    'whole_admitted_domain_SM80_execution_established': False,
})
print(json.dumps({'delivery': pin(delivery), 'delta_archive': pin(archive),
                  'delta_archive_members': len(delta_files), 'unchanged_base_pins': len(base_files) - len(replaced_paths)}, indent=2))
