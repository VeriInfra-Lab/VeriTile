# Explicit gzip storage proposal — producer evidence, not acceptance

The candidate changes one production file, `bench/adapter_common.py`, and adds
storage/audit regressions. Repository files and historical checkpoints were not
edited. The candidate source is under `after/`; `candidate.patch` is generated
against the pinned `before/` files. Root must review and integrate separately.

## Behavior

`load` and `write_json` recognize the exact, case-sensitive `.json.gz` suffix.
There is no filename search, fallback, magic-byte inference, or automatic rename.
Plain JSON output retains its exact old formatting and plain readers retain their
old behavior. Gzip uses UTF-8, no embedded filename, and timestamp zero. Output is
repeatable in the same Python/zlib environment; raw-byte identity across arbitrary
compression-library versions is not assumed.

The complete gzip stream is read before JSON parsing, checking CRC and length.
Malformed headers, truncated streams/trailers, bad deflate, CRC/length mismatches,
and non-gzip trailing junk fail closed. Existing duplicate-key rejection runs at
every object depth after decompression. JSON parsing and all schemas/validation
assertions are unchanged.

`canonical`, `sha`, `hash_file`, `relative`, `within`, and `checked` are unchanged.
Canonical object hashes survive representation changes. File hashes always cover
the actual stored bytes, including gzip metadata; even a timestamp-only rewrite
invalidates a raw-byte receipt. Existing path traversal, noncanonical relative
path, symlink escape, and lowercase SHA-256 checks remain in force.

## Complete active consumer map for the proposed formats

| Consumer | What it reads or forwards | Change needed |
|---|---|---|
| `bench/current_source_catalog.py` | Catalog output/check/targets, supplement, root-review and metadata-review references | None; shared loader/writer already used |
| `bench/current_source_audit.py` | Catalog, explicit supplement and scope-ledger paths; raw catalog stability check | None |
| `bench/check_original_program_scope.py` | Catalog, ledger, hash-bound scope review, unified queue | None; keep queue path/plain format unchanged |
| `bench/current_value_metadata.py` | Catalog, supplement, hash-bound value scope review | None |
| `bench/current_acceptance.py` | Catalog and explicit build/gate/record inputs | None |
| `bench/legacy_source_adapter.py` | Catalog; output receipts | None |
| `bench/audit_trust.sh` | Catalog path forwarded to catalog CLI; raw `sha256sum` before/after workers | None |
| `bench/select_audit_shard.py` | Newline-separated validated target names from stdin | None; it never reads JSON |
| `.github/workflows/bench-audit.yml` | Global catalog/supplement/ledger flags; corpus catalog flag | Root updates explicit paths for the new checkpoint and active ledger |
| `bench/original_program_scope.md` | Active ledger link and example CLI flag | Root updates active `.json` link/path to `.json.gz` |
| `bench/current_source_acceptance.md` | Current and preceding frozen catalog links | Update only a new current link when integrating; preserve historical links |
| `scripts/test_audit_shards.py` | Real catalog validation and shard dispatcher, with proof executor stub | Candidate adds gzip subclass and byte-preserving rewrite mutation |
| `bench/tests/test_current_source_adapters.py`, `test_current_source_audit.py`, `test_current_value_metadata.py`, `test_original_program_scope.py` | Shared plain fixtures | Existing 176 cases pass unchanged |
| `bench/tests/test_json_storage.py`, `test_gzip_source_audit.py` | New compressed/plain compatibility, rejection, forwarding, and bound-review fixtures | Candidate adds 14 cases |

All eight active production Python modules importing and calling the shared
`load` are enumerated with exact call expressions and line numbers in
`evidence/shared-loader-consumers.json`. The six catalog/scope consumers above are
joined by `bench/reviewed_numerical_extensions.py` and
`bench/vector_native_numerical_extension.py`: these continue reading their
existing, explicit plain frozen receipt/dependency paths unchanged.

The following active modules have independent JSON readers but do **not** read
the proposed catalog/supplement/ledger artifacts: `acceptance_tritonbench_g.py`,
`coverage_review.py`, `inventory_tritonbench_g_completion.py`,
`numerical_obligations.py`, `deferred_numerical_experiments.py`,
`exact_numerical_bindings.py`, `fp_value_extensions.py`, `fp_value_repairs.py`,
`value_source_entries.py`, `quant_transpose_numerical_extension.py`, and source
profile adapters. Their existing plain artifacts, numerical queue, frozen
baselines, and receipts must remain unchanged. No universal JSON migration is
proposed. `exact_scope_gate.py` consumes already loaded objects and needs no edit.
`bench/audit_trust_prep.py` handles Lean source and a text manifest, not JSON.

## Integration sequence

1. Review the four candidate files and ensure the two modified existing files
   still match `evidence/input-sha256.json`; rebase deliberately if they changed.
2. Apply the adapter and tests. Existing CI already discovers both new bench
   tests and the modified shard suite, so no test-discovery change is needed.
3. Generate only **new** catalog and supplement files with `.json.gz` output
   paths. Keep all old catalog/supplement/receipt/baseline bytes and paths intact.
4. Generate the active `bench/original_program_scope.json.gz` from the final
   current ledger object and update its current workflow/documentation paths.
   Do not retain two competing active ledger files or add fallback selection.
   The unified numerical queue stays plain at its required existing path.
5. Also use `.json.gz` for a **new** combined root review if it grows near the
   repository file limit. Current combined root review is already ~63 MB. New
   supplement references must name this exact compressed path and hash its actual
   bytes. This reference change changes supplement canonical content: regenerate
   catalog and current scope-review/ledger bindings normally, without rewriting
   historical evidence. Merely compressing a document with no reference changes
   preserves its own canonical hash.
6. Update the two workflow catalog flags, supplement flag, and ledger flag to
   the final explicit paths. Run the existing full reproduction, scope, numerical
   equality, and audit gates against those final artifacts. This prototype does
   not confer proof acceptance or replace those gates.

## Evidence and limitations

`evidence/data-inputs.json` pins actual raw hashes of all four real-data snapshots.
Each snapshot was checked against the repository immediately after copying.
`replay_storage.py` records compression sizes, object equality, canonical hashes,
full catalog and supplement validations, equal scope results, and end-of-run
source stability. All four real data files were stable. Its first scope results
identically reported 183 unaccepted because the copied quant numerical adapter
predated the parent's `.pyc` to `.pyc.bin` archival path update. The obsolete
helper source, failure diagnosis, and before/after hashes are preserved under
`evidence/`. Only that temporary helper was rebased; no candidate production
change was needed. `replay_scope_current.py` reruns only the affected scope
comparison and pins tools, catalog, ledger, supplement, root review, and queue
before and after. The final comparison is in
`evidence/scope-current-comparison.json` when completed.

The storage tests, six gzip global/bound-review tests, 38 shard tests, 134 current
adapter tests, and 42 scope tests total 228 passing cases. Comparator execution
in shard fixtures is intentionally stubbed: these are dispatcher/hash tests,
not Lean/comparator evidence. One failed test attempt used the wrong expected
error-message regex; its source and log are retained before the corrected test.
The scope replay initially expected all four accepted scopes to be conditional;
the unchanged actual split is one verified and three conditional. That extra
harness assertion and source are preserved. `finalize_scope_current.py` checks
the already saved complete plain/gzip gate results and stable input pins with the
correct split, without repeating the successful gate executions.

No Git operations, installations, GPU launches, or historical edits were made.
The new storage format does not alter pending/accepted scope counts. This package
is a reviewable producer proposal, and root alone may accept or integrate it.
