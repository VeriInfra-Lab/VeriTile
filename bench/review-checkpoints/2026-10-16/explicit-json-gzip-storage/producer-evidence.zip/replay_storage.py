"""Read-only production-data replay; compression copies live only in this package."""
from pathlib import Path
import gc
import json
import shutil
import sys
import time

PACKAGE = Path(__file__).resolve().parent
ROOT = Path('/mnt/VerifiableAILab/VerifiableAILab/zenan.li/VeriTile')
sys.path.insert(0, str(PACKAGE / 'runtime/bench'))
from adapter_common import canonical, hash_file, load, sha, write_json
from current_source_catalog import validate_catalog, validate_supplement
from current_value_metadata import check_supplement_scope
from check_original_program_scope import check

checkpoint = 'bench/review-checkpoints/2026-10-16/native-vector-quant-transpose-acceptance/'
inputs = {
    'catalog': checkpoint + 'current-source-catalog.json',
    'supplement': checkpoint + 'catalog-supplement.json',
    'root_review': checkpoint + 'root-review.json',
    'ledger': 'bench/original_program_scope.json',
}
snapshots = PACKAGE / 'inputs'
snapshots.mkdir(exist_ok=False)
rows = {}
for key, name in inputs.items():
    target = snapshots / (key + '.json')
    shutil.copyfile(ROOT / name, target)
    rows[key] = {'source': name, 'snapshot_sha256': hash_file(target),
                 'source_bytes': target.stat().st_size}
    if rows[key]['snapshot_sha256'] != hash_file(ROOT / name):
        raise ValueError('input changed while snapshotting: ' + name)
write_json(PACKAGE / 'evidence/data-inputs.json', rows)

for key, row in rows.items():
    start = time.monotonic()
    original = load(snapshots / (key + '.json'))
    output = PACKAGE / 'compressed' / (key + '.json.gz')
    write_json(output, original)
    restored = load(output)
    assert restored == original
    digest = sha(canonical(original))
    assert sha(canonical(restored)) == digest
    row.update(compressed_sha256=hash_file(output), compressed_bytes=output.stat().st_size,
               canonical_sha256=digest, equality=True,
               roundtrip_seconds=round(time.monotonic() - start, 3))
    print(key, row, flush=True)
    del original, restored
    gc.collect()

plain_catalog = load(snapshots / 'catalog.json')
compressed_catalog = load(PACKAGE / 'compressed/catalog.json.gz')
catalog_results = [validate_catalog(ROOT, value) for value in (plain_catalog, compressed_catalog)]
assert catalog_results[0] == catalog_results[1]
print('catalog validation', catalog_results[0], flush=True)
supplement_results = []
for path in (snapshots / 'supplement.json', PACKAGE / 'compressed/supplement.json.gz'):
    supplement = load(path)
    validate_supplement(ROOT, ROOT / 'bench/review-checkpoints', supplement,
                        set(plain_catalog['expected_task_names']))
    supplement_results.append(check_supplement_scope(supplement, ROOT / 'bench/review-checkpoints'))
assert supplement_results[0] == supplement_results[1]
print('supplement validation: identical', flush=True)
scope_results = [check(ROOT, catalog, load(path)) for catalog, path in (
    (plain_catalog, snapshots / 'ledger.json'),
    (compressed_catalog, PACKAGE / 'compressed/ledger.json.gz'))]
assert scope_results[0] == scope_results[1]
print('scope validation', scope_results[0]['status'], scope_results[0]['counts'], flush=True)

result = {'schema': 1, 'kind': 'storage_prototype_replay_not_acceptance',
          'status': 'passed', 'files': rows,
          'catalog_validation': catalog_results[0],
          'supplement_validation_equal': True,
          'scope_validation_equal': True,
          'scope_result_status': scope_results[0]['status'],
          'scope_result_counts': scope_results[0]['counts'],
          'source_snapshot_still_matches': {key: hash_file(ROOT / row['source']) == row['snapshot_sha256']
                                            for key, row in rows.items()},
          'boundary': 'Representation replay only. Existing pending scopes remain pending. No compilation or proof acceptance.'}
write_json(PACKAGE / 'evidence/production-storage-replay.json', result)
