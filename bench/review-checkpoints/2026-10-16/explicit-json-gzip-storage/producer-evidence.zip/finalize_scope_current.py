"""Validate saved complete scope runs and stable pins without repeating gates."""
from pathlib import Path
import sys

PACKAGE = Path(__file__).resolve().parent
ROOT = Path('/mnt/VerifiableAILab/VerifiableAILab/zenan.li/VeriTile')
sys.path.insert(0, str(PACKAGE / 'runtime/bench'))
from adapter_common import hash_file, load, write_json

plain = load(PACKAGE / 'evidence/scope-current-plain-result.json')
compressed = load(PACKAGE / 'evidence/scope-current-gzip-result.json')
assert plain == compressed
assert plain['counts'] == {'not_accepted': 179, 'verified': 1, 'verified_with_deferred_numerics': 3}
pins = load(PACKAGE / 'evidence/scope-current-input-pins.json')
assert pins == {name: hash_file(ROOT / name) for name in pins}
write_json(PACKAGE / 'evidence/scope-current-comparison.json', {
    'kind': 'storage_scope_comparison_not_acceptance', 'status': 'passed',
    'plain_gzip_results_equal': True, 'counts': plain['counts'],
    'scope_gate_status': plain['status'], 'input_pins_before_after_equal': True,
    'input_pins_sha256': hash_file(PACKAGE / 'evidence/scope-current-input-pins.json'),
    'plain_result_sha256': hash_file(PACKAGE / 'evidence/scope-current-plain-result.json'),
    'gzip_result_sha256': hash_file(PACKAGE / 'evidence/scope-current-gzip-result.json'),
    'rebase_sha256': hash_file(PACKAGE / 'evidence/tool-rebase.json'),
    'preserved_harness_assertion_failure': 'replay_scope_current.py originally expected four conditional scopes; actual unchanged split is one verified plus three conditional. Saved gate outputs are checked here without rerunning gates.',
    'boundary': 'Same four existing scope reviews and 179 pending. No new acceptance.'})
print('scope storage comparison passed: one verified, three conditional, 179 pending')
