from pathlib import Path
import hashlib
import json
import sys

PACKAGE = Path(__file__).resolve().parent
ROOT = Path('/mnt/VerifiableAILab/VerifiableAILab/zenan.li/VeriTile')
sha = lambda p: hashlib.sha256(p.read_bytes()).hexdigest()
load = lambda p: json.loads(p.read_text())
scope = load(PACKAGE / 'evidence/scope-current-comparison.json')
assert scope['status'] == 'passed'
assert scope['counts'] == {'not_accepted': 179, 'verified': 1, 'verified_with_deferred_numerics': 3}
tests = [('storage-tests.log', 8), ('global-gzip-tests-attempt3.log', 6),
         ('shard-tests.log', 38), ('current-adapter-regressions.log', 134),
         ('scope-regressions.log', 42)]
for name, count in tests:
    text = (PACKAGE / 'evidence' / name).read_text()
    assert f'Ran {count} tests' in text and text.rstrip().endswith('OK'), name
modified = ['bench/adapter_common.py', 'scripts/test_audit_shards.py']
assert all((ROOT / name).read_bytes() == (PACKAGE / 'before' / name).read_bytes()
           for name in modified), 'candidate inputs changed; rebase before handoff'
after = {str(p.relative_to(PACKAGE / 'after')): sha(p)
         for p in sorted((PACKAGE / 'after').rglob('*')) if p.is_file()}
assert len(after) == 4
for name in after:
    assert (PACKAGE / 'runtime' / name).read_bytes() == (PACKAGE / 'after' / name).read_bytes()
receipt_path = PACKAGE / 'evidence/receipt.json'
assert not receipt_path.exists(), 'freeze only once'
artifacts = {str(p.relative_to(PACKAGE)): sha(p)
             for p in sorted(PACKAGE.rglob('*')) if p.is_file()}
receipt = {
    'schema': 1, 'kind': 'explicit_json_gzip_storage_producer_proposal',
    'status': 'ready_for_independent_root_review_not_applied',
    'repository_mutations': 0, 'historical_mutations': 0,
    'candidate_files': after,
    'modified_source_before_sha256': {name: sha(PACKAGE / 'before' / name) for name in modified},
    'patch_sha256': sha(PACKAGE / 'candidate.patch'),
    'tests': [{'log': 'evidence/' + name, 'tests': count, 'status': 'passed'} for name, count in tests],
    'tests_total': sum(n for _, n in tests),
    'real_storage_roundtrip': load(PACKAGE / 'evidence/production-storage-replay.json'),
    'final_scope_comparison': scope,
    'preserved_attempts': {
        'test_regex_failure': 'evidence/global-gzip-tests-attempt2.log',
        'test_source': 'evidence/test_gzip_source_audit-attempt2.py',
        'stale_tool_scope_results': 'evidence/production-storage-replay.json',
        'stale_tool_diagnosis': 'evidence/scope-diagnosis-attempt1.log',
        'temporary_tool_rebase': 'evidence/tool-rebase.json',
        'overstrict_scope_count_assertion': 'evidence/scope-current-comparison.log',
        'scope_count_attempt_source': 'evidence/replay_scope_current-attempt1.py'},
    'artifacts': artifacts,
    'boundary': 'Representation and validation compatibility only; no proof acceptance. Root alone reviews/integrates. Numerical queue and frozen history remain plain and unchanged by this proposal.'}
receipt_path.write_text(json.dumps(receipt, indent=2) + '\n')
print(json.dumps({'receipt': str(receipt_path), 'sha256': sha(receipt_path),
                  'artifacts': len(artifacts), 'tests': receipt['tests_total']}))
