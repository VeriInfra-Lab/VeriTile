"""Trusted-report import preserves admission, domains and precision contracts."""
from copy import deepcopy
import json
from pathlib import Path
import shutil
import subprocess
import tempfile
import unittest

from scripts import export_supplemental_rules as exporter


class SupplementalExportTests(unittest.TestCase):
    def mutate(self, filename, update):
        tmp = tempfile.TemporaryDirectory()
        self.addCleanup(tmp.cleanup)
        target = Path(tmp.name)
        shutil.copytree(exporter.REPORT, target, dirs_exist_ok=True)
        path = target / filename
        content = json.loads(path.read_text())
        update(content)
        path.write_text(json.dumps(content))
        return target

    def test_exact_accepted_precision_instances_and_reproducible_export(self):
        _, _, rows, _, _ = exporter.load_report(exporter.REPORT)
        self.assertEqual(len(rows), 36)
        self.assertEqual(sum(r['format'] == 'fp64_fp64_fp32' for r in rows), 1)
        self.assertEqual({r['format'] for r in rows if r['rule'] == 'MUL-RCP-CANCEL'},
                         {'bf16_fp32', 'fp32'})
        text = exporter.render()
        self.assertEqual(text, exporter.OUTPUT.read_text())
        for name in ('fp32_log_exp', 'fp32_log_mul', 'bf16_mul_rcp_cancel',
                     'bf16_div_mul_rcp'):
            self.assertNotIn(f'def {name} :', text)
        self.assertIn('def bf16_fp32_exp_sub :', text)
        self.assertIn('def fp32_exp_sub :', text)
        self.assertIn('def fp32_mul_rcp_cancel :', text)
        self.assertNotIn('axiom ', text)

    def test_nonaccepted_results_cannot_be_promoted(self):
        for key in [('LOG-EXP', 'fp32'), ('LOG-MUL', 'fp32'),
                    ('DIV-MUL-RCP', 'bf16'),
                    ('MUL-RCP-CANCEL', 'bf16'), ('ADD-ZERO', 'fp64_fp64_fp32')]:
            def promote(report):
                row = next(r for r in report['rows'] if (r['rule'], r['format']) == key)
                row['accept'] = True
            with self.subTest(key=key):
                target = self.mutate('summary.json', promote)
                with self.assertRaisesRegex(ValueError, 'accept disagrees'):
                    exporter.render(target)

    def test_pass_labels_do_not_override_the_bias_budget(self):
        def exceed(report):
            next(r for r in report['rows'] if r['accept'])['B'] = .051
        with self.assertRaisesRegex(ValueError, 'budget'):
            exporter.render(self.mutate('summary.json', exceed))

    def test_source_profile_and_manifest_tampering_rejected(self):
        for kind in ('sources', 'shape', 'smoke', 'entries'):
            def alter(settings):
                if kind == 'sources':
                    settings['sources']['scripts/numerical_gates.py'] = '0' * 64
                elif kind == 'shape':
                    settings['profile']['shape'] = [32, 33]
                elif kind == 'smoke':
                    settings['smoke'] = True
                else:
                    settings['entries'].pop()
            with self.subTest(kind=kind):
                target = self.mutate('experiment.json', alter)
                with self.assertRaises(ValueError):
                    exporter.render(target)

    def test_incomplete_unknown_duplicate_or_missing_rows_rejected(self):
        for kind in ('unknown', 'duplicate', 'missing', 'replay', 'replicates'):
            def alter(summary):
                row = next(r for r in summary['rows'] if r['accept'])
                if kind == 'unknown':
                    row['rule'] = 'SOFTMAX-ONLINE'
                elif kind == 'duplicate':
                    summary['rows'].append(deepcopy(row))
                elif kind == 'missing':
                    summary['rows'].pop()
                elif kind == 'replay':
                    row['replayed'] = False
                else:
                    row['replicates'] = 1
            with self.subTest(kind=kind):
                target = self.mutate('summary.json', alter)
                with self.assertRaises(ValueError):
                    exporter.render(target)

    def test_scalar_operand_domains_are_retained(self):
        self.assertEqual(exporter.domain('DIV-MUL-RCP'),
                         [('a', 'finite'), ('b', 'finite'), ('b', 'nonzero')])
        self.assertEqual(exporter.domain('MUL-RCP-CANCEL'), [('a', 'finite'), ('a', 'nonzero')])
        self.assertEqual(exporter.domain('EXP-NEG-INF-SUB'), [('a', 'finite')])

    def test_trust_report_is_explicit(self):
        result = subprocess.run(['python3', 'scripts/export_supplemental_rules.py', '--check'],
                                cwd=exporter.ROOT, text=True, capture_output=True)
        self.assertNotEqual(result.returncode, 0)
        self.assertIn('--trust-report', result.stderr)

    def test_log_report_only_admits_guarded_rewrites(self):
        report = exporter.REPORT.parent / 'log_report'
        _, _, rows, _, _ = exporter.load_report(report)
        self.assertEqual({(r['rule'], r['format']) for r in rows},
                         {('LOG-MUL-GUARDED', 'fp32'), ('LOG-EXP-GUARDED', 'fp32'),
                          ('LOG-MUL-GUARDED-INTRINSIC', 'fp32'), ('LOG-EXP-GUARDED-INTRINSIC', 'fp32')})
        self.assertEqual(exporter.domain('LOG-EXP-GUARDED'), [('a', 'finite')])
        self.assertEqual(exporter.domain('LOG-MUL-GUARDED'),
                         [('a', 'finite'), ('b', 'finite'), ('a', 'positive'), ('b', 'positive')])
        self.assertEqual(exporter.domain('LOG-MUL-GUARDED-INTRINSIC'),
                         exporter.domain('LOG-MUL-GUARDED'))
        self.assertEqual(exporter.domain('LOG-EXP-GUARDED-INTRINSIC'), [('a', 'finite')])
        text = exporter.render(report, 'LogAdmission')
        self.assertEqual(text, (exporter.ROOT /
            'VeriTile/Triton/Float/LogAdmission.lean').read_text())
        for name in ('fp32_log_mul', 'fp32_log_mul_libdevice', 'fp32_log_mul_log1p',
                     'fp32_log_exp_libdevice', 'fp32_log_exp_full_libdevice',
                     'fp32_log_exp_log_libdevice', 'fp32_log_mul_log1p_intrinsic',
                     'fp32_log_exp_guarded_full_intrinsic', 'fp32_log_exp_guarded_exp_intrinsic'):
            self.assertNotIn(f'def {name} :', text)

        validation = exporter.REPORT.parent / 'log_product_validation_report'
        _, _, confirmed, _, _ = exporter.load_report(validation)
        self.assertEqual({(r['rule'], r['format']) for r in confirmed},
                         {('LOG-MUL-GUARDED', 'fp32'), ('LOG-EXP-GUARDED', 'fp32'),
                          ('LOG-MUL-GUARDED-INTRINSIC', 'fp32'), ('LOG-EXP-GUARDED-INTRINSIC', 'fp32')})

    def test_exp_reports_cover_both_implementations_and_confirm_decisions(self):
        from scripts import supplement_numerics as supplemental
        reports = [exporter.REPORT.parent / name for name in ('exp_report', 'exp_validation_report')]
        expected = {r for pair in supplemental.EXP_PAIRS for r in pair if not r.startswith('LOG-')}
        accepted = []
        for report in reports:
            settings, profile, rows, _, _ = exporter.load_report(report)
            self.assertEqual(set(profile['rules']), expected)
            self.assertEqual(settings['execution']['independent_cpu_replay']['complete_rows'], 6)
            accepted.append({row['rule'] for row in rows})
        self.assertEqual(*accepted)
        self.assertEqual(accepted[0], {'EXP-SUB', 'EXP-ZERO', 'EXP-ZERO-LIBDEVICE',
                                       'EXP-NEG-INF-SUB', 'EXP-NEG-INF-SUB-LIBDEVICE'})
        text = exporter.render(reports[0], 'ExpAdmission')
        self.assertEqual(text, (exporter.ROOT / 'VeriTile/Triton/Float/ExpAdmission.lean').read_text())
        self.assertNotIn('def fp32_exp_sub_intrinsic :', text)

    def test_invalid_namespace_is_rejected(self):
        with self.assertRaisesRegex(ValueError, 'identifier'):
            exporter.render(namespace='LogAdmission\naxiom injected : False')


if __name__ == '__main__':
    unittest.main()
