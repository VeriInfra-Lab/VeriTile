#!/usr/bin/env python3
"""Freeze a trusted, published numerical report into Lean rule data.

This is an explicit trust-report import, not independent replay or a proof of
GPU execution. It never creates EvidenceValidated proofs or IEEE axioms.
"""
import argparse
from collections import Counter
from copy import deepcopy
import hashlib
import json
import math
from pathlib import Path
import re

if __package__:
    from . import check_numerics as experiment
else:
    import check_numerics as experiment

ROOT = Path(__file__).resolve().parents[1]
REPORT = ROOT / 'experiments/floating_point/report'
OUTPUT = ROOT / 'VeriTile/Triton/Float/ReportedAdmission.lean'
# PR #11's user-trusted report predates domain filtering. Keep its exact
# source identity without relabelling it as a run of the new sampler.
LEGACY_SOURCE_SNAPSHOT = '1eb7897501c164b19973e3c114bf3e0522c58f23632e3317168b9bb6aea9f04b'


def validate_accepted_bounds(row, profile):
    """A PASS label cannot override the frozen numerical budgets."""
    tau = profile['gates']['bias']['tau']
    if (row.get('tau') != tau or any(type(row.get(k)) not in (float, int)
                                   or not math.isfinite(row[k]) or row[k] < 0 for k in ('B', 'U'))
            or row['B'] > tau or row['U'] > profile['gates']['vars']['warn']):
        raise ValueError('accepted row disagrees with bias or magnitude budget')


def digest(data):
    return hashlib.sha256(data).hexdigest()


def load_report(directory):
    settings = experiment.read_json(directory / 'experiment.json')
    summary = experiment.read_json(directory / 'summary.json')
    profile = experiment.validate_profile(deepcopy(settings['profile']))
    if (settings['sources'] != experiment.source_hashes()
            and digest(experiment.registry.canonical_json(settings['sources'])) != LEGACY_SOURCE_SNAPSHOT):
        raise ValueError('report source hashes differ from the numerical implementation')
    if profile['gates']['warning_policy'] != 'pass_only':
        raise ValueError('this exporter requires pass_only admission')
    formats = {f['name']: f for f in profile['formats']}
    expected = {(r, f) for r in profile['rules'] for f in formats}
    seen, accepted = set(), []
    for row in summary['rows']:
        identity = row['rule'], row['format']
        if identity not in expected or identity in seen:
            raise ValueError('unknown or duplicate rule/format row')
        seen.add(identity)
        for flag in ('accept', 'replayed'):
            if type(row[flag]) is not bool:
                raise ValueError('the published report must have final Boolean flags')
        passed = (row['state'] == 'COMPLETE' and row['replayed']
                  and row['decision'] == 'ACCEPT' and row['bias'] == 'PASS'
                  and row['vars'] == 'PASS')
        if row['accept'] != passed:
            raise ValueError('accept disagrees with the reported state and gates')
        if passed:
            validate_accepted_bounds(row, profile)
            if (type(row['replicates']) is not int
                    or not profile['replicates'] <= row['replicates'] <=
                    ((profile['replicates_max'] + profile['batch'] - 1) // profile['batch']) * profile['batch']
                    or row['replicates'] % profile['batch']):
                raise ValueError('invalid replicate count in accepted row')
            accepted.append(row)
    if seen != expected or summary['total'] != len(expected):
        raise ValueError('report does not cover the frozen profile')
    if (summary['accepted'] != len(accepted)
            or summary['replayed'] != sum(r['replayed'] for r in summary['rows'])
            or summary['states'] != dict(Counter(r['state'] for r in summary['rows']))
            or summary['complete'] is not True):
        raise ValueError('inconsistent report totals')
    hashes = {name: digest((directory / name).read_bytes())
              for name in ('experiment.json', 'summary.json')}
    snapshot = digest(experiment.registry.canonical_json(hashes))
    return settings, profile, accepted, hashes, snapshot


def lean_string(value):
    # JSON string escapes used here are also Lean string escapes for ASCII.
    # The exported payload is ASCII JSON even if report metadata contains Unicode.
    return json.dumps(value, ensure_ascii=False)


def declaration_name(row):
    name = row['format'] + '_' + row['rule'].lower().replace('-', '_')
    if not re.fullmatch('[A-Za-z_][A-Za-z_0-9]*', name):
        raise ValueError('invalid generated declaration name')
    return name


def render(directory=REPORT):
    settings, profile, rows, hashes, snapshot = load_report(directory)
    try:
        report_path = str(directory.resolve().relative_to(ROOT))
    except ValueError:
        report_path = str(directory.resolve())
    metadata = {'trust': 'published report trusted by the user; no independent replay during export',
                'report_sha256': hashes, 'bundle_manifest_sha256': settings['bundle_manifest_sha256'],
                'profile': profile, 'backend': settings['backend'], 'sources': settings['sources']}
    encoded = experiment.registry.canonical_json(metadata).decode('ascii')
    lines = [
        '/- Generated by scripts/export_numerical_rules.py --trust-report. Do not edit.',
        '   Only accepted rows are exported. Numerical validity remains the explicit',
        '   scoped model assumption; this file adds no axioms. -/',
        'import VeriTile.Triton.Float.ReportedRules', '',
        'namespace VeriTile.Triton.FP.ReportedAdmission', '',
        f'def snapshot : String := {lean_string(snapshot)}',
        f'def reportMetadata : Lean.Json := (Lean.Json.parse {lean_string(encoded)}).toOption.getD .null',
        '',
    ]
    formats = {f['name']: f for f in profile['formats']}
    for row in rows:
        name = declaration_name(row)
        fmt = formats[row['format']]
        row_json = experiment.registry.canonical_json(row).decode('ascii')
        key = f'report:{snapshot}:{row["format"]}:{row["rule"]}'
        artifact = f'{report_path}/summary.json#{row["format"]}/{row["rule"]}'
        dist = profile['distribution']
        description = (f"shape={profile['shape']}; block={profile['launch']['block']}; "
                       f"input/compute/accumulator/output={fmt['input']}/{fmt['compute']}/"
                       f"{fmt['accumulator']}/{fmt['output']}; "
                       f"independent Normal(mean={dist['mean']}, std={dist['std']})")
        lines += [f'def {name} : ReportedRule where',
                  f'  ruleID := {lean_string(row["rule"])}',
                  f'  format := {lean_string(row["format"])}',
                  f'  key := {lean_string(key)}',
                  f'  artifact := {lean_string(artifact)}',
                  f'  description := {lean_string(description)}',
                  '  configuration := Lean.Json.mkObj [("report", reportMetadata),',
                  f'    ("row", (Lean.Json.parse {lean_string(row_json)}).toOption.getD .null)]',
                  f'  shape := {profile["shape"]}', f'  block := {profile["launch"]["block"]}']
        lines += [f'  {field} := {lean_string(fmt[field])}'
                  for field in ('input', 'compute', 'accumulator', 'output')]
        lines.append('')
    lines += ['def all : List ReportedRule := [',
              '  ' + ',\n  '.join(declaration_name(row) for row in rows) + ']', '',
              f'theorem accepted_count : all.length = {len(rows)} := rfl', '',
              'end VeriTile.Triton.FP.ReportedAdmission', '']
    return '\n'.join(lines)


def main():
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument('--report', type=Path, default=REPORT)
    parser.add_argument('--output', type=Path, default=OUTPUT)
    parser.add_argument('--trust-report', action='store_true', required=True,
                        help='explicitly trust the published report instead of replaying GPU observations')
    parser.add_argument('--check', action='store_true', help='fail if the committed Lean table is stale')
    args = parser.parse_args()
    try:
        content = render(args.report)
        if args.check:
            if args.output.read_text() != content:
                raise ValueError('generated Lean table is stale; regenerate before proving')
        else:
            args.output.parent.mkdir(parents=True, exist_ok=True)
            args.output.write_text(content)
        print(f'{"Checked" if args.check else "Generated"} {args.output}')
    except (OSError, ValueError, KeyError, TypeError) as error:
        parser.error(str(error))


if __name__ == '__main__':
    main()
