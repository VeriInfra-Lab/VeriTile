"""Only the scope comparison after rebasing the temporary quant tool copy."""
from pathlib import Path
import sys

PACKAGE = Path(__file__).resolve().parent
ROOT = Path('/mnt/VerifiableAILab/VerifiableAILab/zenan.li/VeriTile')
sys.path.insert(0, str(PACKAGE / 'runtime/bench'))
from adapter_common import hash_file, load, write_json
from check_original_program_scope import check

files = load(PACKAGE / 'evidence/data-inputs.json')
pins = {row['source']: hash_file(ROOT / row['source']) for row in files.values()}
pins['bench/tritonbench_g/deferred_numerical_experiments.json'] = hash_file(
    ROOT / 'bench/tritonbench_g/deferred_numerical_experiments.json')
for name, digest in load(PACKAGE / 'evidence/input-sha256.json').items():
    if not name.endswith('.py'):
        continue
    current = hash_file(ROOT / name)
    if name == 'bench/quant_transpose_numerical_extension.py':
        assert current == hash_file(PACKAGE / 'runtime' / name)
    else:
        assert current == digest, 'unrebased tool drift: ' + name
    pins[name] = current
write_json(PACKAGE / 'evidence/scope-current-input-pins.json', pins)
plain = check(ROOT, load(PACKAGE / 'inputs/catalog.json'), load(PACKAGE / 'inputs/ledger.json'))
write_json(PACKAGE / 'evidence/scope-current-plain-result.json', plain)
print('plain:', plain['counts'], flush=True)
compressed = check(ROOT, load(PACKAGE / 'compressed/catalog.json.gz'),
                   load(PACKAGE / 'compressed/ledger.json.gz'))
write_json(PACKAGE / 'evidence/scope-current-gzip-result.json', compressed)
print('compressed:', compressed['counts'], flush=True)
assert plain == compressed
assert plain['counts'] == {'not_accepted': 179, 'verified_with_deferred_numerics': 4}
after = {name: hash_file(ROOT / name) for name in pins}
assert pins == after, 'source data or tools changed during scope replay'
write_json(PACKAGE / 'evidence/scope-current-comparison.json', {
    'kind': 'storage_scope_comparison_not_acceptance', 'status': 'passed',
    'plain_gzip_results_equal': True, 'counts': plain['counts'],
    'scope_gate_status': plain['status'], 'input_pins_before_after_equal': True,
    'input_pins_sha256': hash_file(PACKAGE / 'evidence/scope-current-input-pins.json'),
    'rebase_sha256': hash_file(PACKAGE / 'evidence/tool-rebase.json'),
    'boundary': 'Same four existing conditional scope reviews and 179 pending. No new acceptance.'})
