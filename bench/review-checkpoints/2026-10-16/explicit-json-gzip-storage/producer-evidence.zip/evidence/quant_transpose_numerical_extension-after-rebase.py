"""Fail-closed proposed transpose extension requiring independent root pins.
Only repository sources and retained checkpoint evidence become queue inputs.
Historical object paths are checked during producer/root verification, not CI.
"""
import sys
sys.dont_write_bytecode = True
from copy import deepcopy
import hashlib
import json
from pathlib import Path


def hash_file(path):
    return hashlib.sha256(Path(path).read_bytes()).hexdigest()


def load(path):
    return json.loads(Path(path).read_text())


def safe_path(root, relative):
    relative = Path(relative)
    path = (root / relative).resolve()
    if relative.is_absolute() or '..' in relative.parts or not path.is_relative_to(root):
        raise ValueError('transpose evidence path escapes root: ' + str(relative))
    return path


def native_receipt_inputs(package, reference, original_sha256):
    """Resolve copied artifacts locally; receipt absolute paths are provenance only."""
    package = Path(package).resolve()
    receipt_path = safe_path(package, reference['path'])
    if hash_file(receipt_path) != reference['sha256']:
        raise ValueError('changed transpose native receipt')
    receipt = load(receipt_path)
    actual_source = receipt.get('source_sha256', receipt.get('original_source_sha256'))
    unchanged = receipt.get('production_ast_unchanged', receipt.get('production_AST_unchanged'))
    if actual_source != original_sha256 or unchanged is not True:
        raise ValueError('native receipt does not bind original transpose source')
    if receipt.get('gpu_launches', receipt.get('gpu_executions')) != 0:
        raise ValueError('unexpected transpose native execution claim')
    inputs = {Path(reference['path']).as_posix(): reference['sha256']}
    def retain(name, expected):
        relative = (Path(reference['path']).parent / name).as_posix()
        path = safe_path(package, relative)
        if hash_file(path) != expected:
            raise ValueError('changed transpose native artifact: ' + relative)
        if inputs.get(relative, expected) != expected:
            raise ValueError('conflicting native artifact hash')
        inputs[relative] = expected
    prefix = Path(receipt['copied_prefix']).name if 'copied_prefix' in receipt else 'original_prefix.py'
    retain(prefix, receipt['copied_prefix_sha256'])
    if 'probe_sha256' in receipt:
        retain('probe_native.py', receipt['probe_sha256'])
    for record in receipt['records']:
        if any(record['constexprs'].get(k) != v for k, v in {'BLOCK_M':128, 'BLOCK_N':128, 'GROUP_M':8}.items()):
            raise ValueError('changed transpose native block configuration')
        if record['config_index'] not in [0, 1]:
            raise ValueError('unknown transpose native config entry')
        if any(record['options'].get(k) != v for k, v in {'num_warps':4, 'num_ctas':1, 'num_stages':3}.items()):
            raise ValueError('changed transpose native launch options')
        target = record.get('target', receipt.get('target'))
        if target != {'backend':'cuda', 'arch':90, 'warp_size':32}:
            raise ValueError('changed transpose native target')
        for artifact in record.get('artifacts', {}).values():
            retain(Path(artifact['path']).name, artifact['sha256'])
    return inputs


def project_dependency_inputs(package, snapshot_references):
    """Union project sources/repository inputs; preserve objects as evidence only."""
    package = Path(package).resolve()
    result = {}
    for reference in snapshot_references:
        path = safe_path(package, reference['path'])
        if hash_file(path) != reference['sha256']:
            raise ValueError('changed transpose dependency snapshot')
        snapshot = load(path)
        captured_roots = set()
        for module, entry in snapshot.get('project', {}).items():
            relative = module.replace('.', '/') + '.lean'
            source = Path(entry['source'])
            if source.parts[-len(Path(relative).parts):] != Path(relative).parts:
                raise ValueError('invalid captured transpose source path')
            captured_roots.add(source.parents[len(Path(relative).parts)-1])
            if result.get(relative, entry['sha256']) != entry['sha256']:
                raise ValueError('conflicting transpose dependency snapshot: ' + relative)
            result[relative] = entry['sha256']
        if snapshot.get('input_sha256'):
            if len(captured_roots) != 1:
                raise ValueError('ambiguous captured transpose repository root')
            captured_root = next(iter(captured_roots))
            for captured, expected in snapshot['input_sha256'].items():
                source = Path(captured)
                if not source.is_relative_to(captured_root):
                    raise ValueError('nonrepository input in transpose dependency snapshot')
                relative = source.relative_to(captured_root).as_posix()
                if result.get(relative, expected) != expected:
                    raise ValueError('conflicting transpose repository input snapshot')
                result[relative] = expected
    return result


def extend_authority(root, previous, package_path, receipt_sha256, review_path, review_sha256):
    from adapter_common import declarations
    root = Path(root).resolve()
    result = deepcopy(previous)
    def bind(relative, expected):
        path = safe_path(root, relative)
        if not path.is_file() or hash_file(path) != expected:
            raise ValueError('changed reviewed transpose input: ' + str(relative))
        key = 'repo:' + Path(relative).as_posix()
        if result['input_sha256'].get(key, expected) != expected:
            raise ValueError('conflicting preexisting exact input: ' + key)
        result['input_sha256'][key] = expected
        return path
    package_relative = Path(package_path)
    package = safe_path(root, package_relative)
    receipt = load(bind(package_relative / 'evidence/receipt.json', receipt_sha256))
    review = load(bind(review_path, review_sha256))
    if (receipt.get('frozen') is not True or review.get('reviewer') != 'root'
            or review.get('status') != 'substantively_reviewed_for_finite_scope_integration'
            or review.get('producer_receipt_sha256') != receipt_sha256):
        raise ValueError('unreviewed transpose finite authority')
    mapping = receipt['checkpoint_module_source_paths']
    if mapping != {p:p+'.txt' for p in receipt['modules']}:
        raise ValueError('invalid frozen transpose source mapping')
    for relative, expected in receipt['modules'].items():
        bind(package_relative / mapping[relative], expected)
        bind(relative, expected)
    for relative, expected in receipt['artifacts'].items():
        # Archive exact historical source/object bytes outside active Lean discovery.
        archived = relative + '.txt' if relative.endswith('.lean') else (
            relative + '.bin' if relative.endswith(('.olean', '.olean.private', '.olean.server', '.ilean', '.ir', '.pyc')) else relative)
        bind(package_relative / archived, expected)
    delta = load(package / 'evidence/numerical-authority-delta.json')
    if delta['task'] != 'quant_transpose_kernel':
        raise ValueError('wrong task in transpose numerical delta')
    actual_counts = {'scalar_families':len(delta['rules']), 'scope_bindings':len(delta['provenance']),
        'declaration_cases':sum(len(t['cases']) for t in delta['requirements']),
        'registered_declarations':len(delta['requirements'])}
    if any(delta['summary'].get(key) != value for key, value in actual_counts.items()):
        raise ValueError('inconsistent transpose authority counts')
    snapshots = delta['dependency_snapshots']
    expected_snapshots = {p for p in receipt['artifacts'] if Path(p).parent == Path('evidence')
        and (Path(p).name == 'dependencies-before.json' or Path(p).name.startswith('dependencies-added-before-'))}
    if {r['path'] for r in snapshots} != expected_snapshots or len(snapshots) != len(expected_snapshots):
        raise ValueError('incomplete transpose dependency snapshots')
    for reference in snapshots:
        if receipt['artifacts'].get(reference['path']) != reference['sha256']:
            raise ValueError('unbound transpose dependency snapshot')
    for relative, expected in project_dependency_inputs(package, snapshots).items():
        bind(relative, expected)
    after_path = 'evidence/dependencies-after.json'
    if after_path not in receipt['artifacts']:
        raise ValueError('missing transpose dependency verification receipt')
    after = load(package / after_path)
    expected_captures = {r['path']:{'sha256':r['sha256'], 'verified_unchanged':True} for r in snapshots}
    if after.get('all_unchanged') is not True or after.get('captures') != expected_captures:
        raise ValueError('incomplete transpose dependency verification receipt')
    native_evidence = delta['native_evidence']
    if len(native_evidence) != 2 or {r['role'] for r in native_evidence} != {'original_dtype_config_matrix', 'independent_mixed_width_metadata'}:
        raise ValueError('incomplete transpose native provenance')
    original = delta['original_source']
    bind(original['path'], original['sha256'])
    native_references = []
    for evidence in native_evidence:
        reference = evidence['receipt']
        inputs = native_receipt_inputs(package, reference, original['sha256'])
        if inputs != evidence['retained_inputs']:
            raise ValueError('incomplete retained transpose native inputs')
        for relative, expected in inputs.items():
            if receipt['artifacts'].get(relative) != expected:
                raise ValueError('unbound transpose native artifact: ' + relative)
            bind(package_relative / relative, expected)
        native_references.append(reference)
    for port in delta['provenance'].values():
        if port['original_source'] != original or port['native_receipts'] != native_references:
            raise ValueError('transpose port native provenance mismatch')
        if port['lean_source_sha256'] != receipt['modules']:
            raise ValueError('transpose port module provenance mismatch')
        legacy = port['legacy_route_source']
        bind(legacy['path'], legacy['sha256'])
    for table in delta['requirements']:
        reference = table['declaration']
        declaration = declarations(root / reference['file']).get(reference['declaration'])
        if declaration is None or declaration['kind'] != 'specification' or declaration['statement_sha256'] != reference['statement_sha256']:
            raise ValueError('changed transpose public statement')
    old_ids = {r['id'] for r in result['rules']}
    new_ids = [r['id'] for r in delta['rules']]
    old_refs = {(r['declaration']['file'],r['declaration']['declaration']) for r in result['requirements']}
    new_refs = [(r['declaration']['file'],r['declaration']['declaration']) for r in delta['requirements']]
    if (old_ids.intersection(new_ids) or len(new_ids) != len(set(new_ids))
            or set(result['provenance']).intersection(delta['provenance'])
            or old_refs.intersection(new_refs) or len(new_refs) != len(set(new_refs))):
        raise ValueError('reviewed transpose authority collision')
    result['rules'] += deepcopy(delta['rules'])
    result['provenance'].update(deepcopy(delta['provenance']))
    result['requirements'] += deepcopy(delta['requirements'])
    result.setdefault('independent_source_reviews', []).append({'package':'repo', 'path':str(review_path), 'sha256':review_sha256})
    result['summary'].update(new_scalar_families=len(result['rules']), scope_bindings=len(result['provenance']),
        declaration_cases=sum(len(r['cases']) for r in result['requirements']),
        registered_declarations=len(result['requirements']), unvalidated_numeric_instances=len(result['provenance']),
        quant_transpose_finite_delta=deepcopy(delta['summary']))
    return result
