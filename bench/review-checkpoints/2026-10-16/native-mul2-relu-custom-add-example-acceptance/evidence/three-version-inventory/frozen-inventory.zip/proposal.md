# Real / FP32 / BF16 acceptance: independent sidecar proposal

This is a reviewable migration proposal and an evidence inventory. It performs no repository write, acceptance promotion, proof change, numeric-registration change, or validator change.

Use a new `bench/original_program_versions.json` sidecar with `kind=three_version_source_acceptance`, `schema=1`, and `policy_id=real-fp32-bf16-v1`. For a later implementation step, add a separate `check_original_program_versions.py` command. The immediate landing is the policy and 183-task evidence inventory; no new checker is required to publish that honest progress view. Keep `check_original_program_scope.py` and the meaning of its schema2 records unchanged. The old whole-original-domain counts and the new three-version counts answer different questions.

## Meaning of the three versions

- **Real** is the source algorithm under an explicitly reviewed mathematical abstraction and ideal arithmetic. It is not a tensor dtype, a Triton signature, or a GPU ABI. Retain source control flow, indexing, allocation/frame effects, and as-written behavior. For example, abstraction cannot silently repair ReLU's pid-zero-only stores. Mathematical treatment of quantization, casts, bit operations, special values, and source failures must be stated; a theorem whose metadata says `mathematical` is not enough by itself.
- **FP32** and **BF16** use actual source input, output, accumulation, intermediate-operation, conversion, and target/configuration profiles. BF16 inputs with FP32 accumulation or FP32 output can be a BF16 version. A BF16 output on a packed-input conversion alone does not establish the generic BF16-input version.
- Preserve indispensable source types and profiles: packed quantized data, integer outputs, indices, masks, source-required FP16, and mixed precision. Identify payload ports and special ports explicitly, with source evidence. Do not replace every port type with the version label.
- The default work list is three versions, plus explicitly justified indispensable profiles. Do not generate all runtime dtype families or Cartesian dtype pairs. Existing wider proofs and exact numerical registrations remain valid evidence and remain recorded; new work selects the required source-grounded profiles without deleting old claims.

## Separate proof coverage from implementation support

Each version has independent fields for `proof_status`, `support_status`, and `native_status`. A proof may correctly characterize original rejection while the original implementation remains unsupported. A successful offline compile is not GPU execution. A repaired candidate never changes the original's support status.

Suggested proof states are `pending`, `verified`, and `verified_with_deferred_numerics`. Suggested support states are `unreviewed`, `mathematical_not_runtime`, `supported_original`, `partially_supported_original`, `unsupported_original`, `variant_only`, and `essential_profile_exception`. Native states distinguish `not_applicable`, `not_evaluated`, `compile_observed`, and `gpu_execution_observed`.

A finite compile failure is initially an observation tied to its exact original source, target, compiler options, and configuration. It does not automatically establish failure of all configurations. An original-profile support review resolves the required domain and derives the aggregate support state. `unsupported_original` and `variant_only` never contribute to the successful original FP32/BF16 implementation count.

For a wrapper that hardcodes FP16, such as `matrix_transpose`, keep its accepted FP16 evidence and propose an explicit essential-profile policy review. Do not mechanically relabel that theorem FP32/BF16 and do not silently mark those requested versions complete or remove them from the denominator. If a policy exception is approved, display it separately from a functioning original FP32/BF16 version.

## Reuse exact evidence, review the projection

The sidecar pins the current catalog, old scope ledger, numerical queue, original Python sources, and every referenced public declaration hash. Store each concrete case once and refer to its canonical case ID from coverage entries. Do not copy a 22-by-22 case matrix into every stage/branch obligation.

Reuse the existing source inventory for stage/branch identities and harness review. Record a reviewed index of applicable memory obligations: allocation, aliasing, reads/writes, unwritten cells, frames, masks, offsets, integer overflow, and error-before/after-effect obligations. Reuse existing accepted proofs and reviews that already discharge them. The old structural inventory has no independent memory dimension, so attach the existing memory evidence and review its version instantiation; this is not a request to reprove every accepted obligation.

Each version must account for every applicable shared obligation with an explicit disposition, proof references, case IDs where relevant, explanation, and review. A shared coverage group may contain the common proof references once and each version may point to its reviewed instantiation; do not duplicate the evidence or repeat the proof. Reuse can be justified by one theorem polymorphic in the relevant carrier/width, or by a reviewed instantiation of that theorem; the version still names its instantiation. Dtype-dependent branches, pointer widths, storage conversions, arithmetic error behavior, and memory footprints require their actual profiles. Shared strings or matching file names do not prove applicability.

For Real, keep mathematical domain/specification and source-abstraction review separate from runtime cases. Reuse the existing mathematical host/index/frame model where applicable; do not invent a native Real host or ABI implementation. Do not add `real` to `check_original_program_scope.DTYPES` or route Real through `validate_case`. A mathematical abstraction cannot establish floating-point callback conformance.

For FP32/BF16, retain the existing exact `{dtype_profile: {inputs, outputs, compute}, configuration}` case format. Add explicit payload-port roles and an operation/conversion profile reference. Projection to a version does not make a subset theorem a whole-version theorem: required profile-domain exhaustiveness and all stage/branch/memory obligations need substantive review.

## Preserve the numerical gate

Reuse `validate_case`, `validate_deferrals`, and `validate_used_numerics` for the selected concrete cases. The new checker can construct the same per-proof canonical `proof_cases` mapping and call the existing helper without changing its implementation. Preserve exact `deferred_numerical_assumptions` and `callback_assumptions` entries.

`exact_scope_gate.validated_exact_requirements` first validates the complete queue against source-derived authority, then permits selected cases only when they are members of the exact authority table. `validate_exact_case_links` requires every scalar port binding, including repeated callbacks. Keep this behavior and the existing scalar-port tables intact. Never infer precision/configuration compatibility from a version label, prose, operation name, or old task status.

Real has a separate mathematical assumption audit. It cannot inherit a floating-point deferral as a mathematical truth. Undefined conversions and known false claims remain non-deferrable.

## Minimal implementation and migration sequence

1. Land the policy document and the 183-task evidence inventory first. The separate checker and final machine schema are a later, bounded implementation step, not a prerequisite for showing existing progress. Keep the old schema2 checker, exact numerical validators, default legacy command, public statements, and accepted old records unchanged.
2. Freeze one coherent catalog/ledger/queue snapshot. Seed 183 rows with Real/FP32/BF16 records all `pending`; copy only evidence candidates and exact input pins. Preserve old status and review references in `legacy` fields. Do not convert old `verified` into three new `verified` states.
3. Review each task's required profiles and essential types. Start with homogeneous payload FP32/BF16 and source-required exceptions. Existing mixed-input evidence is available, but does not mandate expanding a Cartesian product.
4. Review source-to-model projection, shared obligation applicability, memory inventory, and exact numerical links for each version. Pin the review to canonical sidecar content excluding the review field, catalog/public/source hashes, selected cases, profile domain, memory inventory, and queue authority.
5. Validate with the new checker. Only then set the corresponding proof/support state. Keep native tests, official comparator, build, and trust-audit results separate and hash-bound. A candidate-native result remains attached to its candidate source.
6. Publish both dashboards: legacy schema2 accepted count; per-version proof states; original supported/unsupported/partial/exception states; repaired-variant progress; native observations. Do not publish one new "fully done" task count until its aggregation rule is explicit.

The current inventory is anchored to commit `97e11a9a6cea8d5dfe35db643a1492d79e423cdf` and preserves its 4/183 accepted states. The four independently reviewed tasks being integrated are a separate candidate list. After their checkpoint is committed, regenerate from that coherent snapshot and preserve 8/183 under the **legacy** policy. Neither 4 nor 8 means that all three new versions have passed.

## Required checker rejection cases

- Unknown/missing tasks, missing one of the three slots, duplicate identities, stale catalog/source/public/queue/review hashes, or acceptance without a substantive root review.
- Real inserted into runtime dtype maps, a bit-interpreter declaration automatically treated as Real, or FP callbacks silently reused as real equalities.
- Output-only BF16 or a mixed-input profile automatically treated as homogeneous BF16; source-required integer/packed/index types silently replaced; FP32 accumulation wrongly rejecting a source-correct BF16 profile.
- A repaired or compiled-graph declaration substituted for original-source execution; an original compile rejection counted as successful implementation; one native configuration generalized to all configurations without a domain review.
- Missing stage, branch, memory/frame, source rejection, or production host-wiring obligations; sharing without per-version applicability; empty/tautological final-output oracle evidence.
- Missing scalar callback/port links, incorrect numeric configuration/dtype/declaration bindings, refuted assumptions, or dropping old registrations to make a selected version pass.
- Automatic 22-family/pair expansion or silent removal of an indispensable profile. Explicitly selected complete source domains still require all relevant cases within that domain.

The small `representation-example.json` illustrates the proposed data separation. It is not an implemented schema or acceptance validator. The immediate inventory is useful without adopting that exact future format. Only the new-policy projection is unreviewed: the existing proofs and old accepted states retain their full previously reviewed meaning.

## Existing-evidence inventory limits and counts

`inventory.json` retains declaration-level references, structured case profiles, source inventory bindings, frozen package references, and separately mapped variant evidence. `inventory.csv` is the 183-row summary. `summary.json` is authoritative for computed counts. The inventory checks committed document hashes and the current bytes of 3,616 pinned task source files; it does not rerun Lean, native compilation, the official comparator, or the old acceptance checker.

Real model evidence is found for 177 tasks. Six have no explicit mathematical-contract mapping in this catalog: `fp4_to_bf16`, `isfinite_kernel`, `layer_norm_triton`, `multinomial_sampling`, `spinning_lock_reduction`, and `streamk_matmul`. This is an evidence-discovery statement, not a proof of nonexistence.

FP32 and BF16 each have structured homogeneous-input cases for four tasks: `quant_transpose_kernel`, `quantize_global`, `relu_triton_kernel`, and `vector_addition`. These cases include successful, error, and rejection partitions; counts are not successful runtime test counts. For BF16, the two quantization tasks have only error/unsupported partitions (`unsupported_llrint` and `unsupported_llrint_overload`), with no returned-outcome label. Only old ReLU and vector addition among these four have BF16 returned-outcome labels, which still require version projection review. In particular, the old ReLU case metadata is not an automatic new-policy acceptance.

There are 99 FP32 and 55 BF16 textual profile hits across tasks. These counts overlap with structured evidence and may mention accumulation, output, or limitations. They are not implementation counts. The conservative inventory puts mixed/index/packed input profiles in a separate bucket until source-specific port roles are reviewed.

Separately from those two structured unsupported BF16 partitions, two frozen packages contain explicit original BF16 compile failures at their recorded configurations: `attention_kernel_aligned` and `sgmv_expand_slice`. The latter also records a comma-only repaired candidate's offline compile success. Native-rejection discovery follows explicit native profile fields of the pinned value-registry receipts; it is not a new exhaustive native sweep. Nine tasks have variant declarations whose precision projection remains unassigned.

All 549 requested task/version cells have new-policy mapping status `not_evaluated_under_new_policy`. This means the new projection has not been reviewed, not that the 177 mathematical-contract evidence sets or existing FP proofs have disappeared or failed. Zero acceptance transitions were assigned by this inventory; no new-policy acceptance checker was run.
