# Three-version evidence inventory and migration proposal

Immediate landing recommendation: policy plus the 183-task evidence inventory. Reuse existing proof groups and review the Real/FP32/BF16 instantiations. A new acceptance checker is a later bounded implementation step. This package changes no repository file or acceptance state.

- `proposal.md`: interpretation, shared-proof reuse, exact numeric gate reuse, and minimal migration sequence.
- `inventory.json`: complete 183-task map with declaration references and frozen evidence pins.
- `inventory.csv`: compact per-task counts.
- `summary.json`: precise counts, unsupported original observations, and four integration candidates kept separate.
- `representation-example.json`: small illustrative records; not a schema or acceptance result.
- `input-sha256.json` and `reviewed-policy-code-inputs.json`: committed baseline and reviewed input pins.
- `validation.json`: evidence-map consistency audit. `reproducibility.json`: byte-identical regeneration check.
- `receipt.json`: final package hashes; no inferred Lean/native/checker results.

Baseline: `97e11a9a6cea8d5dfe35db643a1492d79e423cdf`. Old schema2 accepted count remains **4/183** (one verified, three with deferred numerics). The four independently reviewed integration candidates are separately annotated; this snapshot does not mix in their in-progress catalog/ledger state. After the integration is committed, re-inventory a coherent snapshot to retain the old 8/183 count independently of the new policy.

| Existing evidence | Real | FP32 | BF16 |
| --- | ---: | ---: | ---: |
| Tasks with explicit mathematical model declarations | 177 | — | — |
| Tasks with structured homogeneous-input case evidence | — | 4 | 4 |
| Of those, tasks with a returned-outcome label | — | 4 | 2 |
| Tasks with prose profile mentions (overlaps other rows) | — | 99 | 55 |
| Tasks with explicit structured unsupported partitions | — | 0 | 2 |
| Tasks with recorded original native compile failures in frozen package fields | — | 0 | 2 |
| New-policy version projection not yet reviewed | 183 | 183 | 183 |

**These are evidence counts, not successful implementation or completed-version counts.** BF16 unsupported structured partitions belong to `quantize_global` and `quant_transpose_kernel`; the two separately recorded native failures belong to `attention_kernel_aligned` and `sgmv_expand_slice`. Observations retain their recorded source/configuration scope. A repaired candidate's offline success remains separate.

The 177 Real entries are mathematical-contract evidence sets available for reuse, not 177 fully accepted new Real versions. New-policy projection status does not revoke existing proofs or erase prior progress. No acceptance transition is assigned here.

Reproduce the inventory with `python -B build_inventory.py` in this directory while the pinned source files and the separately pinned four candidate packages remain available. Audit it with `python -B validate_inventory.py`. Both scripts read the repository and write only this package directory. They do not run Lean, native compilation, GPU execution, comparator, or acceptance checkers.
