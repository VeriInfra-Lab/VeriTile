"""Read-only consistency audit of evidence mapping, not an acceptance checker."""
from pathlib import Path
from collections import Counter
import csv,hashlib,json,subprocess,sys
sys.dont_write_bytecode=True
W=Path(__file__).resolve().parent;R=Path('/mnt/VerifiableAILab/VerifiableAILab/zenan.li/VeriTile')
I=json.loads((W/'inventory.json').read_text());S=json.loads((W/'summary.json').read_text());P=json.loads((W/'input-sha256.json').read_text())
C=I['metadata']['baseline_commit']
def canon(x):return json.dumps(x,sort_keys=True,separators=(',',':'),ensure_ascii=False).encode()
def sha(x):return hashlib.sha256(x).hexdigest()
def committed(p):return subprocess.check_output(['git','show',C+':'+p],cwd=R)
for p,e in P['committed_documents'].items():
 b=committed(p);assert sha(b)==e['sha256'] and len(b)==e['bytes'],p
cat=json.loads(committed('bench/review-checkpoints/2026-10-16/native-vector-quant-transpose-acceptance/current-source-catalog.json'))
ledger=json.loads(committed('bench/original_program_scope.json'))
tasks={t['task']:t for t in I['tasks']};old={t['task']:t for t in ledger['tasks']}
assert len(tasks)==183 and set(tasks)==set(old)
assert set(tasks)=={t['task'] for t in cat['tasks']} - {'fp4_to_bf16_conversion'}
public={d['file']+'::'+d['declaration']:(t['task'],d) for t in cat['tasks'] if t['task'] in tasks for d in t['declarations']}
assert set(public)==set(I['declaration_index']) and len(public)==955
checked_structured=0
for name,t in tasks.items():
 assert t['old_policy_scope_status']==old[name]['status']
 assert t['source_inventory_sha256']==sha(canon(old[name]['source_inventory']))
 assert t['new_policy_assignment']=='none_inventory_only'
 assert set(t['versions'])=={'Real','FP32','BF16'}
 for version,v in t['versions'].items():
  assert v['new_policy_mapping_status']=='not_evaluated_under_new_policy'
  for k in v['mathematical_declarations']:
   owner,d=public[k];assert owner==name and d.get('fp_model_review',{}).get('kind')=='mathematical_contract'
  for field in ['structured_primary_profile_declarations','documented_profile_mentions','output_or_mixed_profile_declarations','variant_declarations']:
   for e in v[field]:assert public[e['declaration']][0]==name
  for e in v['structured_primary_profile_declarations']:
   d=public[e['declaration']][1];assert not d.get('source_variant') or d['source_variant']=='original_source_translation'
   dtype={'FP32':'fp32','BF16':'bf16'}[version]
   actual={canon(c):c for cases in d['original_scope']['cases'].values() for c in cases if set(c['dtype_profile']['inputs'].values())=={dtype}}
   assert len(actual)==e['unique_case_count']
   assert sha(canon(sorted(actual.values(),key=canon)))==e['case_set_sha256']
   assert all(set(p['inputs'].values())=={dtype} for p in e['dtype_profiles'])
   checked_structured+=1
  for rejection in v['known_original_rejections']:
   e=rejection['evidence'];b=committed(e['path']);assert sha(b)==e['sha256'];obj=json.loads(b)
   for key in rejection['json_pointer'].split('/')[1:]:obj=obj[key]
   assert obj==rejection['recorded_result']
assert I['summary']==S and S['old_scope_counts']==dict(Counter(t['old_policy_scope_status'] for t in tasks.values()))
assert S['old_scope_counts']=={'pending':179,'verified':1,'verified_with_deferred_numerics':3}
assert S['new_policy_acceptance_assignments']==0
for v in ['Real','FP32','BF16']:
 assert S['per_version'][v]['new_policy_status_counts']=={'not_evaluated_under_new_policy':183}
 assert S['per_version'][v]['inventory_state_counts']==dict(Counter(t['versions'][v]['inventory_summary'] for t in tasks.values()))
assert S['per_version']['BF16']['tasks_with_structured_original_unsupported_partitions']==2
assert S['per_version']['BF16']['tasks_with_structured_return_outcome_labels']==2
assert S['per_version']['BF16']['tasks_with_explicit_original_rejection_evidence']==4
assert S['per_version']['FP32']['tasks_with_structured_return_outcome_labels']==4
for p,h in P['frozen_package_documents'].items():assert sha(committed(p))==h,p
with (W/'inventory.csv').open(newline='') as f:csvrows=list(csv.DictReader(f))
assert len(csvrows)==183 and {x['task'] for x in csvrows}==set(tasks)
assert all(x['new_policy_status']=='not_evaluated' for x in csvrows)
report={'status':'pass_evidence_mapping_consistency_only','baseline_commit':C,'tasks':183,'public_declaration_references_checked':len(public),'structured_declaration_version_mappings_checked':checked_structured,'committed_input_documents_checked':len(P['committed_documents']),'frozen_package_document_hashes_checked':len(P['frozen_package_documents']),'current_task_source_hashes_checked_by_builder':len(P['checked_current_task_sources']),'old_acceptance_states_preserved':S['old_scope_counts'],'new_policy_mapping_cells':549,'new_policy_acceptance_transitions':0,'not_run':['Lean build','native compiler or GPU execution','official comparator','legacy acceptance checker','new-policy acceptance checker']}
(W/'validation.json').write_text(json.dumps(report,indent=2)+'\n');print(json.dumps(report,indent=2))
