"""Evidence mapping only: no acceptance transitions, validators or repo writes."""
from pathlib import Path
from collections import Counter,defaultdict
import ast,csv,gzip,hashlib,json,re,subprocess,sys
sys.dont_write_bytecode=True
W=Path(__file__).resolve().parent;R=Path('/mnt/VerifiableAILab/VerifiableAILab/zenan.li/VeriTile')
COMMIT='97e11a9a6cea8d5dfe35db643a1492d79e423cdf'
CAT='bench/review-checkpoints/2026-10-16/native-vector-quant-transpose-acceptance/current-source-catalog.json'
LEDGER='bench/original_program_scope.json';QUEUE='bench/tritonbench_g/deferred_numerical_experiments.json'
EXCLUDE='fp4_to_bf16_conversion';VERSIONS=['Real','FP32','BF16'];FLOATS={'fp16','bf16','fp32','fp64','fp8e4m3fn','fp8e5m2','fp8e4m3fnuz','fp8e5m2fnuz','fp8e8m0fnu'}
def sha(data):return hashlib.sha256(data).hexdigest()
def canonical(obj):return json.dumps(obj,sort_keys=True,separators=(',',':'),ensure_ascii=False).encode()
def digest(path):return sha(Path(path).read_bytes())
def write(path,obj):path.write_text(json.dumps(obj,indent=2,ensure_ascii=False)+'\n')
def committed(path):return subprocess.check_output(['git','show',COMMIT+':'+path],cwd=R)
inputs={}
def snapshot(path):
 raw=committed(path);inputs[path]={'commit':COMMIT,'sha256':sha(raw),'bytes':len(raw)};return json.loads(raw)
cat=snapshot(CAT);ledger=snapshot(LEDGER);queue=snapshot(QUEUE)
rows={t['task']:t for t in ledger['tasks']};tasks=[t for t in cat['tasks'] if t['task']!=EXCLUDE]
assert len(tasks)==183 and set(rows)=={t['task'] for t in tasks}
sourcehashes={f['path']:f['observed_sha256'] for t in tasks for f in t['files']}
for rel,h in sourcehashes.items():assert digest(R/rel)==h,rel
read_files={};receipt_files={};known_rejections=[]

def document(path,h):
 raw=committed(path);assert sha(raw)==h,path
 receipt_files[path]=h
 return json.loads(raw)

def primary_version(case):
 profile=case.get('dtype_profile',{});vals=set(profile.get('inputs',{}).values())
 # No port-role inference: integer/index/packed/mixed inputs stay separate until
 # source-specific review identifies the payload and indispensable special ports.
 if vals=={'fp32'}:return 'FP32'
 if vals=={'bf16'}:return 'BF16'
 return None

def profile_key(case):return canonical(case['dtype_profile']).decode()
def outcomes(cases):
 counts=Counter(str(c['configuration'].get('outcome','not_labeled')) for c in cases)
 return dict(sorted(counts.items()))

def ref(d):return {k:d.get(k) for k in ['file','declaration','statement_sha256','line']}

def profile_mentions(d):
 fields=[]
 for key in ['dtype_profile','reviewed_scope']:
  value=d.get(key)
  if isinstance(value,str):fields.append((key,value))
 result={v:[] for v in ['FP32','BF16']}
 for key,value in fields:
  for v,pattern in [('FP32',r'(?i)(?<![A-Za-z0-9])(?:fp32|float32|binary32)(?![A-Za-z0-9])'),('BF16',r'(?i)(?<![A-Za-z0-9])(?:bf16|bfloat16)(?![A-Za-z0-9])')]:
   if re.search(pattern,value):result[v].append({'field':key,'exact_text':value})
 return result

result=[];proof_index={};package_index=[]
for task in tasks:
 name=task['task'];old=rows[name];decls=task['declarations'];versions={v:{'new_policy_mapping_status':'not_evaluated_under_new_policy','mathematical_declarations':[],'structured_primary_profile_declarations':[],'documented_profile_mentions':[],'output_or_mixed_profile_declarations':[],'variant_declarations':[],'native_variant_evidence':[],'known_original_rejections':[]} for v in VERSIONS}
 for d in decls:
  key=d['file']+'::'+d['declaration'];model=d.get('model_kind') or d.get('fp_model_review',{}).get('kind');variant=d.get('source_variant')
  p={'reference':ref(d),'model_class':model,'numeric_model':d.get('numeric_model'),'source_variant':variant or 'historical_task_declaration_graph_requires_projection_review','role':d.get('role'),'coverage_level':d.get('coverage_level'),'scope_relation':d.get('scope_relation'),'dtype_scope_relation':d.get('dtype_scope_relation'),'has_schema2_case_scope':False,'profile_mapping_method':'explicit_case_profile_or_reviewed_annotation_only','new_policy_full_version_coverage_claimed':False}
  proof_index[key]=p
  if (d.get('fp_model_review') or {}).get('kind')=='mathematical_contract':versions['Real']['mathematical_declarations'].append(key)
  cs=d.get('original_scope',{}).get('cases')
  cases=[]
  if isinstance(cs,dict):
   unique={canonical(x):x for xs in cs.values() for x in xs if isinstance(x,dict) and 'dtype_profile' in x and 'configuration' in x}
   cases=list(unique.values());p['has_schema2_case_scope']=True
  mentions=profile_mentions(d)
  for version,dtype in [('FP32','fp32'),('BF16','bf16')]:
   primary=[x for x in cases if primary_version(x)==version]
   other=[x for x in cases if primary_version(x)!=version and any(dtype in v.values() for v in x['dtype_profile'].values())]
   item={'declaration':key,'source_variant':p['source_variant']}
   if primary:
    exact_profiles={profile_key(x):x['dtype_profile'] for x in primary}
    targets={canonical(x['configuration'].get('target',{'metadata':'not_explicit_in_case'})).decode():x['configuration'].get('target') for x in primary}
    item.update(unique_case_count=len(primary),dtype_profiles=list(exact_profiles.values()),outcome_partition_counts=outcomes(primary),target_annotations=list(targets.values()),case_set_sha256=sha(canonical(sorted(primary,key=canonical))))
    dest='variant_declarations' if variant and variant!='original_source_translation' else 'structured_primary_profile_declarations'
    versions[version][dest].append(item)
   if other:versions[version]['output_or_mixed_profile_declarations'].append({'declaration':key,'unique_case_count':len(other),'note':'This dtype appears in output, compute or a mixed-input profile; it is not automatically a primary version.'})
   if mentions[version]:
    textitem={'declaration':key,'annotations':mentions[version],'warning':'Textual reviewed-profile annotation only; may describe accumulation/output/limitations. Not an implemented-version or whole-task claim.'}
    if variant and variant!='original_source_translation':versions[version]['variant_declarations'].append(textitem)
    else:versions[version]['documented_profile_mentions'].append(textitem)
 # Follow frozen value-registry package pins for explicit original/native rejection facts.
 ext=(task.get('value_registry_row') or {}).get('value_extension') or {}
 for package in ext.get('packages',[]):
  if 'receipt' not in package or 'receipt_sha256' not in package:continue
  receipt=document(package['receipt'],package['receipt_sha256']);review=document(package['root_review'],package['root_review_sha256'])
  if 'receipt_sha256' in review:assert review['receipt_sha256']==package['receipt_sha256'],package
  entry={'task':name,'receipt':{'path':package['receipt'],'sha256':package['receipt_sha256']},'root_review':{'path':package['root_review'],'sha256':package['root_review_sha256']},'review_binding':{'authority':'pinned_catalog_package_record','recorded_reviewer':review.get('reviewer'),'review_body_binds_receipt_sha256':'receipt_sha256' in review,'new_review_performed':False}}
  package_index.append(entry)
  native=receipt.get('native_compile') or {}
  if isinstance(native,dict):
   for version,dtype in [('FP32','fp32'),('BF16','bf16')]:
    original=native.get('original_profiles',{})
    if isinstance(original,dict) and dtype in original and str(original[dtype]).upper().startswith('FAIL'):
     rejection={'task':name,'version':version,'state':'unsupported_original_at_recorded_native_configuration','evidence':entry['receipt'],'json_pointer':'/native_compile/original_profiles/'+dtype,'recorded_result':original[dtype],'target':native.get('target'),'configuration':{k:native[k] for k in ['blocks','enable_fp_fusion','triton'] if k in native},'variant_result':(native.get('comma_only_candidate_profiles') or {}).get(dtype),'interpretation':'A repaired variant result does not implement the rejected original profile.'}
     versions[version]['known_original_rejections'].append(rejection);known_rejections.append(rejection)
     candidate=(native.get('comma_only_candidate_profiles') or {}).get(dtype)
     if candidate:
      versions[version]['native_variant_evidence'].append({'source_variant':'comma_only_compile_repaired_candidate','evidence':entry['receipt'],'json_pointer':'/native_compile/comma_only_candidate_profiles/'+dtype,'recorded_result':candidate,'target':native.get('target'),'configuration':rejection['configuration'],'original_rejection_pointer':rejection['json_pointer'],'gpu_execution_established':False})
  native=receipt.get('native') or {}
  if isinstance(native,dict) and native.get('offline_bf16_compile_failures',0)>0:
   rejection={'task':name,'version':'BF16','state':'unsupported_original_at_recorded_native_configuration','evidence':entry['receipt'],'json_pointer':'/native/offline_bf16_compile_failures','recorded_result':native['offline_bf16_compile_failures'],'native_audit_sha256':native.get('audit_sha256'),'interpretation':'A recorded original BF16 compile failure; not a successful functional BF16 version. This fact is scoped to the captured configuration.'}
   versions['BF16']['known_original_rejections'].append(rejection);known_rejections.append(rejection)
 for version,v in versions.items():
  if v['known_original_rejections']:v['inventory_summary']='original_profile_has_recorded_compile_rejection'
  elif v['mathematical_declarations'] or v['structured_primary_profile_declarations']:v['inventory_summary']='explicit_model_or_case_evidence_present_scope_projection_unreviewed'
  elif v['documented_profile_mentions']:v['inventory_summary']='reviewed_profile_annotations_present_scope_unreviewed'
  elif v['output_or_mixed_profile_declarations'] or v['variant_declarations']:v['inventory_summary']='only_other_profile_or_variant_mapping_found'
  else:v['inventory_summary']='no_explicit_mapping_found_in_pinned_catalog'
 row={'task':name,'old_policy_scope_status':old['status'],'old_scope_schema':old.get('scope_schema'),'old_scope_review':old.get('review'),'historical_source_entry':task['historical_source_entry'],'original_source_present':task['original_source_present'],'source_variant_views':[{'id':v.get('id'),'variant':v.get('variant'),'frontend':v.get('frontend'),'selected_definitions':v.get('selected_definitions'),'original_python':v.get('original_python'),'candidate_python':v.get('candidate_python'),'memory_semantics':v.get('memory_semantics')} for v in task['source_views']],'variant_declarations_without_version_projection':[ref(d) for d in decls if d.get('source_variant') and d['source_variant']!='original_source_translation'],'source_inventory_sha256':sha(canonical(old['source_inventory'])),'source_stage_count':len(old['source_inventory']['stages']),'source_branch_count':len(old['source_inventory']['branches']),'source_dtype_obligations':old['source_inventory']['dtypes'],'old_structural_gaps_count':len(old.get('structural_gaps',[])),'shared_obligations_status':'existing_evidence_preserved_version_projection_unreviewed','versions':versions,'mandatory_special_profile_clues':{'reviewed_value_dtype_profile':ext.get('dtype_profile'),'source_status':ext.get('source_status'),'instruction':'Preserve source-required storage/output/index/quantization types; do not replace them mechanically with the version label.'},'new_policy_assignment':'none_inventory_only'}
 result.append(row)

# Keep the current four independently reviewed candidates separate from committed evidence.
specpath=W.parent/'next-source-integration-specs.json';spec=json.loads(specpath.read_text());candidates=[]
for item in spec['packages']:
 root=W.parent/item['root'];producer=W.parent/item['producer'];assert digest(root/'review.json')==item['review'];assert digest(producer/'evidence/receipt.json')==item['receipt']
 d=json.loads((producer/'evidence/declaration-proposal.json').read_text());case_map=d.get('original_scope',{}).get('cases',{});unique={canonical(c):c for cs in case_map.values() for c in cs};cs=list(unique.values())
 candidates.append({'task':item['task'],'status':'independently_reviewed_candidate_integration_in_progress_not_counted_in_baseline','root_review_sha256':item['review'],'producer_receipt_sha256':item['receipt'],'public':ref(d),'new_policy_acceptance':'not_reviewed','pure_primary_case_counts':{v:sum(primary_version(c)==v for c in cs) for v in ['FP32','BF16']}})
summary={'tasks':183,'baseline_public_declarations':sum(len(t['declarations']) for t in tasks),'excluded_task':EXCLUDE,'old_scope_counts':dict(Counter(x['old_policy_scope_status'] for x in result)),'new_policy_acceptance_assignments':0,'new_policy_status':'inventory_only_not_an_acceptance_run','per_version':{},'known_original_rejections':known_rejections,'tasks_with_unassigned_variant_declarations':sum(bool(x['variant_declarations_without_version_projection']) for x in result),'pending_integration_candidates':candidates}
for v in VERSIONS:
 summary['per_version'][v]={'tasks_with_mathematical_model_declarations':sum(bool(x['versions'][v]['mathematical_declarations']) for x in result),'tasks_with_structured_primary_profile_evidence':sum(bool(x['versions'][v]['structured_primary_profile_declarations']) for x in result),'tasks_with_reviewed_profile_text_mentions':sum(bool(x['versions'][v]['documented_profile_mentions']) for x in result),'tasks_with_output_or_mixed_profile_mentions':sum(bool(x['versions'][v]['output_or_mixed_profile_declarations']) for x in result),'tasks_with_version_mapped_variant_declarations':sum(bool(x['versions'][v]['variant_declarations']) for x in result),'tasks_with_recorded_native_variant_evidence':sum(bool(x['versions'][v]['native_variant_evidence']) for x in result),'new_policy_status_counts':dict(Counter(x['versions'][v]['new_policy_mapping_status'] for x in result)),'tasks_with_recorded_original_compile_rejection':sum(bool(x['versions'][v]['known_original_rejections']) for x in result),'inventory_state_counts':dict(Counter(x['versions'][v]['inventory_summary'] for x in result))}
for v in ['FP32','BF16']:
 unsupported=[];returned_tasks=set()
 for task in result:
  for d in task['versions'][v]['structured_primary_profile_declarations']:
   outcomes=d['outcome_partition_counts']
   labels={k:n for k,n in outcomes.items() if k.startswith('unsupported_')}
   if labels:unsupported.append({'task':task['task'],'declaration':d['declaration'],'outcome_partition_counts':labels,'interpretation':'An explicit original unsupported partition in existing case metadata; not a successful implementation or a newly run native test.'})
   if any(k in {'returned','returned_or_undefined_conversion','two31_no_access_return'} for k in outcomes):returned_tasks.add(task['task'])
 summary['per_version'][v]['structured_original_unsupported_partitions']=unsupported
 summary['per_version'][v]['tasks_with_structured_original_unsupported_partitions']=len({x['task'] for x in unsupported})
 summary['per_version'][v]['tasks_with_structured_return_outcome_labels']=len(returned_tasks)
 summary['per_version'][v]['tasks_with_explicit_original_rejection_evidence']=len({x['task'] for x in unsupported}|{x['task'] for x in known_rejections if x['version']==v})
metadata={'schema':1,'kind':'three_version_evidence_inventory_not_acceptance','baseline_commit':COMMIT,'catalog':inputs[CAT],'ledger':inputs[LEDGER],'queue':inputs[QUEUE],'checked_existing_task_source_files':len(sourcehashes),'checked_frozen_package_documents':len(receipt_files),'scope':'183 originals; four reviewed candidates separately annotated','inventory_limits':['Counts describe discoverable evidence in the pinned catalog, not complete implementation or acceptance','Text-annotation hits can describe accumulation, outputs or limitations; counts overlap with structured evidence','Original compile rejection extraction follows explicit native profile fields of value-registry receipts, not a new exhaustive native sweep','No source-specific index/payload role is inferred for mixed input profiles','Old case outcomes include success/error/rejection partitions; case counts are not execution test counts'],'classification_rules':['Real requires fp_model_review.kind=mathematical_contract, never numeric_model label alone','Conservative primary FP32/BF16 case mapping requires every INPUT type to match that version, with outputs/compute retained verbatim; mixed/index/packed inputs need source-role review','Reviewed prose mentions are inventory hints, not support or completeness proofs','Output-only/mixed profiles and variants are listed separately','Explicit original compile failures stay unsupported at their captured configurations','No existing status changed; no new-policy acceptance inferred']}
write(W/'inventory.json',{'metadata':metadata,'summary':summary,'tasks':result,'declaration_index':proof_index,'frozen_package_index':package_index})
write(W/'summary.json',summary);write(W/'input-sha256.json',{'committed_documents':inputs,'checked_current_task_sources':sourcehashes,'frozen_package_documents':receipt_files})
with (W/'inventory.csv').open('w',newline='') as f:
 writer=csv.writer(f);writer.writerow(['task','old_policy_status','Real_model_declarations','FP32_structured_declarations','FP32_documented_declarations','BF16_structured_declarations','BF16_documented_declarations','BF16_original_compile_rejections','FP32_variant_refs','BF16_variant_refs','new_policy_status'])
 for x in result:
  vs=x['versions'];writer.writerow([x['task'],x['old_policy_scope_status'],len(vs['Real']['mathematical_declarations']),len(vs['FP32']['structured_primary_profile_declarations']),len(vs['FP32']['documented_profile_mentions']),len(vs['BF16']['structured_primary_profile_declarations']),len(vs['BF16']['documented_profile_mentions']),len(vs['BF16']['known_original_rejections']),len(vs['FP32']['variant_declarations']),len(vs['BF16']['variant_declarations']),'not_evaluated'])
print(json.dumps(summary,indent=2,ensure_ascii=False))
