import VeriTile.Triton
import VeriTile.Triton.Math.MaximumProjection
import VeriTile.Triton.Semantics.UncheckedBlockLoad
import VeriTile.Meta.StatementAudit

/-! Mathematical execution and streamed IO for relative-position-biased attention.
All floating operations use the real channel and all precision casts are erased.
The independent score is scaled Q·K plus the two B0 windows, and the output is
its base-2 softmax weighted sum of V. The typed source and reciprocal candidate
are connected to this execution stack by separate source/normalization proofs.
The internal rounding interface is instantiated at identity rounding by the
real contract; this file supplies no FP equivalence assumptions. -/

namespace VeriTile.Bench.TritonBenchG.AttentionKernel.RealKernel

open VeriTile.Triton

set_option linter.unusedSimpArgs false
set_option linter.unusedVariables false
set_option maxHeartbeats 600000
set_option maxRecDepth 24000

section Correct_without_Rounding

/-- Cast-free mathematical source used by the execution proof.
`RealSource.original_real_source` checks its complete algorithm body against
the precision-erased real and bf16 sources. -/
def mathematical
    (Q K V B0 Out : RegionName) (sm_scale : ℝ)
    (stride_qh stride_qm stride_qk
      stride_kh stride_kn stride_kk
      stride_vh stride_vk stride_vn
      stride_oh stride_om stride_on
      stride_b0h stride_b0m
      _Z _H N_CTX P_SEQ BIAS_LAST_SIZE B0_NUMEL
      BLOCK_DMODEL BLOCK_M BLOCK_N : Nat)
    (out_dtype : FloatDType) :
    ComputeKernel := (triton {
  start_m = tl.program_id(0)
  off_hz = tl.program_id(1)
  q_offset = off_hz * $(stride_qh)
  kv_offset = off_hz * $(stride_kh)
  Q_block_ptr = tl.make_block_ptr(base=Q + q_offset,
    shape=($(N_CTX), $(BLOCK_DMODEL)),
    strides=($(stride_qm), $(stride_qk)),
    offsets=(start_m * $(BLOCK_M), 0),
    block_shape=($(BLOCK_M), $(BLOCK_DMODEL)),
    order=(1, 0))
  K_block_ptr = tl.make_block_ptr(base=K + kv_offset,
    shape=($((BLOCK_DMODEL : Nat)), $((N_CTX + P_SEQ : Nat))),
    strides=($(stride_kk), $(stride_kn)),
    offsets=(0, 0),
    block_shape=($(BLOCK_DMODEL), $(BLOCK_N)),
    order=(0, 1))
  V_block_ptr = tl.make_block_ptr(base=V + kv_offset,
    shape=($((N_CTX + P_SEQ : Nat)), $(BLOCK_DMODEL)),
    strides=($(stride_vk), $(stride_vn)),
    offsets=(0, 0),
    block_shape=($(BLOCK_N), $(BLOCK_DMODEL)),
    order=(1, 0))

  m_i = tl.zeros([$(BLOCK_M)], dtype=tl.float32) - float("inf")
  l_i = tl.zeros([$(BLOCK_M)], dtype=tl.float32)
  acc = tl.zeros([$(BLOCK_M), $(BLOCK_DMODEL)], dtype=tl.float32)
  qk_scale = $((sm_scale : ℝ)) * 1.44269504
  q = tl.load(Q_block_ptr)
  q = q * qk_scale
  lo = 0
  hi = $((N_CTX + P_SEQ : Nat))

  b_ptr_offsets_m = tl.arange(0, $(BLOCK_M))
  b_offset = off_hz * $(stride_b0h)
  b_ptr_offsets_n_1 = (tl.arange(0, $(BLOCK_N)) % $(BIAS_LAST_SIZE)) +
    $(BIAS_LAST_SIZE)
  b1 = tl.load(B0 + b_offset + ((start_m * $(BLOCK_M) + b_ptr_offsets_m) *
    $(stride_b0m))[:, None] + b_ptr_offsets_n_1[None, :])
  for start_n in range(lo, hi, $(BLOCK_N)) {
    k = tl.load(K_block_ptr)
    v = tl.load(V_block_ptr)
    qk = tl.zeros([$(BLOCK_M), $(BLOCK_N)], dtype=tl.float32)
    qk += tl.dot(q, k)

    b0 = tl.load(B0 + b_offset + ((start_m * $(BLOCK_M) + b_ptr_offsets_m) *
      $(stride_b0m))[:, None] + start_n // $(BLOCK_N))
    qk += ((b0 + b1) * 1.44269504)

    m_i_new = tl.maximum(m_i, tl.max(qk, 1))
    alpha = tl.math.exp2(m_i - m_i_new)
    p = tl.math.exp2(qk - m_i_new[:, None])
    acc *= alpha[:, None]
    acc += tl.dot(p, v)
    l_i = l_i * alpha + tl.sum(p, 1)
    m_i = m_i_new
    K_block_ptr = tl.advance(K_block_ptr, [$(0), $(BLOCK_N)])
    V_block_ptr = tl.advance(V_block_ptr, [$(BLOCK_N), $(0)])
  }

  acc = acc / l_i[:, None]
  O_block_ptr = tl.make_block_ptr(base=Out + q_offset,
    shape=($(N_CTX), $(BLOCK_DMODEL)),
    strides=($(stride_om), $(stride_on)),
    offsets=(start_m * $(BLOCK_M), 0),
    block_shape=($(BLOCK_M), $(BLOCK_DMODEL)),
    order=(1, 0))
  tl.store(O_block_ptr, acc)
}).eraseDType

/-- The full aligned attention-kernel surface lowers to the algorithm layer. -/
theorem mathematical_toAlgorithm_supported
    (Q K V B0 Out : RegionName) (sm_scale : ℝ)
    (stride_qh stride_qm stride_qk
      stride_kh stride_kn stride_kk
      stride_vh stride_vk stride_vn
      stride_oh stride_om stride_on
      stride_b0h stride_b0m
      Z H N_CTX P_SEQ BIAS_LAST_SIZE B0_NUMEL
      BLOCK_DMODEL BLOCK_M BLOCK_N : Nat)
    (out_dtype : FloatDType) :
    ∃ alg, (mathematical Q K V B0 Out sm_scale
      stride_qh stride_qm stride_qk stride_kh stride_kn stride_kk stride_vh
      stride_vk stride_vn stride_oh stride_om stride_on stride_b0h
      stride_b0m Z H N_CTX P_SEQ BIAS_LAST_SIZE B0_NUMEL BLOCK_DMODEL
      BLOCK_M BLOCK_N out_dtype).toAlgorithm? = Except.ok alg := by
  simp only [mathematical, ComputeKernel.eraseDType, ComputeKernel.toAlgorithm?_mk,
    ComputeStmt.listToAlgorithm?, ComputeStmt.toAlgorithm?, ComputeExpr.toAlgorithm?,
    ComputeOp.toAlgorithm?, Except.bind, bind]
  simp

/-- Reuse the supported projection without expanding the complete AST again. -/
private theorem supported_projection (k : ComputeKernel)
    (h : ∃ alg, k.toAlgorithm? = Except.ok alg) :
    k.toAlgorithm? = Except.ok k.toAlgKernel := by
  obtain ⟨alg,h⟩ := h
  simp [ComputeKernel.toAlgKernel,h]

def mIndex (s : BlockState) (BLOCK_M : Nat) (i : Fin BLOCK_M) : Nat :=
  s.pids 0 * BLOCK_M + i.val

def kIndex (idx : TileIndex [BLOCK_M, BLOCK_DMODEL]) : Nat :=
  idx.2.1.val

def surfaceOutOffset
    (s : BlockState)
    (stride_qh stride_om stride_on BLOCK_M : Nat)
    (idx : TileIndex [BLOCK_M, BLOCK_DMODEL]) : Nat :=
  s.pids 1 * stride_qh +
    mIndex s BLOCK_M idx.1 * stride_om + kIndex idx * stride_on

/-! The independent result is `attnGenScore`: base-2 softmax weighted V,
with scaled Q·K and both relative-position bias windows. The following lemmas
connect block-pointer loads, the loop invariant and the terminal store to that
formula. -/

namespace ClosedForm

open VeriTile.Triton

/-- **`makeBlockPtrDyn` eval** (the `K`/`V` block pointers — static offsets,
dynamic base): evaluates the base-offset op and packages the constant
`BlockPtr` tile. -/
theorem makeBlockPtrDyn_eval (region : RegionName) (baseOffset : Op .nat [])
    (parentShape : List Nat) (blockShape : TileShape)
    (strides offsets : List Nat) (s : BlockState) (base : Nat)
    (hb : evalOp baseOffset s = some (Tile.scalar base)) :
    evalOp (.makeBlockPtrDyn region baseOffset parentShape blockShape strides offsets) s
      = some (⟨fun _ : TileIndex blockShape =>
          { region := region, baseOffset := base, parentShape := parentShape,
            blockShape := blockShape, strides := strides, offsets := offsets }⟩) := by
  simp only [evalOp, hb, Option.bind]
  rfl

/-- **`makeBlockPtrDynOffsets` (dynamic row offset, literal `0` column) eval**
(the `Q`/`O` block pointers): packages the constant `BlockPtr` tile with the
resolved row offset. -/
theorem makeBlockPtr_rowcol_eval (region : RegionName) (baseOffset : Op .nat [])
    (parentShape : List Nat) (blockShape : TileShape) (strides : List Nat)
    (rowOp : Op .nat []) (s : BlockState) (base rowOff : Nat)
    (hb : evalOp baseOffset s = some (Tile.scalar base))
    (hr : evalOp rowOp s = some (Tile.scalar rowOff)) :
    evalOp (.makeBlockPtrDynOffsets region baseOffset parentShape blockShape strides
        [rowOp, Op.constNat 0]) s
      = some (⟨fun _ : TileIndex blockShape =>
          { region := region, baseOffset := base, parentShape := parentShape,
            blockShape := blockShape, strides := strides, offsets := [rowOff, 0] }⟩) := by
  rw [makeBlockPtr2_eval]
  simp only [hb, hr, evalOp, Option.bind, List.mapM, List.mapM.loop, Tile.scalar]
  rfl

/-- **`tl.advance [0, d]` of a `[rowOff=0, colOff]` block pointer** (the `K`
pointer step): advances the column offset by `d`. -/
theorem advance_col_eval (s : BlockState) (region : RegionName)
    (base rows cols BT BS strideT strideS colOff d : Nat) (name : RegName)
    (hkp : s.regs .blockPtr [BT, BS] name = some
      (⟨fun _ : TileIndex [BT, BS] =>
        { region := region, baseOffset := base, parentShape := [rows, cols],
          blockShape := [BT, BS], strides := [strideT, strideS], offsets := [0, colOff] }⟩)) :
    evalOp (Op.advanceBlockPtr (Op.ref .blockPtr [BT, BS] name) [(0:Nat), d]) s
      = some (⟨fun _ : TileIndex [BT, BS] =>
        { region := region, baseOffset := base, parentShape := [rows, cols],
          blockShape := [BT, BS], strides := [strideT, strideS], offsets := [0, colOff + d] }⟩) := by
  rw [advanceBlockPtr_eval]
  simp only [evalOp, hkp, Option.bind]
  refine congrArg some ?_
  ext i
  simp [BlockPtr.advance_2d_offsets]

/-- **`tl.advance [d, 0]` of a `[rowOff, colOff=0]` block pointer** (the `V`
pointer step): advances the row offset by `d`. -/
theorem advance_row_eval (s : BlockState) (region : RegionName)
    (base rows cols BT BS strideT strideS rowOff d : Nat) (name : RegName)
    (hkp : s.regs .blockPtr [BT, BS] name = some
      (⟨fun _ : TileIndex [BT, BS] =>
        { region := region, baseOffset := base, parentShape := [rows, cols],
          blockShape := [BT, BS], strides := [strideT, strideS], offsets := [rowOff, 0] }⟩)) :
    evalOp (Op.advanceBlockPtr (Op.ref .blockPtr [BT, BS] name) [d, (0:Nat)]) s
      = some (⟨fun _ : TileIndex [BT, BS] =>
        { region := region, baseOffset := base, parentShape := [rows, cols],
          blockShape := [BT, BS], strides := [strideT, strideS], offsets := [rowOff + d, 0] }⟩) := by
  rw [advanceBlockPtr_eval]
  simp only [evalOp, hkp, Option.bind]
  refine congrArg some ?_
  ext i
  simp [BlockPtr.advance_2d_offsets]

/-! ### Genuine kernel theorem

The loaded Q/K/V/B0 tiles read from the *input* state `s0`, and the kernel's
genuine per-key score `fscore` (used as the `score` argument of the generalized
streaming-softmax spec `VeriTile.Triton.attnGenScore`). -/

/-- Loaded (pre-scale) Q tile: row `r`, head lane `e`. -/
noncomputable def qRaw (s0 : BlockState) (Q : RegionName)
    (q_offset BLOCK_M HEAD_DIM : Nat) (start_m : Nat) :
    TileIndex [BLOCK_M, HEAD_DIM] → ℝ :=
  fun (r, e, _) => s0.readMem Q (q_offset + (start_m * BLOCK_M + r.val) * HEAD_DIM + e.val)

/-- Loaded K tile as a flat per-key function over `[HEAD_DIM, N_CTX]`. -/
noncomputable def kFlat (s0 : BlockState) (K : RegionName)
    (kv_offset HEAD_DIM N_CTX : Nat) :
    Fin HEAD_DIM → Fin N_CTX → ℝ :=
  fun e j => s0.readMem K (kv_offset + e.val + j.val * HEAD_DIM)

/-- Loaded V tile, flat per-key over `[N_CTX, HEAD_DIM]`. -/
noncomputable def vFlat (s0 : BlockState) (V : RegionName)
    (kv_offset HEAD_DIM N_CTX : Nat) :
    TileIndex [N_CTX, HEAD_DIM] → ℝ :=
  fun (j, d, _) => s0.readMem V (kv_offset + j.val * HEAD_DIM + d.val)

/-- Per-row, per-block-column bias `b0` read (`c = j / BLOCK_N`). -/
noncomputable def b0Val (s0 : BlockState) (B0 : RegionName)
    (b_offset BLOCK_M stride_b0m : Nat) (start_m : Nat)
    (r : Fin BLOCK_M) (c : Nat) : ℝ :=
  s0.readMem B0 (b_offset + (start_m * BLOCK_M + r.val) * stride_b0m + c)

/-- Per-row, per-lane bias `b1` read at lane `jL` (`jL = j % BLOCK_N`). -/
noncomputable def b1Val (s0 : BlockState) (B0 : RegionName)
    (b_offset BLOCK_M stride_b0m BIAS_LAST_SIZE : Nat) (start_m : Nat)
    (r : Fin BLOCK_M) (jL : Nat) : ℝ :=
  s0.readMem B0
    (b_offset + (start_m * BLOCK_M + r.val) * stride_b0m + (jL % BIAS_LAST_SIZE + BIAS_LAST_SIZE))

/-- **Genuine per-key score** `fscore r j` of `_fwd_kernel_aligned`:
`qk_scale·(Σ_e Q[r,e]·K[e,j]) + (b0[r, j/BN] + b1[r, j%BN])·log2 e`,
with `qk_scale = sm_scale · log2 e` already folded into the pre-scaled `q`. This
is the `score` argument of `VeriTile.Triton.attnGenScore`, whose batch base-2
softmax `(Σ 2^fscore · V) / (Σ 2^fscore)` is the kernel's closed form (see
`closed_form_g`). -/
noncomputable def fscore (s0 : BlockState) (Q K B0 : RegionName)
    (sm_scale : ℝ) (q_offset kv_offset b_offset
      BLOCK_M BLOCK_N HEAD_DIM N_CTX BIAS_LAST_SIZE stride_b0m : Nat)
    (start_m : Nat)
    (r : Fin BLOCK_M) (j : Fin N_CTX) : ℝ :=
  (sm_scale * 1.44269504) *
      Finset.univ.sum (fun e : Fin HEAD_DIM =>
        qRaw s0 Q q_offset BLOCK_M HEAD_DIM start_m (r, e, PUnit.unit)
          * kFlat s0 K kv_offset HEAD_DIM N_CTX e j)
    + (b0Val s0 B0 b_offset BLOCK_M stride_b0m start_m r (j.val / BLOCK_N)
        + b1Val s0 B0 b_offset BLOCK_M stride_b0m BIAS_LAST_SIZE start_m r (j.val % BLOCK_N))
      * 1.44269504

/-- **Closed-form target.** The kernel's genuine theorem is
`attnGenScore (fscore …) (vFlat …)`: the base-2 streaming softmax over the
genuine per-key score `fscore` (scaled dot + additive bias). The generalized
math lemma `closed_form_g` establishes that the running `oPg / lPg` recurrence
the kernel's loop maintains converges to exactly this value after all
`numKVBlocks` key blocks — which is what the remaining `exec`-side assembly
discharges. -/
noncomputable def attentionKernelSpec (s0 : BlockState) (Q K V B0 : RegionName)
    (sm_scale : ℝ) (q_offset kv_offset b_offset
      BLOCK_M BLOCK_N HEAD_DIM N_CTX BIAS_LAST_SIZE stride_b0m : Nat)
    (start_m : Nat) : TileIndex [BLOCK_M, HEAD_DIM] → ℝ :=
  attnGenScore
    (fscore s0 Q K B0 sm_scale q_offset kv_offset b_offset
      BLOCK_M BLOCK_N HEAD_DIM N_CTX BIAS_LAST_SIZE stride_b0m start_m)
    (vFlat s0 V kv_offset HEAD_DIM N_CTX)

/-- **Closed-form readout.** After all `numKVBlocks` key blocks the kernel's
running `oPg / lPg` ratio (which the loop invariant maintains) is exactly the
genuine spec `attentionKernelSpec` (= `attnGenScore fscore vFlat`). Direct
corollary of the generalized math lemma `closed_form_g`. -/
theorem attentionKernelSpec_eq_ratio (s0 : BlockState) (Q K V B0 : RegionName)
    (sm_scale : ℝ) (q_offset kv_offset b_offset
      BLOCK_M BLOCK_N HEAD_DIM BIAS_LAST_SIZE stride_b0m nB : Nat)
    (start_m : Nat) (hBN : 0 < BLOCK_N) (hnB : 1 ≤ nB)
    (i : Fin BLOCK_M) (d : Fin HEAD_DIM) :
    let score := fscore s0 Q K B0 sm_scale q_offset kv_offset b_offset
      BLOCK_M BLOCK_N HEAD_DIM (BLOCK_N * nB) BIAS_LAST_SIZE stride_b0m start_m
    let V' := vFlat s0 V kv_offset HEAD_DIM (BLOCK_N * nB)
    oPg score V' i d nB / lPg score i nB
      = attentionKernelSpec s0 Q K V B0 sm_scale q_offset kv_offset b_offset
          BLOCK_M BLOCK_N HEAD_DIM (BLOCK_N * nB) BIAS_LAST_SIZE stride_b0m start_m (i, d, PUnit.unit) :=
  closed_form_g _ _ hBN hnB i d

/-- **Kernel-faithful running denominator.** Same recurrence as the math `lPg`
but seeded `0` (the kernel inits `l_i = 0`, whereas the generalized `lPg` seeds
`1`). This is the value the loop invariant must carry in the `l_i` register. -/
noncomputable def lPgK {Mq : Nat} {BN nB : Nat}
    (score : Fin Mq → Fin (BN * nB) → ℝ) (i : Fin Mq) : Nat → ℝ
  | 0 => 0
  | c + 1 =>
      if h : c + 1 ≤ nB then
        alphaPg score i c * lPgK score i c +
          Finset.univ.sum (fun a : Fin BN =>
            pow2 (score i (gkey BN nB c (by omega) a) - mRg score i (c + 1)))
      else lPgK score i c

/-- The seed difference is killed by `alphaPg 0 = 0`: for `1 ≤ c ≤ nB` the
kernel's seed-`0` denominator agrees with the math `lPg` (seed `1`). So the
final `c = nB ≥ 1` readout is unaffected by the kernel's `l_i = 0` initialization,
and `closed_form_g` / `attentionKernelSpec_eq_ratio` apply unchanged. -/
theorem lPgK_eq_lPg {Mq : Nat} {BN nB : Nat}
    (score : Fin Mq → Fin (BN * nB) → ℝ) (i : Fin Mq) :
    ∀ c, 1 ≤ c → c ≤ nB → lPgK score i c = lPg score i c := by
  intro c hc1 hc
  induction c, hc1 using Nat.le_induction with
  | base => simp only [lPgK, lPg, dif_pos hc, alphaPg_zero score i, zero_mul]
  | succ c hc1 ih =>
    have ihc := ih (by omega)
    simp only [lPgK, lPg, dif_pos hc, ihc]

/-- A `WithBot ℝ` sum of `some`-valued cells is `some` of the real sum. -/
theorem withBot_sum_some {N : Nat} (g : Fin N → ℝ) :
    @Finset.sum (Fin N) (WithBot ℝ) _ Finset.univ (fun k => (some (g k) : WithBot ℝ))
      = some (Finset.univ.sum g) := by
  show (Finset.univ.sum fun k => ((g k : ℝ) : WithBot ℝ)) = ((Finset.univ.sum g : ℝ) : WithBot ℝ)
  exact (WithBot.coe_sum Finset.univ g).symm

/-- The `p · v` dot row (contraction over all `BLOCK_N` keys). -/
theorem dot_pv (BM BN BD : Nat) (p : Tile .real [BM,BN]) (v : Tile .real [BN,BD])
    (r : Fin BM) (d : Fin BD) (fp fv : Fin BN → ℝ)
    (hp : ∀ jL : Fin BN, p.data (r, jL, PUnit.unit) = some (fp jL))
    (hv : ∀ jL : Fin BN, v.data (jL, d, PUnit.unit) = some (fv jL)) :
    (Tile.dot [] p v).data (r, d, PUnit.unit) = some (Finset.univ.sum fun jL : Fin BN => fp jL * fv jL) := by
  rw [Tile.dot_nil_data]
  rw [show (@Finset.sum (Fin BN) (WithBot ℝ) _ Finset.univ
        (fun k => Option.map₂ (· * ·) (p.data (r, k, PUnit.unit)) (v.data (k, d, PUnit.unit))))
      = @Finset.sum (Fin BN) (WithBot ℝ) _ Finset.univ (fun k => (some (fp k * fv k) : WithBot ℝ))
      from Finset.sum_congr rfl (fun k _ => by rw [hp k, hv k]; rfl)]
  exact withBot_sum_some _

/-- A `some`-valued exp2 reduction at one cell. -/
theorem exp2_some {M N : Nat} (h : Fin M → Fin N → ℝ) (x : Tile .real [M, N])
    (i : Fin M) (j : Fin N) (hx : x.data (i, j, PUnit.unit) = some (h i j)) :
    (Tile.uop WithBot.realExp2 x).data (i, j, PUnit.unit) = some (pow2 (h i j)) := by
  show WithBot.realExp2 _ = _
  rw [hx, WithBot.realExp2_some]
  refine congrArg some ?_
  rw [show pow2 (h i j) = Real.exp (Real.log 2 * (h i j)) from rfl, mul_comm]

/-- `reduceMaxDrop` of a row whose cells are `g jL` = `Finset.sup` of the `g`. -/
theorem reduceMaxDrop_data_row (BM BN : Nat) (hBN : 0 < BN) (qk : Tile .real [BM, BN])
    (rmaxT : Tile .real [BM]) (hrm : Tile.reduceMaxDrop (⟨1, by simp⟩ : Fin [BM,BN].length) qk = some rmaxT)
    (r : Fin BM) (g : Fin BN → WithBot ℝ) (hqk : ∀ jL : Fin BN, qk.data (r, jL, PUnit.unit) = g jL) :
    rmaxT.data (r, PUnit.unit) = Finset.univ.sup g := by
  unfold Tile.reduceMaxDrop at hrm
  rw [dif_pos (show 0 < TileShape.axisDim [BM,BN] (⟨1, by simp⟩ : Fin [BM,BN].length) from hBN)] at hrm
  rw [← Option.some.inj hrm]
  simp only [Finset.sup'_eq_sup]
  exact Finset.sup_congr rfl (fun jL _ => hqk jL)

/-- **`m_ij = mPg(c+1)`** (generic). -/
theorem mijg_eq {Mq : Nat} (BN nB c : Nat) (hc : c < nB)
    (score : Fin Mq → Fin (BN*nB) → ℝ)
    (m_i rmaxT : Tile .real [Mq]) (r : Fin Mq)
    (hmi : m_i.data (r, PUnit.unit) = mPg BN nB score r c)
    (hrmax : rmaxT.data (r, PUnit.unit)
        = Finset.univ.sup (fun a : Fin BN => ((score r (gkey BN nB c hc a) : ℝ) : WithBot ℝ))) :
    (Tile.select (Tile.cop ComparableDType.real.gt (Broadcast.consSame Broadcast.nil) m_i rmaxT) m_i rmaxT).data (r, PUnit.unit)
      = mPg BN nB score r (c+1) := by
  rw [Tile.select_data, Tile.cop_data]
  simp only [Broadcast.leftIndex, Broadcast.rightIndex, ComparableDType.gt, hmi, hrmax]
  rw [mPg, dif_pos (by omega : c + 1 ≤ nB)]
  by_cases h : mPg BN nB score r c ≤ Finset.univ.sup (fun a : Fin BN => ((score r (gkey BN nB c hc a) : ℝ) : WithBot ℝ))
  · rw [if_neg (by simp [not_lt.mpr h]), max_eq_right h]
  · rw [if_pos (by simpa using not_le.mp h), max_eq_left (le_of_lt (not_le.mp h))]

/-- `mPg (c+1) ≠ ⊥` whenever `mPg c ≠ ⊥` (running max is monotone). -/
theorem mPg_succ_ne_bot {Mq : Nat} {BN nB : Nat}
    (score : Fin Mq → Fin (BN*nB) → ℝ) (r : Fin Mq) (c : Nat)
    (hc : mPg BN nB score r c ≠ ⊥) : mPg BN nB score r (c+1) ≠ ⊥ := by
  rw [mPg]
  by_cases h : c + 1 ≤ nB
  · rw [dif_pos h]
    intro hbot; rw [max_eq_bot] at hbot; exact hc hbot.1
  · rw [dif_neg h]; exact hc

/-- **`alpha = some(alphaPg c)`** (generic). -/
theorem alphag_eq {Mq : Nat} (BN nB c : Nat)
    (score : Fin Mq → Fin (BN*nB) → ℝ)
    (m_i m_ij : Tile .real [Mq]) (r : Fin Mq)
    (hmi : m_i.data (r, PUnit.unit) = mPg BN nB score r c)
    (hmij : m_ij.data (r, PUnit.unit) = mPg BN nB score r (c+1)) :
    (Tile.uop WithBot.realExp2 (Tile.bop NumericDType.real.sub (Broadcast.consSame Broadcast.nil) m_i m_ij)).data (r, PUnit.unit)
      = some (alphaPg score r c) := by
  show WithBot.realExp2 _ = _
  simp only [Tile.bop_data, Broadcast.leftIndex, Broadcast.rightIndex, hmi, hmij, NumericDType.sub]
  unfold alphaPg
  cases hm : mPg BN nB score r c with
  | bot => rw [WithBot.realSub_bot_left, WithBot.realExp2_bot]; rfl
  | coe a =>
    show WithBot.realExp2 (WithBot.realSub (↑a) (mPg BN nB score r (c+1))) = some (pow2 (a - mRg score r (c+1)))
    rw [show mRg score r (c+1) = (mPg BN nB score r (c+1)).unbotD 0 from rfl]
    have hne : mPg BN nB score r (c+1) ≠ ⊥ := mPg_succ_ne_bot score r c (by rw [hm]; exact WithBot.coe_ne_bot)
    cases hm1 : mPg BN nB score r (c+1) with
    | bot => exact absurd hm1 hne
    | coe b =>
      rw [WithBot.realSub_coe_coe, WithBot.realExp2_coe, WithBot.unbotD_coe]
      refine congrArg some ?_
      rw [show pow2 (a - b) = Real.exp (Real.log 2 * (a - b)) from rfl, mul_comm]

set_option maxHeartbeats 1000000 in
/-- **`l_i = lPgK(c+1)`** (generic). -/
theorem lig_eq {Mq : Nat} (BN nB c : Nat) (hBN : 0 < BN) (hc : c < nB)
    (score : Fin Mq → Fin (BN*nB) → ℝ)
    (m_i m_ij l_i : Tile .real [Mq]) (qk : Tile .real [Mq, BN]) (r : Fin Mq)
    (hmi : m_i.data (r, PUnit.unit) = mPg BN nB score r c)
    (hmij : m_ij.data (r, PUnit.unit) = mPg BN nB score r (c+1))
    (hli : l_i.data (r, PUnit.unit) = some (lPgK score r c))
    (hqk : ∀ a : Fin BN, qk.data (r, a, PUnit.unit) = some (score r (gkey BN nB c hc a))) :
    (Tile.bop NumericDType.real.add (Broadcast.consSame Broadcast.nil)
       (Tile.bop NumericDType.real.mul (Broadcast.consSame Broadcast.nil) l_i
         (Tile.uop WithBot.realExp2 (Tile.bop NumericDType.real.sub (Broadcast.consSame Broadcast.nil) m_i m_ij)))
       (Tile.reduceSumDrop (⟨1, by simp⟩ : Fin [Mq,BN].length)
         (Tile.uop WithBot.realExp2 (Tile.bop NumericDType.real.sub (Broadcast.consSame (Broadcast.consR Broadcast.nil)) qk
           (Tile.expandDim (⟨1, by simp⟩ : Fin [Mq].length.succ) m_ij))))).data (r, PUnit.unit)
      = some (lPgK score r (c+1)) := by
  have hmijReal : m_ij.data (r, PUnit.unit) = some (mRg score r (c+1)) := by
    rw [hmij]
    rw [mPg_eq_coe score hBN r (c+1) (by omega) (by omega)]; rfl
  have halpha := alphag_eq BN nB c score m_i m_ij r hmi hmij
  simp only [Tile.bop_data, Broadcast.leftIndex, Broadcast.rightIndex]
  rw [halpha, hli]
  simp only [Tile.reduceSumDrop_data, Tile.uop_data, Tile.bop_data, Broadcast.leftIndex,
    Broadcast.rightIndex, Tile.expandDim_data, TileShape.dropInsertedIndex,
    TileShape.insertAxisIndex, hqk, hmijReal, NumericDType.sub, WithBot.realSub,
    Option.map₂, Option.bind, Option.map, WithBot.realExp2_some]
  simp only [withBot_sum_some]
  rw [lPgK, dif_pos (by omega : c + 1 ≤ nB)]
  simp only [NumericDType.add, NumericDType.mul, WithBot.realAdd, WithBot.realMul,
    Option.map₂, Option.bind, Option.map]
  refine congrArg some ?_
  rw [mul_comm (lPgK score r c)]
  congr 1
  exact Finset.sum_congr rfl (fun k _ => by rw [pow2, mul_comm])

set_option maxHeartbeats 1000000 in
/-- **`acc = oPg(c+1)`** (generic). -/
theorem accg_eq {Mq Dh : Nat} (BN nB c : Nat) (hc : c < nB)
    (score : Fin Mq → Fin (BN*nB) → ℝ) (V : TileIndex [BN*nB, Dh] → ℝ)
    (acc : Tile .real [Mq,Dh]) (alpha : Tile .real [Mq]) (p : Tile .real [Mq,BN]) (v : Tile .real [BN,Dh])
    (r : Fin Mq) (d : Fin Dh)
    (hacc : acc.data (r, d, PUnit.unit) = some (oPg score V r d c))
    (halpha : alpha.data (r, PUnit.unit) = some (alphaPg score r c))
    (hp : ∀ a : Fin BN, p.data (r, a, PUnit.unit) = some (pow2 (score r (gkey BN nB c hc a) - mRg score r (c+1))))
    (hv : ∀ a : Fin BN, v.data (a, d, PUnit.unit) = some (V (gkey BN nB c hc a, d, PUnit.unit))) :
    (Tile.bop NumericDType.real.add (Broadcast.consSame (Broadcast.consSame Broadcast.nil))
       (Tile.bop NumericDType.real.mul (Broadcast.consSame (Broadcast.consR Broadcast.nil)) acc
         (Tile.expandDim (⟨1, by simp⟩ : Fin [Mq].length.succ) alpha))
       (Tile.dot [] p v)).data (r, d, PUnit.unit)
      = some (oPg score V r d (c+1)) := by
  simp only [Tile.bop_data, Broadcast.leftIndex, Broadcast.rightIndex, Tile.expandDim_data,
    TileShape.dropInsertedIndex, halpha]
  rw [dot_pv Mq BN Dh p v r d (fun a => pow2 (score r (gkey BN nB c hc a) - mRg score r (c+1)))
      (fun a => V (gkey BN nB c hc a, d, PUnit.unit)) hp hv]
  rw [hacc]
  rw [oPg, dif_pos (by omega : c + 1 ≤ nB)]
  simp only [NumericDType.add, NumericDType.mul, WithBot.realAdd, WithBot.realMul,
    Option.map₂, Option.bind, Option.map]
  refine congrArg some ?_
  rw [mul_comm (oPg score V r d c)]

/-! ### Loop invariant skeleton

The `forRangeDyn` loop-invariant `Prop` carried across key blocks. The counter `i`
ranges over `0, BLOCK_N, 2·BLOCK_N, …` (`c = i / BLOCK_N` blocks consumed); the
streaming registers `m_i`/`l_i`/`acc` equal the generalized partials
`mPg`/`lPgK`/`oPg` of the genuine score `fscore` and value tile `vFlat` over the
first `c` blocks (kernel seed `l_i = 0`, hence `lPgK` not `lPg`), and the K/V
block pointers have advanced `c` column/row steps of `BLOCK_N`. The loop-invariant
registers (`q` pre-scaled+loaded, `b1`, `b_offset`, `start_m`/`off_hz`) are fixed.
`preLoopG` establishes `attnKernelInvariant … 0`, `attn_stepG` advances it by one
block, and `attn_postLoopG` reads the closed form off `… numKVBlocks` via
`attentionKernelSpec_eq_ratio`. -/
noncomputable def attnKernelInvariant
    (s0 : BlockState) (Q K V B0 Out : RegionName) (sm_scale : ℝ)
    (q_offset kv_offset b_offset
      BLOCK_M BLOCK_N HEAD_DIM P_SEQ BIAS_LAST_SIZE stride_b0m stride_kk stride_kn
      stride_vk stride_vn numKVBlocks : Nat)
    (start_m : Nat) (i : Nat) (s : BlockState) : Prop :=
  let nB := numKVBlocks; let c := i / BLOCK_N; let N_CTX := BLOCK_N * numKVBlocks
  let score := fscore s0 Q K B0 sm_scale q_offset kv_offset b_offset
    BLOCK_M BLOCK_N HEAD_DIM N_CTX BIAS_LAST_SIZE stride_b0m start_m
  let V' := vFlat s0 V kv_offset HEAD_DIM N_CTX
  s.pids = s0.pids ∧ i = c * BLOCK_N ∧ c ≤ nB ∧
  (s.regs .real [BLOCK_M] "m_i" = some ⟨fun r : TileIndex [BLOCK_M] => mPg BLOCK_N nB score r.1 c⟩) ∧
  (s.regs .real [BLOCK_M] "l_i" = some ⟨fun r : TileIndex [BLOCK_M] => ((lPgK score r.1 c : ℝ) : WithBot ℝ)⟩) ∧
  (s.regs .real [BLOCK_M, HEAD_DIM] "acc" = some ⟨fun idx : TileIndex [BLOCK_M, HEAD_DIM] =>
        ((oPg score V' idx.1 idx.2.1 c : ℝ) : WithBot ℝ)⟩) ∧
  (s.regs .blockPtr [HEAD_DIM, BLOCK_N] "K_block_ptr" = some
      (⟨fun _ : TileIndex [HEAD_DIM, BLOCK_N] =>
        { region := K, baseOffset := kv_offset,
          parentShape := [HEAD_DIM, N_CTX + P_SEQ], blockShape := [HEAD_DIM, BLOCK_N],
          strides := [stride_kk, stride_kn], offsets := [0, c * BLOCK_N] }⟩)) ∧
  (s.regs .blockPtr [BLOCK_N, HEAD_DIM] "V_block_ptr" = some
      (⟨fun _ : TileIndex [BLOCK_N, HEAD_DIM] =>
        { region := V, baseOffset := kv_offset,
          parentShape := [N_CTX + P_SEQ, HEAD_DIM], blockShape := [BLOCK_N, HEAD_DIM],
          strides := [stride_vk, stride_vn], offsets := [c * BLOCK_N, 0] }⟩)) ∧
  -- loop-invariant (fixed) registers the body reads
  (s.regs .real [BLOCK_M, HEAD_DIM] "q" = some ⟨fun idx : TileIndex [BLOCK_M, HEAD_DIM] =>
      FloatDType.real.cast FloatDType.real
        (some (sm_scale * 1.44269504 * qRaw s0 Q q_offset BLOCK_M HEAD_DIM start_m idx))⟩) ∧
  (s.regs .real [BLOCK_M, BLOCK_N] "b1" = some ⟨fun idx : TileIndex [BLOCK_M, BLOCK_N] =>
      some (b1Val s0 B0 b_offset BLOCK_M stride_b0m BIAS_LAST_SIZE start_m idx.1 idx.2.1.val)⟩) ∧
  (s.regs .nat [] "b_offset" = some (Tile.scalar b_offset)) ∧
  (s.regs .nat [] "start_m" = some (Tile.scalar start_m)) ∧
  (s.regs .nat [] "q_offset" = some (Tile.scalar q_offset)) ∧
  (s.regs .nat [BLOCK_M] "b_ptr_offsets_m" = some (Tile.vec (fun r : Fin BLOCK_M => r.val))) ∧
  (∀ rg o, s.undef rg o = 0) ∧ (s.mem = s0.mem)

/-! ### preLoop prefix (deterministic prologue → invariant base seeds)

The first ten prologue statements are deterministic (no loads): the four scalar
offsets, the three block pointers, and the `m_i`/`l_i`/`acc` initializers. They
step with the validated recipe (`stepStmts.cons_some (stepStmt_assign_eq_some
…)` per statement, threading register reads through the accumulated `setReg`
chain) using the block-pointer eval lemmas above. The result is the base-case
register seeding for the loop invariant: `m_i = ⊥` (= `mPg … 0`),
`l_i = 0` (the kernel's seed; `lPgK … 0`), `acc = 0` (= `oPg … 0`), and the
`K`/`V` block pointers at their initial `[0,0]` offsets. -/

/-- Scalar `ref · constNat` eval (the `q_offset` / `kv_offset` / `start_m·BLOCK_M`
offsets). -/
theorem evalOp_mul_ref_const (s : BlockState) (name : RegName) (a c : Nat)
    (hr : s.regs .nat [] name = some (Tile.scalar a)) :
    evalOp (Op.mul .nat Broadcast.nil (Op.ref .nat [] name) (Op.constNat c)) s
      = some (Tile.scalar (a * c)) := by
  rw [evalOp_mul, evalOp_ref, hr, evalOp_constNat]
  refine congrArg some ?_
  ext i
  simp only [Tile.bop_data, NumericDType.mul]
  rfl

set_option maxHeartbeats 1000000 in
/-- **preLoop prefix** (prologue statements 0–9): steps the deterministic
offset/pointer/init prologue to a state carrying the invariant base seeds. -/
theorem preLoop_prefix (Q K V B0 Out : RegionName) (sm_scale : ℝ)
    (stride_qh stride_qm stride_qk stride_kh stride_kn stride_kk
      stride_vh stride_vk stride_vn stride_oh stride_om stride_on
      stride_b0h stride_b0m Z H N_CTX P_SEQ BIAS_LAST_SIZE B0_NUMEL
      BLOCK_DMODEL BLOCK_M BLOCK_N : Nat) (out_dtype : FloatDType) (s : BlockState) :
    ∃ s10, stepStmts ((mathematical Q K V B0 Out sm_scale
        stride_qh stride_qm stride_qk stride_kh stride_kn stride_kk stride_vh
        stride_vk stride_vn stride_oh stride_om stride_on stride_b0h stride_b0m
        Z H N_CTX P_SEQ BIAS_LAST_SIZE B0_NUMEL BLOCK_DMODEL BLOCK_M BLOCK_N
        out_dtype).toAlgKernel.body.take 10) s = some s10
      ∧ s10.pids = s.pids
      ∧ s10.regs .nat [] "start_m" = some (Tile.scalar (s.pids 0))
      ∧ s10.regs .nat [] "off_hz" = some (Tile.scalar (s.pids 1))
      ∧ s10.regs .nat [] "q_offset" = some (Tile.scalar (s.pids 1 * stride_qh))
      ∧ s10.regs .nat [] "kv_offset" = some (Tile.scalar (s.pids 1 * stride_kh))
      ∧ s10.regs .blockPtr [BLOCK_M, BLOCK_DMODEL] "Q_block_ptr" = some
          (⟨fun _ : TileIndex [BLOCK_M, BLOCK_DMODEL] =>
            { region := Q, baseOffset := s.pids 1 * stride_qh,
              parentShape := [N_CTX, BLOCK_DMODEL], blockShape := [BLOCK_M, BLOCK_DMODEL],
              strides := [stride_qm, stride_qk], offsets := [s.pids 0 * BLOCK_M, 0] }⟩)
      ∧ s10.regs .blockPtr [BLOCK_DMODEL, BLOCK_N] "K_block_ptr" = some
          (⟨fun _ : TileIndex [BLOCK_DMODEL, BLOCK_N] =>
            { region := K, baseOffset := s.pids 1 * stride_kh,
              parentShape := [BLOCK_DMODEL, N_CTX + P_SEQ], blockShape := [BLOCK_DMODEL, BLOCK_N],
              strides := [stride_kk, stride_kn], offsets := [0, 0] }⟩)
      ∧ s10.regs .blockPtr [BLOCK_N, BLOCK_DMODEL] "V_block_ptr" = some
          (⟨fun _ : TileIndex [BLOCK_N, BLOCK_DMODEL] =>
            { region := V, baseOffset := s.pids 1 * stride_kh,
              parentShape := [N_CTX + P_SEQ, BLOCK_DMODEL], blockShape := [BLOCK_N, BLOCK_DMODEL],
              strides := [stride_vk, stride_vn], offsets := [0, 0] }⟩)
      ∧ s10.regs .real [BLOCK_M] "m_i" = some (⟨fun _ : TileIndex [BLOCK_M] => (⊥ : WithBot ℝ)⟩)
      ∧ s10.regs .real [BLOCK_M] "l_i" = some (⟨fun _ : TileIndex [BLOCK_M] => some (0:ℝ)⟩)
      ∧ s10.regs .real [BLOCK_M, BLOCK_DMODEL] "acc"
          = some (⟨fun _ : TileIndex [BLOCK_M, BLOCK_DMODEL] => some (0:ℝ)⟩)
      ∧ s10.undef = s.undef
      ∧ s10.mem = s.mem := by
  rw [show ((mathematical Q K V B0 Out sm_scale
        stride_qh stride_qm stride_qk stride_kh stride_kn stride_kk stride_vh
        stride_vk stride_vn stride_oh stride_om stride_on stride_b0h stride_b0m
        Z H N_CTX P_SEQ BIAS_LAST_SIZE B0_NUMEL BLOCK_DMODEL BLOCK_M BLOCK_N
        out_dtype).toAlgKernel.body.take 10)
      = [ Stmt.assign .nat [] "start_m" (Op.programId 0),
          Stmt.assign .nat [] "off_hz" (Op.programId 1),
          Stmt.assign .nat [] "q_offset" (Op.mul .nat Broadcast.nil (Op.ref .nat [] "off_hz") (Op.constNat stride_qh)),
          Stmt.assign .nat [] "kv_offset" (Op.mul .nat Broadcast.nil (Op.ref .nat [] "off_hz") (Op.constNat stride_kh)),
          Stmt.assign .blockPtr [BLOCK_M, BLOCK_DMODEL] "Q_block_ptr"
            (Op.makeBlockPtrDynOffsets Q (Op.ref .nat [] "q_offset") [N_CTX, BLOCK_DMODEL] [BLOCK_M, BLOCK_DMODEL]
              [stride_qm, stride_qk] [Op.mul .nat Broadcast.nil (Op.ref .nat [] "start_m") (Op.constNat BLOCK_M), Op.constNat 0]),
          Stmt.assign .blockPtr [BLOCK_DMODEL, BLOCK_N] "K_block_ptr"
            (Op.makeBlockPtrDyn K (Op.ref .nat [] "kv_offset") [BLOCK_DMODEL, N_CTX + P_SEQ] [BLOCK_DMODEL, BLOCK_N]
              [stride_kk, stride_kn] [0, 0]),
          Stmt.assign .blockPtr [BLOCK_N, BLOCK_DMODEL] "V_block_ptr"
            (Op.makeBlockPtrDyn V (Op.ref .nat [] "kv_offset") [N_CTX + P_SEQ, BLOCK_DMODEL] [BLOCK_N, BLOCK_DMODEL]
              [stride_vk, stride_vn] [0, 0]),
          Stmt.assign .real [BLOCK_M] "m_i" (Op.add .real Broadcast.scalarR (Op.full [BLOCK_M] (Op.const 0)) Op.negInf),
          Stmt.assign .real [BLOCK_M] "l_i" (Op.full [BLOCK_M] (Op.const 0)),
          Stmt.assign .real [BLOCK_M, BLOCK_DMODEL] "acc" (Op.full [BLOCK_M, BLOCK_DMODEL] (Op.const 0)) ] from by
    simp only [mathematical, ComputeKernel.eraseDType, ComputeKernel.toAlgKernel_fromKernelBody, ComputeKernel.toAlgorithm?_fromKernelBody, Kernel.eraseDType, ComputeKernel.toAlgKernel_mk, ComputeKernel.toAlgorithm?_mk, ComputeStmt.listToAlgorithm?, ComputeStmt.toAlgorithm?, ComputeExpr.toAlgorithm?, ComputeOp.toAlgorithm?, Stmt.eraseDTypeList, Stmt.eraseDType, Op.eraseDType.eq_def, MemAccess.eraseDType.eq_def, MaskOpt.eraseDType.eq_def, VeriTile.Triton.eraseDType, NumericDType.eraseDType, ComparableDType.eraseDType, IntegralDType.eraseDType, FloatDType.toTileDType, Except.bind, bind, ↓List.map_cons, ↓List.map_nil]
    all_goals rfl]
  have hmi : ∀ s' : BlockState, evalOp (Op.add .real Broadcast.scalarR (Op.full [BLOCK_M] (Op.const 0)) Op.negInf) s'
      = some (⟨fun _ : TileIndex [BLOCK_M] => (⊥ : WithBot ℝ)⟩ : Tile .real [BLOCK_M]) := by
    intro s'
    simp only [evalOp_add, evalOp_full, evalOp_negInf, evalOp_const, Option.bind_eq_bind, Option.bind_some]
    refine congrArg some ?_
    ext r; simp only [Tile.bop_data, NumericDType.add]; rfl
  have hli : ∀ s' : BlockState, evalOp (Op.full [BLOCK_M] (Op.const 0)) s'
      = some (⟨fun _ : TileIndex [BLOCK_M] => some (0:ℝ)⟩ : Tile .real [BLOCK_M]) := by
    intro s'; simp [evalOp_full, evalOp_const, Option.bind]
  have hacc : ∀ s' : BlockState, evalOp (Op.full [BLOCK_M, BLOCK_DMODEL] (Op.const 0)) s'
      = some (⟨fun _ : TileIndex [BLOCK_M, BLOCK_DMODEL] => some (0:ℝ)⟩ : Tile .real [BLOCK_M, BLOCK_DMODEL]) := by
    intro s'; simp [evalOp_full, evalOp_const, Option.bind]
  rw [stepStmts.cons_some (stepStmt_assign_eq_some (s := s) (by rw [evalOp_programId])),
    stepStmts.cons_some (stepStmt_assign_eq_some (by rw [evalOp_programId])),
    stepStmts.cons_some (stepStmt_assign_eq_some
      (evalOp_mul_ref_const _ "off_hz" (s.pids 1) stride_qh (by simp [BlockState.setReg]))),
    stepStmts.cons_some (stepStmt_assign_eq_some
      (evalOp_mul_ref_const _ "off_hz" (s.pids 1) stride_kh (by simp [BlockState.setReg]))),
    stepStmts.cons_some (stepStmt_assign_eq_some
      (makeBlockPtr_rowcol_eval Q _ [N_CTX, BLOCK_DMODEL] [BLOCK_M, BLOCK_DMODEL] [stride_qm, stride_qk] _ _
        (s.pids 1 * stride_qh) (s.pids 0 * BLOCK_M)
        (by simp [BlockState.setReg]) (evalOp_mul_ref_const _ "start_m" (s.pids 0) BLOCK_M (by simp [BlockState.setReg])))),
    stepStmts.cons_some (stepStmt_assign_eq_some
      (makeBlockPtrDyn_eval K _ [BLOCK_DMODEL, N_CTX + P_SEQ] [BLOCK_DMODEL, BLOCK_N] [stride_kk, stride_kn] [0,0] _
        (s.pids 1 * stride_kh) (by simp [BlockState.setReg]))),
    stepStmts.cons_some (stepStmt_assign_eq_some
      (makeBlockPtrDyn_eval V _ [N_CTX + P_SEQ, BLOCK_DMODEL] [BLOCK_N, BLOCK_DMODEL] [stride_vk, stride_vn] [0,0] _
        (s.pids 1 * stride_kh) (by simp [BlockState.setReg]))),
    stepStmts.cons_some (stepStmt_assign_eq_some (hmi _)),
    stepStmts.cons_some (stepStmt_assign_eq_some (hli _)),
    stepStmts.cons_some (stepStmt_assign_eq_some (hacc _)),
    stepStmts.nil]
  refine ⟨_, rfl, ?_⟩
  refine ⟨?_, ?_, ?_, ?_, ?_, ?_, ?_, ?_, ?_, ?_, ?_, ?_, ?_⟩ <;>
    simp [BlockState.setReg, BlockState.setReg_same, BlockState.setReg_ne_name]

/-! ### preLoop tail loads (statements 10–18 eval helpers)

The prologue's final block (statements 10–18: `qk_scale`, the Q block-pointer
load + scale + `OUT_DTYPE` cast, the `lo`/`hi` constants, the bias arange/offset
prep, and the `b1` region load) needs three eval reductions beyond the
deterministic-prologue recipe used by `preLoop_prefix`:

* the two generalized canonical-axis `expandDim` reductions over an arbitrary
  `nat` operand (`evalOp_expandDim_one_nat'`/`evalOp_expandDim_zero_nat'`) — the
  generic `evalOp_expandDim` cannot `rw`/`simp`-match the `triton{}`-elaborated
  surface because its result shape `TileShape.insertAxis [M] 1 1` is only
  defeq-not-syntactic to `[M, 1]`; these state the concrete-shape form (the
  `b1`/`b0` offset uses `expandDim` of a *computed* `mul`/`add`, not a bare
  register, so the existing register-only specializations don't apply);
* the `b1` (and identically-shaped `b0`) relative-position-bias region load
  (`load_b1_eval`): reads `B0` at the resolved contiguous per-lane address
  `b_offset + (start_m·BLOCK_M + r)·stride_b0m + (jL % BIAS_LAST_SIZE +
  BIAS_LAST_SIZE)` — i.e. exactly `b1Val`'s address (the `b0` block-column read
  `… + start_n // BLOCK_N` is the `floorDiv` variant). -/

/-- Generalized canonical axis-1 `expandDim` eval over an arbitrary `nat`
operand (explicit `[M, 1]` result shape). -/
@[simp] theorem evalOp_expandDim_one_nat' {M : Nat} (e : Op .nat [M]) (s : BlockState) :
    @evalOp .nat [M, 1] (Op.expandDim ⟨1, by simp⟩ e) s =
      (evalOp e s).bind (fun v =>
        some ({ data := fun i : TileIndex [M, 1] => v.data (i.1, PUnit.unit) } : Tile .nat [M, 1])) := by
  conv_lhs => unfold evalOp
  cases evalOp e s with
  | none => rfl
  | some v =>
      simp only [Option.bind_some, Option.bind_eq_bind]
      refine congrArg some ?_; ext i; simp [Tile.expandDim]

/-- Generalized canonical axis-0 `expandDim` eval over an arbitrary `nat`
operand (explicit `[1, D]` result shape). -/
@[simp] theorem evalOp_expandDim_zero_nat' {D : Nat} (e : Op .nat [D]) (s : BlockState) :
    @evalOp .nat [1, D] (Op.expandDim ⟨0, by simp⟩ e) s =
      (evalOp e s).bind (fun v =>
        some ({ data := fun i : TileIndex [1, D] => v.data (i.2.1, PUnit.unit) } : Tile .nat [1, D])) := by
  conv_lhs => unfold evalOp
  cases evalOp e s with
  | none => rfl
  | some v =>
      simp only [Option.bind_some, Option.bind_eq_bind]
      refine congrArg some ?_; ext i; simp [Tile.expandDim]

/-- **`b1` relative-position-bias region load** (statement 18; the `b0` per-block
read is the `floorDiv` analogue). Resolves the `B0 + b_offset + (start_m·BLOCK_M
+ b_ptr_offsets_m)·stride_b0m[:,None] + b_ptr_offsets_n_1[None,:]` pointer
arithmetic to the per-lane `readMem` at `b_offset + (start_m·BLOCK_M + r)·
stride_b0m + (jL % BIAS_LAST_SIZE + BIAS_LAST_SIZE)` (= `b1Val`'s address). -/
theorem load_b1_eval (s : BlockState) (B0 : RegionName)
    (BLOCK_M BLOCK_N stride_b0m BIAS_LAST_SIZE smbm boff : Nat)
    (hbo : s.regs .nat [] "b_offset" = some (Tile.scalar boff))
    (hsm : s.regs .nat [] "start_m" = some (Tile.scalar smbm))
    (hm : s.regs .nat [BLOCK_M] "b_ptr_offsets_m" = some (Tile.vec (fun r : Fin BLOCK_M => r.val)))
    (hn1 : s.regs .nat [BLOCK_N] "b_ptr_offsets_n_1"
      = some (Tile.vec (fun jL : Fin BLOCK_N => jL.val % BIAS_LAST_SIZE + BIAS_LAST_SIZE))) :
    evalOp (Op.load .real (.region B0
        (Op.add .nat (Broadcast.consR (Broadcast.consL Broadcast.nil))
          (Op.add .nat Broadcast.scalarL (Op.ref .nat [] "b_offset")
            (Op.expandDim ⟨1, by simp⟩ (Op.mul .nat Broadcast.scalarR
              (Op.add .nat Broadcast.scalarL
                (Op.mul .nat Broadcast.nil (Op.ref .nat [] "start_m") (Op.constNat BLOCK_M))
                (Op.ref .nat [BLOCK_M] "b_ptr_offsets_m")) (Op.constNat stride_b0m))))
          (Op.expandDim ⟨0, by simp⟩ (Op.ref .nat [BLOCK_N] "b_ptr_offsets_n_1"))))
        .none) s
      = some (⟨fun idx : TileIndex [BLOCK_M, BLOCK_N] =>
          some (s.readMem B0
            (boff + (smbm * BLOCK_M + idx.1.val) * stride_b0m
              + (idx.2.1.val % BIAS_LAST_SIZE + BIAS_LAST_SIZE)))⟩) := by
  rw [evalOp_load_region_none]
  simp only [evalOp_add, evalOp_mul, evalOp_constNat, evalOp_ref, evalOp_expandDim_one_nat',
    evalOp_expandDim_zero_nat', hbo, hsm, hm, hn1, Option.bind_eq_bind, Option.bind_some]
  refine congrArg some ?_
  ext idx
  simp only [Tile.bop_data, Broadcast.leftIndex, Broadcast.rightIndex, Tile.scalar, Tile.vec,
    NumericDType.add, NumericDType.mul, BlockState.readMemValue_real, Region.cast_id]

/-! ## exec-side loop-body assembly (Python shape `BLOCK_M=BLOCK_N=64`, `HEAD_DIM=128`)

The 15-statement `forRangeDyn` body, stepped one block at a time. Mirrors the
`AttentionForwardClosedForm`/`flash_attn` assembly: block-ptr K/V loads, the
bias-augmented `qk = fscore` cell, the online-softmax `m_i`/`alpha`/`p`/`acc`/`l_i`
updates, and the K/V block-pointer advances — non-causal (no masks). -/

/-- `evalOp` of `tl.math.exp2`. -/
theorem evalOp_exp2' {shape : TileShape} (a : Op .real shape) (s : BlockState) :
    evalOp (.exp2 a) s = (do let va ← evalOp a s; some (Tile.uop WithBot.realExp2 va)) := by
  simp [evalOp]

/-- The lowered 15-statement `forRangeDyn` body, dimension-parameterized over
`BLOCK_M BLOCK_N HEAD_DIM stride_b0m` (at the Python test shape these are
`64 64 128 128`). -/
def attnLoopBodyG (B0 : RegionName)
    (BLOCK_M BLOCK_N HEAD_DIM stride_b0m : Nat) : List Stmt :=
  [ Stmt.assign .real [HEAD_DIM, BLOCK_N] "k"
      (Op.load .real (.blockPtr (Op.ref .blockPtr [HEAD_DIM, BLOCK_N] "K_block_ptr") []) .none .unspecified),
    Stmt.assign .real [BLOCK_N, HEAD_DIM] "v"
      (Op.load .real (.blockPtr (Op.ref .blockPtr [BLOCK_N, HEAD_DIM] "V_block_ptr") []) .none .unspecified),
    Stmt.assign .real [BLOCK_M, BLOCK_N] "qk" (Op.full [BLOCK_M, BLOCK_N] ((Op.const 0))),
    Stmt.assign .real [BLOCK_M, BLOCK_N] "qk"
      (Op.add .real (Broadcast.consSame (Broadcast.consSame Broadcast.nil))
        ((Op.ref .real [BLOCK_M, BLOCK_N] "qk"))
        (Op.dot (batch := []) ((Op.ref .real [BLOCK_M, HEAD_DIM] "q"))
          (Op.ref .real [HEAD_DIM, BLOCK_N] "k"))),
    Stmt.assign .real [BLOCK_M, 1] "b0"
      (Op.load .real (.region B0
        (Op.add .nat Broadcast.scalarR
          (Op.add .nat Broadcast.scalarL (Op.ref .nat [] "b_offset")
            (Op.expandDim ⟨1, by simp⟩ (Op.mul .nat Broadcast.scalarR
              (Op.add .nat Broadcast.scalarL
                (Op.mul .nat Broadcast.nil (Op.ref .nat [] "start_m") (Op.constNat BLOCK_M))
                (Op.ref .nat [BLOCK_M] "b_ptr_offsets_m")) (Op.constNat stride_b0m))))
          (Op.floorDiv .nat Broadcast.nil (Op.ref .nat [] "start_n") (Op.constNat BLOCK_N))))
        .none),
    Stmt.assign .real [BLOCK_M, BLOCK_N] "qk"
      (Op.add .real (Broadcast.consSame (Broadcast.consSame Broadcast.nil))
        (Op.ref .real [BLOCK_M, BLOCK_N] "qk")
        (Op.mul .real Broadcast.scalarR
          (Op.add .real (Broadcast.consSame (Broadcast.consL Broadcast.nil))
            (Op.ref .real [BLOCK_M, 1] "b0") (Op.ref .real [BLOCK_M, BLOCK_N] "b1")) (Op.const 1.44269504))),
    Stmt.assign .real [BLOCK_M] "m_i_new"
      (Op.max2 (Broadcast.consSame Broadcast.nil) (Op.ref .real [BLOCK_M] "m_i")
        (Op.reduceMax (⟨1, by simp⟩ : Fin [BLOCK_M, BLOCK_N].length) Bool.false (Op.ref .real [BLOCK_M, BLOCK_N] "qk"))),
    Stmt.assign .real [BLOCK_M] "alpha"
      (Op.exp2 (Op.sub .real (Broadcast.consSame Broadcast.nil) (Op.ref .real [BLOCK_M] "m_i")
        (Op.ref .real [BLOCK_M] "m_i_new"))),
    Stmt.assign .real [BLOCK_M, BLOCK_N] "p"
      (Op.exp2 (Op.sub .real (Broadcast.consSame (Broadcast.consR Broadcast.nil))
        (Op.ref .real [BLOCK_M, BLOCK_N] "qk") (Op.expandDim ⟨1, by simp⟩ (Op.ref .real [BLOCK_M] "m_i_new")))),
    Stmt.assign .real [BLOCK_M, HEAD_DIM] "acc"
      (Op.mul .real (Broadcast.consSame (Broadcast.consR Broadcast.nil))
        (Op.ref .real [BLOCK_M, HEAD_DIM] "acc")
        (Op.expandDim ⟨1, by simp⟩ (Op.ref .real [BLOCK_M] "alpha"))),
    Stmt.assign .real [BLOCK_M, HEAD_DIM] "acc"
      (Op.add .real (Broadcast.consSame (Broadcast.consSame Broadcast.nil))
        (Op.ref .real [BLOCK_M, HEAD_DIM] "acc")
        (Op.dot (batch := []) (((Op.ref .real [BLOCK_M, BLOCK_N] "p"))) (Op.ref .real [BLOCK_N, HEAD_DIM] "v"))),
    Stmt.assign .real [BLOCK_M] "l_i"
      (Op.add .real (Broadcast.consSame Broadcast.nil)
        (Op.mul .real (Broadcast.consSame Broadcast.nil) (Op.ref .real [BLOCK_M] "l_i")
          (Op.ref .real [BLOCK_M] "alpha"))
        (Op.reduceSum (⟨1, by simp⟩ : Fin [BLOCK_M, BLOCK_N].length) Bool.false (Op.ref .real [BLOCK_M, BLOCK_N] "p"))),
    Stmt.assign .real [BLOCK_M] "m_i" (Op.ref .real [BLOCK_M] "m_i_new"),
    Stmt.assign .blockPtr [HEAD_DIM, BLOCK_N] "K_block_ptr"
      (Op.advanceBlockPtr (Op.ref .blockPtr [HEAD_DIM, BLOCK_N] "K_block_ptr") [(0:Nat), BLOCK_N]),
    Stmt.assign .blockPtr [BLOCK_N, HEAD_DIM] "V_block_ptr"
      (Op.advanceBlockPtr (Op.ref .blockPtr [BLOCK_N, HEAD_DIM] "V_block_ptr") [BLOCK_N, (0:Nat)]) ]

/-- `ComputeOp.toAlgorithm?` of an `.alg` op (the structural erase). -/
@[simp] theorem computeOp_toAlgorithm?_alg {dtype : ComputeDType} {shape : TileShape}
    (e : Op dtype.eraseDType shape) :
    ComputeOp.toAlgorithm? (ComputeOp.alg dtype e) = Except.ok e := rfl

/-- `ComputeExpr.toAlgorithm?` of `compute (alg ..)`. -/
@[simp] theorem computeExpr_toAlgorithm?_compute_alg {dtype : ComputeDType} {shape : TileShape}
    (e : Op dtype.eraseDType shape) :
    (ComputeExpr.compute (ComputeOp.alg dtype e)).toAlgorithm? = Except.ok e := rfl

set_option maxRecDepth 100000 in
/-- **General** `drop 19` of the dimension-parameterized surface = `forRangeDyn`
over `attnLoopBodyG`, then `drop 20`. By `rfl` (statement structure is
dim-independent). -/
theorem attnLoopBodyG_check (Q K V B0 Out : RegionName) (sm_scale : ℝ)
    (stride_qh stride_qm stride_qk stride_kh stride_kn stride_kk
      stride_vh stride_vk stride_vn stride_oh stride_om stride_on
      stride_b0h stride_b0m Z H N_CTX P_SEQ BIAS_LAST_SIZE B0_NUMEL
      BLOCK_DMODEL BLOCK_M BLOCK_N : Nat) :
    (mathematical Q K V B0 Out sm_scale
        stride_qh stride_qm stride_qk stride_kh stride_kn stride_kk stride_vh
        stride_vk stride_vn stride_oh stride_om stride_on stride_b0h
        stride_b0m Z H N_CTX P_SEQ BIAS_LAST_SIZE B0_NUMEL BLOCK_DMODEL
        BLOCK_M BLOCK_N FloatDType.real).toAlgKernel.body.drop 19
      = Stmt.forRangeDyn "start_n" (Op.ref .nat [] "lo") (Op.ref .nat [] "hi")
          (Op.constNat BLOCK_N) (attnLoopBodyG B0 BLOCK_M BLOCK_N BLOCK_DMODEL stride_b0m)
        :: (mathematical Q K V B0 Out sm_scale
            stride_qh stride_qm stride_qk stride_kh stride_kn stride_kk stride_vh
            stride_vk stride_vn stride_oh stride_om stride_on stride_b0h
            stride_b0m Z H N_CTX P_SEQ BIAS_LAST_SIZE B0_NUMEL BLOCK_DMODEL
            BLOCK_M BLOCK_N FloatDType.real).toAlgKernel.body.drop 20 := by
  simp only [↓List.map_cons, ↓List.map_nil, mathematical, ComputeKernel.eraseDType, ComputeKernel.toAlgKernel_fromKernelBody, ComputeKernel.toAlgorithm?_fromKernelBody, Kernel.eraseDType, ComputeKernel.toAlgorithm?_mk, ComputeStmt.listToAlgorithm?, ComputeStmt.toAlgorithm?, ComputeExpr.toAlgorithm?, ComputeOp.toAlgorithm?, Stmt.eraseDTypeList, Stmt.eraseDType, Op.eraseDType.eq_def, MemAccess.eraseDType.eq_def, MaskOpt.eraseDType.eq_def, VeriTile.Triton.eraseDType, NumericDType.eraseDType, ComparableDType.eraseDType, IntegralDType.eraseDType, FloatDType.toTileDType, Except.bind, bind, ComputeKernel.toAlgKernel_mk,
    ComputeStmt.listToAlgorithm?_cons_assign_alg, ComputeStmt.listToAlgorithm?_cons_assign_compute,
    ComputeStmt.listToAlgorithm?_cons_forRangeDyn, ComputeStmt.listToAlgorithm?_cons_store_alg,
    ComputeStmt.listToAlgorithm?_nil, computeExpr_toAlgorithm?_compute_alg,
    ComputeExpr.toAlgorithm?_compute_full_alg, ComputeExpr.toAlgorithm?_alg,
    ComputeExpr.toAlgorithm?, ComputeOp.toAlgorithm?_full_alg, computeOp_toAlgorithm?_alg,
    List.drop_succ_cons, List.drop_zero, attnLoopBodyG]
  all_goals rfl

/-- The lowered 3-statement post-loop, dimension-parameterized over
`BLOCK_M BLOCK_DMODEL N_CTX stride_om stride_on`. -/
def attnPostLoopG (Out : RegionName)
    (BLOCK_M BLOCK_DMODEL N_CTX stride_om stride_on : Nat) : List Stmt :=
  [ Stmt.assign .real [BLOCK_M, BLOCK_DMODEL] "acc"
      (Op.div .real (Broadcast.consSame (Broadcast.consR Broadcast.nil))
        (Op.ref .real [BLOCK_M, BLOCK_DMODEL] "acc")
        (Op.expandDim ⟨1, by simp⟩ (Op.ref .real [BLOCK_M] "l_i"))),
    Stmt.assign .blockPtr [BLOCK_M, BLOCK_DMODEL] "O_block_ptr"
      (Op.makeBlockPtrDynOffsets Out (Op.ref .nat [] "q_offset") [N_CTX, BLOCK_DMODEL] [BLOCK_M, BLOCK_DMODEL]
        [stride_om, stride_on] [Op.mul .nat Broadcast.nil (Op.ref .nat [] "start_m") (Op.constNat BLOCK_M), Op.constNat 0]),
    Stmt.store .real [BLOCK_M, BLOCK_DMODEL] (.blockPtr (Op.ref .blockPtr [BLOCK_M, BLOCK_DMODEL] "O_block_ptr") [])
      ((Op.ref .real [BLOCK_M, BLOCK_DMODEL] "acc")) .none ]

/-- **General** `drop 20` of the dimension-parameterized surface = `attnPostLoopG`. -/
theorem attnPostLoopG_check (Q K V B0 Out : RegionName) (sm_scale : ℝ)
    (stride_qh stride_qm stride_qk stride_kh stride_kn stride_kk
      stride_vh stride_vk stride_vn stride_oh stride_om stride_on
      stride_b0h stride_b0m Z H N_CTX P_SEQ BIAS_LAST_SIZE B0_NUMEL
      BLOCK_DMODEL BLOCK_M BLOCK_N : Nat) :
    (mathematical Q K V B0 Out sm_scale
        stride_qh stride_qm stride_qk stride_kh stride_kn stride_kk stride_vh
        stride_vk stride_vn stride_oh stride_om stride_on stride_b0h
        stride_b0m Z H N_CTX P_SEQ BIAS_LAST_SIZE B0_NUMEL BLOCK_DMODEL
        BLOCK_M BLOCK_N FloatDType.real).toAlgKernel.body.drop 20
      = attnPostLoopG Out BLOCK_M BLOCK_DMODEL N_CTX stride_om stride_on := by
  simp only [↓List.map_cons, ↓List.map_nil, mathematical, ComputeKernel.eraseDType, ComputeKernel.toAlgKernel_fromKernelBody, ComputeKernel.toAlgorithm?_fromKernelBody, Kernel.eraseDType, ComputeKernel.toAlgorithm?_mk, ComputeStmt.listToAlgorithm?, ComputeStmt.toAlgorithm?, ComputeExpr.toAlgorithm?, ComputeOp.toAlgorithm?, Stmt.eraseDTypeList, Stmt.eraseDType, Op.eraseDType.eq_def, MemAccess.eraseDType.eq_def, MaskOpt.eraseDType.eq_def, VeriTile.Triton.eraseDType, NumericDType.eraseDType, ComparableDType.eraseDType, IntegralDType.eraseDType, FloatDType.toTileDType, Except.bind, bind, ComputeKernel.toAlgKernel_mk,
    ComputeStmt.listToAlgorithm?_cons_assign_alg, ComputeStmt.listToAlgorithm?_cons_assign_compute,
    ComputeStmt.listToAlgorithm?_cons_forRangeDyn, ComputeStmt.listToAlgorithm?_cons_store_alg,
    ComputeStmt.listToAlgorithm?_nil, computeExpr_toAlgorithm?_compute_alg,
    ComputeExpr.toAlgorithm?_compute_full_alg, ComputeExpr.toAlgorithm?_alg,
    ComputeExpr.toAlgorithm?, ComputeOp.toAlgorithm?_full_alg, computeOp_toAlgorithm?_alg,
    List.drop_succ_cons, List.drop_zero, attnPostLoopG]
  all_goals rfl

/-- **General** `qk = zeros + dot(q, k)` (dimension-parameterized). -/
theorem qk_dot_op_evalG (s : BlockState) (BM BN HEAD : Nat)
    (qtile : Tile .real [BM, HEAD]) (ktile : Tile .real [HEAD, BN])
    (hqk : s.regs .real [BM, BN] "qk" = some ⟨fun _ : TileIndex [BM, BN] =>
        FloatDType.real.cast FloatDType.real (some 0)⟩)
    (hq : s.regs .real [BM, HEAD] "q" = some qtile)
    (hk : s.regs .real [HEAD, BN] "k" = some ktile) :
    evalOp (Op.add .real (Broadcast.consSame (Broadcast.consSame Broadcast.nil))
        ((Op.ref .real [BM, BN] "qk"))
        (Op.dot (batch := []) ((Op.ref .real [BM, HEAD] "q"))
          (Op.ref .real [HEAD, BN] "k"))) s
      = some (Tile.bop NumericDType.real.add (Broadcast.consSame (Broadcast.consSame Broadcast.nil))
          (⟨fun _ : TileIndex [BM, BN] => FloatDType.real.cast FloatDType.real (FloatDType.real.cast FloatDType.real (some 0))⟩)
          (Tile.dot [] (⟨fun i => FloatDType.real.cast FloatDType.real (qtile.data i)⟩ : Tile .real [BM, HEAD]) ktile)) := by
  have hczA : evalOp ((Op.ref .real [BM, BN] "qk")) s
      = some (⟨fun _ : TileIndex [BM, BN] => FloatDType.real.cast FloatDType.real (FloatDType.real.cast FloatDType.real (some 0))⟩ : Tile .real [BM, BN]) := by
    simp [evalOp_ref, hqk, FloatDType.cast]
  have hcz : @evalOp TileDType.real [BM, BN] ((Op.ref .real [BM, BN] "qk")) s
      = some (⟨fun _ : TileIndex [BM, BN] => FloatDType.real.cast FloatDType.real (FloatDType.real.cast FloatDType.real (some 0))⟩ : Tile .real [BM, BN]) := hczA
  have hcbA : evalOp ((Op.ref .real [BM, HEAD] "q")) s
      = some (⟨fun i => FloatDType.real.cast FloatDType.real (qtile.data i)⟩ : Tile .real [BM, HEAD]) := by
    simp [evalOp_ref, hq, FloatDType.cast]
  have hcb2 : @evalOp TileDType.real [BM, HEAD] ((Op.ref .real [BM, HEAD] "q")) s
      = some (⟨fun i => FloatDType.real.cast FloatDType.real (qtile.data i)⟩ : Tile .real [BM, HEAD]) := hcbA
  have hdotN : evalOp (Op.dot (batch := []) ((Op.ref .real [BM, HEAD] "q")) (Op.ref .real [HEAD, BN] "k")) s
      = some (Tile.dot [] (⟨fun i => FloatDType.real.cast FloatDType.real (qtile.data i)⟩ : Tile .real [BM, HEAD]) ktile) := by
    rw [evalOp_dot]; simp [hcb2, hk]
  have hdotN2 : @evalOp TileDType.real [BM, BN]
      (Op.dot (batch := []) ((Op.ref .real [BM, HEAD] "q")) (Op.ref .real [HEAD, BN] "k")) s
      = some (Tile.dot [] (⟨fun i => FloatDType.real.cast FloatDType.real (qtile.data i)⟩ : Tile .real [BM, HEAD]) ktile) := hdotN
  rw [evalOp_add, hcz, hdotN2]; rfl

/-- **General** `qk += (b0 + b1)·log2e` (dimension-parameterized). -/
theorem qk_bias_op_evalG (s : BlockState) (BM BN : Nat) (qktile : Tile .real [BM, BN])
    (b0tile : Tile .real [BM, 1]) (b1tile : Tile .real [BM, BN])
    (hqk : s.regs .real [BM, BN] "qk" = some qktile)
    (hb0 : s.regs .real [BM, 1] "b0" = some b0tile)
    (hb1 : s.regs .real [BM, BN] "b1" = some b1tile) :
    evalOp (Op.add .real (Broadcast.consSame (Broadcast.consSame Broadcast.nil))
        (Op.ref .real [BM, BN] "qk")
        (Op.mul .real Broadcast.scalarR
          (Op.add .real (Broadcast.consSame (Broadcast.consL Broadcast.nil))
            (Op.ref .real [BM, 1] "b0") (Op.ref .real [BM, BN] "b1")) (Op.const 1.44269504))) s
      = some (Tile.bop NumericDType.real.add (Broadcast.consSame (Broadcast.consSame Broadcast.nil)) qktile
          (Tile.bop NumericDType.real.mul Broadcast.scalarR
            (Tile.bop NumericDType.real.add (Broadcast.consSame (Broadcast.consL Broadcast.nil)) b0tile b1tile)
            (Tile.scalar (some 1.44269504)))) := by
  rw [evalOp_add]
  simp only [evalOp_mul, evalOp_add, evalOp_const, evalOp_ref, hqk, hb0, hb1,
    Option.bind_eq_bind, Option.bind_some]

/-- **General** `b0` per-block bias load (dimension-parameterized over `BLOCK_N`). -/
theorem load_b0_evalG (s : BlockState) (B0 : RegionName)
    (BLOCK_M BLOCK_N stride_b0m smbm boff snv : Nat) (hax : 1 < [BLOCK_M].length.succ)
    (hbo : s.regs .nat [] "b_offset" = some (Tile.scalar boff))
    (hsm : s.regs .nat [] "start_m" = some (Tile.scalar smbm))
    (hsn : s.regs .nat [] "start_n" = some (Tile.scalar snv))
    (hm : s.regs .nat [BLOCK_M] "b_ptr_offsets_m" = some (Tile.vec (fun r : Fin BLOCK_M => r.val))) :
    evalOp ((Op.load .real (.region B0
        (Op.add .nat Broadcast.scalarR
          (Op.add .nat Broadcast.scalarL (Op.ref .nat [] "b_offset")
            (Op.expandDim ⟨1, hax⟩ (Op.mul .nat Broadcast.scalarR
              (Op.add .nat Broadcast.scalarL
                (Op.mul .nat Broadcast.nil (Op.ref .nat [] "start_m") (Op.constNat BLOCK_M))
                (Op.ref .nat [BLOCK_M] "b_ptr_offsets_m")) (Op.constNat stride_b0m))))
          (Op.floorDiv .nat Broadcast.nil (Op.ref .nat [] "start_n") (Op.constNat BLOCK_N))))
        .none : Op .real [BLOCK_M, 1])) s
      = some (⟨fun idx : TileIndex [BLOCK_M, 1] =>
          some (s.readMem B0
            (boff + (smbm * BLOCK_M + idx.1.val) * stride_b0m + snv / BLOCK_N))⟩ : Tile .real [BLOCK_M, 1]) := by
  rw [evalOp_load_region_none]
  have hoff : evalOp ((Op.add .nat Broadcast.scalarR
        (Op.add .nat Broadcast.scalarL (Op.ref .nat [] "b_offset")
          (Op.expandDim ⟨1, hax⟩ (Op.mul .nat Broadcast.scalarR
            (Op.add .nat Broadcast.scalarL
              (Op.mul .nat Broadcast.nil (Op.ref .nat [] "start_m") (Op.constNat BLOCK_M))
              (Op.ref .nat [BLOCK_M] "b_ptr_offsets_m")) (Op.constNat stride_b0m))))
        (Op.floorDiv .nat Broadcast.nil (Op.ref .nat [] "start_n") (Op.constNat BLOCK_N))) : Op .nat [BLOCK_M, 1]) s
      = some (⟨fun idx : TileIndex [BLOCK_M, 1] =>
          boff + (smbm * BLOCK_M + idx.1.val) * stride_b0m + snv / BLOCK_N⟩ : Tile .nat [BLOCK_M, 1]) := by
    conv_lhs => unfold evalOp
    conv_lhs => unfold evalOp
    conv_lhs => unfold evalOp
    conv_lhs => unfold evalOp
    conv_lhs => unfold evalOp
    conv_lhs => unfold evalOp
    rw [evalOp_ref, hsm]
    simp only [evalOp_ref, evalOp_constNat, hbo, hsn, hm, Option.bind, Option.map]
    refine congrArg some ?_
    ext idx
    simp only [Tile.bop_data, Tile.expandDim_data, TileShape.dropInsertedIndex, Broadcast.leftIndex,
      Broadcast.rightIndex, Tile.scalar, Tile.vec, NumericDType.add, NumericDType.mul,
      IntegralDType.floorDiv]
  rw [hoff]
  simp only [Option.bind_eq_bind, Option.bind_some]
  refine congrArg some ?_
  ext idx
  simp only [BlockState.readMemValue_real, Region.cast_id]

/-! ### Loop-body execution chain (`attnLoopBody_stepsG`)

Steps the 15-statement `attnLoopBodyG` one block at a time, exposing the symbolic
`qk`/`m_i_new`/`alpha`/`p`/`acc`/`l_i` tiles so the banked per-cell bridges
(`mijg_eq`/`alphag_eq`/`lig_eq`/`accg_eq`) advance the invariant by one block.
Mirrors `flashLoopBody_steps`, but the kernel's `qk = dot + (b0+b1)·log2e` bias
augmentation replaces flash's causal mask, and the registers seed `lPgK`
(`l_i = 0`). -/

/-- **`m_i = m_i_new`** op-eval recipe (plain register copy). -/
theorem ak_ref_op_eval (s : BlockState) {dtype : TileDType} {shape : TileShape}
    (name : RegName) (v : Tile dtype shape) (h : s.regs dtype shape name = some v) :
    evalOp (Op.ref dtype shape name) s = some v := by rw [evalOp_ref, h]

/-- **`m_i_new = maximum(m_i, tl.max(qk, 1))`** op-eval recipe. -/
theorem ak_mnew_op_eval (s : BlockState) (BM BN : Nat)
    (mtile : Tile .real [BM]) (qktile : Tile .real [BM, BN]) (rmaxT : Tile .real [BM])
    (hmax : s.regs .real [BM] "m_i" = some mtile)
    (hqk : s.regs .real [BM, BN] "qk" = some qktile)
    (hrm : Tile.reduceMaxDrop (⟨1, by simp⟩ : Fin [BM,BN].length) qktile = some rmaxT) :
    evalOp (Op.where
        (Op.gt .real (Broadcast.consSame Broadcast.nil) (Op.ref .real [BM] "m_i")
          (Op.reduceMax (⟨1, by simp⟩ : Fin [BM,BN].length) Bool.false (Op.ref .real [BM, BN] "qk")))
        (Op.ref .real [BM] "m_i")
        (Op.reduceMax (⟨1, by simp⟩ : Fin [BM,BN].length) Bool.false (Op.ref .real [BM, BN] "qk"))) s
      = some (Tile.select (Tile.cop ComparableDType.real.gt (Broadcast.consSame Broadcast.nil) mtile rmaxT) mtile rmaxT) := by
  have hrmaxN : evalOp (Op.reduceMax (⟨1, by simp⟩ : Fin [BM,BN].length) Bool.false (Op.ref .real [BM, BN] "qk")) s = some rmaxT := by
    rw [evalOp_reduceMax]; simp only [evalOp_ref, hqk]; exact hrm
  have hrmax : @evalOp TileDType.real [BM]
      (Op.reduceMax (⟨1, by simp⟩ : Fin [BM,BN].length) Bool.false (Op.ref .real [BM, BN] "qk")) s = some rmaxT := hrmaxN
  rw [evalOp_where]
  simp only [evalOp_gt, evalOp_ref, hmax, hrmax, Option.bind_eq_bind, Option.bind_some]

/-- The maximum compatibility is restricted to the WithBot Real interpreter. -/
private theorem ak_mnew_source_eval (s : BlockState) (BM BN : Nat)
    (mtile : Tile .real [BM]) (qktile : Tile .real [BM, BN]) (rmaxT : Tile .real [BM])
    (hmax : s.regs .real [BM] "m_i" = some mtile)
    (hqk : s.regs .real [BM, BN] "qk" = some qktile)
    (hrm : Tile.reduceMaxDrop (⟨1, by simp⟩ : Fin [BM,BN].length) qktile = some rmaxT) :
    evalOp (Op.max2 (.consSame .nil) (.ref .real [BM] "m_i")
      (.reduceMax ⟨1, by simp⟩ Bool.false (.ref .real [BM,BN] "qk"))) s =
      some (Tile.select (Tile.cop ComparableDType.real.gt (.consSame .nil) mtile rmaxT) mtile rmaxT) := by
  exact evalOp_max2_of_where (ak_mnew_op_eval s BM BN mtile qktile rmaxT hmax hqk hrm)

/-- **`alpha = tl.math.exp2(m_i - m_i_new)`** op-eval recipe. -/
theorem ak_alpha_op_eval (s : BlockState) (BM : Nat) (mtile mnewtile : Tile .real [BM])
    (hmax : s.regs .real [BM] "m_i" = some mtile) (hmnew : s.regs .real [BM] "m_i_new" = some mnewtile) :
    evalOp (Op.exp2 (Op.sub .real (Broadcast.consSame Broadcast.nil) (Op.ref .real [BM] "m_i") (Op.ref .real [BM] "m_i_new"))) s
      = some (Tile.uop WithBot.realExp2 (Tile.bop NumericDType.real.sub (Broadcast.consSame Broadcast.nil) mtile mnewtile)) := by
  rw [evalOp_exp2', evalOp_sub]; simp [evalOp_ref, hmax, hmnew]

/-- **`p = tl.math.exp2(qk - m_i_new[:, None])`** op-eval recipe. -/
theorem ak_p_op_eval (s : BlockState) (BM BN : Nat) (hax : 1 < [BM].length.succ)
    (qktile : Tile .real [BM, BN]) (mnewtile : Tile .real [BM])
    (hqk : s.regs .real [BM, BN] "qk" = some qktile) (hmnew : s.regs .real [BM] "m_i_new" = some mnewtile) :
    evalOp (Op.exp2 (Op.sub .real (Broadcast.consSame (Broadcast.consR Broadcast.nil)) (Op.ref .real [BM, BN] "qk")
        (Op.expandDim ⟨1, hax⟩ (Op.ref .real [BM] "m_i_new")))) s
      = some (Tile.uop WithBot.realExp2 (Tile.bop NumericDType.real.sub (Broadcast.consSame (Broadcast.consR Broadcast.nil)) qktile
          (Tile.expandDim ⟨1, hax⟩ mnewtile))) := by
  have hexp2 : @evalOp TileDType.real [BM, 1] (Op.expandDim ⟨1, hax⟩ (Op.ref .real [BM] "m_i_new")) s
      = some (Tile.expandDim ⟨1, hax⟩ mnewtile) := evalOp_expandDim_ref_of_regs _ _ _ _ _ _ hmnew
  rw [evalOp_exp2', evalOp_sub]
  simp only [evalOp_ref, hqk, hexp2, Option.bind_eq_bind, Option.bind_some]; rfl

/-- **`acc *= alpha[:, None]`** op-eval recipe. -/
theorem ak_accmul_op_eval (s : BlockState) (BM DIM : Nat) (hax : 1 < [BM].length.succ)
    (acctile : Tile .real [BM, DIM]) (atile : Tile .real [BM])
    (hacc : s.regs .real [BM, DIM] "acc" = some acctile) (ha : s.regs .real [BM] "alpha" = some atile) :
    evalOp (Op.mul .real (Broadcast.consSame (Broadcast.consR Broadcast.nil)) (Op.ref .real [BM, DIM] "acc")
        (Op.expandDim ⟨1, hax⟩ (Op.ref .real [BM] "alpha"))) s
      = some (Tile.bop NumericDType.real.mul (Broadcast.consSame (Broadcast.consR Broadcast.nil)) acctile
          (Tile.expandDim ⟨1, hax⟩ atile)) := by
  have hexp2 : @evalOp TileDType.real [BM, 1] (Op.expandDim ⟨1, hax⟩ (Op.ref .real [BM] "alpha")) s
      = some (Tile.expandDim ⟨1, hax⟩ atile) := evalOp_expandDim_ref_of_regs _ _ _ _ _ _ ha
  rw [evalOp_mul]; simp only [evalOp_ref, hacc, hexp2, Option.bind_eq_bind, Option.bind_some]; rfl

/-- **`acc += tl.dot(p, v)`** op-eval recipe. -/
theorem ak_accadd_op_eval (s : BlockState) (BM BN DIM : Nat)
    (acc1tile : Tile .real [BM, DIM]) (ptile : Tile .real [BM, BN]) (vtile : Tile .real [BN, DIM])
    (hacc : s.regs .real [BM, DIM] "acc" = some acc1tile)
    (hp : s.regs .real [BM, BN] "p" = some ptile)
    (hv : s.regs .real [BN, DIM] "v" = some vtile) :
    evalOp (Op.add .real (Broadcast.consSame (Broadcast.consSame Broadcast.nil)) (Op.ref .real [BM, DIM] "acc")
        (Op.dot (batch := []) (((Op.ref .real [BM, BN] "p"))) (Op.ref .real [BN, DIM] "v"))) s
      = some (Tile.bop NumericDType.real.add (Broadcast.consSame (Broadcast.consSame Broadcast.nil)) acc1tile
          (Tile.dot [] ptile vtile)) := by
  have hpref : evalOp (((Op.ref .real [BM, BN] "p"))) s = some ptile := by
    simpa only [evalOp_ref] using hp
  have hpref' : @evalOp TileDType.real [BM, BN]
      (((Op.ref .real [BM, BN] "p"))) s = some ptile := hpref
  have hdotN : evalOp
      (Op.dot (batch := []) (((Op.ref .real [BM, BN] "p"))) (Op.ref .real [BN, DIM] "v")) s
      = some (Tile.dot [] ptile vtile) := by
    rw [evalOp_dot]; simp [hpref', evalOp_ref, hv]
  have hdot : @evalOp TileDType.real [BM, DIM]
      (Op.dot (batch := []) (((Op.ref .real [BM, BN] "p"))) (Op.ref .real [BN, DIM] "v")) s
      = some (Tile.dot [] ptile vtile) := hdotN
  rw [evalOp_add]; simp only [evalOp_ref, hacc, hdot, Option.bind_eq_bind, Option.bind_some]; rfl

/-- **`l_i = l_i * alpha + tl.sum(p, 1)`** op-eval recipe. -/
theorem ak_li_op_eval (s : BlockState) (BM BN : Nat)
    (ltile atile : Tile .real [BM]) (ptile : Tile .real [BM, BN])
    (hl : s.regs .real [BM] "l_i" = some ltile) (ha : s.regs .real [BM] "alpha" = some atile)
    (hp : s.regs .real [BM, BN] "p" = some ptile) :
    evalOp (Op.add .real (Broadcast.consSame Broadcast.nil)
        (Op.mul .real (Broadcast.consSame Broadcast.nil) (Op.ref .real [BM] "l_i") (Op.ref .real [BM] "alpha"))
        (Op.reduceSum (⟨1, by simp⟩ : Fin [BM,BN].length) Bool.false (Op.ref .real [BM, BN] "p"))) s
      = some (Tile.bop NumericDType.real.add (Broadcast.consSame Broadcast.nil)
          (Tile.bop NumericDType.real.mul (Broadcast.consSame Broadcast.nil) ltile atile)
          (Tile.reduceSumDrop (⟨1, by simp⟩ : Fin [BM,BN].length) ptile)) := by
  have hsumN0 : evalOp (Op.reduceSum (⟨1, by simp⟩ : Fin [BM,BN].length) Bool.false (Op.ref .real [BM, BN] "p")) s
      = some (Tile.reduceSumDrop (⟨1, by simp⟩ : Fin [BM,BN].length) ptile) := by
    rw [evalOp_reduceSum]; simp only [evalOp_ref, hp, Option.bind_eq_bind, Option.bind_some]; rfl
  have hsumN : @evalOp TileDType.real [BM]
      (Op.reduceSum (⟨1, by simp⟩ : Fin [BM,BN].length) Bool.false (Op.ref .real [BM, BN] "p")) s
      = some (Tile.reduceSumDrop (⟨1, by simp⟩ : Fin [BM,BN].length) ptile) := hsumN0
  rw [evalOp_add]
  simp only [evalOp_mul, evalOp_ref, hl, ha, hsumN, Option.bind_eq_bind, Option.bind_some]; rfl

set_option maxHeartbeats 1000000 in
set_option maxRecDepth 8000 in
/-- **General** loop-body execution chain (dimension-parameterized over
`BLOCK_M BLOCK_N HEAD`, with contiguous K/V layout `stride_kk=1, stride_kn=HEAD,
stride_vk=HEAD, stride_vn=1` baked by `kFlat`/`vFlat`). -/
theorem attnLoopBody_stepsG (B0 : RegionName) (BLOCK_M BLOCK_N HEAD stride_b0m : Nat)
    (hBN : 0 < BLOCK_N) (sin : BlockState) (SN : Nat)
    (Kreg Vreg : RegionName) (kbase vbase kcol vrow kcols vrows : Nat)
    (boff smbm : Nat)
    (qtile : Tile .real [BLOCK_M, HEAD]) (mtile ltile : Tile .real [BLOCK_M])
    (acctile : Tile .real [BLOCK_M, HEAD]) (ktile : Tile .real [HEAD, BLOCK_N]) (vtile : Tile .real [BLOCK_N, HEAD])
    (b1tile : Tile .real [BLOCK_M, BLOCK_N])
    (hsn : sin.regs .nat [] "start_n" = some (Tile.scalar SN))
    (hbo : sin.regs .nat [] "b_offset" = some (Tile.scalar boff))
    (hsm : sin.regs .nat [] "start_m" = some (Tile.scalar smbm))
    (hm : sin.regs .nat [BLOCK_M] "b_ptr_offsets_m" = some (Tile.vec (fun r : Fin BLOCK_M => r.val)))
    (hmax : sin.regs .real [BLOCK_M] "m_i" = some mtile)
    (hl : sin.regs .real [BLOCK_M] "l_i" = some ltile)
    (hacc : sin.regs .real [BLOCK_M, HEAD] "acc" = some acctile)
    (hq : sin.regs .real [BLOCK_M, HEAD] "q" = some qtile)
    (hb1 : sin.regs .real [BLOCK_M, BLOCK_N] "b1" = some b1tile)
    (hKp : sin.regs .blockPtr [HEAD, BLOCK_N] "K_block_ptr" = some
      (⟨fun _ : TileIndex [HEAD, BLOCK_N] =>
        { region := Kreg, baseOffset := kbase, parentShape := [HEAD, kcols],
          blockShape := [HEAD, BLOCK_N], strides := [1, HEAD], offsets := [0, kcol] }⟩))
    (hVp : sin.regs .blockPtr [BLOCK_N, HEAD] "V_block_ptr" = some
      (⟨fun _ : TileIndex [BLOCK_N, HEAD] =>
        { region := Vreg, baseOffset := vbase, parentShape := [vrows, HEAD],
          blockShape := [BLOCK_N, HEAD], strides := [HEAD, 1], offsets := [vrow, 0] }⟩))
    (hkload : ∀ idx : TileIndex [HEAD, BLOCK_N],
      ktile.data idx = some (sin.readMem Kreg (kbase + idx.1.val * 1 + (kcol + idx.2.1.val) * HEAD)))
    (hvload : ∀ idx : TileIndex [BLOCK_N, HEAD],
      vtile.data idx = some (sin.readMem Vreg (vbase + (vrow + idx.1.val) * HEAD + idx.2.1.val * 1)))
    (qoffV : Nat) (hqo : sin.regs .nat [] "q_offset" = some (Tile.scalar qoffV))
    (hundef : ∀ rg o, sin.undef rg o = 0) :
    ∃ sF, stepStmts (attnLoopBodyG B0 BLOCK_M BLOCK_N HEAD stride_b0m) sin = some sF
      ∧ sF.pids = sin.pids ∧ sF.mem = sin.mem ∧ (∀ rg o, sF.undef rg o = 0)
      ∧ sF.regs .real [BLOCK_M, HEAD] "q" = some qtile
      ∧ sF.regs .real [BLOCK_M, BLOCK_N] "b1" = some b1tile
      ∧ sF.regs .nat [] "b_offset" = some (Tile.scalar boff)
      ∧ sF.regs .nat [] "start_m" = some (Tile.scalar smbm)
      ∧ sF.regs .nat [] "q_offset" = some (Tile.scalar qoffV)
      ∧ sF.regs .nat [BLOCK_M] "b_ptr_offsets_m" = some (Tile.vec (fun r : Fin BLOCK_M => r.val))
      ∧ sF.regs .blockPtr [HEAD, BLOCK_N] "K_block_ptr" = some
          (⟨fun _ : TileIndex [HEAD, BLOCK_N] =>
            { region := Kreg, baseOffset := kbase, parentShape := [HEAD, kcols],
              blockShape := [HEAD, BLOCK_N], strides := [1, HEAD], offsets := [0, kcol + BLOCK_N] }⟩)
      ∧ sF.regs .blockPtr [BLOCK_N, HEAD] "V_block_ptr" = some
          (⟨fun _ : TileIndex [BLOCK_N, HEAD] =>
            { region := Vreg, baseOffset := vbase, parentShape := [vrows, HEAD],
              blockShape := [BLOCK_N, HEAD], strides := [HEAD, 1], offsets := [vrow + BLOCK_N, 0] }⟩)
      ∧ ∃ (qkT : Tile .real [BLOCK_M, BLOCK_N]) (rmaxT mnewT alphaT : Tile .real [BLOCK_M])
            (pT : Tile .real [BLOCK_M, BLOCK_N]),
          (∀ i : Fin BLOCK_M, ∀ j : Fin BLOCK_N,
            qkT.data (i, j, PUnit.unit)
              = (Tile.bop NumericDType.real.add (Broadcast.consSame (Broadcast.consSame Broadcast.nil))
                  (Tile.bop NumericDType.real.add (Broadcast.consSame (Broadcast.consSame Broadcast.nil))
                    (⟨fun _ : TileIndex [BLOCK_M, BLOCK_N] => FloatDType.real.cast FloatDType.real (FloatDType.real.cast FloatDType.real (some 0))⟩)
                    (Tile.dot [] (⟨fun a => FloatDType.real.cast FloatDType.real (qtile.data a)⟩ : Tile .real [BLOCK_M, HEAD]) ktile))
                  (Tile.bop NumericDType.real.mul Broadcast.scalarR
                    (Tile.bop NumericDType.real.add (Broadcast.consSame (Broadcast.consL Broadcast.nil))
                      (⟨fun idx : TileIndex [BLOCK_M, 1] =>
                        some (sin.readMem B0 (boff + (smbm * BLOCK_M + idx.1.val) * stride_b0m + SN / BLOCK_N))⟩)
                      b1tile)
                    (Tile.scalar (some 1.44269504)))).data (i, j, PUnit.unit))
          ∧ Tile.reduceMaxDrop (⟨1, by simp⟩ : Fin [BLOCK_M, BLOCK_N].length) qkT = some rmaxT
          ∧ mnewT = Tile.select (Tile.cop ComparableDType.real.gt (Broadcast.consSame Broadcast.nil) mtile rmaxT) mtile rmaxT
          ∧ alphaT = Tile.uop WithBot.realExp2 (Tile.bop NumericDType.real.sub (Broadcast.consSame Broadcast.nil) mtile mnewT)
          ∧ pT = Tile.uop WithBot.realExp2 (Tile.bop NumericDType.real.sub (Broadcast.consSame (Broadcast.consR Broadcast.nil)) qkT (Tile.expandDim ⟨1, by simp⟩ mnewT))
          ∧ sF.regs .real [BLOCK_M] "m_i" = some mnewT
          ∧ sF.regs .real [BLOCK_M, HEAD] "acc" = some (Tile.bop NumericDType.real.add (Broadcast.consSame (Broadcast.consSame Broadcast.nil))
              (Tile.bop NumericDType.real.mul (Broadcast.consSame (Broadcast.consR Broadcast.nil)) acctile (Tile.expandDim ⟨1, by simp⟩ alphaT))
              (Tile.dot [] pT vtile))
          ∧ sF.regs .real [BLOCK_M] "l_i" = some (Tile.bop NumericDType.real.add (Broadcast.consSame Broadcast.nil)
              (Tile.bop NumericDType.real.mul (Broadcast.consSame Broadcast.nil) ltile alphaT)
              (Tile.reduceSumDrop (⟨1, by simp⟩ : Fin [BLOCK_M, BLOCK_N].length) pT)) := by
  set b0T : Tile .real [BLOCK_M, 1] :=
    ⟨fun idx : TileIndex [BLOCK_M, 1] => some (sin.readMem B0 (boff + (smbm * BLOCK_M + idx.1.val) * stride_b0m + SN / BLOCK_N))⟩ with hb0T
  set qkdotT : Tile .real [BLOCK_M, BLOCK_N] :=
    Tile.bop NumericDType.real.add (Broadcast.consSame (Broadcast.consSame Broadcast.nil))
      (⟨fun _ : TileIndex [BLOCK_M, BLOCK_N] => FloatDType.real.cast FloatDType.real (FloatDType.real.cast FloatDType.real (some 0))⟩)
      (Tile.dot [] (⟨fun a => FloatDType.real.cast FloatDType.real (qtile.data a)⟩ : Tile .real [BLOCK_M, HEAD]) ktile) with hqkdotT
  set qkT : Tile .real [BLOCK_M, BLOCK_N] :=
    Tile.bop NumericDType.real.add (Broadcast.consSame (Broadcast.consSame Broadcast.nil)) qkdotT
      (Tile.bop NumericDType.real.mul Broadcast.scalarR
        (Tile.bop NumericDType.real.add (Broadcast.consSame (Broadcast.consL Broadcast.nil)) b0T b1tile)
        (Tile.scalar (some 1.44269504))) with hqkT
  have hqkData : ∀ i : Fin BLOCK_M, ∀ j : Fin BLOCK_N, qkT.data (i, j, PUnit.unit)
      = (Tile.bop NumericDType.real.add (Broadcast.consSame (Broadcast.consSame Broadcast.nil)) qkdotT
          (Tile.bop NumericDType.real.mul Broadcast.scalarR
            (Tile.bop NumericDType.real.add (Broadcast.consSame (Broadcast.consL Broadcast.nil)) b0T b1tile)
            (Tile.scalar (some 1.44269504)))).data (i, j, PUnit.unit) := fun _ _ => rfl
  obtain ⟨rmaxT, hrm⟩ : ∃ t, Tile.reduceMaxDrop (⟨1, by simp⟩ : Fin [BLOCK_M, BLOCK_N].length) qkT = some t :=
    ⟨_, by unfold Tile.reduceMaxDrop; rw [dif_pos (show 0 < TileShape.axisDim [BLOCK_M, BLOCK_N] (⟨1, by simp⟩ : Fin [BLOCK_M, BLOCK_N].length) from hBN)]⟩
  set mnewT : Tile .real [BLOCK_M] := Tile.select (Tile.cop ComparableDType.real.gt (Broadcast.consSame Broadcast.nil) mtile rmaxT) mtile rmaxT with hmnew
  set alphaT : Tile .real [BLOCK_M] := Tile.uop WithBot.realExp2 (Tile.bop NumericDType.real.sub (Broadcast.consSame Broadcast.nil) mtile mnewT) with halpha
  set pT : Tile .real [BLOCK_M, BLOCK_N] := Tile.uop WithBot.realExp2 (Tile.bop NumericDType.real.sub (Broadcast.consSame (Broadcast.consR Broadcast.nil)) qkT (Tile.expandDim ⟨1, by simp⟩ mnewT)) with hpT
  unfold attnLoopBodyG
  -- L0: k = load K_block_ptr
  rw [stepStmts.cons_some (stepStmt_assign_eq_some
    (show evalOp (Op.load .real (.blockPtr (Op.ref .blockPtr [HEAD, BLOCK_N] "K_block_ptr") []) .none .unspecified) sin
        = some ktile from by
      rw [evalOp_unchecked_block_load, load_blockPtr_K_eval Kreg kbase HEAD (kcols) HEAD BLOCK_N 1 HEAD kcol
        (Op.ref .blockPtr [HEAD, BLOCK_N] "K_block_ptr") sin (by rw [evalOp_ref]; simp [hKp])]
      refine congrArg some ?_; ext idx; rw [hkload idx]))]
  -- L1: v = load V_block_ptr
  rw [stepStmts.cons_some (stepStmt_assign_eq_some
    (show evalOp (Op.load .real (.blockPtr (Op.ref .blockPtr [BLOCK_N, HEAD] "V_block_ptr") []) .none .unspecified) _
        = some vtile from by
      rw [evalOp_unchecked_block_load, load_blockPtr_Q_eval Vreg vbase (vrows) HEAD BLOCK_N HEAD HEAD 1 vrow
        (Op.ref .blockPtr [BLOCK_N, HEAD] "V_block_ptr") _ (by rw [evalOp_ref]; simp [BlockState.setReg_ne_name, hVp])]
      refine congrArg some ?_; ext idx
      simp only [BlockState.setReg_readMem]; rw [hvload idx]))]
  -- L2: qk = zeros
  rw [stepStmts.cons_some (stepStmt_assign_eq_some
    (show @evalOp TileDType.real [BLOCK_M, BLOCK_N] (Op.full [BLOCK_M, BLOCK_N] ((Op.const 0)))
          ((sin.setReg "k" .real [HEAD, BLOCK_N] ktile).setReg "v" .real [BLOCK_N, HEAD] vtile)
        = some (⟨fun _ : TileIndex [BLOCK_M, BLOCK_N] => FloatDType.real.cast FloatDType.real (some 0)⟩ : Tile .real [BLOCK_M, BLOCK_N]) from by
      conv_lhs => unfold evalOp
      conv_lhs => unfold evalOp
      conv_lhs => unfold evalOp
      simp only [Option.bind_eq_bind]
      rfl))]
  -- L3: qk += dot(q, k)  →  qkdotT
  rw [stepStmts.cons_some (stepStmt_assign_eq_some
    (show evalOp (Op.add .real (Broadcast.consSame (Broadcast.consSame Broadcast.nil))
          ((Op.ref .real [BLOCK_M, BLOCK_N] "qk"))
          (Op.dot (batch := []) ((Op.ref .real [BLOCK_M, HEAD] "q"))
            (Op.ref .real [HEAD, BLOCK_N] "k"))) _ = some qkdotT from by
      rw [qk_dot_op_evalG _ BLOCK_M BLOCK_N HEAD qtile ktile (by rw [BlockState.setReg_same])
        (by simp [BlockState.setReg_ne_name, hq]) (by simp [BlockState.setReg_ne_name, BlockState.setReg_same])]))]
  -- L4: b0 = load B0[..]  →  b0T
  rw [stepStmts.cons_some
    (stepStmt_assign_eq_some (v := b0T)
      (by
        rw [load_b0_evalG
          ((((sin.setReg "k" .real [HEAD, BLOCK_N] ktile).setReg "v" .real [BLOCK_N, HEAD] vtile).setReg "qk"
              .real [BLOCK_M, BLOCK_N] (⟨fun _ : TileIndex [BLOCK_M, BLOCK_N] => FloatDType.real.cast FloatDType.real (some 0)⟩)).setReg
            "qk" .real [BLOCK_M, BLOCK_N] qkdotT)
          B0 BLOCK_M BLOCK_N stride_b0m smbm boff SN (by simp)
          (by simp [BlockState.setReg_ne_name, hbo]) (by simp [BlockState.setReg_ne_name, hsm])
          (by simp [BlockState.setReg_ne_name, hsn]) (by simp [BlockState.setReg_ne_name, hm])]
        refine congrArg some ?_; ext idx
        simp only [hb0T, BlockState.setReg_readMem] : _ = some b0T))]
  -- L5: qk += (b0 + b1)·log2e  →  qkT
  rw [stepStmts.cons_some (stepStmt_assign_eq_some
    (show evalOp (Op.add .real (Broadcast.consSame (Broadcast.consSame Broadcast.nil))
          (Op.ref .real [BLOCK_M, BLOCK_N] "qk")
          (Op.mul .real Broadcast.scalarR
            (Op.add .real (Broadcast.consSame (Broadcast.consL Broadcast.nil))
              (Op.ref .real [BLOCK_M, 1] "b0") (Op.ref .real [BLOCK_M, BLOCK_N] "b1")) (Op.const 1.44269504))) _
        = some qkT from by
      rw [qk_bias_op_evalG _ BLOCK_M BLOCK_N qkdotT b0T b1tile (by simp [BlockState.setReg_ne_name, BlockState.setReg_same])
        (by rw [BlockState.setReg_same]) (by simp [BlockState.setReg_ne_name, hb1])]))]
  -- L6: m_i_new = maximum(m_i, reduceMax qk 1)
  rw [stepStmts.cons_some (stepStmt_assign_eq_some
    (ak_mnew_source_eval _ BLOCK_M BLOCK_N mtile qkT rmaxT
      (by simp [BlockState.setReg_ne_name, hmax]) (by rw [BlockState.setReg_same]) hrm))]
  -- L7: alpha = exp2(m_i - m_i_new)
  rw [stepStmts.cons_some (stepStmt_assign_eq_some
    (ak_alpha_op_eval _ BLOCK_M mtile mnewT
      (by simp [BlockState.setReg_ne_name, hmax]) (by simp [BlockState.setReg_same, hmnew])))]
  -- L8: p = exp2(qk - m_i_new[:,None])
  rw [stepStmts.cons_some (stepStmt_assign_eq_some
    (ak_p_op_eval _ BLOCK_M BLOCK_N (by simp) qkT mnewT
      (by simp [BlockState.setReg_ne_name]) (by simp [BlockState.setReg_ne_name, hmnew])))]
  -- L9: acc *= alpha[:,None]
  rw [stepStmts.cons_some (stepStmt_assign_eq_some
    (ak_accmul_op_eval _ BLOCK_M HEAD (by simp) acctile alphaT
      (by simp [BlockState.setReg_ne_name, hacc]) (by simp [BlockState.setReg_same, halpha])))]
  -- L10: acc += dot(p, v)
  rw [stepStmts.cons_some (stepStmt_assign_eq_some
    (ak_accadd_op_eval _ BLOCK_M BLOCK_N HEAD
      (Tile.bop NumericDType.real.mul (Broadcast.consSame (Broadcast.consR Broadcast.nil)) acctile (Tile.expandDim ⟨1, by simp⟩ alphaT))
      pT vtile
      (by rw [BlockState.setReg_same]) (by simp [BlockState.setReg_ne_name, hpT])
      (by simp [BlockState.setReg_ne_name])))]
  -- L11: l_i = l_i * alpha + sum p 1
  rw [stepStmts.cons_some (stepStmt_assign_eq_some
    (ak_li_op_eval _ BLOCK_M BLOCK_N ltile alphaT pT
      (by simp [BlockState.setReg_ne_name, hl]) (by simp [BlockState.setReg_ne_name, halpha])
      (by simp [BlockState.setReg_ne_name, hpT])))]
  -- L12: m_i = m_i_new
  rw [stepStmts.cons_some (stepStmt_assign_eq_some
    (ak_ref_op_eval _ "m_i_new" mnewT (by simp only [BlockState.setReg_ne_name, BlockState.setReg_same, ne_eq, String.reduceEq, not_false_eq_true, reduceCtorEq, and_self, and_true, true_and]; rw [hmnew])))]
  -- L13: K_block_ptr = advance(K_block_ptr, [0, BLOCK_N])
  rw [stepStmts.cons_some (stepStmt_assign_eq_some
    (advance_col_eval _ Kreg kbase HEAD (kcols) HEAD BLOCK_N 1 HEAD kcol BLOCK_N "K_block_ptr"
      (by simp [BlockState.setReg_ne_name, hKp])))]
  -- L14: V_block_ptr = advance(V_block_ptr, [BLOCK_N, 0])
  rw [stepStmts.cons_some (stepStmt_assign_eq_some
    (advance_row_eval _ Vreg vbase (vrows) HEAD BLOCK_N HEAD HEAD 1 vrow BLOCK_N "V_block_ptr"
      (by simp [BlockState.setReg_ne_name, hVp])))]
  rw [stepStmts.nil]
  refine ⟨_, rfl, ?_, ?_, ?_, ?_, ?_, ?_, ?_, ?_, ?_, ?_, ?_, qkT, rmaxT, mnewT, alphaT, pT,
    hqkData, hrm, rfl, rfl, rfl, ?_, ?_, ?_⟩
  · simp [BlockState.setReg_pids]
  · funext rg o; simp [BlockState.setReg_mem]
  · intro rg o; simp [BlockState.setReg_undef, hundef]
  · simp [BlockState.setReg_ne_name, hq]
  · simp [BlockState.setReg_ne_name, hb1]
  · simp [BlockState.setReg_ne_name, hbo]
  · simp [BlockState.setReg_ne_name, hsm]
  · simp [BlockState.setReg_ne_name, hqo]
  · simp [BlockState.setReg_ne_name, hm]
  · simp [BlockState.setReg_ne_name, BlockState.setReg_same]
  · simp [BlockState.setReg_ne_name, BlockState.setReg_same]
  · simp [BlockState.setReg_ne_name, BlockState.setReg_same]
  · simp [BlockState.setReg_ne_name, BlockState.setReg_same]
  · simp [BlockState.setReg_ne_name, BlockState.setReg_same]

/-- The lowered prologue tail (statements 10–18), dimension-parameterized over
`sm_scale BLOCK_M BLOCK_N HEAD_DIM N_CTX P_SEQ BIAS_LAST_SIZE stride_b0h stride_b0m`. -/
def attnPreLoopTailG (B0 : RegionName) (sm_scale : ℝ)
    (BLOCK_M BLOCK_N HEAD_DIM N_CTX P_SEQ BIAS_LAST_SIZE stride_b0h stride_b0m : Nat) : List Stmt :=
  [ Stmt.assign .real [] "qk_scale" (Op.mul .real Broadcast.nil (Op.const sm_scale) (Op.const 1.44269504)),
    Stmt.assign .real [BLOCK_M, HEAD_DIM] "q"
      (Op.load .real (.blockPtr (Op.ref .blockPtr [BLOCK_M, HEAD_DIM] "Q_block_ptr") []) .none .unspecified),
    Stmt.assign .real [BLOCK_M, HEAD_DIM] "q"
      ((Op.mul .real Broadcast.scalarR (Op.ref .real [BLOCK_M, HEAD_DIM] "q") (Op.ref .real [] "qk_scale"))),
    Stmt.assign .nat [] "lo" (Op.constNat 0),
    Stmt.assign .nat [] "hi" (Op.constNat (N_CTX + P_SEQ)),
    Stmt.assign .nat [BLOCK_M] "b_ptr_offsets_m" (Op.arange BLOCK_M),
    Stmt.assign .nat [] "b_offset" (Op.mul .nat Broadcast.nil (Op.ref .nat [] "off_hz") (Op.constNat stride_b0h)),
    Stmt.assign .nat [BLOCK_N] "b_ptr_offsets_n_1"
      (Op.add .nat Broadcast.scalarR
        (Op.mod .nat Broadcast.scalarR (Op.arange BLOCK_N) (Op.constNat BIAS_LAST_SIZE)) (Op.constNat BIAS_LAST_SIZE)),
    Stmt.assign .real [BLOCK_M, BLOCK_N] "b1"
      (Op.load .real (.region B0
        (Op.add .nat (Broadcast.consR (Broadcast.consL Broadcast.nil))
          (Op.add .nat Broadcast.scalarL (Op.ref .nat [] "b_offset")
            (Op.expandDim ⟨1, by simp⟩ (Op.mul .nat Broadcast.scalarR
              (Op.add .nat Broadcast.scalarL
                (Op.mul .nat Broadcast.nil (Op.ref .nat [] "start_m") (Op.constNat BLOCK_M))
                (Op.ref .nat [BLOCK_M] "b_ptr_offsets_m")) (Op.constNat stride_b0m))))
          (Op.expandDim ⟨0, by simp⟩ (Op.ref .nat [BLOCK_N] "b_ptr_offsets_n_1"))))
        .none) ]

theorem attnPreLoopTailG_check (Q K V B0 Out : RegionName) (sm_scale : ℝ)
    (stride_qh stride_qm stride_qk stride_kh stride_kn stride_kk
      stride_vh stride_vk stride_vn stride_oh stride_om stride_on
      stride_b0h stride_b0m Z H N_CTX P_SEQ BIAS_LAST_SIZE B0_NUMEL
      BLOCK_DMODEL BLOCK_M BLOCK_N : Nat) :
    ((mathematical Q K V B0 Out sm_scale
        stride_qh stride_qm stride_qk stride_kh stride_kn stride_kk stride_vh
        stride_vk stride_vn stride_oh stride_om stride_on stride_b0h
        stride_b0m Z H N_CTX P_SEQ BIAS_LAST_SIZE B0_NUMEL BLOCK_DMODEL
        BLOCK_M BLOCK_N FloatDType.real).toAlgKernel.body.take 19).drop 10
      = attnPreLoopTailG B0 sm_scale BLOCK_M BLOCK_N BLOCK_DMODEL N_CTX P_SEQ BIAS_LAST_SIZE stride_b0h stride_b0m := by
  simp only [↓List.map_cons, ↓List.map_nil, mathematical, ComputeKernel.eraseDType, ComputeKernel.toAlgKernel_fromKernelBody, ComputeKernel.toAlgorithm?_fromKernelBody, Kernel.eraseDType, ComputeKernel.toAlgorithm?_mk, ComputeStmt.listToAlgorithm?, ComputeStmt.toAlgorithm?, ComputeExpr.toAlgorithm?, ComputeOp.toAlgorithm?, Stmt.eraseDTypeList, Stmt.eraseDType, Op.eraseDType.eq_def, MemAccess.eraseDType.eq_def, MaskOpt.eraseDType.eq_def, VeriTile.Triton.eraseDType, NumericDType.eraseDType, ComparableDType.eraseDType, IntegralDType.eraseDType, FloatDType.toTileDType, Except.bind, bind, ComputeKernel.toAlgKernel_mk,
    ComputeStmt.listToAlgorithm?_cons_assign_alg, ComputeStmt.listToAlgorithm?_cons_assign_compute,
    ComputeStmt.listToAlgorithm?_cons_forRangeDyn, ComputeStmt.listToAlgorithm?_cons_store_alg,
    ComputeStmt.listToAlgorithm?_nil, computeExpr_toAlgorithm?_compute_alg,
    ComputeExpr.toAlgorithm?_compute_full_alg, ComputeExpr.toAlgorithm?_alg,
    ComputeExpr.toAlgorithm?, ComputeOp.toAlgorithm?_full_alg, computeOp_toAlgorithm?_alg,
    List.take_succ_cons, List.take_zero, List.drop_succ_cons, List.drop_zero, attnPreLoopTailG]
  all_goals rfl

/-- **General** `q = q · qk_scale` (dimension-parameterized). -/
theorem ak_qscale_op_evalG (s : BlockState) (BM HEAD : Nat) (qtile : Tile .real [BM, HEAD]) (sc : ℝ)
    (hq : s.regs .real [BM, HEAD] "q" = some qtile)
    (hqs : s.regs .real [] "qk_scale" = some (Tile.scalar (some sc))) :
    evalOp ((Op.mul .real Broadcast.scalarR (Op.ref .real [BM, HEAD] "q") (Op.ref .real [] "qk_scale"))) s
      = some (⟨fun idx : TileIndex [BM, HEAD] =>
          FloatDType.real.cast FloatDType.real ((qtile.data idx).bind (fun x => some (x * sc)))⟩ : Tile .real [BM, HEAD]) := by
  have hmul0 : evalOp
        (Op.mul .real Broadcast.scalarR (Op.ref .real [BM, HEAD] "q") (Op.ref .real [] "qk_scale")) s
      = some (Tile.bop NumericDType.real.mul Broadcast.scalarR qtile (Tile.scalar (some sc))) := by
    rw [evalOp_mul]; simp only [evalOp_ref, hq, hqs, Option.bind_eq_bind, Option.bind_some]
  have hmul : @evalOp FloatDType.real.toTileDType [BM, HEAD]
        (Op.mul .real Broadcast.scalarR (Op.ref .real [BM, HEAD] "q") (Op.ref .real [] "qk_scale")) s
      = some (Tile.bop NumericDType.real.mul Broadcast.scalarR qtile (Tile.scalar (some sc))) := hmul0
  erw [hmul0]
  refine congrArg some ?_; ext idx
  simp only [Tile.bop_data, Tile.scalar_data, Broadcast.leftIndex, Broadcast.rightIndex,
    NumericDType.mul, WithBot.realMul, Option.map₂, Option.bind, Option.map, FloatDType.cast,
    FloatDType.ofWithBot, FloatDType.toWithBot]

/-- `evalOp` helper for `Op.mod` (no dedicated `@[simp]` form). -/
theorem evalOp_mod' {dtype a b shape} (h : IntegralDType dtype)
    (bc : Broadcast a b shape) (x : Op dtype a) (y : Op dtype b) (s : BlockState) :
    evalOp (.mod h bc x y) s = (do
      let vx ← evalOp x s; let vy ← evalOp y s; some (Tile.bop h.mod bc vx vy)) := by
  simp [evalOp]

/-- **General** `b_ptr_offsets_n_1 = (arange % BIAS) + BIAS` (parameterized). -/
theorem ak_bn1_op_evalG (s : BlockState) (BLOCK_N BIAS_LAST_SIZE : Nat) :
    evalOp (Op.add .nat Broadcast.scalarR
        (Op.mod .nat Broadcast.scalarR (Op.arange BLOCK_N) (Op.constNat BIAS_LAST_SIZE)) (Op.constNat BIAS_LAST_SIZE)) s
      = some (Tile.vec (fun jL : Fin BLOCK_N => jL.val % BIAS_LAST_SIZE + BIAS_LAST_SIZE)) := by
  rw [evalOp_add, evalOp_mod']
  simp only [evalOp_arange, evalOp_constNat, Option.bind_eq_bind, Option.bind_some]
  refine congrArg some ?_; ext idx
  simp only [Tile.bop_data, Tile.scalar_data, Tile.vec_data, Broadcast.leftIndex,
    Broadcast.rightIndex, NumericDType.add, IntegralDType.nat_mod]

set_option maxHeartbeats 1000000 in
set_option maxRecDepth 8000 in
/-- **General** `preLoopG` (dimension-parameterized). Steps the 19-statement
prologue to `attnKernelInvariant … 0`. Contiguous Q/K/V layout
(`stride_qm=HEAD, stride_qk=1, stride_kk=1, stride_kn=HEAD, stride_vk=HEAD,
stride_vn=1`) per `qRaw`/`kFlat`/`vFlat`. -/
theorem preLoopG (Q K V B0 Out : RegionName) (s : BlockState) (sm_scale : ℝ)
    (stride_qh stride_kh stride_b0h
      BLOCK_M BLOCK_N HEAD P_SEQ BIAS_LAST_SIZE stride_b0m nB : Nat)
    (hundef : ∀ rg o, s.undef rg o = 0) :
    ∃ s0, stepStmts ((mathematical Q K V B0 Out sm_scale
        stride_qh HEAD 1 stride_kh HEAD 1 stride_kh HEAD 1 stride_qh HEAD 1
        stride_b0h stride_b0m 2 4 (BLOCK_N * nB) P_SEQ BIAS_LAST_SIZE 128 HEAD BLOCK_M BLOCK_N
        FloatDType.real).toAlgKernel.body.take 19) s = some s0
      ∧ s0.regs .nat [] "lo" = some (Tile.scalar 0)
      ∧ s0.regs .nat [] "hi" = some (Tile.scalar (BLOCK_N * nB + P_SEQ))
      ∧ attnKernelInvariant s Q K V B0 Out sm_scale
          (s.pids 1 * stride_qh) (s.pids 1 * stride_kh) (s.pids 1 * stride_b0h)
          BLOCK_M BLOCK_N HEAD P_SEQ BIAS_LAST_SIZE stride_b0m 1 HEAD HEAD 1 nB (s.pids 0) 0 s0 := by
  rw [show (mathematical Q K V B0 Out sm_scale
        stride_qh HEAD 1 stride_kh HEAD 1 stride_kh HEAD 1 stride_qh HEAD 1
        stride_b0h stride_b0m 2 4 (BLOCK_N * nB) P_SEQ BIAS_LAST_SIZE 128 HEAD BLOCK_M BLOCK_N
        FloatDType.real).toAlgKernel.body.take 19
      = (mathematical Q K V B0 Out sm_scale
          stride_qh HEAD 1 stride_kh HEAD 1 stride_kh HEAD 1 stride_qh HEAD 1
          stride_b0h stride_b0m 2 4 (BLOCK_N * nB) P_SEQ BIAS_LAST_SIZE 128 HEAD BLOCK_M BLOCK_N
          FloatDType.real).toAlgKernel.body.take 10
        ++ attnPreLoopTailG B0 sm_scale BLOCK_M BLOCK_N HEAD (BLOCK_N * nB) P_SEQ BIAS_LAST_SIZE stride_b0h stride_b0m from by
    conv_lhs => rw [← List.take_append_drop 10
      ((mathematical Q K V B0 Out sm_scale
          stride_qh HEAD 1 stride_kh HEAD 1 stride_kh HEAD 1 stride_qh HEAD 1
          stride_b0h stride_b0m 2 4 (BLOCK_N * nB) P_SEQ BIAS_LAST_SIZE 128 HEAD BLOCK_M BLOCK_N
          FloatDType.real).toAlgKernel.body.take 19)]
    rw [List.take_take, attnPreLoopTailG_check Q K V B0 Out]
    norm_num]
  obtain ⟨s10, hpre, hpids, hstartm, hoffhz, hqoff, hkvoff, hQp, hKp, hVp, hmi, hli, hacc, hundef10, hmem10⟩ :=
    preLoop_prefix Q K V B0 Out sm_scale stride_qh HEAD 1 stride_kh HEAD 1 stride_kh HEAD 1 stride_qh HEAD 1
      stride_b0h stride_b0m 2 4 (BLOCK_N * nB) P_SEQ BIAS_LAST_SIZE 128 HEAD BLOCK_M BLOCK_N FloatDType.real s
  rw [stepStmts.append_some hpre]
  unfold attnPreLoopTailG
  -- T0: qk_scale = sm_scale * 1.44269504
  rw [stepStmts.cons_some (stepStmt_assign_eq_some
    (show evalOp (Op.mul .real Broadcast.nil (Op.const sm_scale) (Op.const 1.44269504)) s10
        = some (Tile.scalar (some (sm_scale * 1.44269504))) from by
      rw [evalOp_mul]; simp only [evalOp_const, Option.bind_eq_bind, Option.bind_some]
      refine congrArg some (congrArg Tile.scalar ?_)
      simp only [NumericDType.mul, WithBot.realMul, Option.map₂, Option.bind, Option.map]))]
  -- T1: q = load Q_block_ptr
  rw [stepStmts.cons_some (stepStmt_assign_eq_some
    (show evalOp (Op.load .real (.blockPtr (Op.ref .blockPtr [BLOCK_M, HEAD] "Q_block_ptr") []) .none .unspecified)
          (s10.setReg "qk_scale" .real [] (Tile.scalar (some (sm_scale * 1.44269504))))
        = some (⟨fun idx : TileIndex [BLOCK_M, HEAD] =>
            some ((s10.setReg "qk_scale" .real [] (Tile.scalar (some (sm_scale * 1.44269504)))).readMem Q
              (s.pids 1 * stride_qh + (s.pids 0 * BLOCK_M + idx.1.val) * HEAD + idx.2.1.val * 1))⟩
            : Tile .real [BLOCK_M, HEAD]) from by
      rw [evalOp_unchecked_block_load]
      exact load_blockPtr_Q_eval Q (s.pids 1 * stride_qh) (BLOCK_N * nB) HEAD BLOCK_M HEAD HEAD 1 (s.pids 0 * BLOCK_M)
        (Op.ref .blockPtr [BLOCK_M, HEAD] "Q_block_ptr") _
        (by rw [evalOp_ref]; rw [show (s10.setReg "qk_scale" .real [] (Tile.scalar (some (sm_scale * 1.44269504)))).regs .blockPtr [BLOCK_M, HEAD] "Q_block_ptr" = s10.regs .blockPtr [BLOCK_M, HEAD] "Q_block_ptr" from by simp [BlockState.setReg_ne_name]]; exact hQp)))]
  -- T2: q = q * qk_scale
  erw [stepStmts.cons_some (stepStmt_assign_eq_some
    (show evalOp ((Op.mul .real Broadcast.scalarR (Op.ref .real [BLOCK_M, HEAD] "q") (Op.ref .real [] "qk_scale"))) _
        = some (⟨fun idx : TileIndex [BLOCK_M, HEAD] =>
            FloatDType.real.cast FloatDType.real
              (some (sm_scale * 1.44269504 * qRaw s Q (s.pids 1 * stride_qh) BLOCK_M HEAD (s.pids 0) idx))⟩ : Tile .real [BLOCK_M, HEAD]) from by
      rw [ak_qscale_op_evalG _ BLOCK_M HEAD
        (⟨fun idx : TileIndex [BLOCK_M, HEAD] =>
          some ((s10.setReg "qk_scale" .real [] (Tile.scalar (some (sm_scale * 1.44269504)))).readMem Q
            (s.pids 1 * stride_qh + (s.pids 0 * BLOCK_M + idx.1.val) * HEAD + idx.2.1.val * 1))⟩ : Tile .real [BLOCK_M, HEAD])
        (sm_scale * 1.44269504)
        (by rw [BlockState.setReg_same])
        (by simp [BlockState.setReg_ne_name, BlockState.setReg_same])]
      refine congrArg some ?_; ext idx
      simp only [Option.bind, Option.map, qRaw]
      have hrm : (s10.setReg "qk_scale" .real [] (Tile.scalar (some (sm_scale * 1.44269504)))).readMem Q
            (s.pids 1 * stride_qh + (s.pids 0 * BLOCK_M + idx.1.val) * HEAD + idx.2.1.val * 1)
          = s.readMem Q (s.pids 1 * stride_qh + (s.pids 0 * BLOCK_M + idx.1.val) * HEAD + idx.2.1.val) := by
        rw [BlockState.setReg_readMem]
        unfold BlockState.readMem; rw [hmem10]; simp only [Nat.mul_one]
      rw [hrm]; ring_nf))]
  -- T3: lo = 0
  rw [stepStmts.cons_some (stepStmt_assign_eq_some (evalOp_constNat 0 _))]
  -- T4: hi = N_CTX + P_SEQ
  rw [stepStmts.cons_some (stepStmt_assign_eq_some (evalOp_constNat (BLOCK_N * nB + P_SEQ) _))]
  -- T5: b_ptr_offsets_m = arange BLOCK_M
  rw [stepStmts.cons_some (stepStmt_assign_eq_some (evalOp_arange BLOCK_M _))]
  -- T6: b_offset = off_hz * stride_b0h
  rw [stepStmts.cons_some (stepStmt_assign_eq_some
    (evalOp_mul_ref_const _ "off_hz" (s.pids 1) stride_b0h
      (by simp [BlockState.setReg_ne_name, hoffhz])))]
  -- T7: b_ptr_offsets_n_1 = (arange % BIAS) + BIAS
  rw [stepStmts.cons_some (stepStmt_assign_eq_some (ak_bn1_op_evalG _ BLOCK_N BIAS_LAST_SIZE))]
  -- T8: b1 = load B0[..]
  rw [stepStmts.cons_some (stepStmt_assign_eq_some
    (load_b1_eval _ B0 BLOCK_M BLOCK_N stride_b0m BIAS_LAST_SIZE (s.pids 0) (s.pids 1 * stride_b0h)
      (by simp [BlockState.setReg_ne_name, BlockState.setReg_same])
      (by simp [BlockState.setReg_ne_name, hstartm])
      (by simp [BlockState.setReg_ne_name, BlockState.setReg_same])
      (by simp [BlockState.setReg_ne_name, BlockState.setReg_same])))]
  rw [stepStmts.nil]
  refine ⟨_, rfl, ?_, ?_, ?_⟩
  · simp [BlockState.setReg_ne_name, BlockState.setReg_same]
  · simp [BlockState.setReg_ne_name, BlockState.setReg_same]
  have hzd : (0:Nat) / BLOCK_N = 0 := Nat.zero_div _
  refine ⟨?_, ?_, ?_, ?_, ?_, ?_, ?_, ?_, ?_, ?_, ?_, ?_, ?_, ?_, ?_, ?_⟩
  · simp only [BlockState.setReg_pids]; exact hpids
  · rw [hzd, Nat.zero_mul]
  · rw [hzd]; omega
  · simp only [BlockState.setReg_ne_name, BlockState.setReg_same, ne_eq, String.reduceEq, not_false_eq_true, reduceCtorEq, and_self, and_true, true_and, hzd]
    rw [hmi]; rfl
  · simp only [BlockState.setReg_ne_name, BlockState.setReg_same, ne_eq, String.reduceEq, not_false_eq_true, reduceCtorEq, and_self, and_true, true_and, hzd]
    rw [hli]; rfl
  · simp only [BlockState.setReg_ne_name, BlockState.setReg_same, ne_eq, String.reduceEq, not_false_eq_true, reduceCtorEq, and_self, and_true, true_and, hzd]
    rw [hacc]; rfl
  · simp only [BlockState.setReg_ne_name, BlockState.setReg_same, ne_eq, String.reduceEq, not_false_eq_true, reduceCtorEq, and_self, and_true, true_and, hzd, Nat.zero_mul, hKp]
  · simp only [BlockState.setReg_ne_name, BlockState.setReg_same, ne_eq, String.reduceEq, not_false_eq_true, reduceCtorEq, and_self, and_true, true_and, hzd, Nat.zero_mul, hVp]
  · simp only [BlockState.setReg_ne_name, BlockState.setReg_same, ne_eq, String.reduceEq,
      not_false_eq_true, reduceCtorEq, and_self, and_true, true_and, FloatDType.toTileDType]
  · rw [BlockState.setReg_same]
    refine congrArg some ?_; ext idx
    simp only [b1Val, BlockState.setReg_readMem]
    unfold BlockState.readMem; rw [hmem10]
  · simp only [BlockState.setReg_ne_name, BlockState.setReg_same, ne_eq, String.reduceEq, not_false_eq_true, reduceCtorEq, and_self, and_true, true_and]
  · simp only [BlockState.setReg_ne_name, BlockState.setReg_same, ne_eq, String.reduceEq, not_false_eq_true, reduceCtorEq, and_self, and_true, true_and]; exact hstartm
  · simp only [BlockState.setReg_ne_name, BlockState.setReg_same, ne_eq, String.reduceEq, not_false_eq_true, reduceCtorEq, and_self, and_true, true_and]; exact hqoff
  · simp only [BlockState.setReg_ne_name, BlockState.setReg_same, ne_eq, String.reduceEq, not_false_eq_true, reduceCtorEq, and_self, and_true, true_and]
  · intro rg o
    show s10.undef rg o = 0
    rw [hundef10]; exact hundef rg o
  · show s10.mem = s.mem
    exact hmem10

set_option maxHeartbeats 1000000 in
/-- **General** `attn_qk_cellG` (dimension-parameterized over `BLOCK_M BLOCK_N HEAD
BIAS_LAST_SIZE stride_b0m`, with `0 < BLOCK_N`). -/
theorem attn_qk_cellG (s0 : BlockState) (Q K B0 : RegionName) (sm_scale : ℝ)
    (BLOCK_M BLOCK_N HEAD BIAS_LAST_SIZE stride_b0m : Nat) (hBN : 0 < BLOCK_N)
    (q_offset kv_offset b_offset : Nat) (nB c bcol : Nat) (hc : c < nB)
    (qtile : Tile .real [BLOCK_M, HEAD]) (ktile : Tile .real [HEAD, BLOCK_N])
    (b1tile : Tile .real [BLOCK_M, BLOCK_N])
    (hbcol : bcol = c)
    (hq : qtile = ⟨fun idx : TileIndex [BLOCK_M, HEAD] =>
        FloatDType.real.cast FloatDType.real
          (some (sm_scale * 1.44269504 * qRaw s0 Q q_offset BLOCK_M HEAD (s0.pids 0) idx))⟩)
    (hk : ∀ idx : TileIndex [HEAD, BLOCK_N],
        ktile.data idx = some (s0.readMem K (kv_offset + idx.1.val * 1 + (c * BLOCK_N + idx.2.1.val) * HEAD)))
    (hb1 : b1tile = ⟨fun idx : TileIndex [BLOCK_M, BLOCK_N] =>
        some (b1Val s0 B0 b_offset BLOCK_M stride_b0m BIAS_LAST_SIZE (s0.pids 0) idx.1 idx.2.1.val)⟩)
    (i : Fin BLOCK_M) (jL : Fin BLOCK_N) :
    (Tile.bop NumericDType.real.add (Broadcast.consSame (Broadcast.consSame Broadcast.nil))
        (Tile.bop NumericDType.real.add (Broadcast.consSame (Broadcast.consSame Broadcast.nil))
          (⟨fun _ : TileIndex [BLOCK_M, BLOCK_N] => FloatDType.real.cast FloatDType.real (FloatDType.real.cast FloatDType.real (some 0))⟩)
          (Tile.dot [] (⟨fun a => FloatDType.real.cast FloatDType.real (qtile.data a)⟩ : Tile .real [BLOCK_M, HEAD]) ktile))
        (Tile.bop NumericDType.real.mul Broadcast.scalarR
          (Tile.bop NumericDType.real.add (Broadcast.consSame (Broadcast.consL Broadcast.nil))
            (⟨fun idx : TileIndex [BLOCK_M, 1] =>
              some (s0.readMem B0 (b_offset + (s0.pids 0 * BLOCK_M + idx.1.val) * stride_b0m + bcol))⟩)
            b1tile)
          (Tile.scalar (some 1.44269504)))).data (i, jL, PUnit.unit)
      = some (fscore s0 Q K B0 sm_scale q_offset kv_offset b_offset
          BLOCK_M BLOCK_N HEAD (BLOCK_N * nB) BIAS_LAST_SIZE stride_b0m (s0.pids 0) i (gkey BLOCK_N nB c hc jL)) := by
  have hdot : (Tile.dot [] (⟨fun a => FloatDType.real.cast FloatDType.real (qtile.data a)⟩ : Tile .real [BLOCK_M, HEAD]) ktile).data (i, jL, PUnit.unit)
      = some (sm_scale * 1.44269504 * Finset.univ.sum (fun e : Fin HEAD =>
          qRaw s0 Q q_offset BLOCK_M HEAD (s0.pids 0) (i, e, PUnit.unit)
            * kFlat s0 K kv_offset HEAD (BLOCK_N * nB) e (gkey BLOCK_N nB c hc jL))) := by
    rw [Tile.dot_nil_data]
    rw [show (@Finset.sum (Fin HEAD) (WithBot ℝ) _ Finset.univ
          (fun e => Option.map₂ (· * ·)
            ((⟨fun a => FloatDType.real.cast FloatDType.real (qtile.data a)⟩ : Tile .real [BLOCK_M, HEAD]).data (i, e, PUnit.unit))
            (ktile.data (e, jL, PUnit.unit))))
        = @Finset.sum (Fin HEAD) (WithBot ℝ) _ Finset.univ
          (fun e => (some (sm_scale * 1.44269504 * (qRaw s0 Q q_offset BLOCK_M HEAD (s0.pids 0) (i, e, PUnit.unit)
              * kFlat s0 K kv_offset HEAD (BLOCK_N * nB) e (gkey BLOCK_N nB c hc jL))) : WithBot ℝ))
        from Finset.sum_congr rfl (fun e _ => by
          simp only [hq, FloatDType.cast, FloatDType.ofWithBot, FloatDType.toWithBot,
            FloatDType.real_toWithBot, Option.map₂]
          rw [hk (e, jL, PUnit.unit)]
          simp only [Option.bind, Option.map]
          refine congrArg some ?_
          simp only [qRaw, kFlat, gkey]
          rw [show kv_offset + e.val * 1 + (c * BLOCK_N + jL.val) * HEAD
                = kv_offset + e.val + (c * BLOCK_N + jL.val) * HEAD from by ring]
          ring)]
    rw [withBot_sum_some]
    refine congrArg some ?_
    rw [Finset.mul_sum]
  simp only [Tile.bop_data, Broadcast.leftIndex, Broadcast.rightIndex, Tile.scalar,
    NumericDType.add, NumericDType.mul, hb1, hdot, b1Val, b0Val]
  simp only [FloatDType.cast, FloatDType.ofWithBot, FloatDType.toWithBot,
    WithBot.realAdd, WithBot.realMul, Option.map₂, Option.bind, Option.map]
  refine congrArg some ?_
  simp only [fscore, qRaw, kFlat, b0Val, b1Val, gkey, hbcol]
  have hjLlt := jL.isLt
  rw [show (c * BLOCK_N + jL.val) / BLOCK_N = c from by
    rw [Nat.mul_comm c BLOCK_N, Nat.mul_add_div hBN, Nat.div_eq_of_lt jL.isLt]
    omega]
  rw [show (c * BLOCK_N + jL.val) % BLOCK_N = jL.val from by
    rw [Nat.mul_comm c BLOCK_N, Nat.mul_add_mod, Nat.mod_eq_of_lt jL.isLt]]
  ring

set_option maxHeartbeats 1600000 in
set_option maxRecDepth 8000 in
/-- **General** `attn_stepG` (dimension-parameterized). Advances the invariant by
one key block of `BLOCK_N` keys. Contiguous K/V layout (`stride_kk=1,
stride_kn=HEAD, stride_vk=HEAD, stride_vn=1`) per `kFlat`/`vFlat`. -/
theorem attn_stepG (Q K V B0 Out : RegionName) (s0 : BlockState) (sm_scale : ℝ)
    (BLOCK_M BLOCK_N HEAD P_SEQ BIAS_LAST_SIZE stride_b0m : Nat) (hBN : 0 < BLOCK_N)
    (q_offset kv_offset b_offset : Nat)
    (nB : Nat) (i : Nat) (s : BlockState) (hilt : i < BLOCK_N * nB)
    (hinv : attnKernelInvariant s0 Q K V B0 Out sm_scale
        q_offset kv_offset b_offset
        BLOCK_M BLOCK_N HEAD P_SEQ BIAS_LAST_SIZE stride_b0m 1 HEAD HEAD 1 nB (s0.pids 0) i s) :
    ∃ s', stepStmts (attnLoopBodyG B0 BLOCK_M BLOCK_N HEAD stride_b0m) (s.setReg "start_n" .nat [] (Tile.scalar i)) = some s'
      ∧ attnKernelInvariant s0 Q K V B0 Out sm_scale
          q_offset kv_offset b_offset
          BLOCK_M BLOCK_N HEAD P_SEQ BIAS_LAST_SIZE stride_b0m 1 HEAD HEAD 1 nB (s0.pids 0) (i + BLOCK_N) s' := by
  have hc : i / BLOCK_N < nB := (Nat.div_lt_iff_lt_mul hBN).mpr (by rw [Nat.mul_comm]; exact hilt)
  have hc1 : (i + BLOCK_N) / BLOCK_N = i / BLOCK_N + 1 := Nat.add_div_right i hBN
  simp only [attnKernelInvariant] at hinv
  obtain ⟨hpids, hieq, hcle, hmi, hli, hacc, hKp, hVp, hq, hb1, hbo, hsm, hqo, hm, hundef, hmem⟩ := hinv
  set sc := fscore s0 Q K B0 sm_scale q_offset kv_offset b_offset
    BLOCK_M BLOCK_N HEAD (BLOCK_N * nB) BIAS_LAST_SIZE stride_b0m (s0.pids 0) with hscdef
  set V' := vFlat s0 V kv_offset HEAD (BLOCK_N * nB) with hVpdef
  have hrmem : ∀ (R : RegionName) (o : Nat),
      (s.setReg "start_n" .nat [] (Tile.scalar i)).readMem R o = s0.readMem R o := by
    intro R o; simp only [BlockState.setReg_readMem]; unfold BlockState.readMem; rw [hmem]
  have hmi' : (s.setReg "start_n" .nat [] (Tile.scalar i)).regs .real [BLOCK_M] "m_i"
      = some (⟨fun r : TileIndex [BLOCK_M] => mPg BLOCK_N nB sc r.1 (i / BLOCK_N)⟩) := by
    rw [BlockState.setReg_ne_name _ _ _ _ _ _ _ _ (by decide)]; exact hmi
  have hli' : (s.setReg "start_n" .nat [] (Tile.scalar i)).regs .real [BLOCK_M] "l_i"
      = some (⟨fun r : TileIndex [BLOCK_M] => ((lPgK sc r.1 (i / BLOCK_N) : ℝ) : WithBot ℝ)⟩) := by
    rw [BlockState.setReg_ne_name _ _ _ _ _ _ _ _ (by decide)]; exact hli
  have hacc' : (s.setReg "start_n" .nat [] (Tile.scalar i)).regs .real [BLOCK_M, HEAD] "acc"
      = some (⟨fun idx : TileIndex [BLOCK_M, HEAD] => ((oPg sc V' idx.1 idx.2.1 (i / BLOCK_N) : ℝ) : WithBot ℝ)⟩) := by
    rw [BlockState.setReg_ne_name _ _ _ _ _ _ _ _ (by decide)]; exact hacc
  have hKp' : (s.setReg "start_n" .nat [] (Tile.scalar i)).regs .blockPtr [HEAD, BLOCK_N] "K_block_ptr"
      = some (⟨fun _ : TileIndex [HEAD, BLOCK_N] =>
        { region := K, baseOffset := kv_offset, parentShape := [HEAD, BLOCK_N * nB + P_SEQ],
          blockShape := [HEAD, BLOCK_N], strides := [1, HEAD], offsets := [0, i / BLOCK_N * BLOCK_N] }⟩) := by
    rw [BlockState.setReg_ne_name _ _ _ _ _ _ _ _ (by decide), hKp]
  have hVp' : (s.setReg "start_n" .nat [] (Tile.scalar i)).regs .blockPtr [BLOCK_N, HEAD] "V_block_ptr"
      = some (⟨fun _ : TileIndex [BLOCK_N, HEAD] =>
        { region := V, baseOffset := kv_offset, parentShape := [BLOCK_N * nB + P_SEQ, HEAD],
          blockShape := [BLOCK_N, HEAD], strides := [HEAD, 1], offsets := [i / BLOCK_N * BLOCK_N, 0] }⟩) := by
    rw [BlockState.setReg_ne_name _ _ _ _ _ _ _ _ (by decide), hVp]
  have hq' : (s.setReg "start_n" .nat [] (Tile.scalar i)).regs .real [BLOCK_M, HEAD] "q"
      = some (⟨fun idx : TileIndex [BLOCK_M, HEAD] =>
        FloatDType.real.cast FloatDType.real
          (some (sm_scale * 1.44269504 * qRaw s0 Q q_offset BLOCK_M HEAD (s0.pids 0) idx))⟩) := by
    rw [BlockState.setReg_ne_name _ _ _ _ _ _ _ _ (by decide)]; exact hq
  have hb1' : (s.setReg "start_n" .nat [] (Tile.scalar i)).regs .real [BLOCK_M, BLOCK_N] "b1"
      = some (⟨fun idx : TileIndex [BLOCK_M, BLOCK_N] =>
        some (b1Val s0 B0 b_offset BLOCK_M stride_b0m BIAS_LAST_SIZE (s0.pids 0) idx.1 idx.2.1.val)⟩) := by
    rw [BlockState.setReg_ne_name _ _ _ _ _ _ _ _ (by decide)]; exact hb1
  obtain ⟨sF, hchain, hpidsF, hmemF, hundefF, hqF, hb1F, hboF, hsmF, hqoF, hmF, hKpF, hVpF,
      qkT, rmaxT, mnewT, alphaT, pT, hqkData, hrm, hmnewd, halphad, hpTd, hm_iF, haccF, hl_iF⟩ :=
    attnLoopBody_stepsG B0 BLOCK_M BLOCK_N HEAD stride_b0m hBN (s.setReg "start_n" .nat [] (Tile.scalar i)) i
      K V kv_offset kv_offset (i / BLOCK_N * BLOCK_N) (i / BLOCK_N * BLOCK_N) (BLOCK_N * nB + P_SEQ) (BLOCK_N * nB + P_SEQ)
      b_offset (s0.pids 0)
      (⟨fun idx : TileIndex [BLOCK_M, HEAD] =>
        FloatDType.real.cast FloatDType.real
          (some (sm_scale * 1.44269504 * qRaw s0 Q q_offset BLOCK_M HEAD (s0.pids 0) idx))⟩)
      (⟨fun r : TileIndex [BLOCK_M] => mPg BLOCK_N nB sc r.1 (i / BLOCK_N)⟩)
      (⟨fun r : TileIndex [BLOCK_M] => ((lPgK sc r.1 (i / BLOCK_N) : ℝ) : WithBot ℝ)⟩)
      (⟨fun idx : TileIndex [BLOCK_M, HEAD] => ((oPg sc V' idx.1 idx.2.1 (i / BLOCK_N) : ℝ) : WithBot ℝ)⟩)
      (⟨fun idx : TileIndex [HEAD, BLOCK_N] =>
        some (s0.readMem K (kv_offset + idx.1.val * 1 + (i / BLOCK_N * BLOCK_N + idx.2.1.val) * HEAD))⟩)
      (⟨fun idx : TileIndex [BLOCK_N, HEAD] =>
        some (s0.readMem V (kv_offset + (i / BLOCK_N * BLOCK_N + idx.1.val) * HEAD + idx.2.1.val * 1))⟩)
      (⟨fun idx : TileIndex [BLOCK_M, BLOCK_N] =>
        some (b1Val s0 B0 b_offset BLOCK_M stride_b0m BIAS_LAST_SIZE (s0.pids 0) idx.1 idx.2.1.val)⟩)
      (by rw [BlockState.setReg_same])
      (by rw [BlockState.setReg_ne_name _ _ _ _ _ _ _ _ (by decide)]; exact hbo)
      (by rw [BlockState.setReg_ne_name _ _ _ _ _ _ _ _ (by decide)]; exact hsm)
      (by rw [BlockState.setReg_ne_name _ _ _ _ _ _ _ _ (by decide)]; exact hm)
      hmi' hli' hacc' hq' hb1' hKp' hVp'
      (fun idx => congrArg some (hrmem K _).symm) (fun idx => congrArg some (hrmem V _).symm)
      q_offset (by rw [BlockState.setReg_ne_name _ _ _ _ _ _ _ _ (by decide)]; exact hqo)
      (by intro rg o; simp [BlockState.setReg_undef, hundef])
  refine ⟨sF, hchain, ?_⟩
  have hqk : ∀ (r : Fin BLOCK_M) (jL : Fin BLOCK_N),
      qkT.data (r, jL, PUnit.unit) = some (sc r (gkey BLOCK_N nB (i / BLOCK_N) hc jL)) := by
    intro r jL
    rw [hqkData r jL]
    have := attn_qk_cellG s0 Q K B0 sm_scale BLOCK_M BLOCK_N HEAD BIAS_LAST_SIZE stride_b0m hBN
      q_offset kv_offset b_offset
      nB (i / BLOCK_N) (i / BLOCK_N) hc
      (⟨fun idx : TileIndex [BLOCK_M, HEAD] =>
        FloatDType.real.cast FloatDType.real
          (some (sm_scale * 1.44269504 * qRaw s0 Q q_offset BLOCK_M HEAD (s0.pids 0) idx))⟩)
      (⟨fun idx : TileIndex [HEAD, BLOCK_N] =>
        some (s0.readMem K (kv_offset + idx.1.val * 1 + (i / BLOCK_N * BLOCK_N + idx.2.1.val) * HEAD))⟩)
      (⟨fun idx : TileIndex [BLOCK_M, BLOCK_N] =>
        some (b1Val s0 B0 b_offset BLOCK_M stride_b0m BIAS_LAST_SIZE (s0.pids 0) idx.1 idx.2.1.val)⟩)
      rfl rfl (fun idx => rfl) rfl r jL
    simp only [hscdef]
    simp only [hrmem] at this ⊢
    exact this
  have hmij_eq : ∀ idx : TileIndex [BLOCK_M], mnewT.data idx
      = mPg BLOCK_N nB sc idx.1 (i / BLOCK_N + 1) := by
    intro idx
    rw [hmnewd]
    refine mijg_eq BLOCK_N nB (i / BLOCK_N) hc sc _ rmaxT idx.1 ?_ ?_
    · rfl
    · exact reduceMaxDrop_data_row BLOCK_M BLOCK_N hBN _ rmaxT hrm idx.1 _ (fun jL => hqk idx.1 jL)
  simp only [attnKernelInvariant]
  refine ⟨?_, ?_, ?_, ?_, ?_, ?_, ?_, ?_, ?_, ?_, ?_, ?_, ?_, ?_, ?_, ?_⟩
  · rw [hpidsF]; exact hpids
  · rw [hc1, Nat.add_one_mul, ← hieq]
  · rw [hc1]; omega
  · rw [hm_iF, hc1]; refine congrArg some ?_; ext idx; exact hmij_eq idx
  · rw [hl_iF, hc1]; refine congrArg some ?_; ext idx
    rw [halphad, hpTd]
    exact lig_eq BLOCK_N nB (i / BLOCK_N) hBN hc sc _ mnewT _ qkT idx.1 rfl (hmij_eq idx) rfl (fun jL => hqk idx.1 jL)
  · rw [haccF, hc1]; refine congrArg some ?_
    ext idx
    have hv : ∀ jL : Fin BLOCK_N,
        (⟨fun idx : TileIndex [BLOCK_N, HEAD] =>
          some (s0.readMem V (kv_offset + (i / BLOCK_N * BLOCK_N + idx.1.val) * HEAD + idx.2.1.val * 1))⟩
          : Tile .real [BLOCK_N, HEAD]).data (jL, idx.2.1, PUnit.unit)
          = some (V' (gkey BLOCK_N nB (i / BLOCK_N) hc jL, idx.2.1, PUnit.unit)) := by
      intro jL
      refine congrArg some ?_
      simp only [hVpdef, vFlat, gkey]
      rw [show kv_offset + (i / BLOCK_N * BLOCK_N + jL.val) * HEAD + idx.2.1.val * 1
            = kv_offset + (i / BLOCK_N * BLOCK_N + jL.val) * HEAD + idx.2.1.val from by ring]
    refine accg_eq BLOCK_N nB (i / BLOCK_N) hc sc V' _ alphaT pT _ idx.1 idx.2.1 rfl ?_ ?_ hv
    · rw [halphad]
      exact alphag_eq BLOCK_N nB (i / BLOCK_N) sc _ mnewT idx.1 rfl (hmij_eq (idx.1, PUnit.unit))
    · intro jL
      rw [hpTd]
      refine exp2_some (fun a b => sc a (gkey BLOCK_N nB (i / BLOCK_N) hc b) - mRg sc a (i / BLOCK_N + 1)) _ idx.1 jL ?_
      simp only [Tile.bop_data, Broadcast.leftIndex, Broadcast.rightIndex, Tile.expandDim_data,
        TileShape.dropInsertedIndex, TileShape.insertAxisIndex, hqk idx.1 jL,
        hmij_eq (idx.1, PUnit.unit),
        mPg_eq_coe sc hBN idx.1 (i / BLOCK_N + 1) (Nat.le_add_left 1 (i / BLOCK_N)) hc,
        NumericDType.sub, WithBot.realSub, Option.map₂, Option.bind, Option.map]
  · rw [hKpF, hc1, show i / BLOCK_N * BLOCK_N + BLOCK_N = (i / BLOCK_N + 1) * BLOCK_N from by ring]
  · rw [hVpF, hc1, show i / BLOCK_N * BLOCK_N + BLOCK_N = (i / BLOCK_N + 1) * BLOCK_N from by ring]
  · rw [hqF]
  · rw [hb1F]
  · rw [hboF]
  · rw [hsmF]
  · rw [hqoF]
  · rw [hmF]
  · exact hundefF
  · rw [hmemF]; exact hmem

/-! ### M3 — `attn_postLoopG`: `acc /= l_i` + block store = `attentionKernelSpec`

After the streaming loop (invariant at `c = nB`), the `acc /= l_i[:, None]` rescale
and the (unmasked) block-pointer store write the normalized accumulator
`oPg / lPgK = oPg / lPg = attentionKernelSpec` to `Out` at every lane. The store is a
scatter over an injective block-pointer offset map (`row·128 + col` injective since
`col < 128`); `lPgK_eq_lPg` kills the kernel's `l_i = 0` seed (`1 ≤ nB`), and
`attentionKernelSpec_eq_ratio` reads off the closed form. -/

/-- A real `writeMemTyped` foldl over offsets all `≠ o` preserves `mem … o`. -/
theorem foldl_writeMemTyped_real_preserves' {α : Type} {region : RegionName}
    (offsetFn : α → Nat) (valueFn : α → TileCarrier TileDType.real) (o : Nat) (l : List α) :
    ∀ (s : BlockState), (∀ k ∈ l, offsetFn k ≠ o) →
      ((l.foldl (fun acc k => acc.writeMemTyped .real region (offsetFn k) (valueFn k)) s).mem region o)
      = s.mem region o := by
  induction l with
  | nil => intros; rfl
  | cons hd tl ih =>
    intro s h
    have hhd : offsetFn hd ≠ o := h hd (List.mem_cons_self)
    have htl : ∀ k ∈ tl, offsetFn k ≠ o := fun k hk => h k (List.mem_cons_of_mem hd hk)
    rw [List.foldl_cons, ih _ htl]
    unfold BlockState.writeMemTyped BlockState.writeMemAs
    change (if region = region ∧ o = offsetFn hd then _ else s.mem region o) = s.mem region o
    rw [if_neg]; rintro ⟨_, h_eq⟩; exact hhd h_eq.symm

/-- Real block-store readback: an injective real scatter reads back its stored
cell as the real `MemCell`. (Local mirror of the flash O-store readback.) -/
theorem scatter_memcell_real_nd' {region : RegionName} {shape : TileShape}
    (s : BlockState) (offsetFn : TileIndex shape → Nat)
    (valueFn : TileIndex shape → TileCarrier TileDType.real)
    (h_inj : Function.Injective offsetFn) (i : TileIndex shape) :
    ((TileShape.allIndices shape).foldl
       (fun acc k => acc.writeMemTyped .real region (offsetFn k) (valueFn k))
       s).mem region (offsetFn i)
    = MemCell.of .real
        (FloatDType.real.ofReal (FloatDType.real.storeValue (valueFn i))) := by
  let l := TileShape.allIndices shape
  obtain ⟨l₁, l₂, hl⟩ := List.append_of_mem (TileShape.mem_allIndices shape i)
  have h_nodup := TileShape.allIndices_nodup shape
  change ((l.foldl
       (fun acc k => acc.writeMemTyped .real region (offsetFn k) (valueFn k))
       s).mem region (offsetFn i))
    = MemCell.of .real
        (FloatDType.real.ofReal (FloatDType.real.storeValue (valueFn i)))
  rw [hl] at h_nodup
  rw [List.nodup_append, List.nodup_cons] at h_nodup
  obtain ⟨_, ⟨hi_notin_l2, _⟩, _⟩ := h_nodup
  have hl' : l = l₁ ++ i :: l₂ := by simpa [l] using hl
  rw [hl', List.foldl_append, List.foldl_cons]
  have h_l2_not_in : ∀ k ∈ l₂, offsetFn k ≠ offsetFn i := by
    intro k hk heq; have hki : k = i := h_inj heq; subst hki; exact hi_notin_l2 hk
  rw [foldl_writeMemTyped_real_preserves' offsetFn valueFn (offsetFn i) l₂ _ h_l2_not_in]
  unfold BlockState.writeMemTyped BlockState.writeMemAs
  change
    (if region = region ∧ offsetFn i = offsetFn i then
      MemCell.of .real (FloatDType.real.ofReal (FloatDType.real.storeValue (valueFn i)))
    else _) = _
  rw [if_pos ⟨rfl, rfl⟩]

set_option maxHeartbeats 1000000 in
/-- **General** `attn_postLoopG` (dimension-parameterized). The `acc /= l_i` rescale
and block store write the closed form `attentionKernelSpec` to `Out` at every lane.
Contiguous Out layout (`stride_om=HEAD, stride_on=1`). -/
theorem attn_postLoopG (Q K V B0 Out : RegionName) (s0 : BlockState) (sm_scale : ℝ)
    (BLOCK_M BLOCK_N HEAD P_SEQ BIAS_LAST_SIZE stride_b0m q_offset kv_offset b_offset : Nat)
    (hBN : 0 < BLOCK_M) (hKN : 0 < BLOCK_N) (hHD : 0 < HEAD)
    (nB : Nat) (hnB : 1 ≤ nB) (st : BlockState)
    (hinv : attnKernelInvariant s0 Q K V B0 Out sm_scale
        q_offset kv_offset b_offset
        BLOCK_M BLOCK_N HEAD P_SEQ BIAS_LAST_SIZE stride_b0m 1 HEAD HEAD 1 nB (s0.pids 0) (BLOCK_N * nB) st) :
    ∃ sfin, stepStmts (attnPostLoopG Out BLOCK_M HEAD (BLOCK_N * nB) HEAD 1) st = some sfin
      ∧ ∀ idx : TileIndex [BLOCK_M, HEAD],
          sfin.mem Out (q_offset + (s0.pids 0 * BLOCK_M + idx.1.val) * HEAD + idx.2.1.val * 1)
            = MemCell.of .real (FloatDType.real.cast FloatDType.real
                (some (attentionKernelSpec s0 Q K V B0 sm_scale
                  q_offset kv_offset b_offset
                  BLOCK_M BLOCK_N HEAD (BLOCK_N * nB) BIAS_LAST_SIZE stride_b0m (s0.pids 0) idx))) := by
  have hcnB : (BLOCK_N * nB) / BLOCK_N = nB := by rw [Nat.mul_comm, Nat.mul_div_cancel _ hKN]
  have hieqcn : BLOCK_N * nB = BLOCK_N * nB / BLOCK_N * BLOCK_N := by rw [hcnB, Nat.mul_comm]
  simp only [attnKernelInvariant, hcnB] at hinv
  obtain ⟨hpids, hieq, hcle, hmi, hli, hacc, hKp, hVp, hq, hb1, hbo, hsm, hqo, hm, hundef, hmem⟩ := hinv
  set sc := fscore s0 Q K B0 sm_scale q_offset kv_offset b_offset
    BLOCK_M BLOCK_N HEAD (BLOCK_N * nB) BIAS_LAST_SIZE stride_b0m (s0.pids 0) with hscdef
  set V' := vFlat s0 V kv_offset HEAD (BLOCK_N * nB) with hVpdef
  set acc' : Tile .real [BLOCK_M, HEAD] :=
    ⟨fun idx : TileIndex [BLOCK_M, HEAD] => ((oPg sc V' idx.1 idx.2.1 nB / lPgK sc idx.1 nB : ℝ) : WithBot ℝ)⟩
    with hacc'def
  unfold attnPostLoopG
  rw [stepStmts.cons_some (stepStmt_assign_eq_some
    (show evalOp (Op.div .real (Broadcast.consSame (Broadcast.consR Broadcast.nil))
        (Op.ref .real [BLOCK_M, HEAD] "acc")
        (Op.expandDim ⟨1, by simp⟩ (Op.ref .real [BLOCK_M] "l_i"))) st = some acc' from by
      have hexp : @evalOp TileDType.real [BLOCK_M, 1]
            (Op.expandDim ⟨1, by simp⟩ (Op.ref .real [BLOCK_M] "l_i")) st
          = some (Tile.expandDim ⟨1, by simp⟩
              (⟨fun r : TileIndex [BLOCK_M] => ((lPgK sc r.1 nB : ℝ) : WithBot ℝ)⟩ : Tile .real [BLOCK_M])) :=
        evalOp_expandDim_ref_of_regs _ _ _ _ _ _ hli
      rw [evalOp_div]
      simp only [evalOp_ref, hacc, hexp, Option.bind_eq_bind, Option.bind_some]
      refine congrArg some ?_; ext idx
      simp only [Tile.bop_data, Tile.expandDim_data, TileShape.dropInsertedIndex,
        Broadcast.leftIndex, Broadcast.rightIndex, NumericDType.div, WithBot.realDiv,
        Option.map₂, Option.bind, Option.map, hacc'def]
      rfl))]
  set st1 := st.setReg "acc" .real [BLOCK_M, HEAD] acc' with hst1
  rw [stepStmts.cons_some (stepStmt_assign_eq_some
    (makeBlockPtr_rowcol_eval Out (Op.ref .nat [] "q_offset") [BLOCK_N * nB, HEAD] [BLOCK_M, HEAD] [HEAD, 1]
      (Op.mul .nat Broadcast.nil (Op.ref .nat [] "start_m") (Op.constNat BLOCK_M)) st1
      q_offset (s0.pids 0 * BLOCK_M)
      (by rw [evalOp_ref]; simp only [hst1, BlockState.setReg_ne_name]; exact hqo)
      (evalOp_mul_ref_const st1 "start_m" (s0.pids 0) BLOCK_M
        (by simp only [hst1, BlockState.setReg_ne_name]; exact hsm))))]
  set st2 := st1.setReg "O_block_ptr" .blockPtr [BLOCK_M, HEAD]
      ⟨fun _ : TileIndex [BLOCK_M, HEAD] =>
        { region := Out, baseOffset := q_offset, parentShape := [BLOCK_N * nB, HEAD],
          blockShape := [BLOCK_M, HEAD], strides := [HEAD, 1], offsets := [s0.pids 0 * BLOCK_M, 0] }⟩
    with hst2
  set oValFn : TileIndex [BLOCK_M, HEAD] → TileCarrier TileDType.real :=
    fun idx => FloatDType.real.cast FloatDType.real
      (some (oPg sc V' idx.1 idx.2.1 nB / lPgK sc idx.1 nB)) with hoValFn
  set oOffFn : TileIndex [BLOCK_M, HEAD] → Nat :=
    fun idx => q_offset + (s0.pids 0 * BLOCK_M + idx.1.val) * HEAD + idx.2.1.val * 1 with hoOffFn
  have hOpref : @evalOp TileDType.blockPtr [BLOCK_M, HEAD] (Op.ref .blockPtr [BLOCK_M, HEAD] "O_block_ptr") st2
      = some (⟨fun _ : TileIndex [BLOCK_M, HEAD] =>
          { region := Out, baseOffset := q_offset, parentShape := [BLOCK_N * nB, HEAD],
            blockShape := [BLOCK_M, HEAD], strides := [HEAD, 1], offsets := [s0.pids 0 * BLOCK_M, 0] }⟩
          : Tile .blockPtr [BLOCK_M, HEAD]) := by rw [evalOp_ref, hst2, BlockState.setReg_same]
  have haccref : @evalOp TileDType.real [BLOCK_M, HEAD] (Op.ref .real [BLOCK_M, HEAD] "acc") st2 = some acc' := by
    rw [evalOp_ref, hst2, BlockState.setReg_ne_name _ _ _ _ _ _ _ _ (by decide), hst1,
      BlockState.setReg_same]
  have hval : evalOp ((Op.ref .real [BLOCK_M, HEAD] "acc")) st2
        = some (⟨oValFn⟩ : Tile .real [BLOCK_M, HEAD]) := by
    erw [haccref]; rfl
  have hstore : stepStmt (Stmt.store .real [BLOCK_M, HEAD]
      (MemAccess.blockPtr (Op.ref .blockPtr [BLOCK_M, HEAD] "O_block_ptr") [])
      ((Op.ref .real [BLOCK_M, HEAD] "acc")) MaskOpt.none) st2
      = some ((TileShape.allIndices [BLOCK_M, HEAD]).foldl
          (fun acc idx => acc.writeMemTyped .real Out (oOffFn idx) (oValFn idx)) st2) := by
    unfold stepStmt
    erw [hval]
    simp only [Option.bind_eq_bind, Option.bind_some, Option.map_some]
    erw [hOpref]
    simp only [Option.bind_eq_bind, Option.bind_some, Option.map_some]
    refine congrArg some ?_
    refine List.foldl_ext _ _ st2 ?_
    intro acc idx _
    simp only [TileShape.blockPtr_inBounds_nil_index, Bool.and_true, Bool.true_and,
      TileShape.blockPtr_address_2d_row_offset_index, hoOffFn, if_true]
  rw [stepStmts.cons_some hstore, stepStmts.nil]
  refine ⟨_, rfl, ?_⟩
  intro idx
  have hinjO : Function.Injective oOffFn := by
    rintro ⟨⟨a, ha⟩, ⟨b, hb⟩, _⟩ ⟨⟨c, hc⟩, ⟨d, hd⟩, _⟩ heq
    simp only [hoOffFn] at heq
    have hbHD : b < HEAD := hb
    have hdHD : d < HEAD := hd
    set P := s0.pids 0 * BLOCK_M with hP
    have heq2 : (P + a) * HEAD + b = (P + c) * HEAD + d := by
      have : q_offset + (P + a) * HEAD + b * 1 = q_offset + (P + c) * HEAD + d * 1 := heq
      omega
    have hbd : b = d := by
      have e1 : ((P + a) * HEAD + b) % HEAD = b := by
        rw [Nat.mul_add_mod', Nat.mod_eq_of_lt hbHD]
      have e2 : ((P + c) * HEAD + d) % HEAD = d := by
        rw [Nat.mul_add_mod', Nat.mod_eq_of_lt hdHD]
      rw [← e1, ← e2, heq2]
    subst hbd
    have hac : a = c := by
      have hmm : (P + a) * HEAD = (P + c) * HEAD := by omega
      have := Nat.eq_of_mul_eq_mul_right hHD hmm
      omega
    simp only [hoOffFn, hac]
  rw [show q_offset + (s0.pids 0 * BLOCK_M + idx.1.val) * HEAD + idx.2.1.val * 1 = oOffFn idx from rfl]
  rw [scatter_memcell_real_nd' (region := Out) st2 oOffFn oValFn hinjO idx]
  refine congrArg (MemCell.of .real) ?_
  rw [hoValFn]
  simp only [FloatDType.cast, FloatDType.ofReal, FloatDType.storeValue, FloatDType.ofWithBot,
    FloatDType.toWithBot, WithBot.unbotD_coe]
  refine congrArg (FloatDType.real.cast FloatDType.real) ?_
  refine congrArg some ?_
  rw [lPgK_eq_lPg sc idx.1 nB hnB le_rfl]
  exact attentionKernelSpec_eq_ratio s0 Q K V B0 sm_scale
    q_offset kv_offset b_offset
    BLOCK_M BLOCK_N HEAD BIAS_LAST_SIZE stride_b0m nB (s0.pids 0) hKN hnB idx.1 idx.2.1

set_option maxHeartbeats 1000000 in
/-- **General** whole-kernel exec assembly (dimension-parameterized). Steps the
entire faithful surface and reads off the genuine closed form at every `Out` lane.
The loop runs exactly `nB = numKVBlocks` blocks (`N_CTX = BLOCK_N·nB`, `P_SEQ = 0`),
with contiguous Q/K/V/Out layout. -/
theorem attention_kernel_exec_general (Q K V B0 Out : RegionName) (s : BlockState) (sm_scale : ℝ)
    (stride_qh stride_kh stride_b0h BLOCK_M BLOCK_N HEAD BIAS_LAST_SIZE stride_b0m nB : Nat)
    (hKN : 0 < BLOCK_N) (hBM : 0 < BLOCK_M) (hHD : 0 < HEAD) (hnB : 1 ≤ nB)
    (hundef : ∀ rg o, s.undef rg o = 0) :
    ∃ sF, stepStmts (mathematical Q K V B0 Out sm_scale
        stride_qh HEAD 1 stride_kh HEAD 1 stride_kh HEAD 1 stride_qh HEAD 1
        stride_b0h stride_b0m 2 4 (BLOCK_N * nB) 0 BIAS_LAST_SIZE 128 HEAD BLOCK_M BLOCK_N
        FloatDType.real).toAlgKernel.body s = some sF
      ∧ ∀ idx : TileIndex [BLOCK_M, HEAD],
          sF.mem Out (s.pids 1 * stride_qh + (s.pids 0 * BLOCK_M + idx.1.val) * HEAD + idx.2.1.val * 1)
            = MemCell.of .real (FloatDType.real.cast FloatDType.real
                (some (attentionKernelSpec s Q K V B0 sm_scale
                  (s.pids 1 * stride_qh) (s.pids 1 * stride_kh) (s.pids 1 * stride_b0h)
                  BLOCK_M BLOCK_N HEAD (BLOCK_N * nB) BIAS_LAST_SIZE stride_b0m (s.pids 0) idx))) := by
  rw [← List.take_append_drop 19 (mathematical Q K V B0 Out sm_scale
        stride_qh HEAD 1 stride_kh HEAD 1 stride_kh HEAD 1 stride_qh HEAD 1
        stride_b0h stride_b0m 2 4 (BLOCK_N * nB) 0 BIAS_LAST_SIZE 128 HEAD BLOCK_M BLOCK_N
        FloatDType.real).toAlgKernel.body]
  obtain ⟨s0, hpre, hlo, hhi, hinv0⟩ := preLoopG Q K V B0 Out s sm_scale
    stride_qh stride_kh stride_b0h BLOCK_M BLOCK_N HEAD 0 BIAS_LAST_SIZE stride_b0m nB hundef
  rw [stepStmts.append_some hpre]
  rw [attnLoopBodyG_check Q K V B0 Out sm_scale
        stride_qh HEAD 1 stride_kh HEAD 1 stride_kh HEAD 1 stride_qh HEAD 1
        stride_b0h stride_b0m 2 4 (BLOCK_N * nB) 0 BIAS_LAST_SIZE 128 HEAD BLOCK_M BLOCK_N,
    show (mathematical Q K V B0 Out sm_scale
        stride_qh HEAD 1 stride_kh HEAD 1 stride_kh HEAD 1 stride_qh HEAD 1
        stride_b0h stride_b0m 2 4 (BLOCK_N * nB) 0 BIAS_LAST_SIZE 128 HEAD BLOCK_M BLOCK_N
        FloatDType.real).toAlgKernel.body.drop 20
      = attnPostLoopG Out BLOCK_M HEAD (BLOCK_N * nB) HEAD 1 from by
      have := attnPostLoopG_check Q K V B0 Out sm_scale
        stride_qh HEAD 1 stride_kh HEAD 1 stride_kh HEAD 1 stride_qh HEAD 1
        stride_b0h stride_b0m 2 4 (BLOCK_N * nB) 0 BIAS_LAST_SIZE 128 HEAD BLOCK_M BLOCK_N
      simpa using this]
  obtain ⟨final, sL, hloop, hfin, hinvL⟩ :=
    forRangeDyn_inv (idx := "start_n")
      (startOp := Op.ref .nat [] "lo") (stopOp := Op.ref .nat [] "hi")
      (stepOp := Op.constNat BLOCK_N)
      (P := fun i st => attnKernelInvariant s Q K V B0 Out sm_scale
        (s.pids 1 * stride_qh) (s.pids 1 * stride_kh) (s.pids 1 * stride_b0h)
        BLOCK_M BLOCK_N HEAD 0 BIAS_LAST_SIZE stride_b0m 1 HEAD HEAD 1 nB (s.pids 0) i st)
      (s_init := s0)
      (by rw [evalOp_ref, hlo])
      (by rw [evalOp_ref, hhi])
      (by rw [evalOp_constNat])
      (by omega)
      hinv0
      (fun i st hi hP => attn_stepG Q K V B0 Out s sm_scale BLOCK_M BLOCK_N HEAD 0 BIAS_LAST_SIZE stride_b0m hKN
        (s.pids 1 * stride_qh) (s.pids 1 * stride_kh) (s.pids 1 * stride_b0h) nB i st (by omega) hP)
  rw [stepStmts.cons_some hloop]
  have hfinal : final = BLOCK_N * nB := by
    obtain ⟨_, hmod, hle, _⟩ := hinvL
    rw [Nat.add_zero] at hfin
    -- hmod : final = final / BLOCK_N * BLOCK_N ; hle : final / BLOCK_N ≤ nB ; hfin : BLOCK_N * nB ≤ final
    have hub : final ≤ BLOCK_N * nB := by
      calc final = final / BLOCK_N * BLOCK_N := hmod
        _ ≤ nB * BLOCK_N := Nat.mul_le_mul_right _ hle
        _ = BLOCK_N * nB := Nat.mul_comm _ _
    omega
  subst hfinal
  obtain ⟨sF, hpostStep, hO⟩ := attn_postLoopG Q K V B0 Out s sm_scale BLOCK_M BLOCK_N HEAD 0 BIAS_LAST_SIZE stride_b0m
    (s.pids 1 * stride_qh) (s.pids 1 * stride_kh) (s.pids 1 * stride_b0h) hBM hKN hHD nB hnB sL hinvL
  exact ⟨sF, hpostStep, hO⟩

set_option maxHeartbeats 1000000 in
/-! ### ════════ ★ MAIN THEOREM ★ ════════ -/
/-- **General genuine closed-form `Out`-store correctness** (dimension-parameterized).
Every output lane of `_fwd_kernel_aligned` holds the closed-form base-2
streaming-softmax attention `attentionKernelSpec` (= `attnGenScore fscore vFlat`)
under the kernel's genuine bias-augmented per-key score `fscore` — NOT the
kernel's own executed output. Genuinely general over
`BLOCK_M BLOCK_N HEAD BIAS_LAST_SIZE numKVBlocks sm_scale` and the head/bias
strides (`P_SEQ = 0`, contiguous Q/K/V/Out layout per `qRaw`/`kFlat`/`vFlat`). -/
theorem attention_kernel_genuine_output_compute_correct_general
    (Q K V B0 Out : RegionName) (s : BlockState) (sm_scale : ℝ)
    (stride_qh stride_kh stride_b0h BLOCK_M BLOCK_N HEAD BIAS_LAST_SIZE stride_b0m nB : Nat)
    (hKN : 0 < BLOCK_N) (hBM : 0 < BLOCK_M) (hHD : 0 < HEAD) (hnB : 1 ≤ nB)
    (hundef : ∀ rg o, s.undef rg o = 0) :
    ComputeCorrect.Realizes_without_Rounding
      (kernel := mathematical Q K V B0 Out sm_scale
        stride_qh HEAD 1 stride_kh HEAD 1 stride_kh HEAD 1 stride_qh HEAD 1
        stride_b0h stride_b0m 2 4 (BLOCK_N * nB) 0 BIAS_LAST_SIZE 128 HEAD BLOCK_M BLOCK_N
        FloatDType.real)
      (initialState := s)
      (write := fun idx : TileIndex [BLOCK_M, HEAD] =>
        some (Out, surfaceOutOffset s stride_qh HEAD 1 BLOCK_M idx))
      (expected := fun idx : TileIndex [BLOCK_M, HEAD] =>
        MemCell.of .real (FloatDType.real.cast FloatDType.real
          (some (attentionKernelSpec s Q K V B0 sm_scale
            (s.pids 1 * stride_qh) (s.pids 1 * stride_kh) (s.pids 1 * stride_b0h)
            BLOCK_M BLOCK_N HEAD (BLOCK_N * nB) BIAS_LAST_SIZE stride_b0m (s.pids 0) idx)))) := by
  apply ComputeKernel.computeCorrect_of_toAlgKernel
  · apply supported_projection
    apply mathematical_toAlgorithm_supported
  intro s0 s' hExec hs0
  subst s0
  intro idx
  obtain ⟨sF, hstep, hO⟩ := attention_kernel_exec_general Q K V B0 Out s sm_scale
    stride_qh stride_kh stride_b0h BLOCK_M BLOCK_N HEAD BIAS_LAST_SIZE stride_b0m nB hKN hBM hHD hnB hundef
  rw [show exec _ s = stepStmts _ s from rfl, hstep] at hExec
  obtain rfl : sF = s' := Option.some.inj hExec
  simp only [ComputeCorrect.OutputReadable.read_memcell]
  rw [show surfaceOutOffset s stride_qh HEAD 1 BLOCK_M idx
        = s.pids 1 * stride_qh + (s.pids 0 * BLOCK_M + idx.1.val) * HEAD + idx.2.1.val * 1 from by
    simp [surfaceOutOffset, mIndex, kIndex]]
  exact hO idx

end ClosedForm

end Correct_without_Rounding

/-! Four input streams and one output. Q is static; K/V advance one key
block per iteration. B0 has two windows packed into `[BLOCK_M, BLOCK_N + 1]`:
columns below BLOCK_N describe static b1, and the last column describes the
iteration-dependent b0. The identity-rounding IO adapter below reuses the flat
memory transport machinery for this cast-free real program. -/

section IOFace

open scoped VeriTile.Triton.StreamMasked3DKernelIO₄
open ClosedForm

/-! ## Cast-free collapse under `R.round .real = id` -/

private theorem readMemAs_real_of_cell {s : BlockState} {region : RegionName}
    {offset : Nat} {x : ℝ}
    (h : s.mem region offset = MemCell.of .real (FloatDType.real.ofReal x)) :
    s.readMemAs .real region offset = FloatDType.real.ofReal x := by
  simp [BlockState.readMemAs, h, FloatDType.storeValue, FloatDType.ofReal]

/-- With `R.round .real = id`, `.real` stores collapse onto the exact typed
write. -/
private theorem akIO_wmtR_real (R : RoundingModel) (hreal : R.round .real = id)
    (s : BlockState) (region : RegionName) (o : Nat) (v : TileCarrier .real) :
    s.writeMemTypedR R .real region o v = s.writeMemTyped .real region o v := by
  rfl

/-- `mapM` congruence for cast-free dynamic block-pointer offset lists. -/
private theorem akIO_evalOpR_castFree_offsets (R : RoundingModel) :
    ∀ (offsets : List (Op .nat [])) (s : BlockState),
      (∀ o ∈ offsets, evalOpR R o s = evalOp o s) →
      offsets.mapM (fun off => do
          let v ← evalOpR R off s
          some (v.data PUnit.unit))
        = offsets.mapM (fun off => do
            let v ← evalOp off s
            some (v.data PUnit.unit))
  | [], _, _ => rfl
  | off :: rest, s, h => by
      simp only [List.mapM_cons, h off List.mem_cons_self,
        akIO_evalOpR_castFree_offsets R rest s
          (fun o ho => h o (List.mem_cons_of_mem _ ho))]

/-- `evalOpR` mirror of `Op.makeBlockPtrDynOffsets` for cast-free base/offset
ops (the `.nat` channels never round). -/
private theorem akIO_evalOpR_mbpdo_castFree (R : RoundingModel) (region : RegionName)
    (base : Op .nat []) (ps : List Nat) (bs : TileShape) (strides : List Nat)
    (offs : List (Op .nat [])) (s : BlockState)
    (hb : evalOpR R base s = evalOp base s)
    (ho : ∀ o ∈ offs, evalOpR R o s = evalOp o s) :
    evalOpR R (.makeBlockPtrDynOffsets region base ps bs strides offs) s
      = evalOp (.makeBlockPtrDynOffsets region base ps bs strides offs) s := by
  simp only [evalOpR, evalOp, hb, akIO_evalOpR_castFree_offsets R offs s ho]

/-- Per-statement cast-free collapse lifts to statement lists. -/
private theorem akIO_stepStmtsR_castFree_of_stmts (R : RoundingModel) :
    ∀ (l : List Stmt), (∀ st ∈ l, ∀ u, stepStmtR R st u = stepStmt st u) →
      ∀ s, stepStmtsR R l s = stepStmts l s
  | [], _, s => by simp only [stepStmtsR, stepStmts]
  | st :: rest, h, s => by
      simp only [stepStmtsR, stepStmts, h st List.mem_cons_self s]
      cases stepStmt st s with
      | none => rfl
      | some s' =>
          exact akIO_stepStmtsR_castFree_of_stmts R rest
            (fun st' h' u => h st' (List.mem_cons_of_mem _ h') u) s'

/-! ## Body split at the pinned layout

The lowered body of the pinned surface (`stride_qm = stride_kn = stride_vk =
stride_om = HEAD`, unit fastest strides, `N_CTX = BLOCK_N·nB`, `P_SEQ = 0`)
splits as the explicit 10-statement deterministic prologue prefix, the
existing `attnPreLoopTailG`, the `forRangeDyn` streaming loop over
`attnLoopBodyG`, and the existing `attnPostLoopG`. -/

/-- The 10-statement deterministic prologue prefix, explicit (the pinned
instantiation of `preLoop_prefix`'s statement list). -/
private def akPreLoop10G (Q K V : RegionName)
    (stride_qh stride_kh BLOCK_M BLOCK_N HEAD nB : Nat) : List Stmt :=
  [ Stmt.assign .nat [] "start_m" (Op.programId 0),
    Stmt.assign .nat [] "off_hz" (Op.programId 1),
    Stmt.assign .nat [] "q_offset"
      (Op.mul .nat Broadcast.nil (Op.ref .nat [] "off_hz") (Op.constNat stride_qh)),
    Stmt.assign .nat [] "kv_offset"
      (Op.mul .nat Broadcast.nil (Op.ref .nat [] "off_hz") (Op.constNat stride_kh)),
    Stmt.assign .blockPtr [BLOCK_M, HEAD] "Q_block_ptr"
      (Op.makeBlockPtrDynOffsets Q (Op.ref .nat [] "q_offset") [BLOCK_N * nB, HEAD]
        [BLOCK_M, HEAD] [HEAD, 1]
        [Op.mul .nat Broadcast.nil (Op.ref .nat [] "start_m") (Op.constNat BLOCK_M),
          Op.constNat 0]),
    Stmt.assign .blockPtr [HEAD, BLOCK_N] "K_block_ptr"
      (Op.makeBlockPtrDyn K (Op.ref .nat [] "kv_offset") [HEAD, BLOCK_N * nB + 0]
        [HEAD, BLOCK_N] [1, HEAD] [0, 0]),
    Stmt.assign .blockPtr [BLOCK_N, HEAD] "V_block_ptr"
      (Op.makeBlockPtrDyn V (Op.ref .nat [] "kv_offset") [BLOCK_N * nB + 0, HEAD]
        [BLOCK_N, HEAD] [HEAD, 1] [0, 0]),
    Stmt.assign .real [BLOCK_M] "m_i"
      (Op.add .real Broadcast.scalarR (Op.full [BLOCK_M] (Op.const 0)) Op.negInf),
    Stmt.assign .real [BLOCK_M] "l_i" (Op.full [BLOCK_M] (Op.const 0)),
    Stmt.assign .real [BLOCK_M, HEAD] "acc" (Op.full [BLOCK_M, HEAD] (Op.const 0)) ]

private theorem akIO_take10 (Q K V B0 Out : RegionName) (sm_scale : ℝ)
    (stride_qh stride_kh stride_b0h BLOCK_M BLOCK_N HEAD BIAS_LAST_SIZE stride_b0m nB : Nat) :
    ((mathematical Q K V B0 Out sm_scale
        stride_qh HEAD 1 stride_kh HEAD 1 stride_kh HEAD 1 stride_qh HEAD 1
        stride_b0h stride_b0m 2 4 (BLOCK_N * nB) 0 BIAS_LAST_SIZE 128 HEAD BLOCK_M BLOCK_N
        FloatDType.real).toAlgKernel.body.take 10)
      = akPreLoop10G Q K V stride_qh stride_kh BLOCK_M BLOCK_N HEAD nB := by
  simp only [↓List.map_cons, ↓List.map_nil, mathematical, ComputeKernel.eraseDType, ComputeKernel.toAlgKernel_fromKernelBody, ComputeKernel.toAlgorithm?_fromKernelBody, Kernel.eraseDType, ComputeKernel.toAlgKernel_mk, ComputeKernel.toAlgorithm?_mk, ComputeStmt.listToAlgorithm?, ComputeStmt.toAlgorithm?, ComputeExpr.toAlgorithm?, ComputeOp.toAlgorithm?, Stmt.eraseDTypeList, Stmt.eraseDType, Op.eraseDType.eq_def, MemAccess.eraseDType.eq_def, MaskOpt.eraseDType.eq_def, VeriTile.Triton.eraseDType, NumericDType.eraseDType, ComparableDType.eraseDType, IntegralDType.eraseDType, FloatDType.toTileDType, Except.bind, bind, akPreLoop10G]
  all_goals rfl

set_option maxRecDepth 100000 in
private theorem akIO_take19 (Q K V B0 Out : RegionName) (sm_scale : ℝ)
    (stride_qh stride_kh stride_b0h BLOCK_M BLOCK_N HEAD BIAS_LAST_SIZE stride_b0m nB : Nat) :
    ((mathematical Q K V B0 Out sm_scale
        stride_qh HEAD 1 stride_kh HEAD 1 stride_kh HEAD 1 stride_qh HEAD 1
        stride_b0h stride_b0m 2 4 (BLOCK_N * nB) 0 BIAS_LAST_SIZE 128 HEAD BLOCK_M BLOCK_N
        FloatDType.real).toAlgKernel.body.take 19)
      = akPreLoop10G Q K V stride_qh stride_kh BLOCK_M BLOCK_N HEAD nB
        ++ attnPreLoopTailG B0 sm_scale BLOCK_M BLOCK_N HEAD (BLOCK_N * nB) 0
            BIAS_LAST_SIZE stride_b0h stride_b0m := by
  conv_lhs => rw [← List.take_append_drop 10
    ((mathematical Q K V B0 Out sm_scale
        stride_qh HEAD 1 stride_kh HEAD 1 stride_kh HEAD 1 stride_qh HEAD 1
        stride_b0h stride_b0m 2 4 (BLOCK_N * nB) 0 BIAS_LAST_SIZE 128 HEAD BLOCK_M BLOCK_N
        FloatDType.real).toAlgKernel.body.take 19)]
  rw [List.take_take, show min 10 19 = 10 from by norm_num,
    attnPreLoopTailG_check Q K V B0 Out sm_scale stride_qh HEAD 1 stride_kh HEAD 1
      stride_kh HEAD 1 stride_qh HEAD 1 stride_b0h stride_b0m 2 4 (BLOCK_N * nB) 0
      BIAS_LAST_SIZE 128 HEAD BLOCK_M BLOCK_N,
    akIO_take10 Q K V B0 Out sm_scale stride_qh stride_kh stride_b0h BLOCK_M BLOCK_N HEAD
      BIAS_LAST_SIZE stride_b0m nB]

set_option maxRecDepth 100000 in
/-- The whole lowered body, split into the four segments. -/
private theorem akIO_body_split (Q K V B0 Out : RegionName) (sm_scale : ℝ)
    (stride_qh stride_kh stride_b0h BLOCK_M BLOCK_N HEAD BIAS_LAST_SIZE stride_b0m nB : Nat) :
    (mathematical Q K V B0 Out sm_scale
        stride_qh HEAD 1 stride_kh HEAD 1 stride_kh HEAD 1 stride_qh HEAD 1
        stride_b0h stride_b0m 2 4 (BLOCK_N * nB) 0 BIAS_LAST_SIZE 128 HEAD BLOCK_M BLOCK_N
        FloatDType.real).toAlgKernel.body
      = akPreLoop10G Q K V stride_qh stride_kh BLOCK_M BLOCK_N HEAD nB
        ++ (attnPreLoopTailG B0 sm_scale BLOCK_M BLOCK_N HEAD (BLOCK_N * nB) 0
              BIAS_LAST_SIZE stride_b0h stride_b0m
          ++ (Stmt.forRangeDyn "start_n" (Op.ref .nat [] "lo") (Op.ref .nat [] "hi")
                (Op.constNat BLOCK_N) (attnLoopBodyG B0 BLOCK_M BLOCK_N HEAD stride_b0m)
              :: attnPostLoopG Out BLOCK_M HEAD (BLOCK_N * nB) HEAD 1)) := by
  conv_lhs => rw [← List.take_append_drop 19
    ((mathematical Q K V B0 Out sm_scale
        stride_qh HEAD 1 stride_kh HEAD 1 stride_kh HEAD 1 stride_qh HEAD 1
        stride_b0h stride_b0m 2 4 (BLOCK_N * nB) 0 BIAS_LAST_SIZE 128 HEAD BLOCK_M BLOCK_N
        FloatDType.real).toAlgKernel.body)]
  rw [akIO_take19 Q K V B0 Out sm_scale stride_qh stride_kh stride_b0h BLOCK_M BLOCK_N HEAD
      BIAS_LAST_SIZE stride_b0m nB,
    attnLoopBodyG_check Q K V B0 Out sm_scale stride_qh HEAD 1 stride_kh HEAD 1 stride_kh
      HEAD 1 stride_qh HEAD 1 stride_b0h stride_b0m 2 4 (BLOCK_N * nB) 0 BIAS_LAST_SIZE 128
      HEAD BLOCK_M BLOCK_N,
    show (mathematical Q K V B0 Out sm_scale
        stride_qh HEAD 1 stride_kh HEAD 1 stride_kh HEAD 1 stride_qh HEAD 1
        stride_b0h stride_b0m 2 4 (BLOCK_N * nB) 0 BIAS_LAST_SIZE 128 HEAD BLOCK_M BLOCK_N
        FloatDType.real).toAlgKernel.body.drop 20
      = attnPostLoopG Out BLOCK_M HEAD (BLOCK_N * nB) HEAD 1 from by
      have := attnPostLoopG_check Q K V B0 Out sm_scale stride_qh HEAD 1 stride_kh HEAD 1
        stride_kh HEAD 1 stride_qh HEAD 1 stride_b0h stride_b0m 2 4 (BLOCK_N * nB) 0
        BIAS_LAST_SIZE 128 HEAD BLOCK_M BLOCK_N
      simpa using this,
    List.append_assoc]

/-! ## Per-segment cast-free collapse -/

set_option maxHeartbeats 600000 in
/-- Every prologue-prefix statement is cast-free (`.nat` arithmetic, the two
`makeBlockPtrDyn` assigns, the `makeBlockPtrDynOffsets` assign through the
`mapM` mirror, and the `.real` initializers). -/
private theorem akIO_preLoop10_stmt_castFree (R : RoundingModel)
    (Q K V : RegionName) (stride_qh stride_kh BLOCK_M BLOCK_N HEAD nB : Nat) :
    ∀ st ∈ akPreLoop10G Q K V stride_qh stride_kh BLOCK_M BLOCK_N HEAD nB,
      ∀ u, stepStmtR R st u = stepStmt st u := by
  intro st hst u
  simp only [akPreLoop10G, List.mem_cons, List.not_mem_nil, or_false] at hst
  rcases hst with rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl
  · simp only [stepStmtR, stepStmt, evalOpR.eq_def, evalOp.eq_def]
  · simp only [stepStmtR, stepStmt, evalOpR.eq_def, evalOp.eq_def]
  · simp only [stepStmtR, stepStmt, evalOpR.eq_def, evalOp.eq_def]
  · simp only [stepStmtR, stepStmt, evalOpR.eq_def, evalOp.eq_def]
  · -- Q_block_ptr (`makeBlockPtrDynOffsets`)
    simp only [stepStmtR, stepStmt,
      akIO_evalOpR_mbpdo_castFree R Q (Op.ref .nat [] "q_offset") [BLOCK_N * nB, HEAD]
        [BLOCK_M, HEAD] [HEAD, 1]
        [Op.mul .nat Broadcast.nil (Op.ref .nat [] "start_m") (Op.constNat BLOCK_M),
          Op.constNat 0] u
        (by simp only [evalOpR.eq_def, evalOp.eq_def])
        (by
          intro o ho
          simp only [List.mem_cons, List.not_mem_nil, or_false] at ho
          rcases ho with rfl | rfl <;> simp only [evalOpR.eq_def, evalOp.eq_def])]
  · simp only [stepStmtR, stepStmt, evalOpR.eq_def, evalOp.eq_def]
  · simp only [stepStmtR, stepStmt, evalOpR.eq_def, evalOp.eq_def]
  · simp only [stepStmtR, stepStmt, evalOpR.eq_def, evalOp.eq_def]
  · simp only [stepStmtR, stepStmt, evalOpR.eq_def, evalOp.eq_def]
  · simp only [stepStmtR, stepStmt, evalOpR.eq_def, evalOp.eq_def]

set_option maxHeartbeats 600000 in
/-- Prologue loads and arithmetic contain no precision casts. -/
private theorem akIO_preLoopTail_stmt_castFree (R : RoundingModel)
    (hreal : R.round .real = id) (B0 : RegionName) (sm_scale : ℝ)
    (BLOCK_M BLOCK_N HEAD N_CTX P_SEQ BIAS_LAST_SIZE stride_b0h stride_b0m : Nat) :
    ∀ st ∈ attnPreLoopTailG B0 sm_scale BLOCK_M BLOCK_N HEAD N_CTX P_SEQ
        BIAS_LAST_SIZE stride_b0h stride_b0m,
      ∀ u, stepStmtR R st u = stepStmt st u := by
  intro st hst u
  simp only [attnPreLoopTailG, List.mem_cons, List.not_mem_nil, or_false] at hst
  rcases hst with rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl <;>
    simp only [stepStmtR, stepStmt, evalOpR.eq_def, evalOp.eq_def]

set_option maxHeartbeats 600000 in
/-- The entire real loop body is independent of rounding. -/
private theorem akIO_loopBody_stmt_castFree (R : RoundingModel)
    (hreal : R.round .real = id) (B0 : RegionName)
    (BLOCK_M BLOCK_N HEAD stride_b0m : Nat) :
    ∀ st ∈ attnLoopBodyG B0 BLOCK_M BLOCK_N HEAD stride_b0m,
      ∀ u, stepStmtR R st u = stepStmt st u := by
  intro st hst u
  simp only [attnLoopBodyG, List.mem_cons, List.not_mem_nil, or_false] at hst
  rcases hst with rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl |
    rfl | rfl | rfl <;>
    simp only [stepStmtR, stepStmt, evalOpR.eq_def, evalOp.eq_def]

set_option maxHeartbeats 600000 in
/-- Normalization, output-pointer construction and the real store are exact. -/
private theorem akIO_postLoop_stmt_castFree (R : RoundingModel)
    (hreal : R.round .real = id) (Out : RegionName) (BLOCK_M HEAD N_CTX : Nat) :
    ∀ st ∈ attnPostLoopG Out BLOCK_M HEAD N_CTX HEAD 1,
      ∀ u, stepStmtR R st u = stepStmt st u := by
  intro st hst u
  simp only [attnPostLoopG, List.mem_cons, List.not_mem_nil, or_false] at hst
  rcases hst with rfl | rfl | rfl
  · simp only [stepStmtR, stepStmt, evalOpR.eq_def, evalOp.eq_def]
  · -- O_block_ptr (`makeBlockPtrDynOffsets`)
    simp only [stepStmtR, stepStmt,
      akIO_evalOpR_mbpdo_castFree R Out (Op.ref .nat [] "q_offset") [N_CTX, HEAD]
        [BLOCK_M, HEAD] [HEAD, 1]
        [Op.mul .nat Broadcast.nil (Op.ref .nat [] "start_m") (Op.constNat BLOCK_M),
          Op.constNat 0] u
        (by simp only [evalOpR.eq_def, evalOp.eq_def])
        (by
          intro o ho
          simp only [List.mem_cons, List.not_mem_nil, or_false] at ho
          rcases ho with rfl | rfl <;> simp only [evalOpR.eq_def, evalOp.eq_def])]
  · simp only [stepStmtR, stepStmt, evalOpR.eq_def, evalOp.eq_def,
      akIO_wmtR_real R hreal]

/-- The streaming `forRangeDyn` statement is cast-free given
`R.round .real = id` (register-ref loop bounds plus the cast-free body
through `stepForRangeAuxR_castFree`). -/
private theorem akIO_loopStmt_castFree (R : RoundingModel)
    (hreal : R.round .real = id) (B0 : RegionName)
    (BLOCK_M BLOCK_N HEAD stride_b0m : Nat) :
    ∀ u, stepStmtR R
        (Stmt.forRangeDyn "start_n" (Op.ref .nat [] "lo") (Op.ref .nat [] "hi")
          (Op.constNat BLOCK_N) (attnLoopBodyG B0 BLOCK_M BLOCK_N HEAD stride_b0m)) u
      = stepStmt
        (Stmt.forRangeDyn "start_n" (Op.ref .nat [] "lo") (Op.ref .nat [] "hi")
          (Op.constNat BLOCK_N) (attnLoopBodyG B0 BLOCK_M BLOCK_N HEAD stride_b0m)) u := by
  intro u
  have hbody : ∀ t, stepStmtsR R (attnLoopBodyG B0 BLOCK_M BLOCK_N HEAD stride_b0m) t
      = stepStmts (attnLoopBodyG B0 BLOCK_M BLOCK_N HEAD stride_b0m) t :=
    akIO_stepStmtsR_castFree_of_stmts R _
      (akIO_loopBody_stmt_castFree R hreal B0 BLOCK_M BLOCK_N HEAD stride_b0m)
  simp only [stepStmtR, stepStmt,
    show evalOpR R (Op.ref .nat [] "lo") u = evalOp (Op.ref .nat [] "lo") u from by
      simp only [evalOpR.eq_def, evalOp.eq_def],
    show evalOpR R (Op.ref .nat [] "hi") u = evalOp (Op.ref .nat [] "hi") u from by
      simp only [evalOpR.eq_def, evalOp.eq_def],
    show evalOpR R (Op.constNat BLOCK_N) u = evalOp (Op.constNat BLOCK_N) u from by
      simp only [evalOpR.eq_def, evalOp.eq_def]]
  cases evalOp (Op.ref .nat [] "lo") u with
  | none => rfl
  | some start' =>
    cases evalOp (Op.ref .nat [] "hi") u with
    | none => rfl
    | some stop' =>
      cases evalOp (Op.constNat BLOCK_N) u with
      | none => rfl
      | some step' =>
        exact stepForRangeAuxR_castFree R _ hbody "start_n"
          (start'.data PUnit.unit) (stop'.data PUnit.unit) (step'.data PUnit.unit) u

/-- The whole lowered body is cast-free given `R.round .real = id`. -/
private theorem akIO_body_castFree (R : RoundingModel) (hreal : R.round .real = id)
    (Q K V B0 Out : RegionName) (sm_scale : ℝ)
    (stride_qh stride_kh stride_b0h BLOCK_M BLOCK_N HEAD BIAS_LAST_SIZE stride_b0m nB : Nat)
    (t : BlockState) :
    stepStmtsR R
        (akPreLoop10G Q K V stride_qh stride_kh BLOCK_M BLOCK_N HEAD nB
          ++ (attnPreLoopTailG B0 sm_scale BLOCK_M BLOCK_N HEAD (BLOCK_N * nB) 0
                BIAS_LAST_SIZE stride_b0h stride_b0m
            ++ (Stmt.forRangeDyn "start_n" (Op.ref .nat [] "lo") (Op.ref .nat [] "hi")
                  (Op.constNat BLOCK_N) (attnLoopBodyG B0 BLOCK_M BLOCK_N HEAD stride_b0m)
                :: attnPostLoopG Out BLOCK_M HEAD (BLOCK_N * nB) HEAD 1))) t
      = stepStmts
        (akPreLoop10G Q K V stride_qh stride_kh BLOCK_M BLOCK_N HEAD nB
          ++ (attnPreLoopTailG B0 sm_scale BLOCK_M BLOCK_N HEAD (BLOCK_N * nB) 0
                BIAS_LAST_SIZE stride_b0h stride_b0m
            ++ (Stmt.forRangeDyn "start_n" (Op.ref .nat [] "lo") (Op.ref .nat [] "hi")
                  (Op.constNat BLOCK_N) (attnLoopBodyG B0 BLOCK_M BLOCK_N HEAD stride_b0m)
                :: attnPostLoopG Out BLOCK_M HEAD (BLOCK_N * nB) HEAD 1))) t := by
  refine akIO_stepStmtsR_castFree_of_stmts R _ ?_ t
  intro st hst u
  rcases List.mem_append.mp hst with h10 | hrest
  · exact akIO_preLoop10_stmt_castFree R Q K V stride_qh stride_kh BLOCK_M BLOCK_N HEAD nB
      st h10 u
  · rcases List.mem_append.mp hrest with htail | hrest2
    · exact akIO_preLoopTail_stmt_castFree R hreal B0 sm_scale BLOCK_M BLOCK_N HEAD
        (BLOCK_N * nB) 0 BIAS_LAST_SIZE stride_b0h stride_b0m st htail u
    · rcases List.mem_cons.mp hrest2 with rfl | hpost
      · exact akIO_loopStmt_castFree R hreal B0 BLOCK_M BLOCK_N HEAD stride_b0m u
      · exact akIO_postLoop_stmt_castFree R hreal Out BLOCK_M HEAD (BLOCK_N * nB) st hpost u

set_option maxHeartbeats 600000 in
/-- The pinned surface sits inside the flat-memory bridge's covered fragment
(no `ptrSub`; block-pointer ops structurally covered). -/
private theorem akIO_flattenOk (Q K V B0 Out : RegionName) (sm_scale : ℝ)
    (stride_qh stride_kh stride_b0h BLOCK_M BLOCK_N HEAD BIAS_LAST_SIZE stride_b0m nB : Nat) :
    ((mathematical Q K V B0 Out sm_scale
      stride_qh HEAD 1 stride_kh HEAD 1 stride_kh HEAD 1 stride_qh HEAD 1
      stride_b0h stride_b0m 2 4 (BLOCK_N * nB) 0 BIAS_LAST_SIZE 128 HEAD BLOCK_M BLOCK_N
      FloatDType.real).toAlgKernel).FlattenOk := by
  unfold Kernel.FlattenOk
  rw [akIO_body_split Q K V B0 Out sm_scale stride_qh stride_kh stride_b0h BLOCK_M BLOCK_N
    HEAD BIAS_LAST_SIZE stride_b0m nB]
  simp [akPreLoop10G, attnPreLoopTailG, attnLoopBodyG, attnPostLoopG, StmtList.FlattenOk,
    Stmt.FlattenOk, Op.FlattenOk]
  simp [Op.FlattenOk.eq_def]

/-! ## Memory helper (frame leg) -/

/-- An unmasked `.real` typed-write foldl into `W` never touches another
region. -/
private theorem akIO_foldl_real_other_region {α : Type} {W : RegionName}
    (offsetFn : α → Nat) (valueFn : α → TileCarrier TileDType.real)
    (r : RegionName) (hr : r ≠ W) (o : Nat) (l : List α) :
    ∀ s : BlockState,
      ((l.foldl (fun acc k => acc.writeMemTyped .real W (offsetFn k) (valueFn k)) s).mem r o)
        = s.mem r o := by
  induction l with
  | nil => intro s; rfl
  | cons hd tl ih =>
      intro s
      rw [List.foldl_cons, ih]
      unfold BlockState.writeMemTyped BlockState.writeMemAs
      change (if r = W ∧ o = offsetFn hd then _ else s.mem r o) = s.mem r o
      rw [if_neg (fun hc => hr hc.1)]

/-! ## Address evals for the two `B0` window loads (safety side) -/

/-- The `b1` window's address op evaluates to the per-lane
`boff + (smbm·BM + r)·stride_b0m + (jL % BIAS + BIAS)` addresses. -/
private theorem akIO_b1_addr_eval (s : BlockState)
    (BLOCK_M BLOCK_N stride_b0m BIAS_LAST_SIZE smbm boff : Nat)
    (hbo : s.regs .nat [] "b_offset" = some (Tile.scalar boff))
    (hsm : s.regs .nat [] "start_m" = some (Tile.scalar smbm))
    (hm : s.regs .nat [BLOCK_M] "b_ptr_offsets_m" = some (Tile.vec (fun r : Fin BLOCK_M => r.val)))
    (hn1 : s.regs .nat [BLOCK_N] "b_ptr_offsets_n_1"
      = some (Tile.vec (fun jL : Fin BLOCK_N => jL.val % BIAS_LAST_SIZE + BIAS_LAST_SIZE))) :
    evalOp (Op.add .nat (Broadcast.consR (Broadcast.consL Broadcast.nil))
        (Op.add .nat Broadcast.scalarL (Op.ref .nat [] "b_offset")
          (Op.expandDim ⟨1, by simp⟩ (Op.mul .nat Broadcast.scalarR
            (Op.add .nat Broadcast.scalarL
              (Op.mul .nat Broadcast.nil (Op.ref .nat [] "start_m") (Op.constNat BLOCK_M))
              (Op.ref .nat [BLOCK_M] "b_ptr_offsets_m")) (Op.constNat stride_b0m))))
        (Op.expandDim ⟨0, by simp⟩ (Op.ref .nat [BLOCK_N] "b_ptr_offsets_n_1"))) s
      = some (⟨fun idx : TileIndex [BLOCK_M, BLOCK_N] =>
          boff + (smbm * BLOCK_M + idx.1.val) * stride_b0m
            + (idx.2.1.val % BIAS_LAST_SIZE + BIAS_LAST_SIZE)⟩ : Tile .nat [BLOCK_M, BLOCK_N]) := by
  simp only [evalOp_add, evalOp_mul, evalOp_constNat, evalOp_ref, evalOp_expandDim_one_nat',
    evalOp_expandDim_zero_nat', hbo, hsm, hm, hn1, Option.bind_eq_bind, Option.bind_some]
  refine congrArg some ?_
  ext idx
  simp only [Tile.bop_data, Broadcast.leftIndex, Broadcast.rightIndex, Tile.scalar, Tile.vec,
    NumericDType.add, NumericDType.mul]

/-- The in-loop `b0` block-column address op evaluates to the per-row
`boff + (smbm·BM + r)·stride_b0m + SN / BLOCK_N` addresses. -/
private theorem akIO_b0_addr_eval (s : BlockState)
    (BLOCK_M BLOCK_N stride_b0m smbm boff snv : Nat) (hax : 1 < [BLOCK_M].length.succ)
    (hbo : s.regs .nat [] "b_offset" = some (Tile.scalar boff))
    (hsm : s.regs .nat [] "start_m" = some (Tile.scalar smbm))
    (hsn : s.regs .nat [] "start_n" = some (Tile.scalar snv))
    (hm : s.regs .nat [BLOCK_M] "b_ptr_offsets_m" = some (Tile.vec (fun r : Fin BLOCK_M => r.val))) :
    evalOp ((Op.add .nat Broadcast.scalarR
        (Op.add .nat Broadcast.scalarL (Op.ref .nat [] "b_offset")
          (Op.expandDim ⟨1, hax⟩ (Op.mul .nat Broadcast.scalarR
            (Op.add .nat Broadcast.scalarL
              (Op.mul .nat Broadcast.nil (Op.ref .nat [] "start_m") (Op.constNat BLOCK_M))
              (Op.ref .nat [BLOCK_M] "b_ptr_offsets_m")) (Op.constNat stride_b0m))))
        (Op.floorDiv .nat Broadcast.nil (Op.ref .nat [] "start_n") (Op.constNat BLOCK_N))) :
        Op .nat [BLOCK_M, 1]) s
      = some (⟨fun idx : TileIndex [BLOCK_M, 1] =>
          boff + (smbm * BLOCK_M + idx.1.val) * stride_b0m + snv / BLOCK_N⟩
          : Tile .nat [BLOCK_M, 1]) := by
  conv_lhs => unfold evalOp
  conv_lhs => unfold evalOp
  conv_lhs => unfold evalOp
  conv_lhs => unfold evalOp
  conv_lhs => unfold evalOp
  conv_lhs => unfold evalOp
  rw [evalOp_ref, hsm]
  simp only [evalOp_ref, evalOp_constNat, hbo, hsn, hm, Option.bind, Option.map]
  refine congrArg some ?_
  ext idx
  simp only [Tile.bop_data, Tile.expandDim_data, TileShape.dropInsertedIndex, Broadcast.leftIndex,
    Broadcast.rightIndex, Tile.scalar, Tile.vec, NumericDType.add, NumericDType.mul,
    IntegralDType.floorDiv]

/-! ## Weak (safety-side) loop principles

The library's `Stmt.forRangeTraceSafeR_inv` demands per-iteration success,
which would drag the `undef`-clean full invariant into the safety walk. These
local principles (copies of the triton_attention recipe — bench files
never import each other) take the success-conditional obligation
instead. -/

/-- Invariant principle for `forRangeTraceSafeR` with success-conditional
transport. -/
private theorem akIO_forRangeTraceSafeR_inv (R : RoundingModel) (bounds : RegionBounds)
    (idx : RegName) (stop step : Nat) (body : List Stmt)
    (P : Nat → BlockState → Prop)
    (hstep : ∀ c st, c < stop → P c st →
      Stmt.TraceSafeListR R bounds body (st.setReg idx .nat [] (Tile.scalar c)) ∧
      (∀ st', stepStmtsR R body (st.setReg idx .nat [] (Tile.scalar c)) = some st' →
        P (c + step) st')) :
    ∀ cur st, P cur st → Stmt.forRangeTraceSafeR R bounds idx cur stop step body st
  | cur, st, hP => by
      rw [Stmt.forRangeTraceSafeR]
      split
      · trivial
      · split
        · obtain ⟨hsafe, hnext⟩ := hstep cur st ‹cur < stop› hP
          refine ⟨hsafe, ?_⟩
          cases hrun : stepStmtsR R body (st.setReg idx .nat [] (Tile.scalar cur)) with
          | none => trivial
          | some st' =>
              exact akIO_forRangeTraceSafeR_inv R bounds idx stop step body P hstep
                (cur + step) st' (hnext st' hrun)
        · trivial
  termination_by cur _ _ => stop - cur
  decreasing_by omega

/-- Exit-state transport through `stepForRangeAuxR`: a counter-free state
predicate preserved by every successful body run survives to the loop exit. -/
private theorem akIO_forRangeAuxR_exit (R : RoundingModel)
    (idx : RegName) (stop step : Nat) (body : List Stmt)
    (P : BlockState → Prop)
    (hbody : ∀ (c : Nat) (st st' : BlockState), P st →
      stepStmtsR R body (st.setReg idx .nat [] (Tile.scalar c)) = some st' → P st') :
    ∀ (cur : Nat) (st st2 : BlockState), P st →
      stepForRangeAuxR R idx cur stop step body st = some st2 → P st2
  | cur, st, st2, hP, h => by
      rw [stepForRangeAuxR] at h
      split at h
      · exact (Option.some.inj h) ▸ hP
      · split at h
        · cases hrun : stepStmtsR R body (st.setReg idx .nat [] (Tile.scalar cur)) with
          | none => rw [hrun] at h; cases h
          | some st' =>
              rw [hrun] at h
              exact akIO_forRangeAuxR_exit R idx stop step body P hbody
                (cur + step) st' st2 (hbody cur st st' hP hrun) h
        · exact (Option.some.inj h) ▸ hP
  termination_by cur _ _ _ _ => stop - cur
  decreasing_by omega

/-- Cons inversion for `stepStmtsR`. -/
private theorem akIO_stepStmtsR_cons_inv {R : RoundingModel} {st : Stmt}
    {rest : List Stmt} {s s' : BlockState}
    (h : stepStmtsR R (st :: rest) s = some s') :
    ∃ s1, stepStmtR R st s = some s1 ∧ stepStmtsR R rest s1 = some s' := by
  rw [stepStmtsR] at h
  cases hs : stepStmtR R st s with
  | none =>
      rw [hs] at h
      exact absurd h (by simp)
  | some s1 =>
      simp only [hs] at h
      exact ⟨s1, rfl, h⟩

set_option maxHeartbeats 2000000 in
/-- Weak loop-body inversion: from any successful `R`-run of the
15-statement body, the pids and the loop-invariant `.nat` registers are
preserved and the K/V block pointers advance one `BLOCK_N` block. No value
tracking, no `undef` demands. -/
private theorem akIO_bodyR_inv (R : RoundingModel) (B0 : RegionName)
    (BLOCK_M BLOCK_N HEAD stride_b0m : Nat) {u st' : BlockState}
    (h : stepStmtsR R (attnLoopBodyG B0 BLOCK_M BLOCK_N HEAD stride_b0m) u = some st') :
    st'.pids = u.pids
    ∧ st'.regs .nat [] "q_offset" = u.regs .nat [] "q_offset"
    ∧ st'.regs .nat [] "start_m" = u.regs .nat [] "start_m"
    ∧ st'.regs .nat [] "b_offset" = u.regs .nat [] "b_offset"
    ∧ st'.regs .nat [BLOCK_M] "b_ptr_offsets_m" = u.regs .nat [BLOCK_M] "b_ptr_offsets_m"
    ∧ (∀ (Kreg : RegionName) (kbase kcols colOff : Nat),
        u.regs .blockPtr [HEAD, BLOCK_N] "K_block_ptr"
          = some (⟨fun _ : TileIndex [HEAD, BLOCK_N] =>
              { region := Kreg, baseOffset := kbase, parentShape := [HEAD, kcols],
                blockShape := [HEAD, BLOCK_N], strides := [1, HEAD],
                offsets := [0, colOff] }⟩) →
        st'.regs .blockPtr [HEAD, BLOCK_N] "K_block_ptr"
          = some (⟨fun _ : TileIndex [HEAD, BLOCK_N] =>
              { region := Kreg, baseOffset := kbase, parentShape := [HEAD, kcols],
                blockShape := [HEAD, BLOCK_N], strides := [1, HEAD],
                offsets := [0, colOff + BLOCK_N] }⟩))
    ∧ (∀ (Vreg : RegionName) (vbase vrows rowOff : Nat),
        u.regs .blockPtr [BLOCK_N, HEAD] "V_block_ptr"
          = some (⟨fun _ : TileIndex [BLOCK_N, HEAD] =>
              { region := Vreg, baseOffset := vbase, parentShape := [vrows, HEAD],
                blockShape := [BLOCK_N, HEAD], strides := [HEAD, 1],
                offsets := [rowOff, 0] }⟩) →
        st'.regs .blockPtr [BLOCK_N, HEAD] "V_block_ptr"
          = some (⟨fun _ : TileIndex [BLOCK_N, HEAD] =>
              { region := Vreg, baseOffset := vbase, parentShape := [vrows, HEAD],
                blockShape := [BLOCK_N, HEAD], strides := [HEAD, 1],
                offsets := [rowOff + BLOCK_N, 0] }⟩)) := by
  unfold attnLoopBodyG at h
  obtain ⟨u1, h1, h⟩ := akIO_stepStmtsR_cons_inv h
  obtain ⟨w1, -, rfl⟩ := stepStmtR_assign_inv h1
  obtain ⟨u2, h2, h⟩ := akIO_stepStmtsR_cons_inv h
  obtain ⟨w2, -, rfl⟩ := stepStmtR_assign_inv h2
  obtain ⟨u3, h3, h⟩ := akIO_stepStmtsR_cons_inv h
  obtain ⟨w3, -, rfl⟩ := stepStmtR_assign_inv h3
  obtain ⟨u4, h4, h⟩ := akIO_stepStmtsR_cons_inv h
  obtain ⟨w4, -, rfl⟩ := stepStmtR_assign_inv h4
  obtain ⟨u5, h5, h⟩ := akIO_stepStmtsR_cons_inv h
  obtain ⟨w5, -, rfl⟩ := stepStmtR_assign_inv h5
  obtain ⟨u6, h6, h⟩ := akIO_stepStmtsR_cons_inv h
  obtain ⟨w6, -, rfl⟩ := stepStmtR_assign_inv h6
  obtain ⟨u7, h7, h⟩ := akIO_stepStmtsR_cons_inv h
  obtain ⟨w7, -, rfl⟩ := stepStmtR_assign_inv h7
  obtain ⟨u8, h8, h⟩ := akIO_stepStmtsR_cons_inv h
  obtain ⟨w8, -, rfl⟩ := stepStmtR_assign_inv h8
  obtain ⟨u9, h9, h⟩ := akIO_stepStmtsR_cons_inv h
  obtain ⟨w9, -, rfl⟩ := stepStmtR_assign_inv h9
  obtain ⟨u10, h10, h⟩ := akIO_stepStmtsR_cons_inv h
  obtain ⟨w10, -, rfl⟩ := stepStmtR_assign_inv h10
  obtain ⟨u11, h11, h⟩ := akIO_stepStmtsR_cons_inv h
  obtain ⟨w11, -, rfl⟩ := stepStmtR_assign_inv h11
  obtain ⟨u12, h12, h⟩ := akIO_stepStmtsR_cons_inv h
  obtain ⟨w12, -, rfl⟩ := stepStmtR_assign_inv h12
  obtain ⟨u13, h13, h⟩ := akIO_stepStmtsR_cons_inv h
  obtain ⟨w13, -, rfl⟩ := stepStmtR_assign_inv h13
  obtain ⟨u14, h14, h⟩ := akIO_stepStmtsR_cons_inv h
  obtain ⟨w14, hw14, rfl⟩ := stepStmtR_assign_inv h14
  obtain ⟨u15, h15, h⟩ := akIO_stepStmtsR_cons_inv h
  obtain ⟨w15, hw15, rfl⟩ := stepStmtR_assign_inv h15
  rw [stepStmtsR] at h
  obtain rfl := Option.some.inj h
  refine ⟨?_, ?_, ?_, ?_, ?_, ?_, ?_⟩
  · simp [BlockState.setReg_pids]
  · iterate 15 rw [BlockState.setReg_ne_name _ _ _ _ _ _ _ _ (by decide)]
  · iterate 15 rw [BlockState.setReg_ne_name _ _ _ _ _ _ _ _ (by decide)]
  · iterate 15 rw [BlockState.setReg_ne_name _ _ _ _ _ _ _ _ (by decide)]
  · iterate 15 rw [BlockState.setReg_ne_name _ _ _ _ _ _ _ _ (by decide)]
  · -- K_block_ptr advanced
    intro Kreg kbase kcols colOff hk
    have hk13 : (((((((((((((u.setReg "k" .real [HEAD, BLOCK_N] w1).setReg
        "v" .real [BLOCK_N, HEAD] w2).setReg "qk" .real [BLOCK_M, BLOCK_N] w3).setReg
        "qk" .real [BLOCK_M, BLOCK_N] w4).setReg "b0" .real [BLOCK_M, 1] w5).setReg
        "qk" .real [BLOCK_M, BLOCK_N] w6).setReg "m_i_new" .real [BLOCK_M] w7).setReg
        "alpha" .real [BLOCK_M] w8).setReg "p" .real [BLOCK_M, BLOCK_N] w9).setReg
        "acc" .real [BLOCK_M, HEAD] w10).setReg "acc" .real [BLOCK_M, HEAD] w11).setReg
        "l_i" .real [BLOCK_M] w12).setReg "m_i" .real [BLOCK_M] w13).regs
          .blockPtr [HEAD, BLOCK_N] "K_block_ptr"
        = some (⟨fun _ : TileIndex [HEAD, BLOCK_N] =>
            { region := Kreg, baseOffset := kbase, parentShape := [HEAD, kcols],
              blockShape := [HEAD, BLOCK_N], strides := [1, HEAD],
              offsets := [0, colOff] }⟩) := by
      iterate 13 rw [BlockState.setReg_ne_name _ _ _ _ _ _ _ _ (by decide)]
      exact hk
    have hcollK : ∀ st : BlockState,
        evalOpR R (Op.advanceBlockPtr (Op.ref .blockPtr [HEAD, BLOCK_N] "K_block_ptr")
          [(0:Nat), BLOCK_N]) st
          = evalOp (Op.advanceBlockPtr (Op.ref .blockPtr [HEAD, BLOCK_N] "K_block_ptr")
            [(0:Nat), BLOCK_N]) st := fun st => by
      simp only [evalOpR.eq_def, evalOp.eq_def]
    rw [hcollK,
      advance_col_eval _ Kreg kbase HEAD kcols HEAD BLOCK_N 1 HEAD colOff BLOCK_N
        "K_block_ptr" hk13] at hw14
    obtain rfl := Option.some.inj hw14
    rw [BlockState.setReg_ne_name _ _ _ _ _ _ _ _ (by decide), BlockState.setReg_same]
  · -- V_block_ptr advanced
    intro Vreg vbase vrows rowOff hv
    have hv14 : ((((((((((((((u.setReg "k" .real [HEAD, BLOCK_N] w1).setReg
        "v" .real [BLOCK_N, HEAD] w2).setReg "qk" .real [BLOCK_M, BLOCK_N] w3).setReg
        "qk" .real [BLOCK_M, BLOCK_N] w4).setReg "b0" .real [BLOCK_M, 1] w5).setReg
        "qk" .real [BLOCK_M, BLOCK_N] w6).setReg "m_i_new" .real [BLOCK_M] w7).setReg
        "alpha" .real [BLOCK_M] w8).setReg "p" .real [BLOCK_M, BLOCK_N] w9).setReg
        "acc" .real [BLOCK_M, HEAD] w10).setReg "acc" .real [BLOCK_M, HEAD] w11).setReg
        "l_i" .real [BLOCK_M] w12).setReg "m_i" .real [BLOCK_M] w13).setReg
        "K_block_ptr" .blockPtr [HEAD, BLOCK_N] w14).regs
          .blockPtr [BLOCK_N, HEAD] "V_block_ptr"
        = some (⟨fun _ : TileIndex [BLOCK_N, HEAD] =>
            { region := Vreg, baseOffset := vbase, parentShape := [vrows, HEAD],
              blockShape := [BLOCK_N, HEAD], strides := [HEAD, 1],
              offsets := [rowOff, 0] }⟩) := by
      iterate 14 rw [BlockState.setReg_ne_name _ _ _ _ _ _ _ _ (by decide)]
      exact hv
    have hcollV : ∀ st : BlockState,
        evalOpR R (Op.advanceBlockPtr (Op.ref .blockPtr [BLOCK_N, HEAD] "V_block_ptr")
          [BLOCK_N, (0:Nat)]) st
          = evalOp (Op.advanceBlockPtr (Op.ref .blockPtr [BLOCK_N, HEAD] "V_block_ptr")
            [BLOCK_N, (0:Nat)]) st := fun st => by
      simp only [evalOpR.eq_def, evalOp.eq_def]
    rw [hcollV,
      advance_row_eval _ Vreg vbase vrows HEAD BLOCK_N HEAD HEAD 1 rowOff BLOCK_N
        "V_block_ptr" hv14] at hw15
    obtain rfl := Option.some.inj hw15
    rw [BlockState.setReg_same]

/-! ## Small `evalOpR` value helpers (cast-free `.nat` channels) -/

private theorem akIO_evalOpR_constNat (R : RoundingModel) (n : Nat) (st : BlockState) :
    evalOpR R (Op.constNat n) st = some (Tile.scalar n) := by
  rw [show evalOpR R (Op.constNat n) st = evalOp (Op.constNat n) st from by
      simp only [evalOpR.eq_def, evalOp.eq_def], evalOp_constNat]

private theorem akIO_evalOpR_arange (R : RoundingModel) (n : Nat) (st : BlockState) :
    evalOpR R (Op.arange n) st = some (Tile.vec (fun i : Fin n => i.val)) := by
  rw [show evalOpR R (Op.arange n) st = evalOp (Op.arange n) st from by
      simp only [evalOpR.eq_def, evalOp.eq_def], evalOp_arange]

private theorem akIO_evalOpR_mul_ref_const (R : RoundingModel) (st : BlockState)
    (name : RegName) (a c : Nat)
    (hr : st.regs .nat [] name = some (Tile.scalar a)) :
    evalOpR R (Op.mul .nat Broadcast.nil (Op.ref .nat [] name) (Op.constNat c)) st
      = some (Tile.scalar (a * c)) := by
  rw [show evalOpR R (Op.mul .nat Broadcast.nil (Op.ref .nat [] name) (Op.constNat c)) st
      = evalOp (Op.mul .nat Broadcast.nil (Op.ref .nat [] name) (Op.constNat c)) st from by
      simp only [evalOpR.eq_def, evalOp.eq_def],
    evalOp_mul_ref_const st name a c hr]

private theorem akIO_evalOpR_bn1 (R : RoundingModel) (BLOCK_N BIAS_LAST_SIZE : Nat)
    (st : BlockState) :
    evalOpR R (Op.add .nat Broadcast.scalarR
        (Op.mod .nat Broadcast.scalarR (Op.arange BLOCK_N) (Op.constNat BIAS_LAST_SIZE))
        (Op.constNat BIAS_LAST_SIZE)) st
      = some (Tile.vec (fun jL : Fin BLOCK_N => jL.val % BIAS_LAST_SIZE + BIAS_LAST_SIZE)) := by
  rw [show evalOpR R (Op.add .nat Broadcast.scalarR
        (Op.mod .nat Broadcast.scalarR (Op.arange BLOCK_N) (Op.constNat BIAS_LAST_SIZE))
        (Op.constNat BIAS_LAST_SIZE)) st
      = evalOp (Op.add .nat Broadcast.scalarR
        (Op.mod .nat Broadcast.scalarR (Op.arange BLOCK_N) (Op.constNat BIAS_LAST_SIZE))
        (Op.constNat BIAS_LAST_SIZE)) st from by
      simp only [evalOpR.eq_def, evalOp.eq_def],
    ak_bn1_op_evalG st BLOCK_N BIAS_LAST_SIZE]

/-! ## Loop-body trace safety -/

set_option maxHeartbeats 600000 in
/-- Loop-body trace safety from the block-pointer and bias-register facts:
the K/V block-ptr loads and the `b0` block-column region load are the body's
only memory accesses; every other statement is register-only. -/
private theorem akIO_bodySafeR (R : RoundingModel) (bounds : RegionBounds)
    (Kreg Vreg B0 : RegionName) (BLOCK_M BLOCK_N HEAD stride_b0m : Nat)
    (kvoff kcols vrows colOff boff smbm SN : Nat) (u : BlockState)
    (hKp : u.regs .blockPtr [HEAD, BLOCK_N] "K_block_ptr"
      = some (⟨fun _ : TileIndex [HEAD, BLOCK_N] =>
          { region := Kreg, baseOffset := kvoff, parentShape := [HEAD, kcols],
            blockShape := [HEAD, BLOCK_N], strides := [1, HEAD], offsets := [0, colOff] }⟩))
    (hVp : u.regs .blockPtr [BLOCK_N, HEAD] "V_block_ptr"
      = some (⟨fun _ : TileIndex [BLOCK_N, HEAD] =>
          { region := Vreg, baseOffset := kvoff, parentShape := [vrows, HEAD],
            blockShape := [BLOCK_N, HEAD], strides := [HEAD, 1], offsets := [colOff, 0] }⟩))
    (hbo : u.regs .nat [] "b_offset" = some (Tile.scalar boff))
    (hsm : u.regs .nat [] "start_m" = some (Tile.scalar smbm))
    (hsn : u.regs .nat [] "start_n" = some (Tile.scalar SN))
    (hm : u.regs .nat [BLOCK_M] "b_ptr_offsets_m"
      = some (Tile.vec (fun r : Fin BLOCK_M => r.val)))
    (hbndK : ∀ (e : Fin HEAD) (jL : Fin BLOCK_N),
      kvoff + e.val * 1 + (colOff + jL.val) * HEAD < bounds Kreg)
    (hbndV : ∀ (jL : Fin BLOCK_N) (d : Fin HEAD),
      kvoff + (colOff + jL.val) * HEAD + d.val * 1 < bounds Vreg)
    (hbndB0 : ∀ r : Fin BLOCK_M,
      boff + (smbm * BLOCK_M + r.val) * stride_b0m + SN / BLOCK_N < bounds B0) :
    Stmt.TraceSafeListR R bounds (attnLoopBodyG B0 BLOCK_M BLOCK_N HEAD stride_b0m) u := by
  unfold attnLoopBodyG
  -- L0: the K block-ptr load
  refine Stmt.TraceSafeListR.cons_intro ?_ ?_
  · simp only [Stmt.TraceSafeR, Op.SafeAtR.eq_def, MaskOpt.ActiveR,
      MemAccess.ActiveAddressSafeR, memAccessActiveAddressSafeR]
    refine ⟨trivial, trivial, ?_⟩
    intro ptrs hptrs i _
    rw [evalOpR_ref, hKp] at hptrs
    obtain rfl := Option.some.inj hptrs
    intro _
    simp only [TileShape.blockPtr_address_2d_zero_row_offset_index]
    exact hbndK i.1 i.2.1
  · intro u1 h1
    obtain ⟨w1, -, rfl⟩ := stepStmtR_assign_inv h1
    -- L1: the V block-ptr load
    refine Stmt.TraceSafeListR.cons_intro ?_ ?_
    · simp only [Stmt.TraceSafeR, Op.SafeAtR.eq_def, MaskOpt.ActiveR,
        MemAccess.ActiveAddressSafeR, memAccessActiveAddressSafeR]
      refine ⟨trivial, trivial, ?_⟩
      intro ptrs hptrs i _
      rw [evalOpR_ref, BlockState.setReg_ne_name _ _ _ _ _ _ _ _ (by decide), hVp] at hptrs
      obtain rfl := Option.some.inj hptrs
      intro _
      simp only [TileShape.blockPtr_address_2d_row_offset_index]
      exact hbndV i.1 i.2.1
    · intro u2 h2
      obtain ⟨w2, -, rfl⟩ := stepStmtR_assign_inv h2
      -- L2: qk zeros (register-only)
      refine Stmt.TraceSafeListR.cons_intro
        (by simp [Stmt.TraceSafeR, Op.SafeAtR.eq_def]) ?_
      intro u3 h3
      obtain ⟨w3, -, rfl⟩ := stepStmtR_assign_inv h3
      -- L3: qk += dot(q, k) (register-only)
      refine Stmt.TraceSafeListR.cons_intro
        (by simp [Stmt.TraceSafeR, Op.SafeAtR.eq_def]) ?_
      intro u4 h4
      obtain ⟨w4, -, rfl⟩ := stepStmtR_assign_inv h4
      -- L4: the b0 block-column region load
      refine Stmt.TraceSafeListR.cons_intro ?_ ?_
      · simp only [Stmt.TraceSafeR, Op.SafeAtR.eq_def, MaskOpt.ActiveR,
          MemAccess.ActiveAddressSafeR, memAccessActiveAddressSafeR]
        refine ⟨by simp, trivial, ?_⟩
        intro offsets hoff i _
        have hcoll : ∀ st : BlockState,
            evalOpR R ((Op.add .nat Broadcast.scalarR
              (Op.add .nat Broadcast.scalarL (Op.ref .nat [] "b_offset")
                (Op.expandDim ⟨1, by simp⟩ (Op.mul .nat Broadcast.scalarR
                  (Op.add .nat Broadcast.scalarL
                    (Op.mul .nat Broadcast.nil (Op.ref .nat [] "start_m")
                      (Op.constNat BLOCK_M))
                    (Op.ref .nat [BLOCK_M] "b_ptr_offsets_m")) (Op.constNat stride_b0m))))
              (Op.floorDiv .nat Broadcast.nil (Op.ref .nat [] "start_n")
                (Op.constNat BLOCK_N))) : Op .nat [BLOCK_M, 1]) st
            = evalOp ((Op.add .nat Broadcast.scalarR
              (Op.add .nat Broadcast.scalarL (Op.ref .nat [] "b_offset")
                (Op.expandDim ⟨1, by simp⟩ (Op.mul .nat Broadcast.scalarR
                  (Op.add .nat Broadcast.scalarL
                    (Op.mul .nat Broadcast.nil (Op.ref .nat [] "start_m")
                      (Op.constNat BLOCK_M))
                    (Op.ref .nat [BLOCK_M] "b_ptr_offsets_m")) (Op.constNat stride_b0m))))
              (Op.floorDiv .nat Broadcast.nil (Op.ref .nat [] "start_n")
                (Op.constNat BLOCK_N))) : Op .nat [BLOCK_M, 1]) st := fun st => by
          simp only [evalOpR.eq_def, evalOp.eq_def]
        rw [hcoll, akIO_b0_addr_eval _ BLOCK_M BLOCK_N stride_b0m smbm boff SN (by simp)
          (by simp [BlockState.setReg_ne_name, hbo])
          (by simp [BlockState.setReg_ne_name, hsm])
          (by simp [BlockState.setReg_ne_name, hsn])
          (by simp [BlockState.setReg_ne_name, hm])] at hoff
        obtain rfl := Option.some.inj hoff
        simpa only [Region.cast_id] using hbndB0 i.1
      · intro u5 h5
        obtain ⟨w5, -, rfl⟩ := stepStmtR_assign_inv h5
        -- L5–L14: register-only arithmetic and pointer advances
        refine Stmt.TraceSafeListR.of_forall _ _ ?_
        intro st hst s'
        simp only [List.mem_cons, List.not_mem_nil, or_false] at hst
        rcases hst with rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl <;>
          simp [Stmt.TraceSafeR, Op.SafeAtR.eq_def]

/-! ## Kernel-level trace safety -/

set_option maxHeartbeats 600000 in
set_option maxRecDepth 8000 in
/-- **Kernel-level trace safety** for the pinned surface: assembled from the
deterministic prologue walk, the weak (success-conditional) loop safety
invariant carrying the K/V pointer closed forms and the bias registers, and
the post-loop walk. All bounds come pre-digested at the walk's spellings; no
`undef` hypothesis anywhere. -/
private theorem akIO_traceSafeR (R : RoundingModel) (hreal : R.round .real = id)
    (bounds : RegionBounds) (Q K V B0 Out : RegionName) (sm_scale : ℝ)
    (stride_qh stride_kh stride_b0h BLOCK_M BLOCK_N HEAD BIAS_LAST_SIZE stride_b0m nB : Nat)
    (s : BlockState)
    (hbQ : ∀ (i : Fin BLOCK_M) (e : Fin HEAD),
      s.pids 1 * stride_qh + (s.pids 0 * BLOCK_M + i.val) * HEAD + e.val * 1 < bounds Q)
    (hbK : ∀ (c : Nat), c % BLOCK_N = 0 → c < BLOCK_N * nB →
      ∀ (e : Fin HEAD) (jL : Fin BLOCK_N),
        s.pids 1 * stride_kh + e.val * 1 + (c + jL.val) * HEAD < bounds K)
    (hbV : ∀ (c : Nat), c % BLOCK_N = 0 → c < BLOCK_N * nB →
      ∀ (jL : Fin BLOCK_N) (d : Fin HEAD),
        s.pids 1 * stride_kh + (c + jL.val) * HEAD + d.val * 1 < bounds V)
    (hbB1 : ∀ (r : Fin BLOCK_M) (jL : Fin BLOCK_N),
      s.pids 1 * stride_b0h + (s.pids 0 * BLOCK_M + r.val) * stride_b0m
        + (jL.val % BIAS_LAST_SIZE + BIAS_LAST_SIZE) < bounds B0)
    (hbB0 : ∀ (c : Nat), c % BLOCK_N = 0 → c < BLOCK_N * nB → ∀ r : Fin BLOCK_M,
      s.pids 1 * stride_b0h + (s.pids 0 * BLOCK_M + r.val) * stride_b0m + c / BLOCK_N
        < bounds B0)
    (hbOut : ∀ (i : Fin BLOCK_M) (e : Fin HEAD),
      s.pids 1 * stride_qh + (s.pids 0 * BLOCK_M + i.val) * HEAD + e.val * 1 < bounds Out) :
    ((mathematical Q K V B0 Out sm_scale
      stride_qh HEAD 1 stride_kh HEAD 1 stride_kh HEAD 1 stride_qh HEAD 1
      stride_b0h stride_b0m 2 4 (BLOCK_N * nB) 0 BIAS_LAST_SIZE 128 HEAD BLOCK_M BLOCK_N
      FloatDType.real).toAlgKernel).TraceSafeR R bounds s := by
  unfold Kernel.TraceSafeR
  rw [akIO_body_split Q K V B0 Out sm_scale stride_qh stride_kh stride_b0h BLOCK_M BLOCK_N
    HEAD BIAS_LAST_SIZE stride_b0m nB]
  obtain ⟨s10, hpre10, hpids10, hstartm10, hoffhz10, hqoff10, hkvoff10, hQp10, hKp10, hVp10,
      hmi10, hli10, hacc10, hund10, hmem10⟩ :=
    preLoop_prefix Q K V B0 Out sm_scale stride_qh HEAD 1 stride_kh HEAD 1 stride_kh HEAD 1
      stride_qh HEAD 1 stride_b0h stride_b0m 2 4 (BLOCK_N * nB) 0 BIAS_LAST_SIZE 128 HEAD
      BLOCK_M BLOCK_N FloatDType.real s
  rw [akIO_take10 Q K V B0 Out sm_scale stride_qh stride_kh stride_b0h BLOCK_M BLOCK_N HEAD
    BIAS_LAST_SIZE stride_b0m nB] at hpre10
  refine Stmt.TraceSafeListR.append_intro _ s ?_ ?_
  · -- the 10 deterministic prologue statements are register-only
    refine Stmt.TraceSafeListR.of_forall _ _ ?_
    intro st hst s'
    simp only [akPreLoop10G, List.mem_cons, List.not_mem_nil, or_false] at hst
    rcases hst with rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl
    · simp [Stmt.TraceSafeR, Op.SafeAtR.eq_def]
    · simp [Stmt.TraceSafeR, Op.SafeAtR.eq_def]
    · simp [Stmt.TraceSafeR, Op.SafeAtR.eq_def]
    · simp [Stmt.TraceSafeR, Op.SafeAtR.eq_def]
    · -- Q_block_ptr (`makeBlockPtrDynOffsets`)
      simp only [Stmt.TraceSafeR]
      rw [Op.SafeAtR.eq_def]
      refine ⟨by simp [Op.SafeAtR.eq_def], ?_⟩
      intro off hoff
      rcases List.mem_cons.mp hoff with rfl | hoff
      · simp [Op.SafeAtR.eq_def]
      · rcases List.mem_cons.mp hoff with rfl | hoff
        · simp [Op.SafeAtR.eq_def]
        · exact absurd hoff List.not_mem_nil
    · simp [Stmt.TraceSafeR, Op.SafeAtR.eq_def]
    · simp [Stmt.TraceSafeR, Op.SafeAtR.eq_def]
    · simp [Stmt.TraceSafeR, Op.SafeAtR.eq_def]
    · simp [Stmt.TraceSafeR, Op.SafeAtR.eq_def]
    · simp [Stmt.TraceSafeR, Op.SafeAtR.eq_def]
  · intro s10' h10'
    rw [akIO_stepStmtsR_castFree_of_stmts R _
        (akIO_preLoop10_stmt_castFree R Q K V stride_qh stride_kh BLOCK_M BLOCK_N HEAD nB),
      hpre10] at h10'
    obtain rfl := Option.some.inj h10'
    simp only [attnPreLoopTailG, List.cons_append, List.nil_append]
    -- T0: qk_scale (register-only)
    refine Stmt.TraceSafeListR.cons_intro
      (by simp [Stmt.TraceSafeR, Op.SafeAtR.eq_def]) ?_
    intro u0 h0
    obtain ⟨w0, -, rfl⟩ := stepStmtR_assign_inv h0
    -- T1: the q block-ptr load
    refine Stmt.TraceSafeListR.cons_intro ?_ ?_
    · simp only [Stmt.TraceSafeR, Op.SafeAtR.eq_def, MaskOpt.ActiveR,
        MemAccess.ActiveAddressSafeR, memAccessActiveAddressSafeR]
      refine ⟨trivial, trivial, ?_⟩
      intro ptrs hptrs i _
      rw [evalOpR_ref, BlockState.setReg_ne_name _ _ _ _ _ _ _ _ (by decide), hQp10] at hptrs
      obtain rfl := Option.some.inj hptrs
      intro _
      simp only [TileShape.blockPtr_address_2d_row_offset_index]
      exact hbQ i.1 i.2.1
    · intro u1 h1
      obtain ⟨w1, -, rfl⟩ := stepStmtR_assign_inv h1
      -- T2: q scaling (register-only)
      refine Stmt.TraceSafeListR.cons_intro
        (by simp [Stmt.TraceSafeR, Op.SafeAtR.eq_def]) ?_
      intro u2 h2
      obtain ⟨w2, -, rfl⟩ := stepStmtR_assign_inv h2
      -- T3: lo = 0
      refine Stmt.TraceSafeListR.cons_intro
        (by simp [Stmt.TraceSafeR, Op.SafeAtR.eq_def]) ?_
      intro u3 h3
      obtain ⟨w3, hw3, rfl⟩ := stepStmtR_assign_inv h3
      rw [akIO_evalOpR_constNat R 0] at hw3
      obtain rfl := Option.some.inj hw3
      -- T4: hi = N_CTX + P_SEQ
      refine Stmt.TraceSafeListR.cons_intro
        (by simp [Stmt.TraceSafeR, Op.SafeAtR.eq_def]) ?_
      intro u4 h4
      obtain ⟨w4, hw4, rfl⟩ := stepStmtR_assign_inv h4
      rw [akIO_evalOpR_constNat R (BLOCK_N * nB + 0)] at hw4
      obtain rfl := Option.some.inj hw4
      -- T5: b_ptr_offsets_m = arange
      refine Stmt.TraceSafeListR.cons_intro
        (by simp [Stmt.TraceSafeR, Op.SafeAtR.eq_def]) ?_
      intro u5 h5
      obtain ⟨w5, hw5, rfl⟩ := stepStmtR_assign_inv h5
      rw [akIO_evalOpR_arange R BLOCK_M] at hw5
      obtain rfl := Option.some.inj hw5
      -- T6: b_offset = off_hz * stride_b0h
      refine Stmt.TraceSafeListR.cons_intro
        (by simp [Stmt.TraceSafeR, Op.SafeAtR.eq_def]) ?_
      intro u6 h6
      obtain ⟨w6, hw6, rfl⟩ := stepStmtR_assign_inv h6
      rw [akIO_evalOpR_mul_ref_const R _ "off_hz" (s.pids 1) stride_b0h
        (by simp [BlockState.setReg_ne_name, hoffhz10])] at hw6
      obtain rfl := Option.some.inj hw6
      -- T7: b_ptr_offsets_n_1
      refine Stmt.TraceSafeListR.cons_intro
        (by simp [Stmt.TraceSafeR, Op.SafeAtR.eq_def]) ?_
      intro u7 h7
      obtain ⟨w7, hw7, rfl⟩ := stepStmtR_assign_inv h7
      rw [akIO_evalOpR_bn1 R BLOCK_N BIAS_LAST_SIZE] at hw7
      obtain rfl := Option.some.inj hw7
      -- T8: the b1 window region load
      refine Stmt.TraceSafeListR.cons_intro ?_ ?_
      · simp only [Stmt.TraceSafeR, Op.SafeAtR.eq_def, MaskOpt.ActiveR,
          MemAccess.ActiveAddressSafeR, memAccessActiveAddressSafeR]
        refine ⟨by simp, trivial, ?_⟩
        intro offsets hoff i _
        have hcoll : ∀ st : BlockState,
            evalOpR R (Op.add .nat (Broadcast.consR (Broadcast.consL Broadcast.nil))
              (Op.add .nat Broadcast.scalarL (Op.ref .nat [] "b_offset")
                (Op.expandDim ⟨1, by simp⟩ (Op.mul .nat Broadcast.scalarR
                  (Op.add .nat Broadcast.scalarL
                    (Op.mul .nat Broadcast.nil (Op.ref .nat [] "start_m")
                      (Op.constNat BLOCK_M))
                    (Op.ref .nat [BLOCK_M] "b_ptr_offsets_m")) (Op.constNat stride_b0m))))
              (Op.expandDim ⟨0, by simp⟩ (Op.ref .nat [BLOCK_N] "b_ptr_offsets_n_1"))) st
            = evalOp (Op.add .nat (Broadcast.consR (Broadcast.consL Broadcast.nil))
              (Op.add .nat Broadcast.scalarL (Op.ref .nat [] "b_offset")
                (Op.expandDim ⟨1, by simp⟩ (Op.mul .nat Broadcast.scalarR
                  (Op.add .nat Broadcast.scalarL
                    (Op.mul .nat Broadcast.nil (Op.ref .nat [] "start_m")
                      (Op.constNat BLOCK_M))
                    (Op.ref .nat [BLOCK_M] "b_ptr_offsets_m")) (Op.constNat stride_b0m))))
              (Op.expandDim ⟨0, by simp⟩ (Op.ref .nat [BLOCK_N] "b_ptr_offsets_n_1"))) st :=
          fun st => by simp only [evalOpR.eq_def, evalOp.eq_def]
        rw [hcoll, akIO_b1_addr_eval _ BLOCK_M BLOCK_N stride_b0m BIAS_LAST_SIZE
          (s.pids 0) (s.pids 1 * stride_b0h)
          (by simp [BlockState.setReg_ne_name, BlockState.setReg_same])
          (by simp [BlockState.setReg_ne_name, hstartm10])
          (by simp [BlockState.setReg_ne_name, BlockState.setReg_same])
          (by simp [BlockState.setReg_same])] at hoff
        obtain rfl := Option.some.inj hoff
        simpa only [Region.cast_id] using hbB1 i.1 i.2.1
      · intro u8 h8
        obtain ⟨w8, -, rfl⟩ := stepStmtR_assign_inv h8
        -- the streaming forRangeDyn
        refine Stmt.TraceSafeListR.cons_intro ?_ ?_
        · simp only [Stmt.TraceSafeR]
          refine ⟨by simp [Op.SafeAtR.eq_def], by simp [Op.SafeAtR.eq_def],
            by simp [Op.SafeAtR.eq_def], ?_⟩
          simp only [evalOpR_ref, akIO_evalOpR_constNat, BlockState.setReg_ne_name,
            BlockState.setReg_same, ne_eq, String.reduceEq, not_false_eq_true, reduceCtorEq,
            and_self, and_true, true_and, Tile.scalar_data]
          refine akIO_forRangeTraceSafeR_inv R bounds "start_n" (BLOCK_N * nB + 0) BLOCK_N _
            (fun c st => c % BLOCK_N = 0 ∧ st.pids = s.pids
              ∧ st.regs .blockPtr [HEAD, BLOCK_N] "K_block_ptr"
                  = some (⟨fun _ : TileIndex [HEAD, BLOCK_N] =>
                      { region := K, baseOffset := s.pids 1 * stride_kh,
                        parentShape := [HEAD, BLOCK_N * nB + 0],
                        blockShape := [HEAD, BLOCK_N], strides := [1, HEAD],
                        offsets := [0, c] }⟩)
              ∧ st.regs .blockPtr [BLOCK_N, HEAD] "V_block_ptr"
                  = some (⟨fun _ : TileIndex [BLOCK_N, HEAD] =>
                      { region := V, baseOffset := s.pids 1 * stride_kh,
                        parentShape := [BLOCK_N * nB + 0, HEAD],
                        blockShape := [BLOCK_N, HEAD], strides := [HEAD, 1],
                        offsets := [c, 0] }⟩)
              ∧ st.regs .nat [] "b_offset" = some (Tile.scalar (s.pids 1 * stride_b0h))
              ∧ st.regs .nat [] "start_m" = some (Tile.scalar (s.pids 0))
              ∧ st.regs .nat [BLOCK_M] "b_ptr_offsets_m"
                  = some (Tile.vec (fun r : Fin BLOCK_M => r.val)))
            ?_ 0 _ ?_
          · intro c st hc hP
            obtain ⟨hcmod, hstpids, hkc, hvc, hboP, hsmP, hmP⟩ := hP
            constructor
            · refine akIO_bodySafeR R bounds K V B0 BLOCK_M BLOCK_N HEAD stride_b0m
                (s.pids 1 * stride_kh) (BLOCK_N * nB + 0) (BLOCK_N * nB + 0) c
                (s.pids 1 * stride_b0h) (s.pids 0) c _
                (by simp [BlockState.setReg_ne_name, hkc])
                (by simp [BlockState.setReg_ne_name, hvc])
                (by simp [BlockState.setReg_ne_name, hboP])
                (by simp [BlockState.setReg_ne_name, hsmP])
                (by simp [BlockState.setReg_same])
                (by simp [BlockState.setReg_ne_name, hmP])
                (fun e jL => hbK c hcmod (by omega) e jL)
                (fun jL d => hbV c hcmod (by omega) jL d)
                (fun r => hbB0 c hcmod (by omega) r)
            · intro st' hrun
              obtain ⟨hp1, hp2, hp3, hp4, hp5, hpK, hpV⟩ :=
                akIO_bodyR_inv R B0 BLOCK_M BLOCK_N HEAD stride_b0m hrun
              refine ⟨?_, ?_, ?_, ?_, ?_, ?_, ?_⟩
              · rw [Nat.add_mod_right]; exact hcmod
              · rw [hp1, BlockState.setReg_pids]; exact hstpids
              · exact hpK K (s.pids 1 * stride_kh) (BLOCK_N * nB + 0) c
                  (by simp [BlockState.setReg_ne_name, hkc])
              · exact hpV V (s.pids 1 * stride_kh) (BLOCK_N * nB + 0) c
                  (by simp [BlockState.setReg_ne_name, hvc])
              · rw [hp4, BlockState.setReg_ne_name _ _ _ _ _ _ _ _ (by decide)]; exact hboP
              · rw [hp3, BlockState.setReg_ne_name _ _ _ _ _ _ _ _ (by decide)]; exact hsmP
              · rw [hp5, BlockState.setReg_ne_name _ _ _ _ _ _ _ _ (by decide)]; exact hmP
          · refine ⟨Nat.zero_mod _, ?_, ?_, ?_, ?_, ?_, ?_⟩
            · simp only [BlockState.setReg_pids]; exact hpids10
            · simp [BlockState.setReg_ne_name, hKp10]
            · simp [BlockState.setReg_ne_name, hVp10]
            · simp [BlockState.setReg_ne_name, BlockState.setReg_same]
            · simp [BlockState.setReg_ne_name, hstartm10]
            · simp [BlockState.setReg_ne_name, BlockState.setReg_same]
        · intro s2 hs2
          simp only [stepStmtR, evalOpR_ref, akIO_evalOpR_constNat,
            BlockState.setReg_ne_name, BlockState.setReg_same, ne_eq, String.reduceEq,
            not_false_eq_true, reduceCtorEq, and_self, and_true, true_and,
            Option.bind_eq_bind, Option.bind_some, Tile.scalar_data] at hs2
          have hexit : s2.pids = s.pids
              ∧ s2.regs .nat [] "q_offset" = some (Tile.scalar (s.pids 1 * stride_qh))
              ∧ s2.regs .nat [] "start_m" = some (Tile.scalar (s.pids 0)) := by
            refine akIO_forRangeAuxR_exit R "start_n" (BLOCK_N * nB + 0) BLOCK_N
              (attnLoopBodyG B0 BLOCK_M BLOCK_N HEAD stride_b0m)
              (fun st => st.pids = s.pids
                ∧ st.regs .nat [] "q_offset" = some (Tile.scalar (s.pids 1 * stride_qh))
                ∧ st.regs .nat [] "start_m" = some (Tile.scalar (s.pids 0)))
              ?_ 0 _ s2 ?_ hs2
            · intro c st st' hP' hrun
              obtain ⟨hp1, hp2, hp3, -, -, -, -⟩ :=
                akIO_bodyR_inv R B0 BLOCK_M BLOCK_N HEAD stride_b0m hrun
              refine ⟨?_, ?_, ?_⟩
              · rw [hp1, BlockState.setReg_pids]; exact hP'.1
              · rw [hp2, BlockState.setReg_ne_name _ _ _ _ _ _ _ _ (by decide)]
                exact hP'.2.1
              · rw [hp3, BlockState.setReg_ne_name _ _ _ _ _ _ _ _ (by decide)]
                exact hP'.2.2
            · refine ⟨?_, ?_, ?_⟩
              · simp only [BlockState.setReg_pids]; exact hpids10
              · simp [BlockState.setReg_ne_name, hqoff10]
              · simp [BlockState.setReg_ne_name, hstartm10]
          obtain ⟨hpids2, hqo2, hsm2⟩ := hexit
          -- the post-loop
          simp only [attnPostLoopG]
          refine Stmt.TraceSafeListR.cons_intro
            (by simp [Stmt.TraceSafeR, Op.SafeAtR.eq_def]) ?_
          intro v1 hv1
          obtain ⟨x1, -, rfl⟩ := stepStmtR_assign_inv hv1
          refine Stmt.TraceSafeListR.cons_intro ?_ ?_
          · simp only [Stmt.TraceSafeR]
            rw [Op.SafeAtR.eq_def]
            refine ⟨by simp [Op.SafeAtR.eq_def], ?_⟩
            intro off hoff
            rcases List.mem_cons.mp hoff with rfl | hoff
            · simp [Op.SafeAtR.eq_def]
            · rcases List.mem_cons.mp hoff with rfl | hoff
              · simp [Op.SafeAtR.eq_def]
              · exact absurd hoff List.not_mem_nil
          · intro v2 hv2
            obtain ⟨x2, hx2, rfl⟩ := stepStmtR_assign_inv hv2
            rw [akIO_evalOpR_mbpdo_castFree R Out (Op.ref .nat [] "q_offset")
                [BLOCK_N * nB, HEAD] [BLOCK_M, HEAD] [HEAD, 1]
                [Op.mul .nat Broadcast.nil (Op.ref .nat [] "start_m") (Op.constNat BLOCK_M),
                  Op.constNat 0] _
                (by simp only [evalOpR.eq_def, evalOp.eq_def])
                (by
                  intro o ho
                  simp only [List.mem_cons, List.not_mem_nil, or_false] at ho
                  rcases ho with rfl | rfl <;> simp only [evalOpR.eq_def, evalOp.eq_def]),
              makeBlockPtr_rowcol_eval Out (Op.ref .nat [] "q_offset") [BLOCK_N * nB, HEAD]
                [BLOCK_M, HEAD] [HEAD, 1]
                (Op.mul .nat Broadcast.nil (Op.ref .nat [] "start_m") (Op.constNat BLOCK_M)) _
                (s.pids 1 * stride_qh) (s.pids 0 * BLOCK_M)
                (by rw [evalOp_ref]; simp [BlockState.setReg_ne_name, hqo2])
                (evalOp_mul_ref_const _ "start_m" (s.pids 0) BLOCK_M
                  (by simp [BlockState.setReg_ne_name, hsm2]))] at hx2
            obtain rfl := Option.some.inj hx2
            refine Stmt.TraceSafeListR.cons_intro ?_
              (fun _ _ => Stmt.TraceSafeListR.nil_intro)
            simp only [Stmt.TraceSafeR, Op.SafeAtR.eq_def, MaskOpt.ActiveR,
              MemAccess.SafeAtR, MaskOpt.SafeAtR, MemAccess.ActiveAddressSafeR,
              memAccessActiveAddressSafeR]
            refine ⟨trivial, trivial, trivial, ?_⟩
            intro ptrs hptrs i _
            rw [evalOpR_ref, BlockState.setReg_same] at hptrs
            obtain rfl := Option.some.inj hptrs
            intro _
            simp only [TileShape.blockPtr_address_2d_row_offset_index]
            exact hbOut i.1 i.2.1

/-! ## Frame walk (memory outside the `Out` window is untouched) -/

/-- `acc /= l_i[:, None]` eval at abstract register tiles. -/
private theorem akIO_div_eval (st : BlockState) (BM HD : Nat)
    (aT : Tile .real [BM, HD]) (lT : Tile .real [BM])
    (hacc : st.regs .real [BM, HD] "acc" = some aT)
    (hli : st.regs .real [BM] "l_i" = some lT) :
    evalOp (Op.div .real (Broadcast.consSame (Broadcast.consR Broadcast.nil))
      (Op.ref .real [BM, HD] "acc")
      (Op.expandDim ⟨1, by simp⟩ (Op.ref .real [BM] "l_i"))) st
      = some (Tile.bop NumericDType.real.div (Broadcast.consSame (Broadcast.consR Broadcast.nil))
          aT (Tile.expandDim ⟨1, by simp⟩ lT)) := by
  have hexp : @evalOp TileDType.real [BM, 1]
      (Op.expandDim ⟨1, by simp⟩ (Op.ref .real [BM] "l_i")) st
      = some (Tile.expandDim ⟨1, by simp⟩ lT) :=
    evalOp_expandDim_ref_of_regs _ _ _ _ _ _ hli
  rw [evalOp_div]
  simp only [evalOp_ref, hacc, hexp, Option.bind_eq_bind, Option.bind_some]
  rfl

set_option maxHeartbeats 1000000 in
set_option maxRecDepth 8000 in
/-- **Post-loop frame walk.** Re-runs the `attn_postLoopG` store walk from
the loop-exit invariant, exposing the memory footprint: every cell outside
the `Out` tile window is untouched. -/
private theorem akIO_postLoop_frameG (Q K V B0 Out : RegionName) (s0 : BlockState)
    (sm_scale : ℝ)
    (BLOCK_M BLOCK_N HEAD BIAS_LAST_SIZE stride_b0m q_offset kv_offset b_offset nB : Nat)
    (st : BlockState)
    (hinv : attnKernelInvariant s0 Q K V B0 Out sm_scale q_offset kv_offset b_offset
        BLOCK_M BLOCK_N HEAD 0 BIAS_LAST_SIZE stride_b0m 1 HEAD HEAD 1 nB (s0.pids 0)
        (BLOCK_N * nB) st) :
    ∃ sfin, stepStmts (attnPostLoopG Out BLOCK_M HEAD (BLOCK_N * nB) HEAD 1) st = some sfin
      ∧ ∀ (r : RegionName) (o : Nat),
          (r = Out → ∀ idx : TileIndex [BLOCK_M, HEAD],
            o ≠ q_offset + (s0.pids 0 * BLOCK_M + idx.1.val) * HEAD + idx.2.1.val * 1) →
          sfin.mem r o = st.mem r o := by
  simp only [attnKernelInvariant] at hinv
  obtain ⟨hpids, hieq, hcle, hmi, hli, hacc, hKp, hVp, hq, hb1, hbo, hsm, hqo, hm,
    hundef, hmem⟩ := hinv
  obtain ⟨aT, hacc'⟩ : ∃ t, st.regs .real [BLOCK_M, HEAD] "acc" = some t := ⟨_, hacc⟩
  obtain ⟨lT, hli'⟩ : ∃ t, st.regs .real [BLOCK_M] "l_i" = some t := ⟨_, hli⟩
  set accD : Tile .real [BLOCK_M, HEAD] := Tile.bop NumericDType.real.div
    (Broadcast.consSame (Broadcast.consR Broadcast.nil)) aT
    (Tile.expandDim ⟨1, by simp⟩ lT) with haccD
  set oOffFn : TileIndex [BLOCK_M, HEAD] → Nat :=
    fun idx => q_offset + (s0.pids 0 * BLOCK_M + idx.1.val) * HEAD + idx.2.1.val * 1
    with hoOffFn
  set oValFn : TileIndex [BLOCK_M, HEAD] → TileCarrier TileDType.real :=
    fun idx => FloatDType.real.cast FloatDType.real (accD.data idx) with hoValFn
  unfold attnPostLoopG
  rw [stepStmts.cons_some (stepStmt_assign_eq_some
    (akIO_div_eval st BLOCK_M HEAD aT lT hacc' hli'))]
  rw [stepStmts.cons_some (stepStmt_assign_eq_some
    (makeBlockPtr_rowcol_eval Out (Op.ref .nat [] "q_offset") [BLOCK_N * nB, HEAD]
      [BLOCK_M, HEAD] [HEAD, 1]
      (Op.mul .nat Broadcast.nil (Op.ref .nat [] "start_m") (Op.constNat BLOCK_M))
      (st.setReg "acc" .real [BLOCK_M, HEAD] accD)
      q_offset (s0.pids 0 * BLOCK_M)
      (by rw [evalOp_ref]; simp [BlockState.setReg_ne_name, hqo])
      (evalOp_mul_ref_const _ "start_m" (s0.pids 0) BLOCK_M
        (by simp [BlockState.setReg_ne_name, hsm]))))]
  set st2 := (st.setReg "acc" .real [BLOCK_M, HEAD] accD).setReg "O_block_ptr" .blockPtr
      [BLOCK_M, HEAD]
      ⟨fun _ : TileIndex [BLOCK_M, HEAD] =>
        { region := Out, baseOffset := q_offset, parentShape := [BLOCK_N * nB, HEAD],
          blockShape := [BLOCK_M, HEAD], strides := [HEAD, 1],
          offsets := [s0.pids 0 * BLOCK_M, 0] }⟩
    with hst2
  have hOpref : @evalOp TileDType.blockPtr [BLOCK_M, HEAD]
      (Op.ref .blockPtr [BLOCK_M, HEAD] "O_block_ptr") st2
      = some (⟨fun _ : TileIndex [BLOCK_M, HEAD] =>
          { region := Out, baseOffset := q_offset, parentShape := [BLOCK_N * nB, HEAD],
            blockShape := [BLOCK_M, HEAD], strides := [HEAD, 1],
            offsets := [s0.pids 0 * BLOCK_M, 0] }⟩ : Tile .blockPtr [BLOCK_M, HEAD]) := by
    rw [evalOp_ref, hst2, BlockState.setReg_same]
  have haccref : @evalOp TileDType.real [BLOCK_M, HEAD]
      (Op.ref .real [BLOCK_M, HEAD] "acc") st2 = some accD := by
    rw [evalOp_ref, hst2, BlockState.setReg_ne_name _ _ _ _ _ _ _ _ (by decide),
      BlockState.setReg_same]
  have hval : evalOp ((Op.ref .real [BLOCK_M, HEAD] "acc")) st2
      = some (⟨oValFn⟩ : Tile .real [BLOCK_M, HEAD]) := by
    erw [haccref]; rfl
  have hstore : stepStmt (Stmt.store .real [BLOCK_M, HEAD]
      (MemAccess.blockPtr (Op.ref .blockPtr [BLOCK_M, HEAD] "O_block_ptr") [])
      ((Op.ref .real [BLOCK_M, HEAD] "acc")) MaskOpt.none) st2
      = some ((TileShape.allIndices [BLOCK_M, HEAD]).foldl
          (fun acc idx => acc.writeMemTyped .real Out (oOffFn idx) (oValFn idx)) st2) := by
    unfold stepStmt
    erw [hval]
    simp only [Option.bind_eq_bind, Option.bind_some, Option.map_some]
    erw [hOpref]
    simp only [Option.bind_eq_bind, Option.bind_some, Option.map_some]
    refine congrArg some ?_
    refine List.foldl_ext _ _ st2 ?_
    intro acc idx _
    simp only [TileShape.blockPtr_inBounds_nil_index, Bool.and_true, Bool.true_and,
      TileShape.blockPtr_address_2d_row_offset_index, hoOffFn, if_true]
  rw [stepStmts.cons_some hstore, stepStmts.nil]
  refine ⟨_, rfl, ?_⟩
  intro r o hg
  have h32 : ((TileShape.allIndices [BLOCK_M, HEAD]).foldl
      (fun acc idx => acc.writeMemTyped .real Out (oOffFn idx) (oValFn idx)) st2).mem r o
      = st2.mem r o := by
    by_cases hr : r = Out
    · subst hr
      refine foldl_writeMemTyped_real_preserves' oOffFn oValFn o _ st2 ?_
      intro k _ heq
      exact hg rfl k heq.symm
    · exact akIO_foldl_real_other_region oOffFn oValFn r hr o _ st2
  rw [h32, hst2]
  simp only [BlockState.setReg_mem]

set_option maxHeartbeats 1000000 in
set_option maxRecDepth 8000 in
/-- **Full execution with frame.** The `attention_kernel_exec_general`
composition re-run with `akIO_postLoop_frameG` in the tail: the lowered body
reaches a final state whose memory agrees with the initial state outside the
`Out` write window. (Values are *not* restated — `exec` is deterministic, so
both walks describe the same final state.) -/
private theorem akIO_exec_frameG (Q K V B0 Out : RegionName) (s : BlockState) (sm_scale : ℝ)
    (stride_qh stride_kh stride_b0h BLOCK_M BLOCK_N HEAD BIAS_LAST_SIZE stride_b0m nB : Nat)
    (hKN : 0 < BLOCK_N) (hBM : 0 < BLOCK_M) (hHD : 0 < HEAD) (hnB : 1 ≤ nB)
    (hundef : ∀ rg o, s.undef rg o = 0) :
    ∃ sF, stepStmts (mathematical Q K V B0 Out sm_scale
        stride_qh HEAD 1 stride_kh HEAD 1 stride_kh HEAD 1 stride_qh HEAD 1
        stride_b0h stride_b0m 2 4 (BLOCK_N * nB) 0 BIAS_LAST_SIZE 128 HEAD BLOCK_M BLOCK_N
        FloatDType.real).toAlgKernel.body s = some sF
      ∧ ∀ (r : RegionName) (o : Nat),
          (r = Out → ∀ idx : TileIndex [BLOCK_M, HEAD],
            o ≠ s.pids 1 * stride_qh + (s.pids 0 * BLOCK_M + idx.1.val) * HEAD
              + idx.2.1.val * 1) →
          sF.mem r o = s.mem r o := by
  rw [← List.take_append_drop 19 (mathematical Q K V B0 Out
      sm_scale stride_qh HEAD 1 stride_kh HEAD 1 stride_kh HEAD 1 stride_qh HEAD 1
      stride_b0h stride_b0m 2 4 (BLOCK_N * nB) 0 BIAS_LAST_SIZE 128 HEAD BLOCK_M BLOCK_N
      FloatDType.real).toAlgKernel.body]
  obtain ⟨s0, hpre, hlo, hhi, hinv0⟩ := preLoopG Q K V B0 Out s sm_scale
    stride_qh stride_kh stride_b0h BLOCK_M BLOCK_N HEAD 0 BIAS_LAST_SIZE stride_b0m nB hundef
  rw [stepStmts.append_some hpre]
  rw [attnLoopBodyG_check Q K V B0 Out sm_scale
        stride_qh HEAD 1 stride_kh HEAD 1 stride_kh HEAD 1 stride_qh HEAD 1
        stride_b0h stride_b0m 2 4 (BLOCK_N * nB) 0 BIAS_LAST_SIZE 128 HEAD BLOCK_M BLOCK_N,
    show (mathematical Q K V B0 Out sm_scale
        stride_qh HEAD 1 stride_kh HEAD 1 stride_kh HEAD 1 stride_qh HEAD 1
        stride_b0h stride_b0m 2 4 (BLOCK_N * nB) 0 BIAS_LAST_SIZE 128 HEAD BLOCK_M BLOCK_N
        FloatDType.real).toAlgKernel.body.drop 20
      = attnPostLoopG Out BLOCK_M HEAD (BLOCK_N * nB) HEAD 1 from by
      have := attnPostLoopG_check Q K V B0 Out sm_scale
        stride_qh HEAD 1 stride_kh HEAD 1 stride_kh HEAD 1 stride_qh HEAD 1
        stride_b0h stride_b0m 2 4 (BLOCK_N * nB) 0 BIAS_LAST_SIZE 128 HEAD BLOCK_M BLOCK_N
      simpa using this]
  obtain ⟨final, sL, hloop, hfin, hinvL⟩ :=
    forRangeDyn_inv (idx := "start_n")
      (startOp := Op.ref .nat [] "lo") (stopOp := Op.ref .nat [] "hi")
      (stepOp := Op.constNat BLOCK_N)
      (P := fun i stx => attnKernelInvariant s Q K V B0 Out sm_scale
        (s.pids 1 * stride_qh) (s.pids 1 * stride_kh) (s.pids 1 * stride_b0h)
        BLOCK_M BLOCK_N HEAD 0 BIAS_LAST_SIZE stride_b0m 1 HEAD HEAD 1 nB (s.pids 0) i stx)
      (s_init := s0)
      (by rw [evalOp_ref, hlo])
      (by rw [evalOp_ref, hhi])
      (by rw [evalOp_constNat])
      (by omega)
      hinv0
      (fun i stx hi hP => attn_stepG Q K V B0 Out s sm_scale BLOCK_M BLOCK_N HEAD 0
        BIAS_LAST_SIZE stride_b0m hKN
        (s.pids 1 * stride_qh) (s.pids 1 * stride_kh) (s.pids 1 * stride_b0h) nB i stx
        (by omega) hP)
  rw [stepStmts.cons_some hloop]
  have hfinal : final = BLOCK_N * nB := by
    obtain ⟨_, hmod, hle, _⟩ := hinvL
    rw [Nat.add_zero] at hfin
    have hub : final ≤ BLOCK_N * nB := by
      calc final = final / BLOCK_N * BLOCK_N := hmod
        _ ≤ nB * BLOCK_N := Nat.mul_le_mul_right _ hle
        _ = BLOCK_N * nB := Nat.mul_comm _ _
    omega
  subst hfinal
  obtain ⟨sP, hpost, hframe⟩ := akIO_postLoop_frameG Q K V B0 Out s sm_scale
    BLOCK_M BLOCK_N HEAD BIAS_LAST_SIZE stride_b0m
    (s.pids 1 * stride_qh) (s.pids 1 * stride_kh) (s.pids 1 * stride_b0h) nB sL hinvL
  refine ⟨sP, hpost, ?_⟩
  intro r o hg
  have hmemL : sL.mem = s.mem := by
    simp only [attnKernelInvariant] at hinvL
    obtain ⟨-, -, -, -, -, -, -, -, -, -, -, -, -, -, -, hmem⟩ := hinvL
    exact hmem
  calc sP.mem r o = sL.mem r o := hframe r o hg
    _ = s.mem r o := by rw [hmemL]

/-! ## IO signature, stream tiles, and the closed-form spec `f`

Window transcription (strides pinned to the general stack's contiguous
layout `stride_qm = stride_kn = stride_vk = stride_om = HEAD`, unit fastest
stride, `N_CTX = BLOCK_N·nB`, `P_SEQ = 0`):

* `read1` (`Q`, **static** stream — the window ignores `t`): lane
  `j = (i, e)` row-major over `[BLOCK_M, HEAD]` reads the `Q_block_ptr` cell
  `pid₁·stride_qh + (pid₀·BM + i)·HEAD + e`.
* `read2` (`K`, transposed `[HEAD, BLOCK_N]` tile advanced one column block
  per step): lane `j = (e, jL)` reads `pid₁·stride_kh + e + (t·BN + jL)·HEAD`.
* `read3` (`V`, `[BLOCK_N, HEAD]` tile advanced one row block per step):
  lane `j = (jL, d)` reads `pid₁·stride_kh + (t·BN + jL)·HEAD + d`.
* `read4` (`B0`, the **two-window lane pack** over `[BLOCK_M, BLOCK_N+1]`):
  columns `col < BLOCK_N` are the prologue `b1` window (`t`-free):
  `pid₁·stride_b0h + (pid₀·BM + r)·stride_b0m + (col % BIAS + BIAS)`;
  column `col = BLOCK_N` is the in-loop `b0` block column (`t`-dependent):
  `… + t`. One buffer, two windows — never two channels aliasing one region.
* `write` (`Out` via the unmasked `O_block_ptr` store): lane `(i, e)` writes
  `pid₁·stride_qh + (pid₀·BM + i)·HEAD + e·1`.

All loads and the terminal store are unmasked, so every mask is `True`; the
trip count `T = nB` is pid-free. -/

/-- **Streaming IO signature** of `_fwd_kernel_aligned` on the four-stream
single-output attention fold skin. -/
def attentionKernelIO (Q K V B0 Out : RegionName) (sm_scale : ℝ)
    (stride_qh stride_kh stride_b0h BLOCK_M BLOCK_N HEAD BIAS_LAST_SIZE stride_b0m nB : Nat) :
    StreamMasked3DKernelIO₄ where
  kernel := mathematical Q K V B0 Out sm_scale
    stride_qh HEAD 1 stride_kh HEAD 1 stride_kh HEAD 1 stride_qh HEAD 1
    stride_b0h stride_b0m 2 4 (BLOCK_N * nB) 0 BIAS_LAST_SIZE 128 HEAD BLOCK_M BLOCK_N
    FloatDType.real
  projection := by
    apply supported_projection
    apply mathematical_toAlgorithm_supported
  inp1 := Q
  inp2 := K
  inp3 := V
  inp4 := B0
  out := Out
  T := nB
  B1 := BLOCK_M * HEAD
  B2 := HEAD * BLOCK_N
  B3 := BLOCK_N * HEAD
  B4 := BLOCK_M * (BLOCK_N + 1)
  C := BLOCK_M * HEAD
  outDType := .real
  read1 := fun p₀ p₁ _ _ j =>
    p₁ * stride_qh + (p₀ * BLOCK_M + j.val / HEAD) * HEAD + j.val % HEAD
  read2 := fun _ p₁ _ t j =>
    p₁ * stride_kh + j.val / BLOCK_N + (t.val * BLOCK_N + j.val % BLOCK_N) * HEAD
  read3 := fun _ p₁ _ t j =>
    p₁ * stride_kh + (t.val * BLOCK_N + j.val / HEAD) * HEAD + j.val % HEAD
  read4 := fun p₀ p₁ _ t j =>
    p₁ * stride_b0h + (p₀ * BLOCK_M + j.val / (BLOCK_N + 1)) * stride_b0m +
      (if j.val % (BLOCK_N + 1) < BLOCK_N then
        j.val % (BLOCK_N + 1) % BIAS_LAST_SIZE + BIAS_LAST_SIZE
      else t.val)
  write := fun p₀ p₁ _ j =>
    p₁ * stride_qh + (p₀ * BLOCK_M + j.val / HEAD) * HEAD + (j.val % HEAD) * 1
  mask1 := fun _ _ _ _ _ => True
  mask2 := fun _ _ _ _ _ => True
  mask3 := fun _ _ _ _ _ => True
  mask4 := fun _ _ _ _ _ => True
  writeMask := fun _ _ _ _ => True

/-- The `Q` tile off the (static) first stream — the window ignores `t`, so
the step-`0` slice carries the whole tile (`0` off the empty stream when
`nB = 0`; the headline's `1 ≤ nB` excludes this). -/
noncomputable def akIOqT (T BM HD : Nat) (xs : Fin T → Fin (BM * HD) → ℝ) :
    TileIndex [BM, HD] → ℝ :=
  fun idx => if h : 0 < T then xs ⟨0, h⟩ (Lane2D.encode idx) else 0

/-- The flat per-key `K` function off the transposed `[HEAD, BLOCK_N]` step
tiles: global key `gj` lives in step `gj / BN` at block-local column
`gj % BN`. -/
noncomputable def akIOkT (T HD BN : Nat) (ys : Fin T → Fin (HD * BN) → ℝ) :
    Fin HD → Fin (BN * T) → ℝ :=
  fun e gj =>
    if h : gj.val / BN < T ∧ 0 < BN then
      ys ⟨gj.val / BN, h.1⟩
        (Lane2D.encode (e, ⟨gj.val % BN, Nat.mod_lt _ h.2⟩, PUnit.unit))
    else 0

/-- The flat `V` value tile off the `[BLOCK_N, HEAD]` step tiles. -/
noncomputable def akIOvT (T BN HD : Nat) (zs : Fin T → Fin (BN * HD) → ℝ) :
    TileIndex [BN * T, HD] → ℝ :=
  fun idx =>
    if h : idx.1.val / BN < T ∧ 0 < BN then
      zs ⟨idx.1.val / BN, h.1⟩
        (Lane2D.encode (⟨idx.1.val % BN, Nat.mod_lt _ h.2⟩, idx.2.1, PUnit.unit))
    else 0

/-- Per-row block-column bias `b0` off the packed fourth stream (column
`BLOCK_N` of the `[BLOCK_M, BLOCK_N+1]` lane pack at step `c`). -/
noncomputable def akIOb0T (T BM BN : Nat) (ws : Fin T → Fin (BM * (BN + 1)) → ℝ)
    (r : Fin BM) (c : Nat) : ℝ :=
  if h : c < T then
    ws ⟨c, h⟩ (Lane2D.encode (r, ⟨BN, Nat.lt_succ_self BN⟩, PUnit.unit))
  else 0

/-- Per-row per-lane bias `b1` off the packed fourth stream (the static
columns `< BLOCK_N`, read at step 0). -/
noncomputable def akIOb1T (T BM BN : Nat) (ws : Fin T → Fin (BM * (BN + 1)) → ℝ)
    (r : Fin BM) (jL : Nat) : ℝ :=
  if h : 0 < T ∧ jL < BN then
    ws ⟨0, h.1⟩ (Lane2D.encode (r, ⟨jL, Nat.lt_succ_of_lt h.2⟩, PUnit.unit))
  else 0

/-- **Stream-side genuine per-key score** (the tile-parametric twin of
`ClosedForm.fscore`): `(sm_scale·log₂e)·⟨q_r, k_gj⟩ + (b0 + b1)·log₂e`, with
the `qk_scale` factor folded into the dot exactly as the kernel folds it into
the pre-scaled `q`. -/
noncomputable def akIOscoreT (T BM BN HD : Nat) (sm_scale : ℝ)
    (xs : Fin T → Fin (BM * HD) → ℝ) (ys : Fin T → Fin (HD * BN) → ℝ)
    (ws : Fin T → Fin (BM * (BN + 1)) → ℝ)
    (r : Fin BM) (gj : Fin (BN * T)) : ℝ :=
  (sm_scale * 1.44269504) *
      Finset.univ.sum (fun e : Fin HD =>
        akIOqT T BM HD xs (r, e, PUnit.unit) * akIOkT T HD BN ys e gj)
    + (akIOb0T T BM BN ws r (gj.val / BN) + akIOb1T T BM BN ws r (gj.val % BN))
      * 1.44269504

end IOFace

/-! Complete IO correctness. -/

section IOHeadline

open scoped VeriTile.Triton.StreamMasked3DKernelIO₄
open ClosedForm

set_option maxHeartbeats 600000 in
set_option maxRecDepth 8000 in
/-- Successful flat execution, the bias-attention formula and the memory
frame on the real channel. The final contract instantiates the internal adapter
at identity rounding. Positive dimensions support block maxima and output-lane
decoding; at least one key block supplies the static Q/b1 windows. -/
theorem attention_kernel_io_correctness (R : RoundingModel)
    (hreal : R.round .real = id)
    (Q K V B0 Out : RegionName) (sm_scale : ℝ)
    (stride_qh stride_kh stride_b0h BLOCK_M BLOCK_N HEAD BIAS_LAST_SIZE stride_b0m nB : Nat)
    (hBM : 0 < BLOCK_M) (hBN : 0 < BLOCK_N) (hHD : 0 < HEAD) (hnB : 1 ≤ nB) :
    attentionKernelIO Q K V B0 Out sm_scale stride_qh stride_kh stride_b0h
        BLOCK_M BLOCK_N HEAD BIAS_LAST_SIZE stride_b0m nB ⊨[R]
      fun _ _ _ xs ys zs ws j =>
        attnGenScore (akIOscoreT nB BLOCK_M BLOCK_N HEAD sm_scale xs ys ws)
          (akIOvT nB BLOCK_N HEAD zs) (Lane2D.decode j) := by
  refine StreamMasked3DKernelIO₄.ImplementsR.intro _ ?_ ?_ ?_
  · exact akIO_flattenOk Q K V B0 Out sm_scale stride_qh stride_kh stride_b0h
      BLOCK_M BLOCK_N HEAD BIAS_LAST_SIZE stride_b0m nB
  · -- the trace-safety walk
    intro bounds st xs ys zs ws _hx1 _hx2 _hx3 _hx4 hbr1 hbr2 hbr3 hbr4 hbw
    simp only [attentionKernelIO] at hbr1 hbr2 hbr3 hbr4 hbw ⊢
    have hT0 : 0 < nB := hnB
    refine akIO_traceSafeR R hreal bounds Q K V B0 Out sm_scale stride_qh stride_kh
      stride_b0h BLOCK_M BLOCK_N HEAD BIAS_LAST_SIZE stride_b0m nB st ?_ ?_ ?_ ?_ ?_ ?_
    · -- Q window
      intro i e
      have := hbr1 ⟨0, hT0⟩ (Lane2D.encode (i, e, PUnit.unit)) trivial
      simpa using this
    · -- K window
      intro c hcmod hclt e jL
      have ht : c / BLOCK_N < nB :=
        (Nat.div_lt_iff_lt_mul hBN).mpr (by rw [Nat.mul_comm nB BLOCK_N]; exact hclt)
      have := hbr2 ⟨c / BLOCK_N, ht⟩ (Lane2D.encode (e, jL, PUnit.unit)) trivial
      rw [Nat.div_mul_cancel (Nat.dvd_of_mod_eq_zero hcmod)] at this
      simpa using this
    · -- V window
      intro c hcmod hclt jL d
      have ht : c / BLOCK_N < nB :=
        (Nat.div_lt_iff_lt_mul hBN).mpr (by rw [Nat.mul_comm nB BLOCK_N]; exact hclt)
      have := hbr3 ⟨c / BLOCK_N, ht⟩ (Lane2D.encode (jL, d, PUnit.unit)) trivial
      rw [Nat.div_mul_cancel (Nat.dvd_of_mod_eq_zero hcmod)] at this
      simpa using this
    · -- b1 window (columns < BLOCK_N of the pack)
      intro r jL
      have := hbr4 ⟨0, hT0⟩
        (Lane2D.encode (r, ⟨jL.val, Nat.lt_succ_of_lt jL.isLt⟩, PUnit.unit)) trivial
      simp only [Lane2D.encode_div, Lane2D.encode_mod] at this
      rw [if_pos jL.isLt] at this
      exact this
    · -- b0 window (column BLOCK_N of the pack)
      intro c hcmod hclt r
      have ht : c / BLOCK_N < nB :=
        (Nat.div_lt_iff_lt_mul hBN).mpr (by rw [Nat.mul_comm nB BLOCK_N]; exact hclt)
      have := hbr4 ⟨c / BLOCK_N, ht⟩
        (Lane2D.encode (r, ⟨BLOCK_N, Nat.lt_succ_self BLOCK_N⟩, PUnit.unit)) trivial
      simp only [Lane2D.encode_div, Lane2D.encode_mod] at this
      rw [if_neg (lt_irrefl BLOCK_N)] at this
      exact this
    · -- Out window
      intro i e
      have := hbw (Lane2D.encode (i, e, PUnit.unit)) trivial
      simpa using this
  · -- the region-model triple
    intro s₀ xs ys zs ws hu hx hy hz hw
    simp only [attentionKernelIO] at hx hy hz hw ⊢
    have hT0 : 0 < nB := hnB
    have hundef' : ∀ rg o, s₀.undef rg o = 0 := fun rg o => by rw [hu]
    obtain ⟨sFv, hexecv, hOv⟩ := attention_kernel_exec_general Q K V B0 Out s₀ sm_scale
      stride_qh stride_kh stride_b0h BLOCK_M BLOCK_N HEAD BIAS_LAST_SIZE stride_b0m nB
      hBN hBM hHD hnB hundef'
    obtain ⟨sF, hstepF, hframeF⟩ := akIO_exec_frameG Q K V B0 Out s₀ sm_scale
      stride_qh stride_kh stride_b0h BLOCK_M BLOCK_N HEAD BIAS_LAST_SIZE stride_b0m nB
      hBN hBM hHD hnB hundef'
    obtain rfl : sFv = sF := Option.some.inj (hexecv.symm.trans hstepF)
    -- stream-tile bridges
    have hqEq : qRaw s₀ Q (s₀.pids 1 * stride_qh) BLOCK_M HEAD (s₀.pids 0)
        = akIOqT nB BLOCK_M HEAD xs := by
      funext idx
      obtain ⟨r, e, ⟨⟩⟩ := idx
      unfold akIOqT
      rw [dif_pos hT0, ← hx ⟨0, hT0⟩ (Lane2D.encode (r, e, PUnit.unit)) trivial]
      simp only [Lane2D.encode_div, Lane2D.encode_mod, qRaw]
    have hkEq : kFlat s₀ K (s₀.pids 1 * stride_kh) HEAD (BLOCK_N * nB)
        = akIOkT nB HEAD BLOCK_N ys := by
      funext e gj
      have ht : gj.val / BLOCK_N < nB :=
        (Nat.div_lt_iff_lt_mul hBN).mpr (by rw [Nat.mul_comm nB BLOCK_N]; exact gj.isLt)
      unfold akIOkT
      rw [dif_pos ⟨ht, hBN⟩,
        ← hy ⟨gj.val / BLOCK_N, ht⟩
          (Lane2D.encode (e, ⟨gj.val % BLOCK_N, Nat.mod_lt _ hBN⟩, PUnit.unit)) trivial]
      simp only [Lane2D.encode_div, Lane2D.encode_mod, kFlat]
      congr 1
      rw [Nat.div_add_mod']
    have hvEq : vFlat s₀ V (s₀.pids 1 * stride_kh) HEAD (BLOCK_N * nB)
        = akIOvT nB BLOCK_N HEAD zs := by
      funext idx
      obtain ⟨gj, d, ⟨⟩⟩ := idx
      have ht : gj.val / BLOCK_N < nB :=
        (Nat.div_lt_iff_lt_mul hBN).mpr (by rw [Nat.mul_comm nB BLOCK_N]; exact gj.isLt)
      unfold akIOvT
      rw [dif_pos ⟨ht, hBN⟩,
        ← hz ⟨gj.val / BLOCK_N, ht⟩
          (Lane2D.encode (⟨gj.val % BLOCK_N, Nat.mod_lt _ hBN⟩, d, PUnit.unit)) trivial]
      simp only [Lane2D.encode_div, Lane2D.encode_mod, vFlat]
      congr 1
      rw [Nat.div_add_mod']
    have hb0Eq : ∀ (r : Fin BLOCK_M) (c : Nat), c < nB →
        b0Val s₀ B0 (s₀.pids 1 * stride_b0h) BLOCK_M stride_b0m (s₀.pids 0) r c
          = akIOb0T nB BLOCK_M BLOCK_N ws r c := by
      intro r c hc
      unfold akIOb0T
      rw [dif_pos hc,
        ← hw ⟨c, hc⟩ (Lane2D.encode (r, ⟨BLOCK_N, Nat.lt_succ_self BLOCK_N⟩, PUnit.unit))
          trivial]
      simp only [Lane2D.encode_div, Lane2D.encode_mod, b0Val]
      rw [if_neg (lt_irrefl BLOCK_N)]
    have hb1Eq : ∀ (r : Fin BLOCK_M) (jL : Nat), jL < BLOCK_N →
        b1Val s₀ B0 (s₀.pids 1 * stride_b0h) BLOCK_M stride_b0m BIAS_LAST_SIZE
            (s₀.pids 0) r jL
          = akIOb1T nB BLOCK_M BLOCK_N ws r jL := by
      intro r jL hjL
      unfold akIOb1T
      rw [dif_pos ⟨hT0, hjL⟩,
        ← hw ⟨0, hT0⟩ (Lane2D.encode (r, ⟨jL, Nat.lt_succ_of_lt hjL⟩, PUnit.unit)) trivial]
      simp only [Lane2D.encode_div, Lane2D.encode_mod, b1Val]
      rw [if_pos hjL]
    have hscoreEq : fscore s₀ Q K B0 sm_scale (s₀.pids 1 * stride_qh)
        (s₀.pids 1 * stride_kh) (s₀.pids 1 * stride_b0h)
        BLOCK_M BLOCK_N HEAD (BLOCK_N * nB) BIAS_LAST_SIZE stride_b0m (s₀.pids 0)
        = akIOscoreT nB BLOCK_M BLOCK_N HEAD sm_scale xs ys ws := by
      funext r gj
      have hc : gj.val / BLOCK_N < nB :=
        (Nat.div_lt_iff_lt_mul hBN).mpr (by rw [Nat.mul_comm nB BLOCK_N]; exact gj.isLt)
      unfold fscore akIOscoreT
      simp only [hqEq, hkEq]
      rw [hb0Eq r (gj.val / BLOCK_N) hc, hb1Eq r (gj.val % BLOCK_N) (Nat.mod_lt _ hBN)]
    refine ⟨sFv, ?_, ?_, ?_⟩
    · -- the `execR` run collapses onto the exact one
      show execR R _ s₀ = some sFv
      unfold execR
      rw [akIO_body_split Q K V B0 Out sm_scale stride_qh stride_kh stride_b0h BLOCK_M
          BLOCK_N HEAD BIAS_LAST_SIZE stride_b0m nB,
        akIO_body_castFree R hreal Q K V B0 Out sm_scale stride_qh stride_kh stride_b0h
          BLOCK_M BLOCK_N HEAD BIAS_LAST_SIZE stride_b0m nB s₀,
        ← akIO_body_split Q K V B0 Out sm_scale stride_qh stride_kh stride_b0h BLOCK_M
          BLOCK_N HEAD BIAS_LAST_SIZE stride_b0m nB]
      exact hstepF
    · -- `Out`: real readback of the closed form
      intro j _
      have hOv' := hOv (Lane2D.decode j)
      rw [show s₀.pids 1 * stride_qh + (s₀.pids 0 * BLOCK_M + j.val / HEAD) * HEAD
            + j.val % HEAD * 1
          = s₀.pids 1 * stride_qh
            + (s₀.pids 0 * BLOCK_M + (Lane2D.decode j).1.val) * HEAD
            + (Lane2D.decode j).2.1.val * 1 from by
        simp only [Lane2D.decode_row, Lane2D.decode_col]]
      rw [readMemAs_real_of_cell
        (x := attentionKernelSpec s₀ Q K V B0 sm_scale
          (s₀.pids 1 * stride_qh) (s₀.pids 1 * stride_kh) (s₀.pids 1 * stride_b0h)
          BLOCK_M BLOCK_N HEAD (BLOCK_N * nB) BIAS_LAST_SIZE stride_b0m (s₀.pids 0)
          (Lane2D.decode j))
        (by rw [hOv']; rfl)]
      rw [hreal]
      simp only [id_eq]
      refine congrArg _ ?_
      show attentionKernelSpec s₀ Q K V B0 sm_scale
          (s₀.pids 1 * stride_qh) (s₀.pids 1 * stride_kh) (s₀.pids 1 * stride_b0h)
          BLOCK_M BLOCK_N HEAD (BLOCK_N * nB) BIAS_LAST_SIZE stride_b0m (s₀.pids 0)
          (Lane2D.decode j) = _
      unfold attentionKernelSpec
      rw [hscoreEq, hvEq]
    · -- frame outside the `Out` write window
      intro r o hcond
      refine hframeF r o ?_
      intro hr idx
      rcases hcond with hne | hall
      · exact absurd hr hne
      · have := hall (Lane2D.encode idx) trivial
        simpa using this

end IOHeadline

#guard_msgs (drop info) in
#auditModuleAxioms
end VeriTile.Bench.TritonBenchG.AttentionKernel.RealKernel
