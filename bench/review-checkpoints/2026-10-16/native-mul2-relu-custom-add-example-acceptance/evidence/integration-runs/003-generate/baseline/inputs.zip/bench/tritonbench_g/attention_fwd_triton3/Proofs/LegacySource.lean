import VeriTile.Triton
import VeriTile.Triton.Semantics.UncheckedBlockLoad

/-!
# `attention_fwd_triton3` — historical simplified attention model

Target source: `attention_fwd_triton3.py`'s `_attn_fwd`, including its inner helper.

The theorems in this file prove properties of `attention_fwd_triton3_surface`.
That surface differs from the Python `_attn_fwd` / `_attn_fwd_inner` source:

* Window distances use natural subtraction. Python uses signed distances;
  query row 0 / key 1 is rejected by Python but retained by this model.
* The loop always visits the entire KV context, omitting the window-derived
  lower/upper bounds and the initial pointer advances.
* `IS_EVEN_N` is ignored: K/V boundary checks and score/probability tail masks
  are missing.
* The `tmp != tmp` NaN check and alpha correction are missing.
* The probability-to-V-dtype cast is missing, storage is untyped, and scale
  initialization adds an extra multiplication by one.

Consequently these are specialized proofs of an altered Lean program, not
correctness or FP-equivalence proofs of the Python kernel. The historical
`python_case` theorem names are retained for existing clients. They must not
be counted as completion of this benchmark. The complete replacement is in `Kernels.lean`, with separate real and FP
specifications. See README.md for the source review and current scope.

The historical maximum is explicitly written as comparison/select so this altered
model retains its original AST when the actual floating maximum frontend changes.
This is preservation of the historical model, not migration of the Python source.

Within this model, the four mathematical summaries cover sliding,
complementary, unmasked and resumed attention. Their formulas depend on input
memory and use symbolic dimensions. The IO statements add their displayed
layout, separation and rounding premises. None of those premises repairs the
transcription differences above. The mathematical carrier is `WithBot ℝ`;
it does not model IEEE NaN propagation.

Translation-surface blocker: the helper JIT is inlined, and the additional
semantic transcription differences above are registered in proof_blockers.md
and completion_audit.md. Passing the exempted textual gate is not evidence
that the Python and Lean programs agree.
-/

namespace VeriTile.Bench.TritonBenchG.AttentionFwdTriton3

open VeriTile.Triton

set_option linter.unusedSimpArgs false

/-! **★ Main theorems:** `attention_fwd_triton3_python_case1_output_summary_general`, `attention_fwd_triton3_python_case2_output_summary_general`, `attention_fwd_triton3_python_case3_output_summary_general`, `attention_fwd_triton3_python_case4_output_summary_general` -/

/-! # ══════════ CORRECT — genuine / dimension-general (review this) ══════════ -/

section Correct_without_Rounding

/-- Historical simplified surface; the module header lists its source mismatches. -/
def attention_fwd_triton3_surface
    (Q K V M Out L : RegionName) (sm_scale : ℝ)
    (stride_qz stride_qh stride_qm stride_qk
      stride_kz stride_kh stride_kn stride_kk
      stride_vz stride_vh stride_vk stride_vn
      stride_oz stride_oh stride_om stride_on
      _Z H H_KV N_CTX ROUND_CTX NKV_CTX
      _sliding_window_offset _sliding_window_size
      IS_EVEN_M _IS_EVEN_N BLOCK_M BLOCK_DMODEL BLOCK_N END INIT
      _SLIDING_WINDOW _COMPLEMENT_SLIDING_WINDOW : Nat) :
    ComputeKernel := triton {
  start_m = tl.program_id(0)
  off_hz = tl.program_id(1)
  off_z = off_hz // $(H)
  off_h = off_hz % $(H)
  off_hkv = off_h // ($(H) // $(H_KV))
  q_offset = off_z.to(tl.int64) * $(stride_qz) + off_h.to(tl.int64) * $(stride_qh)
  k_offset = off_z.to(tl.int64) * $(stride_kz) + off_hkv.to(tl.int64) * $(stride_kh)
  v_offset = off_z.to(tl.int64) * $(stride_vz) + off_hkv.to(tl.int64) * $(stride_vh)
  o_offset = off_z.to(tl.int64) * $(stride_oz) + off_h.to(tl.int64) * $(stride_oh)

  Q_block_ptr = tl.make_block_ptr(base=Q + q_offset, shape=($(N_CTX), $(BLOCK_DMODEL)),
    strides=($(stride_qm), $(stride_qk)), offsets=(start_m * $(BLOCK_M), 0),
    block_shape=($(BLOCK_M), $(BLOCK_DMODEL)), order=(1, 0))
  V_block_ptr = tl.make_block_ptr(base=V + v_offset, shape=($(NKV_CTX), $(BLOCK_DMODEL)),
    strides=($(stride_vk), $(stride_vn)), offsets=(0, 0),
    block_shape=($(BLOCK_N), $(BLOCK_DMODEL)), order=(1, 0))
  K_block_ptr = tl.make_block_ptr(base=K + k_offset, shape=($(BLOCK_DMODEL), $(NKV_CTX)),
    strides=($(stride_kk), $(stride_kn)), offsets=(0, 0),
    block_shape=($(BLOCK_DMODEL), $(BLOCK_N)), order=(0, 1))
  O_block_ptr = tl.make_block_ptr(base=Out + o_offset, shape=($(ROUND_CTX), $(BLOCK_DMODEL)),
    strides=($(stride_om), $(stride_on)), offsets=(start_m * $(BLOCK_M), 0),
    block_shape=($(BLOCK_M), $(BLOCK_DMODEL)), order=(1, 0))
  offs_m = start_m * $(BLOCK_M) + tl.arange(0, $(BLOCK_M))
  m_ptrs = M + off_hz * $(ROUND_CTX) + offs_m
  l_ptrs = L + off_hz * $(ROUND_CTX) + offs_m
  if $(INIT) != $(0) {
    m_i = tl.zeros([$(BLOCK_M)], dtype=tl.float32) - float("inf")
    l_i = tl.zeros([$(BLOCK_M)], dtype=tl.float32) + 1.0
    acc = tl.zeros([$(BLOCK_M), $(BLOCK_DMODEL)], dtype=tl.float32)
  } else {
    m_i = tl.load(m_ptrs).to(tl.float32)
    l_i = tl.load(l_ptrs).to(tl.float32)
    acc = tl.load(O_block_ptr).to(tl.float32)
  }
  qk_scale = $(sm_scale) * 1.0
  qk_scale *= 1.4426950408889634
  if $(IS_EVEN_M) != $(0) {
    q = tl.load(Q_block_ptr)
  } else {
    q = tl.load(Q_block_ptr, boundary_check=(0, 1), padding_option="zero")
  }
  for start_n in range($(0), $(NKV_CTX), $(BLOCK_N)) {
    k = tl.load(K_block_ptr)
    qk = tl.zeros([$(BLOCK_M), $(BLOCK_N)], dtype=tl.float32)
    qk += tl.dot(q, k)
    qk = qk * qk_scale
    if $(_SLIDING_WINDOW) != $(0) {
      dist = tl.arange(0, $(BLOCK_M))[:, None] - tl.arange(0, $(BLOCK_N))[None, :]
        + start_m * $(BLOCK_M) - start_n + $(_sliding_window_offset)
      if $(_COMPLEMENT_SLIDING_WINDOW) != $(0) {
        mask = dist >= $(_sliding_window_size)
      } else {
        mask = (dist >= $(0)) & (dist < $(_sliding_window_size))
      }
      qk = tl.where(mask, qk, float("-inf"))
    }
    m_ij = tl.where(m_i > tl.max(qk, 1), m_i, tl.max(qk, 1))
    qk = qk - m_ij[:, None]
    p = tl.math.exp2(qk)
    if $(_SLIDING_WINDOW) != $(0) {
      p = tl.where(mask, p, 0.0)
    }
    l_ij = tl.sum(p, 1)
    tmp = m_i - m_ij
    alpha = tl.math.exp2(tmp)
    l_i = l_i * alpha + l_ij
    acc = acc * alpha[:, None]
    v = tl.load(V_block_ptr)
    acc += tl.dot(p, v)
    m_i = m_ij
    V_block_ptr = tl.advance(V_block_ptr, [$(BLOCK_N), $(0)])
    K_block_ptr = tl.advance(K_block_ptr, [$(0), $(BLOCK_N)])
  }
  if $(END) != $(0) {
    m_i += tl.math.log2(l_i)
    acc = acc / l_i[:, None]
  } else {
    tl.store(l_ptrs, l_i)
  }
  tl.store(m_ptrs, m_i)
  tl.store(O_block_ptr, (acc).to(Out.type.element_ty))
}

/-- The historical surface lowers to the algorithm layer. This is not a
Python-to-Lean source correspondence theorem. -/
theorem attention_fwd_triton3_surface_toAlgorithm_supported
    (Q K V M Out L : RegionName) (sm_scale : ℝ)
    (stride_qz stride_qh stride_qm stride_qk
      stride_kz stride_kh stride_kn stride_kk
      stride_vz stride_vh stride_vk stride_vn
      stride_oz stride_oh stride_om stride_on
      _Z H H_KV N_CTX ROUND_CTX NKV_CTX
      _sliding_window_offset _sliding_window_size
      IS_EVEN_M _IS_EVEN_N BLOCK_M BLOCK_DMODEL BLOCK_N END INIT
      _SLIDING_WINDOW _COMPLEMENT_SLIDING_WINDOW : Nat) :
    ∃ alg, (attention_fwd_triton3_surface Q K V M Out L sm_scale stride_qz
      stride_qh stride_qm stride_qk stride_kz stride_kh stride_kn stride_kk
      stride_vz stride_vh stride_vk stride_vn stride_oz stride_oh stride_om
      stride_on _Z H H_KV N_CTX ROUND_CTX NKV_CTX _sliding_window_offset
      _sliding_window_size IS_EVEN_M _IS_EVEN_N BLOCK_M BLOCK_DMODEL
      BLOCK_N END INIT _SLIDING_WINDOW _COMPLEMENT_SLIDING_WINDOW).toAlgorithm?
        = Except.ok alg := by
  simp [attention_fwd_triton3_surface, ComputeExpr.toAlgorithm?,
    ComputeOp.toAlgorithm?]

/-- Surface transcription/proof-oriented final output-store slice of `attention_fwd_triton3.py`'s
`_attn_fwd`.

The full kernel runs separate streaming attention stages, including the causal
stage when requested. This slice starts after those stages have produced a
precomputed normalized `Acc` tile and proves the final masked writeback into
`Out`, preserving the source store address and mask
`(offs_m < N_CTX) & (offs_k < HEAD_ACTIVE)`. The inner `tl.float32` accumulator is
outside this slice. -/
def offZ (s : BlockState) (H : Nat) : Nat :=
  s.pids 1 / H

def offH (s : BlockState) (H : Nat) : Nat :=
  s.pids 1 % H

def mIndex (s : BlockState) (BLOCK_M : Nat) (i : Fin BLOCK_M) : Nat :=
  s.pids 0 * BLOCK_M + i.val

def kIndex (idx : TileIndex [BLOCK_M, BLOCK_DMODEL]) : Nat :=
  idx.2.1.val

def active
    (s : BlockState) (N_CTX HEAD_ACTIVE BLOCK_M : Nat)
    (idx : TileIndex [BLOCK_M, BLOCK_DMODEL]) : Prop :=
  mIndex s BLOCK_M idx.1 < N_CTX ∧ kIndex idx < HEAD_ACTIVE

instance activeDecidable
    (s : BlockState) (N_CTX HEAD_ACTIVE BLOCK_M BLOCK_DMODEL : Nat)
    (idx : TileIndex [BLOCK_M, BLOCK_DMODEL]) :
    Decidable (active s N_CTX HEAD_ACTIVE BLOCK_M idx) := by
  unfold active
  infer_instance

def outOffset
    (s : BlockState)
    (H stride_qz stride_qh stride_qm stride_qk BLOCK_M : Nat)
    (idx : TileIndex [BLOCK_M, BLOCK_DMODEL]) : Nat :=
  offZ s H * stride_qz + offH s H * stride_qh +
    mIndex s BLOCK_M idx.1 * stride_qm + kIndex idx * stride_qk

/-- Proof-oriented L (log-sum-exp) row store slice of `attention_fwd_triton3.py`.
Takes a precomputed `LPre` vector and proves the row writeback into `L` at
offset `off_hz * ROUND_CTX + offs_m`. -/
def lRowOffset (s : BlockState) (off_hz ROUND_CTX BLOCK_M : Nat)
    (i : Fin BLOCK_M) : Nat :=
  off_hz * ROUND_CTX + (s.pids 0 * BLOCK_M + i.val)

/-- Global query row for output tile-row `i` in this program. -/
def natDist3 (SM : Nat) (i : Fin 64) (j : Fin 128) : Nat :=
  (i.val - j.val % 64) + SM * 64 - (j.val / 64) * 64

/-- **Historical case-1 keep predicate** (sliding window, non-complement): the
kernel's `mask = (dist ≥ 0) & (dist < 64)`. The `dist ≥ 0` clause is vacuous on
ℕ, so this is exactly `natDist3 SM i j < 64` — matching `aft3MaskCell1G` cell for
cell (true by construction). -/
def natSlidingWindowKeep (SM : Nat) (i : Fin 64) (j : Fin 128) : Prop :=
  natDist3 SM i j < 64

instance natSlidingWindowKeepDecidable (SM : Nat) (i : Fin 64) (j : Fin 128) :
    Decidable (natSlidingWindowKeep SM i j) := by
  unfold natSlidingWindowKeep; infer_instance

/-- **Historical case-2 keep predicate** (complement sliding window): the kernel's
`mask = dist ≥ 64`, i.e. `64 ≤ natDist3 SM i j` — matching `aft3MaskCell2G`. -/
def natComplementSlidingWindowKeep (SM : Nat) (i : Fin 64) (j : Fin 128) : Prop :=
  64 ≤ natDist3 SM i j

instance natComplementSlidingWindowKeepDecidable (SM : Nat) (i : Fin 64) (j : Fin 128) :
    Decidable (natComplementSlidingWindowKeep SM i j) := by
  unfold natComplementSlidingWindowKeep; infer_instance

/-- Case 3's masked closed form is the plain unmasked base-2 per-key-scale
softmax (`attentionRealBase2PerKeyScale`). -/
theorem aft3_evalOp_exp2 {shape : TileShape} (a : Op .real shape) (s : BlockState) :
    evalOp (.exp2 a) s = (do let va ← evalOp a s; some (Tile.uop WithBot.realExp2 va)) := by
  simp [evalOp]

/-- `evalOp` helper for the `>=` predicate (`Op.ge`), which has no `@[simp]` form. -/
theorem aft3_evalOp_ge {dtype a b shape} (h : ComparableDType dtype)
    (bc : Broadcast a b shape) (x : Op dtype a) (y : Op dtype b) (s : BlockState) :
    evalOp (.ge h bc x y) s = (do
      let vx ← evalOp x s; let vy ← evalOp y s; some (Tile.cop h.ge bc vx vy)) := by
  simp [evalOp]

set_option maxHeartbeats 1600000 in
set_option maxRecDepth 8000 in
/-- **L1: `k = tl.load(K_block_ptr)`** (no boundary check). K's block ptr has
`order=(0,1)`: parent `(BLOCK_DMODEL, NKV_CTX)`, strides `(stride_kk, stride_kn)`,
offsets `[0, colOff]` (column advances by `BLOCK_N` per block). Each lane reads
`readMem` at `base + e·strideT + (colOff + j)·strideS`. With `K`'s
`strides=(1, 64)` this is head-lane `e`, key `colOff + j` — exactly a `kTile3G`
read after `colOff` column advances. -/
theorem aft3_load_k_eval
    (region : RegionName) (base rows cols BT BS strideT strideS colOff : Nat)
    (ptrOp : Op .blockPtr [BT, BS]) (s : BlockState)
    (hp : evalOp ptrOp s = some
      ⟨fun _ : TileIndex [BT, BS] =>
        { region := region, baseOffset := base, parentShape := [rows, cols],
          blockShape := [BT, BS], strides := [strideT, strideS],
          offsets := [0, colOff] }⟩) :
    evalOp (.load .real (.blockPtr ptrOp []) .none .unspecified) s
      = some ⟨fun idx : TileIndex [BT, BS] =>
          some (s.readMem region
            (base + idx.1.val * strideT + (colOff + idx.2.1.val) * strideS))⟩ := by
  simp only [evalOp, hp, Option.bind]
  refine congrArg some ?_
  ext idx
  simp only [TileShape.indexToList, BlockPtr.inBounds, List.all_nil,
    BlockPtr.address_2d_zero_row_offset, BlockState.readMemValue_real, if_true]

set_option maxHeartbeats 1600000 in
set_option maxRecDepth 8000 in
/-- **L17: `v = tl.load(V_block_ptr)`** (no boundary check). V's block ptr has
`order=(1,0)`: parent `(NKV_CTX, BLOCK_DMODEL)`, strides `(stride_vk, stride_vn)`,
offsets `[rowOff, 0]` (row advances by `BLOCK_N` per block). Each lane reads
`base + (rowOff + j)·strideT + d·strideS`. With `V`'s `strides=(64, 1)` this is
key `rowOff + j`, head-lane `d` — exactly a `vTile3G` read after `rowOff` row
advances. -/
theorem aft3_load_v_eval
    (region : RegionName) (base rows cols BT BS strideT strideS rowOff : Nat)
    (ptrOp : Op .blockPtr [BT, BS]) (s : BlockState)
    (hp : evalOp ptrOp s = some
      ⟨fun _ : TileIndex [BT, BS] =>
        { region := region, baseOffset := base, parentShape := [rows, cols],
          blockShape := [BT, BS], strides := [strideT, strideS],
          offsets := [rowOff, 0] }⟩) :
    evalOp (.load .real (.blockPtr ptrOp []) .none .unspecified) s
      = some ⟨fun idx : TileIndex [BT, BS] =>
          some (s.readMem region
            (base + (rowOff + idx.1.val) * strideT + idx.2.1.val * strideS))⟩ := by
  simp only [evalOp, hp, Option.bind]
  refine congrArg some ?_
  ext idx
  have haddr : BlockPtr.address
      { region := region, baseOffset := base, parentShape := [rows, cols],
        blockShape := [BT, BS], strides := [strideT, strideS],
        offsets := [rowOff, 0] }
      [idx.1.val, idx.2.1.val]
      = base + (rowOff + idx.1.val) * strideT + idx.2.1.val * strideS := by
    show base + ((rowOff + idx.1.val) * strideT + (0 + idx.2.1.val) * strideS) = _
    rw [Nat.zero_add, Nat.add_assoc]
  simp only [TileShape.indexToList, BlockPtr.inBounds, List.all_nil,
    haddr, BlockState.readMemValue_real, if_true]

set_option maxHeartbeats 1600000 in
set_option maxRecDepth 8000 in
/-- **L21: `K_block_ptr = tl.advance(K_block_ptr, [0, BLOCK_N])`** — advance the
column offset of a `[0, colOff]` block pointer by `BLOCK_N`. -/
theorem aft3_advance_k_eval (s : BlockState) (region : RegionName)
    (base rows cols BT BS strideT strideS colOff d : Nat) (name : RegName)
    (hkp : s.regs .blockPtr [BT, BS] name = some
      (⟨fun _ : TileIndex [BT, BS] =>
        { region := region, baseOffset := base, parentShape := [rows, cols],
          blockShape := [BT, BS], strides := [strideT, strideS],
          offsets := [0, colOff] }⟩)) :
    evalOp (Op.advanceBlockPtr (Op.ref .blockPtr [BT, BS] name) [(0:Nat), d]) s
      = some (⟨fun _ : TileIndex [BT, BS] =>
        { region := region, baseOffset := base, parentShape := [rows, cols],
          blockShape := [BT, BS], strides := [strideT, strideS],
          offsets := [0, colOff + d] }⟩) := by
  simp only [evalOp, evalOp_ref, hkp, Option.bind]
  refine congrArg some ?_
  ext i
  simp [BlockPtr.advance_2d_offsets]

set_option maxHeartbeats 1600000 in
set_option maxRecDepth 8000 in
/-- **L20: `V_block_ptr = tl.advance(V_block_ptr, [BLOCK_N, 0])`** — advance the
row offset of a `[rowOff, 0]` block pointer by `BLOCK_N`. -/
theorem aft3_advance_v_eval (s : BlockState) (region : RegionName)
    (base rows cols BT BS strideT strideS rowOff d : Nat) (name : RegName)
    (hkp : s.regs .blockPtr [BT, BS] name = some
      (⟨fun _ : TileIndex [BT, BS] =>
        { region := region, baseOffset := base, parentShape := [rows, cols],
          blockShape := [BT, BS], strides := [strideT, strideS],
          offsets := [rowOff, 0] }⟩)) :
    evalOp (Op.advanceBlockPtr (Op.ref .blockPtr [BT, BS] name) [d, (0:Nat)]) s
      = some (⟨fun _ : TileIndex [BT, BS] =>
        { region := region, baseOffset := base, parentShape := [rows, cols],
          blockShape := [BT, BS], strides := [strideT, strideS],
          offsets := [rowOff + d, 0] }⟩) := by
  simp only [evalOp, evalOp_ref, hkp, Option.bind]
  refine congrArg some ?_
  ext i
  simp [BlockPtr.advance_2d_offsets]

set_option maxHeartbeats 1600000 in
set_option maxRecDepth 8000 in
/-- **L2: `qk = tl.zeros([BLOCK_M, BLOCK_N])`** — the all-`0` neutral dot seed. -/
theorem aft3_qkzeros_eval (s : BlockState) (BM BN : Nat) :
    evalOp (Op.full [BM, BN] (Op.const 0)) s
      = some (⟨fun _ : TileIndex [BM, BN] => some (0 : ℝ)⟩ : Tile .real [BM, BN]) := by
  simp [evalOp_full, evalOp_const, Option.bind]

set_option maxHeartbeats 1600000 in
set_option maxRecDepth 8000 in
/-- **L3: `qk += tl.dot(q, k)`** — adds the `q·k` dot to the zero-seeded `qk`
tile. Both `q` and `k` are `.real` (K is loaded transposed by the block-ptr
`order=(0,1)`, so no `tl.trans` appears in the AST). -/
theorem aft3_qk_dot_eval (s : BlockState) (BM BN BD : Nat)
    (qktile : Tile .real [BM, BN]) (qtile : Tile .real [BM, BD]) (ktile : Tile .real [BD, BN])
    (hqk : s.regs .real [BM, BN] "qk" = some qktile)
    (hq : s.regs .real [BM, BD] "q" = some qtile)
    (hk : s.regs .real [BD, BN] "k" = some ktile) :
    evalOp (Op.add .real (Broadcast.consSame (Broadcast.consSame Broadcast.nil))
        (Op.ref .real [BM, BN] "qk")
        (Op.dot (batch := []) (Op.ref .real [BM, BD] "q") (Op.ref .real [BD, BN] "k"))) s
      = some (Tile.bop NumericDType.real.add
          (Broadcast.consSame (Broadcast.consSame Broadcast.nil))
          qktile (Tile.dot [] qtile ktile)) := by
  have hqr : evalOp (Op.ref .real [BM, BD] "q") s = some qtile := by rw [evalOp_ref, hq]
  have hkr : evalOp (Op.ref .real [BD, BN] "k") s = some ktile := by rw [evalOp_ref, hk]
  have hdot : @evalOp TileDType.real [BM, BN]
      (Op.dot (batch := []) (Op.ref .real [BM, BD] "q") (Op.ref .real [BD, BN] "k")) s
      = some (Tile.dot [] qtile ktile) := by
    erw [evalOp_dot [] (Op.ref .real [BM, BD] "q") (Op.ref .real [BD, BN] "k"), hqr, hkr]; rfl
  rw [evalOp_add]; simp only [evalOp_ref, hqk, hdot, Option.bind_eq_bind, Option.bind_some]; rfl

/-- **L4 (register variant): `qk = qk * qk_scale`** with `qk_scale` read from the
`qk_scale` register (= `keyScale3G`). -/
theorem aft3_qk_scale_ref_eval (s : BlockState) (BM BN : Nat) (sc : ℝ)
    (qktile : Tile .real [BM, BN]) (hqk : s.regs .real [BM, BN] "qk" = some qktile)
    (hqs : s.regs .real [] "qk_scale" = some (Tile.scalar (some sc))) :
    evalOp (Op.mul .real Broadcast.scalarR (Op.ref .real [BM, BN] "qk") (Op.ref .real [] "qk_scale")) s
      = some (Tile.bop NumericDType.real.mul Broadcast.scalarR qktile
          (Tile.scalar (some sc : WithBot ℝ))) := by
  rw [evalOp_mul]; simp only [evalOp_ref, hqk, hqs, Option.bind_eq_bind, Option.bind_some]

/-- `evalOp` helper for `Op.boolAnd` (no `@[simp]` form). -/
theorem aft3_evalOp_boolAnd {a b shape} (bc : Broadcast a b shape)
    (x : Op .bool a) (y : Op .bool b) (s : BlockState) :
    evalOp (.boolAnd bc x y) s = (do
      let vx ← evalOp x s; let vy ← evalOp y s;
      some (Tile.bop (fun p q : Bool => p && q) bc vx vy)) := by
  simp [evalOp]

set_option maxHeartbeats 1600000 in
set_option maxRecDepth 8000 in
/-- **L18: `acc += tl.dot(p, v)`** — numerator accumulation. Both `p` and `v` are
`.real` (no fp16 round-trip in this transcription). -/
theorem aft3_acc_eval (s : BlockState) (BM BN BD : Nat)
    (acctile : Tile .real [BM, BD]) (ptile : Tile .real [BM, BN]) (vtile : Tile .real [BN, BD])
    (hacc : s.regs .real [BM, BD] "acc" = some acctile)
    (hp : s.regs .real [BM, BN] "p" = some ptile)
    (hv : s.regs .real [BN, BD] "v" = some vtile) :
    evalOp (Op.add .real (Broadcast.consSame (Broadcast.consSame Broadcast.nil))
        (Op.ref .real [BM, BD] "acc")
        (Op.dot (batch := []) (Op.ref .real [BM, BN] "p") (Op.ref .real [BN, BD] "v"))) s
      = some (Tile.bop NumericDType.real.add
          (Broadcast.consSame (Broadcast.consSame Broadcast.nil)) acctile
          (Tile.dot [] ptile vtile)) := by
  have hpr : evalOp (Op.ref .real [BM, BN] "p") s = some ptile := by rw [evalOp_ref, hp]
  have hvr : evalOp (Op.ref .real [BN, BD] "v") s = some vtile := by rw [evalOp_ref, hv]
  have hdot : @evalOp TileDType.real [BM, BD]
      (Op.dot (batch := []) (Op.ref .real [BM, BN] "p") (Op.ref .real [BN, BD] "v")) s
      = some (Tile.dot [] ptile vtile) := by
    erw [evalOp_dot [] (Op.ref .real [BM, BN] "p") (Op.ref .real [BN, BD] "v"), hpr, hvr]; rfl
  rw [evalOp_add]; simp only [evalOp_ref, hacc, hdot, Option.bind_eq_bind, Option.bind_some]; rfl

set_option maxHeartbeats 1600000 in
set_option maxRecDepth 8000 in
/-- **Body split (case 1).** The lowered algorithm body of the case-1 surface is
exactly `aft3PreLoopG ++ Stmt.forRange "start_n" 0 128 64 aft3LoopBodyG ::
aft3PostLoopG`. -/
noncomputable def aft3OsStepBot (st : WithBot ℝ × ℝ × ℝ) (sv : ℝ × ℝ) : WithBot ℝ × ℝ × ℝ :=
  let m := st.1; let l := st.2.1; let acc := st.2.2
  let s := sv.1; let v := sv.2
  let m' := m ⊔ ((s : ℝ) : WithBot ℝ)
  let α := (WithBot.realExp2 (WithBot.realSub m m')).unbotD 0
  let p := pow2 (s - m'.unbotD 0)
  (m', l * α + p, acc * α + p * v)

/-- The running `max` component of an `aft3OsStepBot` fold is the `⊔`-fold of the
coerced scores. -/
theorem aft3StateBot_fst
    (xs : List (ℝ × ℝ)) (m₀ : WithBot ℝ) (l₀ acc₀ : ℝ) :
    (xs.foldl aft3OsStepBot (m₀, l₀, acc₀)).1
      = (xs.map (fun p => ((p.1 : ℝ) : WithBot ℝ))).foldl (· ⊔ ·) m₀ := by
  induction xs generalizing m₀ l₀ acc₀ with
  | nil => rfl
  | cons x xs ih => simp only [List.foldl_cons, List.map_cons]; rw [ih]; rfl

/-- **⊥-seeded consistency.** Folding `aft3OsStepBot` from a start anchored to the
true (max-free) batch denominator `L` / accumulator `T` keeps that invariant. -/
theorem aft3OsStepBot_foldl_consistent (xs : List (ℝ × ℝ)) (m : WithBot ℝ) (l acc T L : ℝ)
    (hl : l = (m.elim 0 (fun r => pow2 (-r))) * L)
    (hacc : acc = (m.elim 0 (fun r => pow2 (-r))) * T)
    (hmL : m = ⊥ → L = 0) (hmT : m = ⊥ → T = 0) :
    let st := xs.foldl aft3OsStepBot (m, l, acc)
    st.2.1 = (st.1.elim 0 (fun r => pow2 (-r))) * (L + (xs.map (fun p => pow2 p.1)).sum) ∧
    st.2.2 = (st.1.elim 0 (fun r => pow2 (-r))) * (T + (xs.map (fun p => pow2 p.1 * p.2)).sum) := by
  induction xs generalizing m l acc T L with
  | nil => simp [hl, hacc]
  | cons x xs ih =>
    obtain ⟨s, v⟩ := x
    set m' : WithBot ℝ := m ⊔ ((s : ℝ) : WithBot ℝ) with hm'
    have hm'r : ∃ r : ℝ, m' = (r : WithBot ℝ) := by
      cases m with
      | bot => exact ⟨s, by rw [hm']; rfl⟩
      | coe a => exact ⟨max a s, by rw [hm']; rw [← WithBot.coe_max]⟩
    obtain ⟨mr, hmr⟩ := hm'r
    have hκm' : m'.elim 0 (fun r => pow2 (-r)) = pow2 (-mr) := by rw [hmr]; rfl
    have hunbot : m'.unbotD 0 = mr := by rw [hmr]; rfl
    have hp : pow2 (s - m'.unbotD 0) = pow2 (-mr) * pow2 s := by
      rw [hunbot, ← pow2_add]; ring_nf
    have hl' : l * (WithBot.realExp2 (WithBot.realSub m m')).unbotD 0
        + pow2 (s - m'.unbotD 0) = pow2 (-mr) * (L + pow2 s) := by
      cases m with
      | bot =>
        rw [hmL rfl]
        have hz : (WithBot.realExp2 (WithBot.realSub (⊥ : WithBot ℝ) m')).unbotD 0 = 0 := by
          rw [WithBot.realSub_bot_left, WithBot.realExp2_bot]; rfl
        rw [hz, mul_zero, zero_add, hp]; ring
      | coe a =>
        have hm'a : m' = ((max a s : ℝ) : WithBot ℝ) := by rw [hm']; rw [← WithBot.coe_max]
        have hmra : mr = max a s := by rw [hm'a] at hmr; exact (WithBot.coe_inj.mp hmr.symm)
        have hαa : (pow2 (-a)) * (WithBot.realExp2 (WithBot.realSub (↑a) m')).unbotD 0
            = pow2 (-mr) := by
          rw [hm'a, WithBot.realSub_coe_coe, WithBot.realExp2_coe, WithBot.unbotD_coe]
          rw [show Real.exp ((a - max a s) * Real.log 2) = pow2 (a - max a s) from by
            simp [pow2, mul_comm], ← pow2_add, hmra]; ring_nf
        rw [hl, show ((↑a : WithBot ℝ).elim 0 (fun r => pow2 (-r))) = pow2 (-a) from rfl]
        rw [mul_right_comm, hαa, hp]; ring
    have hacc' : acc * (WithBot.realExp2 (WithBot.realSub m m')).unbotD 0
        + pow2 (s - m'.unbotD 0) * v = pow2 (-mr) * (T + pow2 s * v) := by
      cases m with
      | bot =>
        rw [hmT rfl]
        have hz : (WithBot.realExp2 (WithBot.realSub (⊥ : WithBot ℝ) m')).unbotD 0 = 0 := by
          rw [WithBot.realSub_bot_left, WithBot.realExp2_bot]; rfl
        rw [hz, mul_zero, zero_add, hp]; ring
      | coe a =>
        have hm'a : m' = ((max a s : ℝ) : WithBot ℝ) := by rw [hm']; rw [← WithBot.coe_max]
        have hmra : mr = max a s := by rw [hm'a] at hmr; exact (WithBot.coe_inj.mp hmr.symm)
        have hαa : (pow2 (-a)) * (WithBot.realExp2 (WithBot.realSub (↑a) m')).unbotD 0
            = pow2 (-mr) := by
          rw [hm'a, WithBot.realSub_coe_coe, WithBot.realExp2_coe, WithBot.unbotD_coe]
          rw [show Real.exp ((a - max a s) * Real.log 2) = pow2 (a - max a s) from by
            simp [pow2, mul_comm], ← pow2_add, hmra]; ring_nf
        rw [hacc, show ((↑a : WithBot ℝ).elim 0 (fun r => pow2 (-r))) = pow2 (-a) from rfl]
        rw [mul_right_comm, hαa, hp]; ring
    have step := ih m'
      (l * (WithBot.realExp2 (WithBot.realSub m m')).unbotD 0 + pow2 (s - m'.unbotD 0))
      (acc * (WithBot.realExp2 (WithBot.realSub m m')).unbotD 0 + pow2 (s - m'.unbotD 0) * v)
      (T + pow2 s * v) (L + pow2 s) (by rw [hl', hκm']) (by rw [hacc', hκm'])
      (by rw [hmr]; simp) (by rw [hmr]; simp)
    simpa [List.foldl_cons, aft3OsStepBot, hm', List.map_cons, add_assoc] using step

/-- The `WithBot ⊔`-fold is seed/direction-agnostic. -/
theorem aft3_foldl_sup_bot_eq_foldr (L : List (WithBot ℝ)) :
    L.foldl (· ⊔ ·) (⊥ : WithBot ℝ) = L.foldr (· ⊔ ·) (⊥ : WithBot ℝ) := by
  have gen : ∀ (m : WithBot ℝ), L.foldl (· ⊔ ·) m = m ⊔ L.foldr (· ⊔ ·) ⊥ := by
    induction L with
    | nil => intro m; simp
    | cons a t ih =>
      intro m
      simp only [List.foldl_cons, List.foldr_cons, ih]
      rw [max_assoc]
  rw [gen ⊥, bot_sup_eq]

/-- The `.1` channel of an `aft3OsStepBot` block fold: `m ⊔ blockSup`. -/
theorem aft3OsStepBot_block_fst (m : WithBot ℝ) (l acc : ℝ) (block : List (ℝ × ℝ)) :
    (block.foldl aft3OsStepBot (m, l, acc)).1
      = m ⊔ (block.map (fun p => ((p.1 : ℝ) : WithBot ℝ))).foldr (· ⊔ ·) ⊥ := by
  rw [aft3StateBot_fst]
  induction block generalizing m with
  | nil => simp
  | cons a t ih =>
    simp only [List.map_cons, List.foldl_cons, List.foldr_cons]
    rw [ih]
    rw [show (m ⊔ ((a.1 : ℝ) : WithBot ℝ)) ⊔ (List.foldr (· ⊔ ·) ⊥ (List.map (fun p => ((p.1 : ℝ) : WithBot ℝ)) t))
          = m ⊔ (((a.1 : ℝ) : WithBot ℝ) ⊔ (List.foldr (· ⊔ ·) ⊥ (List.map (fun p => ((p.1 : ℝ) : WithBot ℝ)) t))) from by
      rw [sup_assoc]]

/-- **The block-at-once update equals the key-by-key `aft3OsStepBot` fold.** -/
theorem aft3OsStepBot_block_eq (m : WithBot ℝ) (l acc T L : ℝ) (block : List (ℝ × ℝ))
    (hl : l = (m.elim 0 (fun r => pow2 (-r))) * L)
    (hacc : acc = (m.elim 0 (fun r => pow2 (-r))) * T)
    (hmL : m = ⊥ → L = 0) (hmT : m = ⊥ → T = 0) :
    let M' := m ⊔ (block.map (fun p => ((p.1 : ℝ) : WithBot ℝ))).foldr (· ⊔ ·) ⊥
    (M',
     l * (WithBot.realExp2 (WithBot.realSub m M')).unbotD 0
       + (block.map (fun p => pow2 (p.1 - M'.unbotD 0))).sum,
     acc * (WithBot.realExp2 (WithBot.realSub m M')).unbotD 0
       + (block.map (fun p => pow2 (p.1 - M'.unbotD 0) * p.2)).sum)
      = block.foldl aft3OsStepBot (m, l, acc) := by
  intro M'
  have hfst : (block.foldl aft3OsStepBot (m, l, acc)).1 = M' := by
    rw [aft3OsStepBot_block_fst]
  obtain ⟨hfold_l, hfold_acc⟩ := aft3OsStepBot_foldl_consistent block m l acc T L hl hacc hmL hmT
  rw [hfst] at hfold_l hfold_acc
  have hM'eq : M' = m ⊔ (block.map (fun p => ((p.1 : ℝ) : WithBot ℝ))).foldr (· ⊔ ·) ⊥ := rfl
  cases hM' : M' with
  | bot =>
    have hempty : block = [] := by
      rcases block with _ | ⟨a, t⟩
      · rfl
      · exfalso
        have : ((a.1 : ℝ) : WithBot ℝ) ≤ M' := by
          rw [hM'eq]
          exact le_sup_of_le_right (by simp only [List.map_cons, List.foldr_cons]; exact le_sup_left)
        rw [hM'] at this
        exact absurd (le_bot_iff.mp this) (WithBot.coe_ne_bot)
    have hm0 : m = ⊥ := by
      rw [hM'eq, hempty] at hM'
      simpa only [List.map_nil, List.foldr_nil, sup_bot_eq] using hM'
    have hl0 : l = 0 := by rw [hl, hm0]; simp [hmL hm0]
    have hacc0 : acc = 0 := by rw [hacc, hm0]; simp [hmT hm0]
    subst hempty
    rw [hl0, hacc0]
    simp only [List.foldl_nil, List.map_nil, List.sum_nil, add_zero, mul_zero, zero_mul]
    rw [hm0]
  | coe Mr =>
    rw [hM'] at hfst hfold_l hfold_acc
    have hlα : l * (WithBot.realExp2 (WithBot.realSub m (↑Mr : WithBot ℝ))).unbotD 0 = pow2 (-Mr) * L := by
      cases hm : m with
      | bot =>
        rw [hl, hm, show ((⊥ : WithBot ℝ).elim 0 (fun r => pow2 (-r))) = 0 from rfl,
          zero_mul, hmL hm]; ring
      | coe a =>
        rw [hl, hm, show ((↑a : WithBot ℝ).elim 0 (fun r => pow2 (-r))) = pow2 (-a) from rfl]
        rw [WithBot.realSub_coe_coe, WithBot.realExp2_coe, WithBot.unbotD_coe,
          show Real.exp ((a - Mr) * Real.log 2) = pow2 (a - Mr) from by simp [pow2, mul_comm]]
        rw [mul_right_comm, ← pow2_add]; ring_nf
    have haccα : acc * (WithBot.realExp2 (WithBot.realSub m (↑Mr : WithBot ℝ))).unbotD 0 = pow2 (-Mr) * T := by
      cases hm : m with
      | bot =>
        rw [hacc, hm, show ((⊥ : WithBot ℝ).elim 0 (fun r => pow2 (-r))) = 0 from rfl,
          zero_mul, hmT hm]; ring
      | coe a =>
        rw [hacc, hm, show ((↑a : WithBot ℝ).elim 0 (fun r => pow2 (-r))) = pow2 (-a) from rfl]
        rw [WithBot.realSub_coe_coe, WithBot.realExp2_coe, WithBot.unbotD_coe,
          show Real.exp ((a - Mr) * Real.log 2) = pow2 (a - Mr) from by simp [pow2, mul_comm]]
        rw [mul_right_comm, ← pow2_add]; ring_nf
    have hsumL : (block.map (fun p => pow2 (p.1 - (↑Mr : WithBot ℝ).unbotD 0))).sum
        = pow2 (-Mr) * (block.map (fun p => pow2 p.1)).sum := by
      have := VeriTile.Triton.sum_map_pow2_sub ((↑Mr : WithBot ℝ).unbotD 0) block (fun _ => 1)
      simp only [mul_one] at this
      rw [this, WithBot.unbotD_coe]
    have hsumT : (block.map (fun p => pow2 (p.1 - (↑Mr : WithBot ℝ).unbotD 0) * p.2)).sum
        = pow2 (-Mr) * (block.map (fun p => pow2 p.1 * p.2)).sum := by
      rw [VeriTile.Triton.sum_map_pow2_sub ((↑Mr : WithBot ℝ).unbotD 0) block (fun p => p.2), WithBot.unbotD_coe]
    refine Prod.ext hfst.symm (Prod.ext ?_ ?_)
    · rw [hfold_l, hlα, hsumL, show ((↑Mr : WithBot ℝ).elim 0 (fun r => pow2 (-r))) = pow2 (-Mr) from rfl]; ring
    · rw [hfold_acc, haccα, hsumT, show ((↑Mr : WithBot ℝ).elim 0 (fun r => pow2 (-r))) = pow2 (-Mr) from rfl]; ring

/-- Generic threshold-split for a `.val`-ascending `filterMap`: the `j.val < hi₂`
window splits into the `j.val < t` prefix and the `t ≤ j.val < hi₂` block
(`t ≤ hi₂`). (Ported from the flash-attn private helper.) -/
private theorem aft3_filterMap_window_split {n : Nat} (l : List (Fin n))
    (hsorted : l.Pairwise (fun a b => a.val < b.val))
    (t hi₂ : Nat) (Q : Fin n → Prop) [DecidablePred Q]
    (g : Fin n → ℝ × ℝ) (hle : t ≤ hi₂) :
    l.filterMap (fun j => if Q j ∧ j.val < hi₂ then some (g j) else none)
      = l.filterMap (fun j => if Q j ∧ j.val < t then some (g j) else none)
        ++ l.filterMap (fun j => if t ≤ j.val ∧ j.val < hi₂ ∧ Q j then some (g j) else none) := by
  induction l with
  | nil => simp
  | cons a tl ih =>
    have htl : tl.Pairwise (fun x y => x.val < y.val) := (List.pairwise_cons.mp hsorted).2
    have hahead : ∀ b ∈ tl, a.val < b.val := (List.pairwise_cons.mp hsorted).1
    rw [List.filterMap_cons, List.filterMap_cons, List.filterMap_cons]
    by_cases hlt : a.val < t
    · rw [ih htl]
      have hnb : ¬ (t ≤ a.val ∧ a.val < hi₂ ∧ Q a) := fun h => (Nat.not_le.mpr hlt) h.1
      rw [if_neg hnb]
      by_cases hQ : Q a
      · have h2 : a.val < hi₂ := lt_of_lt_of_le hlt hle
        rw [if_pos (And.intro hQ h2 : Q a ∧ a.val < hi₂),
          if_pos (And.intro hQ hlt : Q a ∧ a.val < t)]
        rfl
      · rw [if_neg (fun h : Q a ∧ a.val < hi₂ => hQ h.1),
          if_neg (fun h : Q a ∧ a.val < t => hQ h.1)]
    · have hge : t ≤ a.val := Nat.not_lt.mp hlt
      have htail_prefix : tl.filterMap (fun j => if Q j ∧ j.val < t then some (g j) else none) = [] := by
        apply List.filterMap_eq_nil_iff.mpr
        intro b hb
        have hab : a.val < b.val := hahead b hb
        have hbt : ¬ (b.val < t) := by omega
        simp [hbt]
      rw [ih htl, htail_prefix]
      have hnp : ¬ (Q a ∧ a.val < t) := fun h => hlt h.2
      rw [if_neg hnp]
      by_cases hQ : Q a
      · by_cases h2 : a.val < hi₂
        · rw [if_pos (And.intro hQ h2 : Q a ∧ a.val < hi₂),
            if_pos (And.intro hge (And.intro h2 hQ) : t ≤ a.val ∧ a.val < hi₂ ∧ Q a)]
          rfl
        · rw [if_neg (fun h : Q a ∧ a.val < hi₂ => h2 h.2),
            if_neg (fun h : t ≤ a.val ∧ a.val < hi₂ ∧ Q a => h2 h.2.1)]
      · rw [if_neg (fun h : Q a ∧ a.val < hi₂ => hQ h.1),
          if_neg (fun h : t ≤ a.val ∧ a.val < hi₂ ∧ Q a => hQ h.2.2)]

/-- **⊥-seed independence of the `l`/`acc` carries.** From a `⊥`-max start the
first key resets the carries, so the `aft3OsStepBot` fold over a nonempty list is
independent of the initial `l`/`acc`. -/
theorem aft3OsStepBot_bot_seed_indep (xs : List (ℝ × ℝ)) (hne : xs ≠ [])
    (l acc l' acc' : ℝ) :
    xs.foldl aft3OsStepBot (⊥, l, acc) = xs.foldl aft3OsStepBot (⊥, l', acc') := by
  obtain ⟨x, t, rfl⟩ := List.exists_cons_of_ne_nil hne
  obtain ⟨s, v⟩ := x
  have hstep : ∀ L A : ℝ, aft3OsStepBot (⊥, L, A) (s, v)
      = (((s : ℝ) : WithBot ℝ), pow2 (s - s), pow2 (s - s) * v) := by
    intro L A
    simp only [aft3OsStepBot, bot_sup_eq]
    have hα : (WithBot.realExp2 (WithBot.realSub (⊥ : WithBot ℝ) ((s : ℝ) : WithBot ℝ))).unbotD 0 = 0 := by
      rw [WithBot.realSub_bot_left, WithBot.realExp2_bot]; rfl
    have hub : (((s : ℝ) : WithBot ℝ)).unbotD 0 = s := by rfl
    rw [hα, hub]
    simp
  simp only [List.foldl_cons, hstep]

/-! ### preLoop evaluation (deliverable 4) -/

/-- `makeBlockPtrDyn` evaluation recipe. -/
theorem aft3_makeBlockPtrDyn_eval (region : RegionName) (baseOffset : Op .nat [])
    (parentShape : List Nat) (blockShape : TileShape)
    (strides offsets : List Nat) (s : BlockState) (base : Nat)
    (hb : evalOp baseOffset s = some (Tile.scalar base)) :
    evalOp (.makeBlockPtrDyn region baseOffset parentShape blockShape strides offsets) s
      = some (⟨fun _ : TileIndex blockShape =>
          { region := region, baseOffset := base, parentShape := parentShape,
            blockShape := blockShape, strides := strides, offsets := offsets }⟩) := by
  simp only [evalOp, hb, Option.bind]
  rfl

/-- `makeBlockPtrDynOffsets` with dynamic row offset, literal `0` column. -/
theorem aft3_makeBlockPtr_rowcol_eval (region : RegionName) (baseOffset : Op .nat [])
    (parentShape : List Nat) (blockShape : TileShape) (strides : List Nat)
    (rowOp : Op .nat []) (s : BlockState) (base rowOff : Nat)
    (hb : evalOp baseOffset s = some (Tile.scalar base))
    (hr : evalOp rowOp s = some (Tile.scalar rowOff)) :
    evalOp (.makeBlockPtrDynOffsets region baseOffset parentShape blockShape strides
        [rowOp, Op.constNat 0]) s
      = some (⟨fun _ : TileIndex blockShape =>
          { region := region, baseOffset := base, parentShape := parentShape,
            blockShape := blockShape, strides := strides, offsets := [rowOff, 0] }⟩) := by
  simp only [evalOp, hb, hr, Option.bind, List.mapM, List.mapM.loop, evalOp_constNat, Tile.scalar]
  rfl

/-- `Stmt.ifThenElse` with a constexpr-true condition runs the then-branch. -/
theorem aft3_ifThenElse_true {cond : Op .bool []} {t e : List Stmt} {s : BlockState}
    (hc : evalOp cond s = some (Tile.scalar Bool.true)) :
    stepStmt (.ifThenElse cond t e) s = stepStmts t s := by
  simp only [stepStmt, hc, Option.bind, Tile.scalar]
  rfl

/-- Eval helper for `floorDiv` (no `@[simp]` form). -/
theorem aft3_evalOp_floorDiv {dtype a b shape} (h : IntegralDType dtype)
    (bc : Broadcast a b shape) (x : Op dtype a) (y : Op dtype b) (s : BlockState) :
    evalOp (.floorDiv h bc x y) s = (do
      let vx ← evalOp x s; let vy ← evalOp y s; some (Tile.bop h.floorDiv bc vx vy)) := by
  simp [evalOp]

/-- Eval helper for `mod` (no `@[simp]` form). -/
theorem aft3_evalOp_mod {dtype a b shape} (h : IntegralDType dtype)
    (bc : Broadcast a b shape) (x : Op dtype a) (y : Op dtype b) (s : BlockState) :
    evalOp (.mod h bc x y) s = (do
      let vx ← evalOp x s; let vy ← evalOp y s; some (Tile.bop h.mod bc vx vy)) := by
  simp [evalOp]

/-- Eval helper for `ptrAdd` (no `@[simp]` form). -/
theorem aft3_evalOp_ptrAdd {a b shape} (bc : Broadcast a b shape)
    (ptr : Op .ptr a) (off : Op .nat b) (s : BlockState) :
    evalOp (.ptrAdd bc ptr off) s = (do
      let ptrs ← evalOp ptr s; let offs ← evalOp off s;
      some (Tile.ptrAdd bc ptrs offs)) := by simp [evalOp]

/-- Eval helper for `ptrBase` (the base region pointer). -/
theorem aft3_evalOp_ptrBase (region : RegionName) (s : BlockState) :
    evalOp (.ptrBase region) s = some (Tile.scalar (region.cast, 0)) := by simp [evalOp]

/-- `Stmt.ifThen` with a constexpr-true condition runs the body. -/
theorem aft3_ifThen_true {cond : Op .bool []} {body : List Stmt} {s : BlockState}
    (hc : evalOp cond s = some (Tile.scalar Bool.true)) :
    stepStmt (.ifThen cond body) s = stepStmts body s := by
  simp only [stepStmt, hc, Option.bind, Tile.scalar]
  rfl

/-- `Stmt.ifThenElse` with a constexpr-false condition runs the else-branch. -/
theorem aft3_ifThenElse_false {cond : Op .bool []} {t e : List Stmt} {s : BlockState}
    (hc : evalOp cond s = some (Tile.scalar Bool.false)) :
    stepStmt (.ifThenElse cond t e) s = stepStmts e s := by
  simp only [stepStmt, hc, Option.bind, Tile.scalar]
  rfl

/-- The constexpr `INIT != 0` / `IS_EVEN_M != 0` condition (`Op.ne 1 0`) is true. -/
theorem aft3_ne_one_zero_true (s : BlockState) :
    evalOp (Op.ne ComparableDType.nat Broadcast.nil (Op.constNat 1) (Op.constNat 0)) s
      = some (Tile.scalar Bool.true) := by
  unfold evalOp
  simp only [evalOp_constNat, Option.bind_eq_bind, Option.bind_some]
  rfl

/-- The constexpr `COMPLEMENT != 0` condition (`Op.ne 0 0`) is false. -/
theorem aft3_ne_zero_zero_false (s : BlockState) :
    evalOp (Op.ne ComparableDType.nat Broadcast.nil (Op.constNat 0) (Op.constNat 0)) s
      = some (Tile.scalar Bool.false) := by
  unfold evalOp
  simp only [evalOp_constNat, Option.bind_eq_bind, Option.bind_some]
  rfl

/-- `Stmt.ifThen` with a constexpr-false condition is a no-op. -/
theorem aft3_ifThen_false {cond : Op .bool []} {body : List Stmt} {s : BlockState}
    (hc : evalOp cond s = some (Tile.scalar Bool.false)) :
    stepStmt (.ifThen cond body) s = some s := by
  simp only [stepStmt, hc, Option.bind, Tile.scalar]
  rfl

set_option maxHeartbeats 1600000 in
set_option maxRecDepth 8000 in
/-- Map-and-sum of a `filterMap` over `finRange` is a masked `Finset.sum`. -/
theorem aft3_filterMap_finRange_sum {α : Type*} (n : Nat)
    (p : Fin n → Prop) [DecidablePred p] (g : Fin n → α) (h : α → ℝ) :
    (((List.finRange n).filterMap (fun j => if p j then some (g j) else none)).map h).sum
      = ∑ j : Fin n, if p j then h (g j) else 0 := by
  rw [List.map_filterMap]
  rw [show (fun j : Fin n => Option.map h (if p j then some (g j) else none))
        = (fun j : Fin n => if p j then some (h (g j)) else none) from by
    funext j; by_cases hj : p j <;> simp [hj]]
  rw [show (((List.finRange n).filterMap (fun j => if p j then some (h (g j)) else none))).sum
        = ((List.finRange n).map (fun j => if p j then h (g j) else 0)).sum from by
    induction (List.finRange n) with
    | nil => simp
    | cons a t ih => by_cases ha : p a <;> simp [ha, ih]]
  rw [← List.sum_ofFn]; congr 1; rw [List.ofFn_eq_map]

/-- Any member of a `WithBot ℝ` list is `≤` its `foldr (⊔) ⊥`. -/
theorem aft3_mem_le_foldr_sup (a : WithBot ℝ) :
    ∀ (L : List (WithBot ℝ)), a ∈ L → a ≤ L.foldr (· ⊔ ·) ⊥ := by
  intro L
  induction L with
  | nil => intro h; simp at h
  | cons x t ih =>
    intro h
    simp only [List.foldr_cons]
    rcases List.mem_cons.mp h with h | h
    · rw [h]; exact le_sup_left
    · exact le_trans (ih h) le_sup_right

/-- `filterMap`-then-coe `foldr ⊔ ⊥` over `finRange n` equals the masked `Finset.sup`. -/
theorem aft3_filterMap_foldr_sup (n : Nat) (P : Fin n → Prop) [DecidablePred P]
    (sc : Fin n → ℝ) :
    (((List.finRange n).filterMap (fun j => if P j then some (sc j) else none)).map
        (fun x => ((x : ℝ) : WithBot ℝ))).foldr (· ⊔ ·) ⊥
      = Finset.univ.sup (fun j : Fin n => if P j then ((sc j : ℝ) : WithBot ℝ) else ⊥) := by
  rw [show (((List.finRange n).filterMap (fun j => if P j then some (sc j) else none)).map
        (fun x => ((x : ℝ) : WithBot ℝ))).foldr (· ⊔ ·) ⊥
      = (List.finRange n).foldr (fun j a => (if P j then ((sc j : ℝ) : WithBot ℝ) else ⊥) ⊔ a) ⊥ from by
    induction (List.finRange n) with
    | nil => simp
    | cons a t ih => by_cases ha : P a <;> simp [ha, ih]]
  apply le_antisymm
  · induction (List.finRange n) with
    | nil => simp
    | cons a t ih =>
      simp only [List.foldr_cons]
      exact sup_le (Finset.le_sup (f := fun j : Fin n => if P j then ((sc j : ℝ) : WithBot ℝ) else ⊥)
        (Finset.mem_univ a)) ih
  · apply Finset.sup_le
    intro j _
    have key : ∀ (l : List (Fin n)), j ∈ l →
        (if P j then ((sc j : ℝ) : WithBot ℝ) else ⊥)
          ≤ l.foldr (fun j a => (if P j then ((sc j : ℝ) : WithBot ℝ) else ⊥) ⊔ a) ⊥ := by
      intro l hl
      induction l with
      | nil => simp at hl
      | cons a t ih =>
        simp only [List.foldr_cons]
        rcases List.mem_cons.mp hl with h | h
        · subst h; exact le_sup_left
        · exact le_trans (ih h) le_sup_right
    exact key _ (List.mem_finRange j)

/-! ### Masked per-channel register bridges (cases 1/2, sliding window)

These mirror the case-3 (`noWindowKeep`) bridges, but the kernel's `qk` cell is
the *masked* tile `if mc jL then some score else ⊥` (out-of-window lanes set to
`-inf` by the `tl.where`). The reconciliation hypothesis `hmc` ties the lowered
nat-mask `mc` (= `aft3MaskCell1G`/`aft3MaskCell2G` on lane `jL`) to the faithful
`keep` predicate at the global key `c·64 + jL`. The empty-block case (`mc` all
false) is now genuinely reachable, so — unlike case 3 — no `ne_bot` assumption is
made: the ⊥-carry (`m_ij = ⊥`, `α = 0`) is handled by the seed-cancellation in
`aft3OsStepBot`. -/

/-- A `foldl` of `writeMem`s into region `R'` preserves `readMem R o` whenever the
read region `R` differs from the written region `R'`. -/
theorem aft3_foldl_writeMem_readMem_other_region {α : Type} (R R' : RegionName)
    (hRR' : R ≠ R') (offsetFn : α → Nat) (valueFn : α → ℝ) (o : Nat) (l : List α)
    (s : BlockState) :
    ((l.foldl (fun acc k => acc.writeMem R' (offsetFn k) (valueFn k)) s).readMem R o)
      = s.readMem R o := by
  induction l generalizing s with
  | nil => rfl
  | cons hd tl ih =>
    rw [List.foldl_cons, ih]
    exact BlockState.writeMem_readMem_of_ne_region s R' (offsetFn hd) (valueFn hd) R o hRR'

/-- General query tile: query row `i`, head lane `e`, at
`base + (pid0·BM + i)·sqm + e·sqk`. -/
noncomputable def qTile3G (s : BlockState) (Q : RegionName)
    (base BM ND sqm sqk : Nat) : TileIndex [BM, ND] → ℝ :=
  fun (i, e, _) => s.readMem Q (base + (s.pids 0 * BM + i.val) * sqm + e.val * sqk)

/-- General key tile: key `j` (global), head lane `e`, at `base + j·skn + e·skk`. -/
noncomputable def kTile3G (s : BlockState) (K : RegionName)
    (base NC ND skn skk : Nat) : TileIndex [NC, ND] → ℝ :=
  fun (j, e, _) => s.readMem K (base + j.val * skn + e.val * skk)

/-- General value tile: key `j` (global), head lane `d`, at `base + j·svk + d·svn`. -/
noncomputable def vTile3G (s : BlockState) (V : RegionName)
    (base NC ND svk svn : Nat) : TileIndex [NC, ND] → ℝ :=
  fun (j, d, _) => s.readMem V (base + j.val * svk + d.val * svn)

/-- General per-key uniform score scale (= `sm_scale · log2e`). -/
noncomputable def keyScale3G (sc : ℝ) (NC : Nat) : Fin NC → ℝ := fun _ => sc

/-- Historical nat-truncated sliding-window distance, block-local key
`jL = j mod BN`, block start `start_n = (j / BN)·BN`:
`dist = (i − jL : ℕ) + SM·BM − start_n + offset`. -/
def natDist3G (SM BM BN off : Nat) {NC : Nat} (i : Fin BM) (j : Fin NC) : Nat :=
  (i.val - j.val % BN) + SM * BM - (j.val / BN) * BN + off

/-- General case-1 keep predicate: `dist < size`. -/
def natSlidingWindowKeepG (SM BM BN off size : Nat) {NC : Nat}
    (i : Fin BM) (j : Fin NC) : Prop :=
  natDist3G SM BM BN off i j < size

instance natSlidingWindowKeepGDecidable (SM BM BN off size : Nat) {NC : Nat}
    (i : Fin BM) (j : Fin NC) : Decidable (natSlidingWindowKeepG SM BM BN off size i j) := by
  unfold natSlidingWindowKeepG; infer_instance

/-- General case-2 complement keep predicate: `size ≤ dist`. -/
def natComplementSlidingWindowKeepG (SM BM BN off size : Nat) {NC : Nat}
    (i : Fin BM) (j : Fin NC) : Prop :=
  size ≤ natDist3G SM BM BN off i j

instance natComplementSlidingWindowKeepGDecidable (SM BM BN off size : Nat) {NC : Nat}
    (i : Fin BM) (j : Fin NC) :
    Decidable (natComplementSlidingWindowKeepG SM BM BN off size i j) := by
  unfold natComplementSlidingWindowKeepG; infer_instance

/-- General genuine closed form, case 1 (sliding window). -/
noncomputable def attentionFwdTriton3Case1OutSpecG
    (s : BlockState) (Q K V : RegionName)
    (base BM ND NC sqm sqk skn skk svk svn : Nat) (sc : ℝ) (BN off size : Nat)
    (idx : TileIndex [BM, ND]) : ℝ :=
  attentionRealBase2PerKeyScalePred (qTile3G s Q base BM ND sqm sqk)
    (kTile3G s K base NC ND skn skk) (vTile3G s V base NC ND svk svn)
    (keyScale3G sc NC) (fun i j => natSlidingWindowKeepG (s.pids 0) BM BN off size i j) idx

/-- General genuine closed form, case 2 (complement sliding window). -/
noncomputable def attentionFwdTriton3Case2OutSpecG
    (s : BlockState) (Q K V : RegionName)
    (base BM ND NC sqm sqk skn skk svk svn : Nat) (sc : ℝ) (BN off size : Nat)
    (idx : TileIndex [BM, ND]) : ℝ :=
  attentionRealBase2PerKeyScalePred (qTile3G s Q base BM ND sqm sqk)
    (kTile3G s K base NC ND skn skk) (vTile3G s V base NC ND svk svn)
    (keyScale3G sc NC) (fun i j => natComplementSlidingWindowKeepG (s.pids 0) BM BN off size i j) idx

/-- General genuine closed form, case 3 (no window) — plain base-2 softmax. -/
noncomputable def attentionFwdTriton3Case3OutSpecG
    (s : BlockState) (Q K V : RegionName)
    (base BM ND NC sqm sqk skn skk svk svn : Nat) (sc : ℝ)
    (idx : TileIndex [BM, ND]) : ℝ :=
  attentionRealBase2PerKeyScalePred (qTile3G s Q base BM ND sqm sqk)
    (kTile3G s K base NC ND skn skk) (vTile3G s V base NC ND svk svn)
    (keyScale3G sc NC) (fun (i : Fin BM) (j : Fin NC) => noWindowKeep i j) idx

/-- Streaming bridge, general case 1: closed form = online-softmax fold of the
masked key list. -/
theorem attentionFwdTriton3Case1OutSpecG_eq_streaming
    (s : BlockState) (Q K V : RegionName)
    (base BM ND NC sqm sqk skn skk svk svn : Nat) (sc : ℝ) (BN off size : Nat)
    (i : Fin BM) (d : Fin ND) :
    attentionFwdTriton3Case1OutSpecG s Q K V base BM ND NC sqm sqk skn skk svk svn sc BN off size
        (i, d, PUnit.unit)
      = (let st := (attnKeyListPred (qTile3G s Q base BM ND sqm sqk)
            (kTile3G s K base NC ND skn skk) (vTile3G s V base NC ND svk svn) (keyScale3G sc NC)
            (fun i j => natSlidingWindowKeepG (s.pids 0) BM BN off size i j) i d).foldl
              osStep (0, 0, 0)
         st.2.2 / st.2.1) := by
  simpa [attentionFwdTriton3Case1OutSpecG] using
    VeriTile.Triton.attentionRealBase2PerKeyScalePred_eq_streaming
      (qTile3G s Q base BM ND sqm sqk) (kTile3G s K base NC ND skn skk)
      (vTile3G s V base NC ND svk svn) (keyScale3G sc NC)
      (fun i j => natSlidingWindowKeepG (s.pids 0) BM BN off size i j) i d

/-- Streaming bridge, general case 2. -/
theorem attentionFwdTriton3Case2OutSpecG_eq_streaming
    (s : BlockState) (Q K V : RegionName)
    (base BM ND NC sqm sqk skn skk svk svn : Nat) (sc : ℝ) (BN off size : Nat)
    (i : Fin BM) (d : Fin ND) :
    attentionFwdTriton3Case2OutSpecG s Q K V base BM ND NC sqm sqk skn skk svk svn sc BN off size
        (i, d, PUnit.unit)
      = (let st := (attnKeyListPred (qTile3G s Q base BM ND sqm sqk)
            (kTile3G s K base NC ND skn skk) (vTile3G s V base NC ND svk svn) (keyScale3G sc NC)
            (fun i j => natComplementSlidingWindowKeepG (s.pids 0) BM BN off size i j) i d).foldl
              osStep (0, 0, 0)
         st.2.2 / st.2.1) := by
  simpa [attentionFwdTriton3Case2OutSpecG] using
    VeriTile.Triton.attentionRealBase2PerKeyScalePred_eq_streaming
      (qTile3G s Q base BM ND sqm sqk) (kTile3G s K base NC ND skn skk)
      (vTile3G s V base NC ND svk svn) (keyScale3G sc NC)
      (fun i j => natComplementSlidingWindowKeepG (s.pids 0) BM BN off size i j) i d

/-- Streaming bridge, general case 3. -/
theorem attentionFwdTriton3Case3OutSpecG_eq_streaming
    (s : BlockState) (Q K V : RegionName)
    (base BM ND NC sqm sqk skn skk svk svn : Nat) (sc : ℝ)
    (i : Fin BM) (d : Fin ND) :
    attentionFwdTriton3Case3OutSpecG s Q K V base BM ND NC sqm sqk skn skk svk svn sc
        (i, d, PUnit.unit)
      = (let st := (attnKeyListPred (qTile3G s Q base BM ND sqm sqk)
            (kTile3G s K base NC ND skn skk) (vTile3G s V base NC ND svk svn) (keyScale3G sc NC)
            (fun (i : Fin BM) (j : Fin NC) => noWindowKeep i j) i d).foldl osStep (0, 0, 0)
         st.2.2 / st.2.1) := by
  simpa [attentionFwdTriton3Case3OutSpecG] using
    VeriTile.Triton.attentionRealBase2PerKeyScalePred_eq_streaming
      (qTile3G s Q base BM ND sqm sqk) (kTile3G s K base NC ND skn skk)
      (vTile3G s V base NC ND svk svn) (keyScale3G sc NC)
      (fun (i : Fin BM) (j : Fin NC) => noWindowKeep i j) i d

/-! ## Dimension-general ⊥-seeded online-softmax math foundation

The dimension-general ⊥-seeded streaming defs `aft3KeysUptoG`/`aft3RunningMaxG`/
`aft3StateBotG`/`aft3BlockG`/`aft3StateBot1G` and their lemmas, parameterized over
`BM` (rows, `Fin BM`), `ND` (head dim, `Fin ND`), `NC` (keys, `Fin NC`), `BN`
(block stride). The generic ⊥-seed core lemmas (`aft3OsStepBot*`,
`aft3_foldl_sup_bot_eq_foldr`, `aft3_filterMap_window_split`, `aft3StateBot_fst`)
operate over arbitrary lists, so they are reused verbatim. The block-split holds
for any `BN` (`c·BN ≤ (c+1)·BN`); the full-window lemma needs `hi = NC`. -/

/-- General windowed prefix key list `[0, hi)`. -/
noncomputable def aft3KeysUptoG {BM ND NC : Nat}
    (qT : TileIndex [BM, ND] → ℝ) (kT vT : TileIndex [NC, ND] → ℝ)
    (keyScale : Fin NC → ℝ) (keep : Fin BM → Fin NC → Prop)
    [∀ i j, Decidable (keep i j)] (hi : Nat) (i : Fin BM) (d : Fin ND) :
    List (ℝ × ℝ) :=
  (List.finRange NC).filterMap (fun j : Fin NC =>
    if j.val < hi ∧ keep i j then
      some (keyScale j * Finset.univ.sum (fun e : Fin ND =>
              qT (i, e, PUnit.unit) * kT (j, e, PUnit.unit)),
            vT (j, d, PUnit.unit))
    else none)

/-- General ⊥-seeded running max over the windowed prefix. -/
noncomputable def aft3RunningMaxG {BM ND NC : Nat}
    (qT : TileIndex [BM, ND] → ℝ) (kT vT : TileIndex [NC, ND] → ℝ)
    (keyScale : Fin NC → ℝ) (keep : Fin BM → Fin NC → Prop)
    [∀ i j, Decidable (keep i j)] (hi : Nat) (i : Fin BM) (d : Fin ND) :
    WithBot ℝ :=
  ((aft3KeysUptoG qT kT vT keyScale keep hi i d).map
    (fun p => ((p.1 : ℝ) : WithBot ℝ))).foldr (· ⊔ ·) ⊥

/-- General ⊥-seeded running `(max, denom, acc)` after the windowed prefix `[0, hi)`. -/
noncomputable def aft3StateBotG {BM ND NC : Nat}
    (qT : TileIndex [BM, ND] → ℝ) (kT vT : TileIndex [NC, ND] → ℝ)
    (keyScale : Fin NC → ℝ) (keep : Fin BM → Fin NC → Prop)
    [∀ i j, Decidable (keep i j)] (hi : Nat) (i : Fin BM) (d : Fin ND) :
    WithBot ℝ × ℝ × ℝ :=
  (aft3KeysUptoG qT kT vT keyScale keep hi i d).foldl aft3OsStepBot (⊥, 0, 0)

/-- General block `c` per-row key list: kept keys with `c·BN ≤ j < (c+1)·BN`. -/
noncomputable def aft3BlockG {BM ND NC : Nat}
    (qT : TileIndex [BM, ND] → ℝ) (kT vT : TileIndex [NC, ND] → ℝ)
    (keyScale : Fin NC → ℝ) (keep : Fin BM → Fin NC → Prop)
    [∀ i j, Decidable (keep i j)] (BN c : Nat) (i : Fin BM) (d : Fin ND) :
    List (ℝ × ℝ) :=
  (List.finRange NC).filterMap (fun j : Fin NC =>
    if c * BN ≤ j.val ∧ j.val < (c + 1) * BN ∧ keep i j then
      some (keyScale j * Finset.univ.sum (fun e : Fin ND =>
              qT (i, e, PUnit.unit) * kT (j, e, PUnit.unit)),
            vT (j, d, PUnit.unit))
    else none)

/-- General resume-**SEEDED** running `(max, denom, acc)` after the windowed prefix
`[0, hi)`: the online-softmax `aft3OsStepBot` fold from an arbitrary initial state
`init i d`, rather than the `(⊥, 0, 0)` of `aft3StateBotG`. This is the case-4
(`INIT=False` cross-launch resume) analogue, where `init` is the prior
`(m_i, l_i, acc)` loaded from the input `M`/`L`/`Out` buffers. -/
noncomputable def aft3StateSeededG {BM ND NC : Nat}
    (qT : TileIndex [BM, ND] → ℝ) (kT vT : TileIndex [NC, ND] → ℝ)
    (keyScale : Fin NC → ℝ) (keep : Fin BM → Fin NC → Prop)
    [∀ i j, Decidable (keep i j)]
    (init : Fin BM → Fin ND → WithBot ℝ × ℝ × ℝ)
    (hi : Nat) (i : Fin BM) (d : Fin ND) : WithBot ℝ × ℝ × ℝ :=
  (aft3KeysUptoG qT kT vT keyScale keep hi i d).foldl aft3OsStepBot (init i d)

/-- Per-row running-stat entry `R[off_hz·ROUND_CTX + start_m·BM + i]` — the
shared row layout of the `M` (running max) and `L` (running denom) buffers. -/
noncomputable def mlRow3G (s : BlockState) (R : RegionName)
    (ROUND_CTX BM : Nat) (i : Nat) : ℝ :=
  s.readMem R (s.pids 1 * ROUND_CTX + (s.pids 0 * BM + i))

/-- Output-buffer lane `Out[base + (start_m·BM + i)·som + d·son]` — the `Out`
block-pointer layout at row stride `som`, lane stride `son`. -/
noncomputable def outLane3G (s : BlockState) (Out : RegionName)
    (base BM som son : Nat) (i d : Nat) : ℝ :=
  s.readMem Out (base + (s.pids 0 * BM + i) * som + d * son)

/-- The `INIT=False` resume seed loaded from input memory: per row `i`,
`m_i = M[off_hz·ROUND_CTX + start_m·BM + i]`, `l_i = L[…]`, and per lane `(i,d)`,
`acc = Out[base + (start_m·BM + i)·som + d·son]` — all read from the **initial**
state `s` (these are the running results of prior chunk launches, i.e. genuine
INPUT memory to this program, not this program's own executed output). -/
noncomputable def aft3Case4Seed
    (s : BlockState) (M Out L : RegionName)
    (base BM ND som son ROUND_CTX : Nat) :
    Fin BM → Fin ND → WithBot ℝ × ℝ × ℝ :=
  fun i d =>
    (((mlRow3G s M ROUND_CTX BM i.val : ℝ) : WithBot ℝ),
     mlRow3G s L ROUND_CTX BM i.val,
     outLane3G s Out base BM som son i.val d.val)

/-- **Genuine closed form, case 4** (`INIT=False` cross-launch resume, sliding
window). The output lane `(i,d)` is the normalized resume-seeded online softmax:
the `aft3StateSeededG` fold of the sliding-window-kept keys onto the loaded
`aft3Case4Seed`, read off as `acc / denom`. Genuinely over INPUT memory
(`Q`/`K`/`V` for the keys, `M`/`L`/`Out` for the resume seed) — **no
self-reference** to this program's executed output. -/
noncomputable def attentionFwdTriton3Case4OutSpecG
    (s : BlockState) (Q K V M Out L : RegionName)
    (base BM ND NC sqm sqk skn skk svk svn som son ROUND_CTX : Nat) (sc : ℝ)
    (BN off size : Nat) (hND : 0 < ND) (idx : TileIndex [BM, ND]) : ℝ :=
  let seed := aft3Case4Seed s M Out L base BM ND som son ROUND_CTX
  let kp := fun i j => natSlidingWindowKeepG (s.pids 0) BM BN off size i j
  (aft3StateSeededG (qTile3G s Q base BM ND sqm sqk) (kTile3G s K base NC ND skn skk)
      (vTile3G s V base NC ND svk svn) (keyScale3G sc NC) kp seed NC idx.1 idx.2.1).2.2
    / (aft3StateSeededG (qTile3G s Q base BM ND sqm sqk) (kTile3G s K base NC ND skn skk)
      (vTile3G s V base NC ND svk svn) (keyScale3G sc NC) kp seed NC idx.1 ⟨0, hND⟩).2.1

/-- The resume-seeded running max decomposes as `seed.1 ⊔ ⊥-seeded running max` —
the online-softmax `max` ignores the carried denom/acc, so the seed only adds its
own max component. The key bridge for the seeded reconciliations. -/
theorem aft3StateSeededG_fst {BM ND NC : Nat}
    (qT : TileIndex [BM, ND] → ℝ) (kT vT : TileIndex [NC, ND] → ℝ)
    (keyScale : Fin NC → ℝ) (keep : Fin BM → Fin NC → Prop)
    [∀ i j, Decidable (keep i j)]
    (seed : Fin BM → Fin ND → WithBot ℝ × ℝ × ℝ) (hi : Nat) (i : Fin BM) (d : Fin ND) :
    (aft3StateSeededG qT kT vT keyScale keep seed hi i d).1
      = (seed i d).1 ⊔ aft3RunningMaxG qT kT vT keyScale keep hi i d := by
  unfold aft3StateSeededG aft3RunningMaxG
  rw [aft3OsStepBot_block_fst]


theorem aft3StateBotG_fst_eq_runningMax {BM ND NC : Nat}
    (qT : TileIndex [BM, ND] → ℝ) (kT vT : TileIndex [NC, ND] → ℝ)
    (keyScale : Fin NC → ℝ) (keep : Fin BM → Fin NC → Prop)
    [∀ i j, Decidable (keep i j)] (hi : Nat) (i : Fin BM) (d : Fin ND) :
    (aft3StateBotG qT kT vT keyScale keep hi i d).1
      = aft3RunningMaxG qT kT vT keyScale keep hi i d := by
  rw [aft3StateBotG, aft3StateBot_fst, aft3RunningMaxG, aft3_foldl_sup_bot_eq_foldr]

theorem aft3RunningMaxG_zero {BM ND NC : Nat}
    (qT : TileIndex [BM, ND] → ℝ) (kT vT : TileIndex [NC, ND] → ℝ)
    (keyScale : Fin NC → ℝ) (keep : Fin BM → Fin NC → Prop)
    [∀ i j, Decidable (keep i j)] (i : Fin BM) (d : Fin ND) :
    aft3RunningMaxG qT kT vT keyScale keep 0 i d = ⊥ := by
  unfold aft3RunningMaxG aft3KeysUptoG
  rw [show (List.finRange NC).filterMap
        (fun j : Fin NC => if j.val < 0 ∧ keep i j
          then some (keyScale j * Finset.univ.sum (fun e : Fin ND =>
                qT (i, e, PUnit.unit) * kT (j, e, PUnit.unit)), vT (j, d, PUnit.unit))
          else none) = [] from by
    apply List.filterMap_eq_nil_iff.mpr; intro j _; simp]
  rfl

theorem aft3KeysUptoG_succ {BM ND NC : Nat}
    (qT : TileIndex [BM, ND] → ℝ) (kT vT : TileIndex [NC, ND] → ℝ)
    (keyScale : Fin NC → ℝ) (keep : Fin BM → Fin NC → Prop)
    [∀ i j, Decidable (keep i j)] (BN c : Nat) (i : Fin BM) (d : Fin ND) :
    aft3KeysUptoG qT kT vT keyScale keep ((c + 1) * BN) i d
      = aft3KeysUptoG qT kT vT keyScale keep (c * BN) i d
        ++ aft3BlockG qT kT vT keyScale keep BN c i d := by
  unfold aft3KeysUptoG aft3BlockG
  rw [show (List.finRange NC).filterMap
        (fun j : Fin NC => if j.val < (c + 1) * BN ∧ keep i j then
          some (keyScale j * Finset.univ.sum (fun e : Fin ND =>
              qT (i, e, PUnit.unit) * kT (j, e, PUnit.unit)), vT (j, d, PUnit.unit)) else none)
      = (List.finRange NC).filterMap
        (fun j : Fin NC => if keep i j ∧ j.val < (c + 1) * BN then
          some (keyScale j * Finset.univ.sum (fun e : Fin ND =>
              qT (i, e, PUnit.unit) * kT (j, e, PUnit.unit)), vT (j, d, PUnit.unit)) else none)
      from List.filterMap_congr (fun j _ => by simp only [and_comm])]
  rw [aft3_filterMap_window_split (List.finRange NC) (List.pairwise_lt_finRange NC)
    (c * BN) ((c + 1) * BN) (fun j => keep i j)
    (fun j => (keyScale j * Finset.univ.sum (fun e : Fin ND =>
        qT (i, e, PUnit.unit) * kT (j, e, PUnit.unit)), vT (j, d, PUnit.unit)))
    (by nlinarith [Nat.zero_le BN])]
  refine congrArg₂ (· ++ ·) ?_ ?_
  · apply List.filterMap_congr; intro j _; simp only [and_comm]
  · apply List.filterMap_congr; intro j _
    by_cases h1 : c * BN ≤ j.val <;> by_cases h2 : j.val < (c + 1) * BN <;>
      by_cases h3 : keep i j <;> simp [h1, h2, h3, and_assoc]

theorem aft3StateBotG_succ {BM ND NC : Nat}
    (qT : TileIndex [BM, ND] → ℝ) (kT vT : TileIndex [NC, ND] → ℝ)
    (keyScale : Fin NC → ℝ) (keep : Fin BM → Fin NC → Prop)
    [∀ i j, Decidable (keep i j)] (BN c : Nat) (i : Fin BM) (d : Fin ND) :
    aft3StateBotG qT kT vT keyScale keep ((c + 1) * BN) i d
      = (aft3BlockG qT kT vT keyScale keep BN c i d).foldl aft3OsStepBot
          (aft3StateBotG qT kT vT keyScale keep (c * BN) i d) := by
  unfold aft3StateBotG
  rw [aft3KeysUptoG_succ, List.foldl_append]

/-- Seeded block-advance: the seeded fold over `[0,(c+1)·BN)` is the block-`c`
fold onto the seeded fold over `[0,c·BN)` (pure `List.foldl_append`). -/
theorem aft3StateSeededG_succ {BM ND NC : Nat}
    (qT : TileIndex [BM, ND] → ℝ) (kT vT : TileIndex [NC, ND] → ℝ)
    (keyScale : Fin NC → ℝ) (keep : Fin BM → Fin NC → Prop)
    [∀ i j, Decidable (keep i j)]
    (seed : Fin BM → Fin ND → WithBot ℝ × ℝ × ℝ) (BN c : Nat) (i : Fin BM) (d : Fin ND) :
    aft3StateSeededG qT kT vT keyScale keep seed ((c + 1) * BN) i d
      = (aft3BlockG qT kT vT keyScale keep BN c i d).foldl aft3OsStepBot
          (aft3StateSeededG qT kT vT keyScale keep seed (c * BN) i d) := by
  unfold aft3StateSeededG
  rw [aft3KeysUptoG_succ, List.foldl_append]

/-- Seeded denom/acc consistency (online-softmax invariant carried from a seed
satisfying it): the seeded fold's `(denom, acc)` decompose as
`pow2(-max)·(Lseed + Σ pow2 p.1)` and `pow2(-max)·(Tseed + Σ pow2 p.1·p.2)`.
Direct from `aft3OsStepBot_foldl_consistent`. -/
theorem aft3StateSeededG_consistent {BM ND NC : Nat}
    (qT : TileIndex [BM, ND] → ℝ) (kT vT : TileIndex [NC, ND] → ℝ)
    (keyScale : Fin NC → ℝ) (keep : Fin BM → Fin NC → Prop)
    [∀ i j, Decidable (keep i j)]
    (seed : Fin BM → Fin ND → WithBot ℝ × ℝ × ℝ) (Lseed Tseed : ℝ)
    (hi : Nat) (i : Fin BM) (d : Fin ND)
    (hseedL : (seed i d).2.1 = ((seed i d).1.elim 0 (fun r => pow2 (-r))) * Lseed)
    (hseedT : (seed i d).2.2 = ((seed i d).1.elim 0 (fun r => pow2 (-r))) * Tseed)
    (hseedmL : (seed i d).1 = ⊥ → Lseed = 0) (hseedmT : (seed i d).1 = ⊥ → Tseed = 0) :
    (aft3StateSeededG qT kT vT keyScale keep seed hi i d).2.1
        = ((aft3StateSeededG qT kT vT keyScale keep seed hi i d).1.elim 0 (fun r => pow2 (-r)))
          * (Lseed + ((aft3KeysUptoG qT kT vT keyScale keep hi i d).map (fun p => pow2 p.1)).sum)
      ∧ (aft3StateSeededG qT kT vT keyScale keep seed hi i d).2.2
        = ((aft3StateSeededG qT kT vT keyScale keep seed hi i d).1.elim 0 (fun r => pow2 (-r)))
          * (Tseed + ((aft3KeysUptoG qT kT vT keyScale keep hi i d).map (fun p => pow2 p.1 * p.2)).sum) := by
  unfold aft3StateSeededG
  exact aft3OsStepBot_foldl_consistent (aft3KeysUptoG qT kT vT keyScale keep hi i d)
    (seed i d).1 (seed i d).2.1 (seed i d).2.2 Tseed Lseed hseedL hseedT hseedmL hseedmT

theorem aft3KeysUptoG_full {BM ND NC : Nat}
    (qT : TileIndex [BM, ND] → ℝ) (kT vT : TileIndex [NC, ND] → ℝ)
    (keyScale : Fin NC → ℝ) (keep : Fin BM → Fin NC → Prop)
    [∀ i j, Decidable (keep i j)] (i : Fin BM) (d : Fin ND) :
    aft3KeysUptoG qT kT vT keyScale keep NC i d
      = attnKeyListPred qT kT vT keyScale keep i d := by
  unfold aft3KeysUptoG VeriTile.Triton.attnKeyListPred
  apply List.filterMap_congr
  intro j _
  simp only [j.isLt, true_and]

theorem aft3StateBotG_snd_fst {BM ND NC : Nat}
    (qT : TileIndex [BM, ND] → ℝ) (kT vT : TileIndex [NC, ND] → ℝ)
    (keyScale : Fin NC → ℝ) (keep : Fin BM → Fin NC → Prop)
    [∀ i j, Decidable (keep i j)] (hi : Nat) (i : Fin BM) (d : Fin ND) :
    (aft3StateBotG qT kT vT keyScale keep hi i d).2.1
      = ((aft3RunningMaxG qT kT vT keyScale keep hi i d).elim 0 (fun r => pow2 (-r)))
        * ((aft3KeysUptoG qT kT vT keyScale keep hi i d).map (fun p => pow2 p.1)).sum := by
  have h := (aft3OsStepBot_foldl_consistent (aft3KeysUptoG qT kT vT keyScale keep hi i d)
    ⊥ 0 0 0 0 (by simp) (by simp) (fun _ => rfl) (fun _ => rfl)).1
  rw [aft3StateBotG]
  rw [show (List.foldl aft3OsStepBot (⊥, 0, 0) (aft3KeysUptoG qT kT vT keyScale keep hi i d)).2.1
        = _ from h]
  rw [show (List.foldl aft3OsStepBot (⊥, 0, 0) (aft3KeysUptoG qT kT vT keyScale keep hi i d)).1
        = aft3RunningMaxG qT kT vT keyScale keep hi i d from by
    rw [aft3StateBot_fst, aft3RunningMaxG, aft3_foldl_sup_bot_eq_foldr]]
  rw [zero_add]

theorem aft3StateBotG_snd_snd {BM ND NC : Nat}
    (qT : TileIndex [BM, ND] → ℝ) (kT vT : TileIndex [NC, ND] → ℝ)
    (keyScale : Fin NC → ℝ) (keep : Fin BM → Fin NC → Prop)
    [∀ i j, Decidable (keep i j)] (hi : Nat) (i : Fin BM) (d : Fin ND) :
    (aft3StateBotG qT kT vT keyScale keep hi i d).2.2
      = ((aft3RunningMaxG qT kT vT keyScale keep hi i d).elim 0 (fun r => pow2 (-r)))
        * ((aft3KeysUptoG qT kT vT keyScale keep hi i d).map (fun p => pow2 p.1 * p.2)).sum := by
  have h := (aft3OsStepBot_foldl_consistent (aft3KeysUptoG qT kT vT keyScale keep hi i d)
    ⊥ 0 0 0 0 (by simp) (by simp) (fun _ => rfl) (fun _ => rfl)).2
  rw [aft3StateBotG]
  rw [show (List.foldl aft3OsStepBot (⊥, 0, 0) (aft3KeysUptoG qT kT vT keyScale keep hi i d)).2.2
        = _ from h]
  rw [show (List.foldl aft3OsStepBot (⊥, 0, 0) (aft3KeysUptoG qT kT vT keyScale keep hi i d)).1
        = aft3RunningMaxG qT kT vT keyScale keep hi i d from by
    rw [aft3StateBot_fst, aft3RunningMaxG, aft3_foldl_sup_bot_eq_foldr]]
  rw [zero_add]

theorem aft3StateBotG_ratio_eq {BM ND NC : Nat}
    (qT : TileIndex [BM, ND] → ℝ) (kT vT : TileIndex [NC, ND] → ℝ)
    (keyScale : Fin NC → ℝ) (keep : Fin BM → Fin NC → Prop)
    [∀ i j, Decidable (keep i j)] (hi : Nat) (i : Fin BM) (d : Fin ND)
    (hne : aft3RunningMaxG qT kT vT keyScale keep hi i d ≠ ⊥) :
    (aft3StateBotG qT kT vT keyScale keep hi i d).2.2
        / (aft3StateBotG qT kT vT keyScale keep hi i d).2.1
      = (let st := (aft3KeysUptoG qT kT vT keyScale keep hi i d).foldl osStep (0, 0, 0)
         st.2.2 / st.2.1) := by
  rw [aft3StateBotG_snd_fst, aft3StateBotG_snd_snd]
  simp only
  have hcL := (VeriTile.Triton.osStep_foldl_consistent
    (aft3KeysUptoG qT kT vT keyScale keep hi i d) 0 0 0 0 0 (by simp) (by simp)).1
  have hcT := (VeriTile.Triton.osStep_foldl_consistent
    (aft3KeysUptoG qT kT vT keyScale keep hi i d) 0 0 0 0 0 (by simp) (by simp)).2
  rw [show (List.foldl osStep (0, 0, 0) (aft3KeysUptoG qT kT vT keyScale keep hi i d)).2.1
        = _ from hcL,
      show (List.foldl osStep (0, 0, 0) (aft3KeysUptoG qT kT vT keyScale keep hi i d)).2.2
        = _ from hcT]
  cases hM : aft3RunningMaxG qT kT vT keyScale keep hi i d with
  | bot => exact absurd hM hne
  | coe r =>
    rw [show ((↑r : WithBot ℝ).elim 0 (fun r => pow2 (-r))) = pow2 (-r) from rfl]
    simp only [zero_add]
    rw [mul_div_mul_left _ _ (ne_of_gt (pow2_pos _)),
        mul_div_mul_left _ _ (ne_of_gt (pow2_pos _))]

/-- General ⊥-seeded running state from the kernel's `l_i = 1` seed. -/
noncomputable def aft3StateBot1G {BM ND NC : Nat}
    (qT : TileIndex [BM, ND] → ℝ) (kT vT : TileIndex [NC, ND] → ℝ)
    (keyScale : Fin NC → ℝ) (keep : Fin BM → Fin NC → Prop)
    [∀ i j, Decidable (keep i j)] (hi : Nat) (i : Fin BM) (d : Fin ND) :
    WithBot ℝ × ℝ × ℝ :=
  (aft3KeysUptoG qT kT vT keyScale keep hi i d).foldl aft3OsStepBot (⊥, 1, 0)

theorem aft3StateBot1G_eq_aft3StateBotG {BM ND NC : Nat}
    (qT : TileIndex [BM, ND] → ℝ) (kT vT : TileIndex [NC, ND] → ℝ)
    (keyScale : Fin NC → ℝ) (keep : Fin BM → Fin NC → Prop)
    [∀ i j, Decidable (keep i j)] (hi : Nat) (i : Fin BM) (d : Fin ND)
    (hne : aft3RunningMaxG qT kT vT keyScale keep hi i d ≠ ⊥) :
    aft3StateBot1G qT kT vT keyScale keep hi i d
      = aft3StateBotG qT kT vT keyScale keep hi i d := by
  have hxs : aft3KeysUptoG qT kT vT keyScale keep hi i d ≠ [] := by
    intro h
    apply hne
    unfold aft3RunningMaxG
    rw [h]; rfl
  unfold aft3StateBot1G aft3StateBotG
  exact aft3OsStepBot_bot_seed_indep _ hxs 1 0 0 0

/-- `aft3RunningMaxG` is independent of the channel index `d`. -/
theorem aft3RunningMaxG_eq {BM ND NC : Nat}
    (qT : TileIndex [BM, ND] → ℝ) (kT vT : TileIndex [NC, ND] → ℝ)
    (keyScale : Fin NC → ℝ) (keep : Fin BM → Fin NC → Prop)
    [∀ i j, Decidable (keep i j)] (hi : Nat) (i : Fin BM) (d d' : Fin ND) :
    aft3RunningMaxG qT kT vT keyScale keep hi i d
      = aft3RunningMaxG qT kT vT keyScale keep hi i d' := by
  unfold aft3RunningMaxG aft3KeysUptoG
  congr 1
  rw [List.map_filterMap, List.map_filterMap]
  apply List.filterMap_congr
  intro j _
  by_cases hj : j.val < hi ∧ keep i j <;> simp [hj]

theorem aft3StateBotG_snd_fst_indep {BM ND NC : Nat}
    (qT : TileIndex [BM, ND] → ℝ) (kT vT : TileIndex [NC, ND] → ℝ)
    (keyScale : Fin NC → ℝ) (keep : Fin BM → Fin NC → Prop)
    [∀ i j, Decidable (keep i j)] (hi : Nat) (i : Fin BM) (d d' : Fin ND) :
    (aft3StateBotG qT kT vT keyScale keep hi i d).2.1
      = (aft3StateBotG qT kT vT keyScale keep hi i d').2.1 := by
  rw [aft3StateBotG_snd_fst, aft3StateBotG_snd_fst,
    aft3RunningMaxG_eq qT kT vT keyScale keep hi i d d']
  congr 2
  unfold aft3KeysUptoG
  rw [List.map_filterMap, List.map_filterMap]
  apply List.filterMap_congr
  intro j _
  by_cases hj : j.val < hi ∧ keep i j <;> simp [hj]

theorem aft3KeysUptoG_sum_zero_of_bot {BM ND NC : Nat}
    (qT : TileIndex [BM, ND] → ℝ) (kT vT : TileIndex [NC, ND] → ℝ)
    (keyScale : Fin NC → ℝ) (keep : Fin BM → Fin NC → Prop)
    [∀ i j, Decidable (keep i j)] (hi : Nat) (i : Fin BM) (d : Fin ND)
    (hbot : aft3RunningMaxG qT kT vT keyScale keep hi i d = ⊥) (h : ℝ × ℝ → ℝ) :
    ((aft3KeysUptoG qT kT vT keyScale keep hi i d).map h).sum = 0 := by
  rw [show aft3KeysUptoG qT kT vT keyScale keep hi i d = [] from ?_, List.map_nil, List.sum_nil]
  by_contra hne
  obtain ⟨p, hp⟩ := List.exists_mem_of_ne_nil _ hne
  have hmem : ((p.1 : ℝ) : WithBot ℝ) ∈
      (aft3KeysUptoG qT kT vT keyScale keep hi i d).map (fun q => ((q.1 : ℝ) : WithBot ℝ)) :=
    List.mem_map_of_mem hp
  have := aft3_mem_le_foldr_sup _ _ hmem
  rw [← aft3RunningMaxG, hbot] at this
  exact absurd (le_bot_iff.mp this) WithBot.coe_ne_bot

/-- General faithful kernel ⊥-carry state (seed-1 at window 0, seed-0 ⊥-state after). -/
noncomputable def aft3StateBotKG {BM ND NC : Nat}
    (qT : TileIndex [BM, ND] → ℝ) (kT vT : TileIndex [NC, ND] → ℝ)
    (keyScale : Fin NC → ℝ) (keep : Fin BM → Fin NC → Prop)
    [∀ i j, Decidable (keep i j)] (hi : Nat) (i : Fin BM) (d : Fin ND) :
    WithBot ℝ × ℝ × ℝ :=
  if hi = 0 then (⊥, 1, 0)
  else aft3StateBotG qT kT vT keyScale keep hi i d

theorem aft3StateBotKG_cancel {BM ND NC : Nat}
    (qT : TileIndex [BM, ND] → ℝ) (kT vT : TileIndex [NC, ND] → ℝ)
    (keyScale : Fin NC → ℝ) (keep : Fin BM → Fin NC → Prop)
    [∀ i j, Decidable (keep i j)] (BN c : Nat) (hBN : 0 < BN) (i : Fin BM) (d : Fin ND)
    (Mc1 : WithBot ℝ) :
    let m := (aft3StateBotG qT kT vT keyScale keep (c * BN) i d).1
    let α := (WithBot.realExp2 (WithBot.realSub m Mc1)).unbotD 0
    (aft3StateBotKG qT kT vT keyScale keep (c * BN) i d).2.1 * α
        = (aft3StateBotG qT kT vT keyScale keep (c * BN) i d).2.1 * α
      ∧ (aft3StateBotKG qT kT vT keyScale keep (c * BN) i d).2.2 * α
        = (aft3StateBotG qT kT vT keyScale keep (c * BN) i d).2.2 * α := by
  intro m α
  unfold aft3StateBotKG
  by_cases hc0 : c = 0
  · subst hc0
    simp only [Nat.zero_mul, if_pos rfl]
    have hmbot : m = ⊥ := by
      show (aft3StateBotG qT kT vT keyScale keep (0 * BN) i d).1 = ⊥
      rw [aft3StateBotG_fst_eq_runningMax, Nat.zero_mul, aft3RunningMaxG_zero]
    have hα0 : α = 0 := by
      show (WithBot.realExp2 (WithBot.realSub m Mc1)).unbotD 0 = 0
      rw [hmbot, WithBot.realSub_bot_left, WithBot.realExp2_bot]; rfl
    rw [hα0]; simp
  · have hne0 : c * BN ≠ 0 := Nat.mul_ne_zero hc0 hBN.ne'
    rw [if_neg hne0]
    exact ⟨rfl, rfl⟩

theorem aft3StateBotKG_zero {BM ND NC : Nat}
    (qT : TileIndex [BM, ND] → ℝ) (kT vT : TileIndex [NC, ND] → ℝ)
    (keyScale : Fin NC → ℝ) (keep : Fin BM → Fin NC → Prop)
    [∀ i j, Decidable (keep i j)] (i : Fin BM) (d : Fin ND) :
    aft3StateBotKG qT kT vT keyScale keep 0 i d
      = aft3StateBot1G qT kT vT keyScale keep 0 i d := by
  unfold aft3StateBotKG aft3StateBot1G aft3KeysUptoG
  rw [if_pos rfl]
  rw [show (List.finRange NC).filterMap
        (fun j : Fin NC => if j.val < 0 ∧ keep i j
          then some (keyScale j * Finset.univ.sum (fun e : Fin ND =>
                qT (i, e, PUnit.unit) * kT (j, e, PUnit.unit)), vT (j, d, PUnit.unit))
          else none) = [] from by
    apply List.filterMap_eq_nil_iff.mpr; intro j _; simp]
  rfl

/-- **General empty-window `0/0` reconciliation** at the full window `hi = NC`. -/
theorem aft3StateBotKG_full_eq_streaming {BM ND NC : Nat}
    (qT : TileIndex [BM, ND] → ℝ) (kT vT : TileIndex [NC, ND] → ℝ)
    (keyScale : Fin NC → ℝ) (keep : Fin BM → Fin NC → Prop)
    [∀ i j, Decidable (keep i j)] (hNC : 0 < NC)
    (ir : Fin BM) (dd : Fin ND) (d0 : Fin ND) :
    ((aft3StateBotKG qT kT vT keyScale keep NC ir dd).2.2)
        / ((aft3StateBotKG qT kT vT keyScale keep NC ir d0).2.1)
      = (let st := (aft3KeysUptoG qT kT vT keyScale keep NC ir dd).foldl osStep (0, 0, 0)
         st.2.2 / st.2.1) := by
  have hNC0 : NC ≠ 0 := hNC.ne'
  have hK : aft3StateBotKG qT kT vT keyScale keep NC ir dd
      = aft3StateBotG qT kT vT keyScale keep NC ir dd := by
    unfold aft3StateBotKG; rw [if_neg hNC0]
  have hK0 : aft3StateBotKG qT kT vT keyScale keep NC ir d0
      = aft3StateBotG qT kT vT keyScale keep NC ir d0 := by
    unfold aft3StateBotKG; rw [if_neg hNC0]
  rw [hK, hK0]
  by_cases hne : aft3RunningMaxG qT kT vT keyScale keep NC ir dd = ⊥
  · have hden : (aft3StateBotG qT kT vT keyScale keep NC ir d0).2.1 = 0 := by
      rw [aft3StateBotG_snd_fst]
      rw [aft3KeysUptoG_sum_zero_of_bot qT kT vT keyScale keep NC ir d0
        (by rw [aft3RunningMaxG_eq qT kT vT keyScale keep NC ir d0 dd]; exact hne) _,
        mul_zero]
    have hnum : (aft3StateBotG qT kT vT keyScale keep NC ir dd).2.2 = 0 := by
      rw [aft3StateBotG_snd_snd]
      rw [aft3KeysUptoG_sum_zero_of_bot qT kT vT keyScale keep NC ir dd hne _, mul_zero]
    have hkeys : aft3KeysUptoG qT kT vT keyScale keep NC ir dd = [] := by
      by_contra hc
      obtain ⟨p, hp⟩ := List.exists_mem_of_ne_nil _ hc
      have hmem : ((p.1 : ℝ) : WithBot ℝ) ∈
          (aft3KeysUptoG qT kT vT keyScale keep NC ir dd).map (fun q => ((q.1 : ℝ) : WithBot ℝ)) :=
        List.mem_map_of_mem hp
      have := aft3_mem_le_foldr_sup _ _ hmem
      rw [← aft3RunningMaxG, hne] at this
      exact absurd (le_bot_iff.mp this) WithBot.coe_ne_bot
    rw [hnum, hden, hkeys]; simp
  · rw [show (aft3StateBotG qT kT vT keyScale keep NC ir d0).2.1
          = (aft3StateBotG qT kT vT keyScale keep NC ir dd).2.1 from
        aft3StateBotG_snd_fst_indep qT kT vT keyScale keep NC ir d0 dd]
    exact aft3StateBotG_ratio_eq qT kT vT keyScale keep NC ir dd hne

/-! ## Dimension-general loop-body op-eval recipes

The `*G` op-eval recipes (`aft3_qk_sub_evalG`/`aft3_p_evalG`/etc.) are stated over
`[BM, BN]`/`[BM]` with symbolic window size. The already-general recipes
(`aft3_load_*`, `aft3_advance_*`, `aft3_qkzeros_eval`, `aft3_qk_dot_eval`,
`aft3_qk_scale_ref_eval`, `aft3_acc_eval`, the floorDiv/mod/ptr helpers) are reused
directly. -/

/-- General L5: `dist = arange[:,None] - arange[None,:] + start_m·BM - start_n + off`. -/
theorem aft3_dist_evalG (s : BlockState) (SM SN BM BN off : Nat) (hax1 : 1 < [BM].length.succ)
    (hax0 : 0 < [BN].length.succ)
    (hsm : s.regs .nat [] "start_m" = some (Tile.scalar SM))
    (hsn : s.regs .nat [] "start_n" = some (Tile.scalar SN)) :
    evalOp (Op.add .nat Broadcast.scalarR
        (Op.sub .nat Broadcast.scalarR
          (Op.add .nat Broadcast.scalarR
            (Op.sub .nat (Broadcast.consR (Broadcast.consL Broadcast.nil))
              (Op.expandDim ⟨1, hax1⟩ (Op.arange BM))
              (Op.expandDim ⟨0, hax0⟩ (Op.arange BN)))
            (Op.mul .nat Broadcast.nil (Op.ref .nat [] "start_m") (Op.constNat BM)))
          (Op.ref .nat [] "start_n"))
        (Op.constNat off)) s
      = some ⟨fun idx : TileIndex [BM, BN] =>
          ((idx.1.val - idx.2.1.val) + SM * BM - SN) + off⟩ := by
  simp only [evalOp.eq_def, hsm, hsn, Option.bind_eq_bind, Option.bind_some, Option.bind]
  refine congrArg some ?_
  ext idx
  simp only [Tile.bop_data, Tile.expandDim_data, Tile.vec, Tile.scalar,
    Broadcast.leftIndex_scalarR, Broadcast.rightIndex_scalarR,
    Broadcast.leftIndex_consR, Broadcast.rightIndex_consR,
    Broadcast.leftIndex_consL, Broadcast.rightIndex_consL,
    Broadcast.leftIndex_nil, Broadcast.rightIndex_nil,
    TileShape.dropInsertedIndex, NumericDType.add, NumericDType.mul, NumericDType.sub]

/-- General L6 case 1: `mask = (dist >= 0) & (dist < size)`. -/
theorem aft3_mask_case1_evalG (s : BlockState) (BM BN size : Nat) (disttile : Tile .nat [BM, BN])
    (hd : s.regs .nat [BM, BN] "dist" = some disttile) :
    evalOp (Op.boolAnd (Broadcast.consSame (Broadcast.consSame Broadcast.nil))
        (Op.ge ComparableDType.nat Broadcast.scalarR (Op.ref .nat [BM, BN] "dist")
          (Op.constNat 0))
        (Op.lt ComparableDType.nat Broadcast.scalarR (Op.ref .nat [BM, BN] "dist")
          (Op.constNat size))) s
      = some ⟨fun idx : TileIndex [BM, BN] =>
          ComparableDType.nat.ge (disttile.data idx) 0
            && ComparableDType.nat.lt (disttile.data idx) size⟩ := by
  rw [aft3_evalOp_boolAnd, aft3_evalOp_ge, evalOp_lt]
  simp only [evalOp_ref, evalOp_constNat, hd, Option.bind_eq_bind, Option.bind_some]
  refine congrArg some ?_
  ext idx
  simp only [Tile.bop_data, Tile.cop_data, Tile.scalar,
    Broadcast.leftIndex_scalarR, Broadcast.rightIndex_scalarR,
    Broadcast.leftIndex_consSame, Broadcast.rightIndex_consSame,
    Broadcast.leftIndex_nil, Broadcast.rightIndex_nil]

/-- General L6 case 2: `mask = (dist >= size)`. -/
theorem aft3_mask_case2_evalG (s : BlockState) (BM BN size : Nat) (disttile : Tile .nat [BM, BN])
    (hd : s.regs .nat [BM, BN] "dist" = some disttile) :
    evalOp (Op.ge ComparableDType.nat Broadcast.scalarR (Op.ref .nat [BM, BN] "dist")
        (Op.constNat size)) s
      = some ⟨fun idx : TileIndex [BM, BN] =>
          ComparableDType.nat.ge (disttile.data idx) size⟩ := by
  rw [aft3_evalOp_ge]
  simp only [evalOp_ref, evalOp_constNat, hd, Option.bind_eq_bind, Option.bind_some]
  refine congrArg some ?_
  ext idx
  simp only [Tile.cop_data, Tile.scalar,
    Broadcast.leftIndex_scalarR, Broadcast.rightIndex_scalarR,
    Broadcast.leftIndex_nil, Broadcast.rightIndex_nil]

/-- General L7: `qk = tl.where(mask, qk, -inf)`. -/
theorem aft3_where_evalG (s : BlockState) (BM BN : Nat) (masktile : Tile .bool [BM, BN])
    (qktile : Tile .real [BM, BN])
    (hmask : s.regs .bool [BM, BN] "mask" = some masktile)
    (hqk : s.regs .real [BM, BN] "qk" = some qktile) :
    evalOp (Op.where (Op.ref .bool [BM, BN] "mask")
        (Op.ref .real [BM, BN] "qk") (Op.broadcast Op.negInf [BM, BN])) s
      = some ⟨fun idx : TileIndex [BM, BN] =>
          if masktile.data idx then qktile.data idx else (⊥ : WithBot ℝ)⟩ := by
  have hbcast : @evalOp TileDType.real [BM, BN] (Op.broadcast Op.negInf [BM, BN]) s
      = some (⟨fun _ : TileIndex [BM, BN] => (⊥ : WithBot ℝ)⟩ : Tile .real [BM, BN]) := by
    simp only [evalOp, evalOp_negInf, Option.bind_eq_bind, Option.bind_some]; rfl
  rw [evalOp_where]
  simp only [evalOp_ref, hmask, hqk, hbcast, Option.bind_eq_bind, Option.bind_some]
  refine congrArg some ?_
  ext idx
  simp only [Tile.select_data, Tile.scalar]

/-- General L8: `m_ij = tl.maximum(m_i, tl.max(qk, 1))`. -/
theorem aft3_mij_evalG (s : BlockState) (BM BN : Nat)
    (mtile : Tile .real [BM]) (qktile : Tile .real [BM, BN]) (rmaxT : Tile .real [BM])
    (hax : 1 < [BM, BN].length)
    (hmi : s.regs .real [BM] "m_i" = some mtile)
    (hqk : s.regs .real [BM, BN] "qk" = some qktile)
    (hrm : Tile.reduceMaxDrop (⟨1, hax⟩ : Fin [BM, BN].length) qktile = some rmaxT) :
    evalOp (Op.where
        (Op.gt .real (Broadcast.consSame Broadcast.nil)
          (Op.ref .real [BM] "m_i")
          (Op.reduceMax (⟨1, hax⟩ : Fin [BM, BN].length) Bool.false (Op.ref .real [BM, BN] "qk")))
        (Op.ref .real [BM] "m_i")
        (Op.reduceMax (⟨1, hax⟩ : Fin [BM, BN].length) Bool.false (Op.ref .real [BM, BN] "qk"))) s
      = some (Tile.select
          (Tile.cop ComparableDType.real.gt (Broadcast.consSame Broadcast.nil) mtile rmaxT)
          mtile rmaxT) := by
  have hrmaxN : evalOp (Op.reduceMax (⟨1, hax⟩ : Fin [BM, BN].length) Bool.false
      (Op.ref .real [BM, BN] "qk")) s = some rmaxT := by
    rw [evalOp_reduceMax]; simp only [evalOp_ref, hqk]; exact hrm
  have hrmax : @evalOp TileDType.real [BM]
      (Op.reduceMax (⟨1, hax⟩ : Fin [BM, BN].length) Bool.false
        (Op.ref .real [BM, BN] "qk")) s = some rmaxT := hrmaxN
  rw [evalOp_where]
  simp only [evalOp_gt, evalOp_ref, hmi, hrmax, Option.bind_eq_bind, Option.bind_some]

/-- General L9: `qk = qk - m_ij[:, None]`. -/
theorem aft3_qk_sub_evalG (s : BlockState) (BM BN : Nat) (hax : 1 < [BM].length.succ)
    (qktile : Tile .real [BM, BN]) (mc : Tile .real [BM])
    (hqk : s.regs .real [BM, BN] "qk" = some qktile)
    (hmij : s.regs .real [BM] "m_ij" = some mc) :
    evalOp (Op.sub .real (Broadcast.consSame (Broadcast.consR Broadcast.nil))
        (Op.ref .real [BM, BN] "qk") (Op.expandDim ⟨1, hax⟩ (Op.ref .real [BM] "m_ij"))) s
      = some (Tile.bop NumericDType.real.sub
          (Broadcast.consSame (Broadcast.consR Broadcast.nil))
          qktile (Tile.expandDim ⟨1, hax⟩ mc)) := by
  have hexp : @evalOp TileDType.real [BM, 1]
      (Op.expandDim ⟨1, hax⟩ (Op.ref .real [BM] "m_ij")) s
      = some (Tile.expandDim ⟨1, hax⟩ mc) := evalOp_expandDim_ref_of_regs _ _ _ _ _ _ hmij
  rw [evalOp_sub]
  simp only [evalOp_ref, hqk, hexp, Option.bind_eq_bind, Option.bind_some]; rfl

/-- General L10: `p = tl.math.exp2(qk)`. -/
theorem aft3_p_evalG (s : BlockState) (BM BN : Nat) (qktile : Tile .real [BM, BN])
    (hqk : s.regs .real [BM, BN] "qk" = some qktile) :
    evalOp (Op.exp2 (Op.ref .real [BM, BN] "qk")) s
      = some (Tile.uop WithBot.realExp2 qktile) := by
  rw [aft3_evalOp_exp2]; simp only [evalOp_ref, hqk, Option.bind_eq_bind, Option.bind_some]

/-- General L11: `p = tl.where(mask, p, 0)`. -/
theorem aft3_p_mask_evalG (s : BlockState) (BM BN : Nat) (masktile : Tile .bool [BM, BN])
    (ptile : Tile .real [BM, BN])
    (hmask : s.regs .bool [BM, BN] "mask" = some masktile)
    (hp : s.regs .real [BM, BN] "p" = some ptile) :
    evalOp (Op.where (Op.ref .bool [BM, BN] "mask")
        (Op.ref .real [BM, BN] "p") (Op.broadcast (Op.const 0.0) [BM, BN])) s
      = some ⟨fun idx : TileIndex [BM, BN] =>
          if masktile.data idx then ptile.data idx else (some (0.0 : ℝ) : WithBot ℝ)⟩ := by
  have hbcast : @evalOp TileDType.real [BM, BN] (Op.broadcast (Op.const 0.0) [BM, BN]) s
      = some (⟨fun _ : TileIndex [BM, BN] => (some (0.0 : ℝ) : WithBot ℝ)⟩ : Tile .real [BM, BN]) := by
    simp only [evalOp, evalOp_const, Option.bind_eq_bind, Option.bind_some]; rfl
  rw [evalOp_where]
  simp only [evalOp_ref, hmask, hp, hbcast, Option.bind_eq_bind, Option.bind_some]
  refine congrArg some ?_
  ext idx
  simp only [Tile.select_data, Tile.scalar]

/-- General L12: `l_ij = tl.sum(p, 1)`. -/
theorem aft3_lij_evalG (s : BlockState) (BM BN : Nat) (ptile : Tile .real [BM, BN])
    (hax : 1 < [BM, BN].length)
    (hp : s.regs .real [BM, BN] "p" = some ptile) :
    evalOp (Op.reduceSum (⟨1, hax⟩ : Fin [BM, BN].length) Bool.false
        (Op.ref .real [BM, BN] "p")) s
      = some (Tile.reduceSumDrop (⟨1, hax⟩ : Fin [BM, BN].length) ptile) := by
  rw [evalOp_reduceSum]; simp only [evalOp_ref, hp, Option.bind_eq_bind, Option.bind_some]; rfl

/-- General L13: `tmp = m_i - m_ij`. -/
theorem aft3_tmp_evalG (s : BlockState) (BM : Nat) (mi mij : Tile .real [BM])
    (hmi : s.regs .real [BM] "m_i" = some mi)
    (hmij : s.regs .real [BM] "m_ij" = some mij) :
    evalOp (Op.sub .real (Broadcast.consSame Broadcast.nil)
        (Op.ref .real [BM] "m_i") (Op.ref .real [BM] "m_ij")) s
      = some (Tile.bop NumericDType.real.sub (Broadcast.consSame Broadcast.nil) mi mij) := by
  rw [evalOp_sub]; simp only [evalOp_ref, hmi, hmij, Option.bind_eq_bind, Option.bind_some]

/-- General L14: `alpha = tl.math.exp2(tmp)`. -/
theorem aft3_alpha_evalG (s : BlockState) (BM : Nat) (tmptile : Tile .real [BM])
    (htmp : s.regs .real [BM] "tmp" = some tmptile) :
    evalOp (Op.exp2 (Op.ref .real [BM] "tmp")) s
      = some (Tile.uop WithBot.realExp2 tmptile) := by
  rw [aft3_evalOp_exp2]; simp only [evalOp_ref, htmp, Option.bind_eq_bind, Option.bind_some]

/-- General L15: `l_i = l_i * alpha + l_ij`. -/
theorem aft3_li_evalG (s : BlockState) (BM : Nat) (li alpha lij : Tile .real [BM])
    (hli : s.regs .real [BM] "l_i" = some li)
    (halpha : s.regs .real [BM] "alpha" = some alpha)
    (hlij : s.regs .real [BM] "l_ij" = some lij) :
    evalOp (Op.add .real (Broadcast.consSame Broadcast.nil)
        (Op.mul .real (Broadcast.consSame Broadcast.nil)
          (Op.ref .real [BM] "l_i") (Op.ref .real [BM] "alpha"))
        (Op.ref .real [BM] "l_ij")) s
      = some (Tile.bop NumericDType.real.add (Broadcast.consSame Broadcast.nil)
          (Tile.bop NumericDType.real.mul (Broadcast.consSame Broadcast.nil) li alpha) lij) := by
  rw [evalOp_add, evalOp_mul]
  simp only [evalOp_ref, hli, halpha, hlij, Option.bind_eq_bind, Option.bind_some]

/-- General L16: `acc = acc * alpha[:, None]`. -/
theorem aft3_acc_rescale_evalG (s : BlockState) (BM BN : Nat) (hax : 1 < [BM].length.succ)
    (acctile : Tile .real [BM, BN]) (alpha : Tile .real [BM])
    (hacc : s.regs .real [BM, BN] "acc" = some acctile)
    (halpha : s.regs .real [BM] "alpha" = some alpha) :
    evalOp (Op.mul .real (Broadcast.consSame (Broadcast.consR Broadcast.nil))
        (Op.ref .real [BM, BN] "acc") (Op.expandDim ⟨1, hax⟩ (Op.ref .real [BM] "alpha"))) s
      = some (Tile.bop NumericDType.real.mul
          (Broadcast.consSame (Broadcast.consR Broadcast.nil))
          acctile (Tile.expandDim ⟨1, hax⟩ alpha)) := by
  have hexp : @evalOp TileDType.real [BM, 1]
      (Op.expandDim ⟨1, hax⟩ (Op.ref .real [BM] "alpha")) s
      = some (Tile.expandDim ⟨1, hax⟩ alpha) := evalOp_expandDim_ref_of_regs _ _ _ _ _ _ halpha
  rw [evalOp_mul]
  simp only [evalOp_ref, hacc, hexp, Option.bind_eq_bind, Option.bind_some]; rfl

/-- General L19: `m_i = m_ij`. -/
theorem aft3_mi_carry_evalG (s : BlockState) (BM : Nat) (mij : Tile .real [BM])
    (hmij : s.regs .real [BM] "m_ij" = some mij) :
    evalOp (Op.ref .real [BM] "m_ij") s = some mij := by
  rw [evalOp_ref, hmij]

/-! ## Dimension-general exec-assembly stack.

A parallel exec stack to the test-shape one, parameterized over symbolic dims
`(BM ND NC BN : Nat)`, strides, `H H_KV ROUND_CTX`, sliding-window `off`/`size`,
and `sm_scale`. The forRange bounds become `0 NC BN`. Reuses the dimension-general
math foundation (`aft3RunningMaxG`, `aft3StateBot1G`, `aft3StateBotKG`,
`aft3KeysUptoG`, the bridges) and op-eval recipes (`aft3_*_evalG`) directly. -/

/-- General lowered preLoop statements (through `q` load). -/
noncomputable def aft3PreLoopG (Q K V M Out L : RegionName) (sm_scale : ℝ)
    (sqz sqh sqm sqk skz skh skn skk svz svh svk svn soz soh som son
      H H_KV N_CTX ROUND_CTX NKV_CTX off size BM ND BN : Nat) : List Stmt :=
  [ Stmt.assign TileDType.nat [] "start_m" (Op.programId 0),
    Stmt.assign TileDType.nat [] "off_hz" (Op.programId 1),
    Stmt.assign TileDType.nat [] "off_z" (Op.floorDiv IntegralDType.nat Broadcast.nil (Op.ref TileDType.nat [] "off_hz") (Op.constNat H)),
    Stmt.assign TileDType.nat [] "off_h" (Op.mod IntegralDType.nat Broadcast.nil (Op.ref TileDType.nat [] "off_hz") (Op.constNat H)),
    Stmt.assign TileDType.nat [] "off_hkv" (Op.floorDiv IntegralDType.nat Broadcast.nil (Op.ref TileDType.nat [] "off_h") (Op.floorDiv IntegralDType.nat Broadcast.nil (Op.constNat H) (Op.constNat H_KV))),
    Stmt.assign TileDType.nat [] "q_offset" (Op.add NumericDType.nat Broadcast.nil (Op.mul NumericDType.nat Broadcast.nil (Op.ref TileDType.nat [] "off_z") (Op.constNat sqz)) (Op.mul NumericDType.nat Broadcast.nil (Op.ref TileDType.nat [] "off_h") (Op.constNat sqh))),
    Stmt.assign TileDType.nat [] "k_offset" (Op.add NumericDType.nat Broadcast.nil (Op.mul NumericDType.nat Broadcast.nil (Op.ref TileDType.nat [] "off_z") (Op.constNat skz)) (Op.mul NumericDType.nat Broadcast.nil (Op.ref TileDType.nat [] "off_hkv") (Op.constNat skh))),
    Stmt.assign TileDType.nat [] "v_offset" (Op.add NumericDType.nat Broadcast.nil (Op.mul NumericDType.nat Broadcast.nil (Op.ref TileDType.nat [] "off_z") (Op.constNat svz)) (Op.mul NumericDType.nat Broadcast.nil (Op.ref TileDType.nat [] "off_hkv") (Op.constNat svh))),
    Stmt.assign TileDType.nat [] "o_offset" (Op.add NumericDType.nat Broadcast.nil (Op.mul NumericDType.nat Broadcast.nil (Op.ref TileDType.nat [] "off_z") (Op.constNat soz)) (Op.mul NumericDType.nat Broadcast.nil (Op.ref TileDType.nat [] "off_h") (Op.constNat soh))),
    Stmt.assign TileDType.blockPtr [BM, ND] "Q_block_ptr" (Op.makeBlockPtrDynOffsets Q (Op.ref TileDType.nat [] "q_offset") [N_CTX, ND] [BM, ND] [sqm, sqk] [Op.mul NumericDType.nat Broadcast.nil (Op.ref TileDType.nat [] "start_m") (Op.constNat BM), Op.constNat 0]),
    Stmt.assign TileDType.blockPtr [BN, ND] "V_block_ptr" (Op.makeBlockPtrDyn V (Op.ref TileDType.nat [] "v_offset") [NKV_CTX, ND] [BN, ND] [svk, svn] [0, 0]),
    Stmt.assign TileDType.blockPtr [ND, BN] "K_block_ptr" (Op.makeBlockPtrDyn K (Op.ref TileDType.nat [] "k_offset") [ND, NKV_CTX] [ND, BN] [skk, skn] [0, 0]),
    Stmt.assign TileDType.blockPtr [BM, ND] "O_block_ptr" (Op.makeBlockPtrDynOffsets Out (Op.ref TileDType.nat [] "o_offset") [ROUND_CTX, ND] [BM, ND] [som, son] [Op.mul NumericDType.nat Broadcast.nil (Op.ref TileDType.nat [] "start_m") (Op.constNat BM), Op.constNat 0]),
    Stmt.assign TileDType.nat [BM] "offs_m" (Op.add NumericDType.nat Broadcast.scalarL (Op.mul NumericDType.nat Broadcast.nil (Op.ref TileDType.nat [] "start_m") (Op.constNat BM)) (Op.arange BM)),
    Stmt.assign TileDType.ptr [BM] "m_ptrs" (Op.ptrAdd Broadcast.scalarL (Op.ptrBase M) (Op.add NumericDType.nat Broadcast.scalarL (Op.mul NumericDType.nat Broadcast.nil (Op.ref TileDType.nat [] "off_hz") (Op.constNat ROUND_CTX)) (Op.ref TileDType.nat [BM] "offs_m"))),
    Stmt.assign TileDType.ptr [BM] "l_ptrs" (Op.ptrAdd Broadcast.scalarL (Op.ptrBase L) (Op.add NumericDType.nat Broadcast.scalarL (Op.mul NumericDType.nat Broadcast.nil (Op.ref TileDType.nat [] "off_hz") (Op.constNat ROUND_CTX)) (Op.ref TileDType.nat [BM] "offs_m"))),
    Stmt.ifThenElse (Op.ne ComparableDType.nat Broadcast.nil (Op.constNat 1) (Op.constNat 0)) [Stmt.assign TileDType.real [BM] "m_i" ((Op.add NumericDType.real Broadcast.scalarR (Op.full [BM] (Op.const 0)) Op.negInf)), Stmt.assign TileDType.real [BM] "l_i" ((Op.add NumericDType.real Broadcast.scalarR (Op.full [BM] (Op.const 0)) (Op.const 1.0))), Stmt.assign TileDType.real [BM, ND] "acc" (Op.full [BM, ND] (Op.const 0))] [Stmt.assign TileDType.real [BM] "m_i" (Op.load TileDType.real (MemAccess.ptr (Op.ref TileDType.ptr [BM] "m_ptrs")) MaskOpt.none), Stmt.assign TileDType.real [BM] "l_i" (Op.load TileDType.real (MemAccess.ptr (Op.ref TileDType.ptr [BM] "l_ptrs")) MaskOpt.none), Stmt.assign TileDType.real [BM, ND] "acc" (Op.load TileDType.real (MemAccess.blockPtr (Op.ref TileDType.blockPtr [BM, ND] "O_block_ptr") []) MaskOpt.none .unspecified)],
    Stmt.assign TileDType.real [] "qk_scale" (Op.mul NumericDType.real Broadcast.nil (Op.const sm_scale) (Op.const 1.0)),
    Stmt.assign TileDType.real [] "qk_scale" (Op.mul NumericDType.real Broadcast.nil (Op.ref TileDType.real [] "qk_scale") (Op.const 1.4426950408889634)),
    Stmt.ifThenElse (Op.ne ComparableDType.nat Broadcast.nil (Op.constNat 1) (Op.constNat 0)) [Stmt.assign TileDType.real [BM, ND] "q" (Op.load TileDType.real (MemAccess.blockPtr (Op.ref TileDType.blockPtr [BM, ND] "Q_block_ptr") []) MaskOpt.none .unspecified)] [Stmt.assign TileDType.real [BM, ND] "q" (Op.load TileDType.real (MemAccess.blockPtr (Op.ref TileDType.blockPtr [BM, ND] "Q_block_ptr") [0, 1]) MaskOpt.none)] ]

/-- Case-4 (`INIT=False` resume) preLoop: identical to `aft3PreLoopG` except the
`INIT` `ifThenElse` condition is `0 ≠ 0` (false), so it takes the load branch
(`m_i/l_i/acc = load(m_ptrs/l_ptrs/O_block_ptr)`) instead of the fresh ⊥/1/0 init. -/
noncomputable def aft3PreLoopG_init0 (Q K V M Out L : RegionName) (sm_scale : ℝ)
    (sqz sqh sqm sqk skz skh skn skk svz svh svk svn soz soh som son
      H H_KV N_CTX ROUND_CTX NKV_CTX off size BM ND BN : Nat) : List Stmt :=
  [ Stmt.assign TileDType.nat [] "start_m" (Op.programId 0),
    Stmt.assign TileDType.nat [] "off_hz" (Op.programId 1),
    Stmt.assign TileDType.nat [] "off_z" (Op.floorDiv IntegralDType.nat Broadcast.nil (Op.ref TileDType.nat [] "off_hz") (Op.constNat H)),
    Stmt.assign TileDType.nat [] "off_h" (Op.mod IntegralDType.nat Broadcast.nil (Op.ref TileDType.nat [] "off_hz") (Op.constNat H)),
    Stmt.assign TileDType.nat [] "off_hkv" (Op.floorDiv IntegralDType.nat Broadcast.nil (Op.ref TileDType.nat [] "off_h") (Op.floorDiv IntegralDType.nat Broadcast.nil (Op.constNat H) (Op.constNat H_KV))),
    Stmt.assign TileDType.nat [] "q_offset" (Op.add NumericDType.nat Broadcast.nil (Op.mul NumericDType.nat Broadcast.nil (Op.ref TileDType.nat [] "off_z") (Op.constNat sqz)) (Op.mul NumericDType.nat Broadcast.nil (Op.ref TileDType.nat [] "off_h") (Op.constNat sqh))),
    Stmt.assign TileDType.nat [] "k_offset" (Op.add NumericDType.nat Broadcast.nil (Op.mul NumericDType.nat Broadcast.nil (Op.ref TileDType.nat [] "off_z") (Op.constNat skz)) (Op.mul NumericDType.nat Broadcast.nil (Op.ref TileDType.nat [] "off_hkv") (Op.constNat skh))),
    Stmt.assign TileDType.nat [] "v_offset" (Op.add NumericDType.nat Broadcast.nil (Op.mul NumericDType.nat Broadcast.nil (Op.ref TileDType.nat [] "off_z") (Op.constNat svz)) (Op.mul NumericDType.nat Broadcast.nil (Op.ref TileDType.nat [] "off_hkv") (Op.constNat svh))),
    Stmt.assign TileDType.nat [] "o_offset" (Op.add NumericDType.nat Broadcast.nil (Op.mul NumericDType.nat Broadcast.nil (Op.ref TileDType.nat [] "off_z") (Op.constNat soz)) (Op.mul NumericDType.nat Broadcast.nil (Op.ref TileDType.nat [] "off_h") (Op.constNat soh))),
    Stmt.assign TileDType.blockPtr [BM, ND] "Q_block_ptr" (Op.makeBlockPtrDynOffsets Q (Op.ref TileDType.nat [] "q_offset") [N_CTX, ND] [BM, ND] [sqm, sqk] [Op.mul NumericDType.nat Broadcast.nil (Op.ref TileDType.nat [] "start_m") (Op.constNat BM), Op.constNat 0]),
    Stmt.assign TileDType.blockPtr [BN, ND] "V_block_ptr" (Op.makeBlockPtrDyn V (Op.ref TileDType.nat [] "v_offset") [NKV_CTX, ND] [BN, ND] [svk, svn] [0, 0]),
    Stmt.assign TileDType.blockPtr [ND, BN] "K_block_ptr" (Op.makeBlockPtrDyn K (Op.ref TileDType.nat [] "k_offset") [ND, NKV_CTX] [ND, BN] [skk, skn] [0, 0]),
    Stmt.assign TileDType.blockPtr [BM, ND] "O_block_ptr" (Op.makeBlockPtrDynOffsets Out (Op.ref TileDType.nat [] "o_offset") [ROUND_CTX, ND] [BM, ND] [som, son] [Op.mul NumericDType.nat Broadcast.nil (Op.ref TileDType.nat [] "start_m") (Op.constNat BM), Op.constNat 0]),
    Stmt.assign TileDType.nat [BM] "offs_m" (Op.add NumericDType.nat Broadcast.scalarL (Op.mul NumericDType.nat Broadcast.nil (Op.ref TileDType.nat [] "start_m") (Op.constNat BM)) (Op.arange BM)),
    Stmt.assign TileDType.ptr [BM] "m_ptrs" (Op.ptrAdd Broadcast.scalarL (Op.ptrBase M) (Op.add NumericDType.nat Broadcast.scalarL (Op.mul NumericDType.nat Broadcast.nil (Op.ref TileDType.nat [] "off_hz") (Op.constNat ROUND_CTX)) (Op.ref TileDType.nat [BM] "offs_m"))),
    Stmt.assign TileDType.ptr [BM] "l_ptrs" (Op.ptrAdd Broadcast.scalarL (Op.ptrBase L) (Op.add NumericDType.nat Broadcast.scalarL (Op.mul NumericDType.nat Broadcast.nil (Op.ref TileDType.nat [] "off_hz") (Op.constNat ROUND_CTX)) (Op.ref TileDType.nat [BM] "offs_m"))),
    Stmt.ifThenElse (Op.ne ComparableDType.nat Broadcast.nil (Op.constNat 0) (Op.constNat 0)) [Stmt.assign TileDType.real [BM] "m_i" ((Op.add NumericDType.real Broadcast.scalarR (Op.full [BM] (Op.const 0)) Op.negInf)), Stmt.assign TileDType.real [BM] "l_i" ((Op.add NumericDType.real Broadcast.scalarR (Op.full [BM] (Op.const 0)) (Op.const 1.0))), Stmt.assign TileDType.real [BM, ND] "acc" (Op.full [BM, ND] (Op.const 0))] [Stmt.assign TileDType.real [BM] "m_i" (Op.load TileDType.real (MemAccess.ptr (Op.ref TileDType.ptr [BM] "m_ptrs")) MaskOpt.none), Stmt.assign TileDType.real [BM] "l_i" (Op.load TileDType.real (MemAccess.ptr (Op.ref TileDType.ptr [BM] "l_ptrs")) MaskOpt.none), Stmt.assign TileDType.real [BM, ND] "acc" (Op.load TileDType.real (MemAccess.blockPtr (Op.ref TileDType.blockPtr [BM, ND] "O_block_ptr") []) MaskOpt.none .unspecified)],
    Stmt.assign TileDType.real [] "qk_scale" (Op.mul NumericDType.real Broadcast.nil (Op.const sm_scale) (Op.const 1.0)),
    Stmt.assign TileDType.real [] "qk_scale" (Op.mul NumericDType.real Broadcast.nil (Op.ref TileDType.real [] "qk_scale") (Op.const 1.4426950408889634)),
    Stmt.ifThenElse (Op.ne ComparableDType.nat Broadcast.nil (Op.constNat 1) (Op.constNat 0)) [Stmt.assign TileDType.real [BM, ND] "q" (Op.load TileDType.real (MemAccess.blockPtr (Op.ref TileDType.blockPtr [BM, ND] "Q_block_ptr") []) MaskOpt.none .unspecified)] [Stmt.assign TileDType.real [BM, ND] "q" (Op.load TileDType.real (MemAccess.blockPtr (Op.ref TileDType.blockPtr [BM, ND] "Q_block_ptr") [0, 1]) MaskOpt.none)] ]

/-- General lowered loop body (case 1, sliding window). -/
def aft3LoopBodyG (sm_scale : ℝ) (off size BM ND BN : Nat) : List Stmt :=
  [ Stmt.assign TileDType.real [ND, BN] "k" (Op.load TileDType.real (MemAccess.blockPtr (Op.ref TileDType.blockPtr [ND, BN] "K_block_ptr") []) MaskOpt.none .unspecified),
    Stmt.assign TileDType.real [BM, BN] "qk" (Op.full [BM, BN] (Op.const 0)),
    Stmt.assign TileDType.real [BM, BN] "qk" ((Op.add NumericDType.real Broadcast.nil.consSame.consSame (Op.ref TileDType.real [BM, BN] "qk") ((Op.dot (batch := []) (Op.ref TileDType.real [BM, ND] "q") (Op.ref TileDType.real [ND, BN] "k"))))),
    Stmt.assign TileDType.real [BM, BN] "qk" ((Op.mul NumericDType.real Broadcast.scalarR (Op.ref TileDType.real [BM, BN] "qk") (Op.ref TileDType.real [] "qk_scale"))),
    Stmt.ifThen (Op.ne ComparableDType.nat Broadcast.nil (Op.constNat 1) (Op.constNat 0)) [Stmt.assign TileDType.nat [BM, BN] "dist" (Op.add NumericDType.nat Broadcast.scalarR (Op.sub NumericDType.nat Broadcast.scalarR (Op.add NumericDType.nat Broadcast.scalarR (Op.sub NumericDType.nat Broadcast.nil.consL.consR (Op.expandDim ⟨1, by simp⟩ (Op.arange BM)) (Op.expandDim ⟨0, by simp⟩ (Op.arange BN))) (Op.mul NumericDType.nat Broadcast.nil (Op.ref TileDType.nat [] "start_m") (Op.constNat BM))) (Op.ref TileDType.nat [] "start_n")) (Op.constNat off)), Stmt.ifThenElse (Op.ne ComparableDType.nat Broadcast.nil (Op.constNat 0) (Op.constNat 0)) [Stmt.assign TileDType.bool [BM, BN] "mask" (Op.ge ComparableDType.nat Broadcast.scalarR (Op.ref TileDType.nat [BM, BN] "dist") (Op.constNat size))] [Stmt.assign TileDType.bool [BM, BN] "mask" (Op.boolAnd Broadcast.nil.consSame.consSame (Op.ge ComparableDType.nat Broadcast.scalarR (Op.ref TileDType.nat [BM, BN] "dist") (Op.constNat 0)) (Op.lt ComparableDType.nat Broadcast.scalarR (Op.ref TileDType.nat [BM, BN] "dist") (Op.constNat size)))], Stmt.assign TileDType.real [BM, BN] "qk" ((Op.ref TileDType.bool [BM, BN] "mask").where (Op.ref TileDType.real [BM, BN] "qk") (Op.negInf.broadcast [BM, BN]))],
    Stmt.assign TileDType.real [BM] "m_ij" (((Op.gt ComparableDType.real Broadcast.nil.consSame (Op.ref TileDType.real [BM] "m_i") (Op.reduceMax ⟨1, by simp⟩ Bool.false (Op.ref TileDType.real [BM, BN] "qk"))).where (Op.ref TileDType.real [BM] "m_i") (Op.reduceMax ⟨1, by simp⟩ Bool.false (Op.ref TileDType.real [BM, BN] "qk")))),
    Stmt.assign TileDType.real [BM, BN] "qk" (Op.sub NumericDType.real Broadcast.nil.consR.consSame (Op.ref TileDType.real [BM, BN] "qk") (Op.expandDim ⟨1, by simp⟩ (Op.ref TileDType.real [BM] "m_ij"))),
    Stmt.assign TileDType.real [BM, BN] "p" (Op.ref TileDType.real [BM, BN] "qk").exp2,
    Stmt.ifThen (Op.ne ComparableDType.nat Broadcast.nil (Op.constNat 1) (Op.constNat 0)) [Stmt.assign TileDType.real [BM, BN] "p" ((Op.ref TileDType.bool [BM, BN] "mask").where (Op.ref TileDType.real [BM, BN] "p") ((Op.const 0.0).broadcast [BM, BN]))],
    Stmt.assign TileDType.real [BM] "l_ij" (Op.reduceSum ⟨1, by simp⟩ Bool.false (Op.ref TileDType.real [BM, BN] "p")),
    Stmt.assign TileDType.real [BM] "tmp" ((Op.sub NumericDType.real Broadcast.nil.consSame (Op.ref TileDType.real [BM] "m_i") (Op.ref TileDType.real [BM] "m_ij"))),
    Stmt.assign TileDType.real [BM] "alpha" (Op.ref TileDType.real [BM] "tmp").exp2,
    Stmt.assign TileDType.real [BM] "l_i" ((Op.add NumericDType.real Broadcast.nil.consSame (Op.mul NumericDType.real Broadcast.nil.consSame (Op.ref TileDType.real [BM] "l_i") (Op.ref TileDType.real [BM] "alpha")) (Op.ref TileDType.real [BM] "l_ij"))),
    Stmt.assign TileDType.real [BM, ND] "acc" ((Op.mul NumericDType.real Broadcast.nil.consR.consSame (Op.ref TileDType.real [BM, ND] "acc") (Op.expandDim ⟨1, by simp⟩ (Op.ref TileDType.real [BM] "alpha")))),
    Stmt.assign TileDType.real [BN, ND] "v" (Op.load TileDType.real (MemAccess.blockPtr (Op.ref TileDType.blockPtr [BN, ND] "V_block_ptr") []) MaskOpt.none .unspecified),
    Stmt.assign TileDType.real [BM, ND] "acc" ((Op.add NumericDType.real Broadcast.nil.consSame.consSame (Op.ref TileDType.real [BM, ND] "acc") ((Op.dot (batch := []) (Op.ref TileDType.real [BM, BN] "p") (Op.ref TileDType.real [BN, ND] "v"))))),
    Stmt.assign TileDType.real [BM] "m_i" ((Op.ref TileDType.real [BM] "m_ij")),
    Stmt.assign TileDType.blockPtr [BN, ND] "V_block_ptr" ((Op.ref TileDType.blockPtr [BN, ND] "V_block_ptr").advanceBlockPtr [BN, (0:Nat)]),
    Stmt.assign TileDType.blockPtr [ND, BN] "K_block_ptr" ((Op.ref TileDType.blockPtr [ND, BN] "K_block_ptr").advanceBlockPtr [(0:Nat), BN]) ]

/-- General lowered loop body (case 2, complement sliding window) — inner select
condition is constexpr-true. -/
def aft3LoopBodyG2 (sm_scale : ℝ) (off size BM ND BN : Nat) : List Stmt :=
  [ Stmt.assign TileDType.real [ND, BN] "k" (Op.load TileDType.real (MemAccess.blockPtr (Op.ref TileDType.blockPtr [ND, BN] "K_block_ptr") []) MaskOpt.none .unspecified),
    Stmt.assign TileDType.real [BM, BN] "qk" (Op.full [BM, BN] (Op.const 0)),
    Stmt.assign TileDType.real [BM, BN] "qk" ((Op.add NumericDType.real Broadcast.nil.consSame.consSame (Op.ref TileDType.real [BM, BN] "qk") ((Op.dot (batch := []) (Op.ref TileDType.real [BM, ND] "q") (Op.ref TileDType.real [ND, BN] "k"))))),
    Stmt.assign TileDType.real [BM, BN] "qk" ((Op.mul NumericDType.real Broadcast.scalarR (Op.ref TileDType.real [BM, BN] "qk") (Op.ref TileDType.real [] "qk_scale"))),
    Stmt.ifThen (Op.ne ComparableDType.nat Broadcast.nil (Op.constNat 1) (Op.constNat 0)) [Stmt.assign TileDType.nat [BM, BN] "dist" (Op.add NumericDType.nat Broadcast.scalarR (Op.sub NumericDType.nat Broadcast.scalarR (Op.add NumericDType.nat Broadcast.scalarR (Op.sub NumericDType.nat Broadcast.nil.consL.consR (Op.expandDim ⟨1, by simp⟩ (Op.arange BM)) (Op.expandDim ⟨0, by simp⟩ (Op.arange BN))) (Op.mul NumericDType.nat Broadcast.nil (Op.ref TileDType.nat [] "start_m") (Op.constNat BM))) (Op.ref TileDType.nat [] "start_n")) (Op.constNat off)), Stmt.ifThenElse (Op.ne ComparableDType.nat Broadcast.nil (Op.constNat 1) (Op.constNat 0)) [Stmt.assign TileDType.bool [BM, BN] "mask" (Op.ge ComparableDType.nat Broadcast.scalarR (Op.ref TileDType.nat [BM, BN] "dist") (Op.constNat size))] [Stmt.assign TileDType.bool [BM, BN] "mask" (Op.boolAnd Broadcast.nil.consSame.consSame (Op.ge ComparableDType.nat Broadcast.scalarR (Op.ref TileDType.nat [BM, BN] "dist") (Op.constNat 0)) (Op.lt ComparableDType.nat Broadcast.scalarR (Op.ref TileDType.nat [BM, BN] "dist") (Op.constNat size)))], Stmt.assign TileDType.real [BM, BN] "qk" ((Op.ref TileDType.bool [BM, BN] "mask").where (Op.ref TileDType.real [BM, BN] "qk") (Op.negInf.broadcast [BM, BN]))],
    Stmt.assign TileDType.real [BM] "m_ij" (((Op.gt ComparableDType.real Broadcast.nil.consSame (Op.ref TileDType.real [BM] "m_i") (Op.reduceMax ⟨1, by simp⟩ Bool.false (Op.ref TileDType.real [BM, BN] "qk"))).where (Op.ref TileDType.real [BM] "m_i") (Op.reduceMax ⟨1, by simp⟩ Bool.false (Op.ref TileDType.real [BM, BN] "qk")))),
    Stmt.assign TileDType.real [BM, BN] "qk" (Op.sub NumericDType.real Broadcast.nil.consR.consSame (Op.ref TileDType.real [BM, BN] "qk") (Op.expandDim ⟨1, by simp⟩ (Op.ref TileDType.real [BM] "m_ij"))),
    Stmt.assign TileDType.real [BM, BN] "p" (Op.ref TileDType.real [BM, BN] "qk").exp2,
    Stmt.ifThen (Op.ne ComparableDType.nat Broadcast.nil (Op.constNat 1) (Op.constNat 0)) [Stmt.assign TileDType.real [BM, BN] "p" ((Op.ref TileDType.bool [BM, BN] "mask").where (Op.ref TileDType.real [BM, BN] "p") ((Op.const 0.0).broadcast [BM, BN]))],
    Stmt.assign TileDType.real [BM] "l_ij" (Op.reduceSum ⟨1, by simp⟩ Bool.false (Op.ref TileDType.real [BM, BN] "p")),
    Stmt.assign TileDType.real [BM] "tmp" ((Op.sub NumericDType.real Broadcast.nil.consSame (Op.ref TileDType.real [BM] "m_i") (Op.ref TileDType.real [BM] "m_ij"))),
    Stmt.assign TileDType.real [BM] "alpha" (Op.ref TileDType.real [BM] "tmp").exp2,
    Stmt.assign TileDType.real [BM] "l_i" ((Op.add NumericDType.real Broadcast.nil.consSame (Op.mul NumericDType.real Broadcast.nil.consSame (Op.ref TileDType.real [BM] "l_i") (Op.ref TileDType.real [BM] "alpha")) (Op.ref TileDType.real [BM] "l_ij"))),
    Stmt.assign TileDType.real [BM, ND] "acc" ((Op.mul NumericDType.real Broadcast.nil.consR.consSame (Op.ref TileDType.real [BM, ND] "acc") (Op.expandDim ⟨1, by simp⟩ (Op.ref TileDType.real [BM] "alpha")))),
    Stmt.assign TileDType.real [BN, ND] "v" (Op.load TileDType.real (MemAccess.blockPtr (Op.ref TileDType.blockPtr [BN, ND] "V_block_ptr") []) MaskOpt.none .unspecified),
    Stmt.assign TileDType.real [BM, ND] "acc" ((Op.add NumericDType.real Broadcast.nil.consSame.consSame (Op.ref TileDType.real [BM, ND] "acc") ((Op.dot (batch := []) (Op.ref TileDType.real [BM, BN] "p") (Op.ref TileDType.real [BN, ND] "v"))))),
    Stmt.assign TileDType.real [BM] "m_i" ((Op.ref TileDType.real [BM] "m_ij")),
    Stmt.assign TileDType.blockPtr [BN, ND] "V_block_ptr" ((Op.ref TileDType.blockPtr [BN, ND] "V_block_ptr").advanceBlockPtr [BN, (0:Nat)]),
    Stmt.assign TileDType.blockPtr [ND, BN] "K_block_ptr" ((Op.ref TileDType.blockPtr [ND, BN] "K_block_ptr").advanceBlockPtr [(0:Nat), BN]) ]

/-- General lowered loop body (case 3, no window) — both sliding-window guards
constexpr-false. -/
def aft3LoopBodyG3 (sm_scale : ℝ) (off BM ND BN : Nat) : List Stmt :=
  [ Stmt.assign TileDType.real [ND, BN] "k" (Op.load TileDType.real (MemAccess.blockPtr (Op.ref TileDType.blockPtr [ND, BN] "K_block_ptr") []) MaskOpt.none .unspecified),
    Stmt.assign TileDType.real [BM, BN] "qk" (Op.full [BM, BN] (Op.const 0)),
    Stmt.assign TileDType.real [BM, BN] "qk" ((Op.add NumericDType.real Broadcast.nil.consSame.consSame (Op.ref TileDType.real [BM, BN] "qk") ((Op.dot (batch := []) (Op.ref TileDType.real [BM, ND] "q") (Op.ref TileDType.real [ND, BN] "k"))))),
    Stmt.assign TileDType.real [BM, BN] "qk" ((Op.mul NumericDType.real Broadcast.scalarR (Op.ref TileDType.real [BM, BN] "qk") (Op.ref TileDType.real [] "qk_scale"))),
    Stmt.ifThen (Op.ne ComparableDType.nat Broadcast.nil (Op.constNat 0) (Op.constNat 0)) [Stmt.assign TileDType.nat [BM, BN] "dist" (Op.add NumericDType.nat Broadcast.scalarR (Op.sub NumericDType.nat Broadcast.scalarR (Op.add NumericDType.nat Broadcast.scalarR (Op.sub NumericDType.nat Broadcast.nil.consL.consR (Op.expandDim ⟨1, by simp⟩ (Op.arange BM)) (Op.expandDim ⟨0, by simp⟩ (Op.arange BN))) (Op.mul NumericDType.nat Broadcast.nil (Op.ref TileDType.nat [] "start_m") (Op.constNat BM))) (Op.ref TileDType.nat [] "start_n")) (Op.constNat off)), Stmt.ifThenElse (Op.ne ComparableDType.nat Broadcast.nil (Op.constNat 0) (Op.constNat 0)) [Stmt.assign TileDType.bool [BM, BN] "mask" (Op.ge ComparableDType.nat Broadcast.scalarR (Op.ref TileDType.nat [BM, BN] "dist") (Op.constNat 0))] [Stmt.assign TileDType.bool [BM, BN] "mask" (Op.boolAnd Broadcast.nil.consSame.consSame (Op.ge ComparableDType.nat Broadcast.scalarR (Op.ref TileDType.nat [BM, BN] "dist") (Op.constNat 0)) (Op.lt ComparableDType.nat Broadcast.scalarR (Op.ref TileDType.nat [BM, BN] "dist") (Op.constNat 0)))], Stmt.assign TileDType.real [BM, BN] "qk" ((Op.ref TileDType.bool [BM, BN] "mask").where (Op.ref TileDType.real [BM, BN] "qk") (Op.negInf.broadcast [BM, BN]))],
    Stmt.assign TileDType.real [BM] "m_ij" (((Op.gt ComparableDType.real Broadcast.nil.consSame (Op.ref TileDType.real [BM] "m_i") (Op.reduceMax ⟨1, by simp⟩ Bool.false (Op.ref TileDType.real [BM, BN] "qk"))).where (Op.ref TileDType.real [BM] "m_i") (Op.reduceMax ⟨1, by simp⟩ Bool.false (Op.ref TileDType.real [BM, BN] "qk")))),
    Stmt.assign TileDType.real [BM, BN] "qk" (Op.sub NumericDType.real Broadcast.nil.consR.consSame (Op.ref TileDType.real [BM, BN] "qk") (Op.expandDim ⟨1, by simp⟩ (Op.ref TileDType.real [BM] "m_ij"))),
    Stmt.assign TileDType.real [BM, BN] "p" (Op.ref TileDType.real [BM, BN] "qk").exp2,
    Stmt.ifThen (Op.ne ComparableDType.nat Broadcast.nil (Op.constNat 0) (Op.constNat 0)) [Stmt.assign TileDType.real [BM, BN] "p" ((Op.ref TileDType.bool [BM, BN] "mask").where (Op.ref TileDType.real [BM, BN] "p") ((Op.const 0.0).broadcast [BM, BN]))],
    Stmt.assign TileDType.real [BM] "l_ij" (Op.reduceSum ⟨1, by simp⟩ Bool.false (Op.ref TileDType.real [BM, BN] "p")),
    Stmt.assign TileDType.real [BM] "tmp" ((Op.sub NumericDType.real Broadcast.nil.consSame (Op.ref TileDType.real [BM] "m_i") (Op.ref TileDType.real [BM] "m_ij"))),
    Stmt.assign TileDType.real [BM] "alpha" (Op.ref TileDType.real [BM] "tmp").exp2,
    Stmt.assign TileDType.real [BM] "l_i" ((Op.add NumericDType.real Broadcast.nil.consSame (Op.mul NumericDType.real Broadcast.nil.consSame (Op.ref TileDType.real [BM] "l_i") (Op.ref TileDType.real [BM] "alpha")) (Op.ref TileDType.real [BM] "l_ij"))),
    Stmt.assign TileDType.real [BM, ND] "acc" ((Op.mul NumericDType.real Broadcast.nil.consR.consSame (Op.ref TileDType.real [BM, ND] "acc") (Op.expandDim ⟨1, by simp⟩ (Op.ref TileDType.real [BM] "alpha")))),
    Stmt.assign TileDType.real [BN, ND] "v" (Op.load TileDType.real (MemAccess.blockPtr (Op.ref TileDType.blockPtr [BN, ND] "V_block_ptr") []) MaskOpt.none .unspecified),
    Stmt.assign TileDType.real [BM, ND] "acc" ((Op.add NumericDType.real Broadcast.nil.consSame.consSame (Op.ref TileDType.real [BM, ND] "acc") ((Op.dot (batch := []) (Op.ref TileDType.real [BM, BN] "p") (Op.ref TileDType.real [BN, ND] "v"))))),
    Stmt.assign TileDType.real [BM] "m_i" ((Op.ref TileDType.real [BM] "m_ij")),
    Stmt.assign TileDType.blockPtr [BN, ND] "V_block_ptr" ((Op.ref TileDType.blockPtr [BN, ND] "V_block_ptr").advanceBlockPtr [BN, (0:Nat)]),
    Stmt.assign TileDType.blockPtr [ND, BN] "K_block_ptr" ((Op.ref TileDType.blockPtr [ND, BN] "K_block_ptr").advanceBlockPtr [(0:Nat), BN]) ]

/-- General lowered postLoop statements. -/
def aft3PostLoopG (M Out L : RegionName) (BM ND : Nat) : List Stmt :=
  [ Stmt.ifThenElse (Op.ne ComparableDType.nat Broadcast.nil (Op.constNat 1) (Op.constNat 0)) [Stmt.assign TileDType.real [BM] "m_i" ((Op.add NumericDType.real Broadcast.nil.consSame (Op.ref TileDType.real [BM] "m_i") (Op.ref TileDType.real [BM] "l_i").log2)), Stmt.assign TileDType.real [BM, ND] "acc" ((Op.div NumericDType.real Broadcast.nil.consR.consSame (Op.ref TileDType.real [BM, ND] "acc") (Op.expandDim ⟨1, by simp⟩ (Op.ref TileDType.real [BM] "l_i"))))] [Stmt.store TileDType.real [BM] (MemAccess.ptr (Op.ref TileDType.ptr [BM] "l_ptrs")) ((Op.ref TileDType.real [BM] "l_i")) MaskOpt.none],
    Stmt.store TileDType.real [BM] (MemAccess.ptr (Op.ref TileDType.ptr [BM] "m_ptrs")) ((Op.ref TileDType.real [BM] "m_i")) MaskOpt.none,
    Stmt.store TileDType.real [BM, ND] (MemAccess.blockPtr (Op.ref TileDType.blockPtr [BM, ND] "O_block_ptr") []) ((Op.ref TileDType.real [BM, ND] "acc")) MaskOpt.none ]

set_option maxHeartbeats 1600000 in
set_option maxRecDepth 8000 in
/-- **General body split (case 1).** -/
theorem aft3_body_splitG (Q K V M Out L : RegionName) (sm_scale : ℝ)
    (sqz sqh sqm sqk skz skh skn skk svz svh svk svn soz soh som son
      Z H H_KV N_CTX ROUND_CTX NKV_CTX off size BM ND BN : Nat) :
    (attention_fwd_triton3_surface Q K V M Out L sm_scale
      sqz sqh sqm sqk skz skh skn skk svz svh svk svn soz soh som son
      Z H H_KV N_CTX ROUND_CTX NKV_CTX off size 1 1 BM ND BN 1 1 1 0).toAlgKernel.body
      = aft3PreLoopG Q K V M Out L sm_scale sqz sqh sqm sqk skz skh skn skk svz svh svk svn soz soh som son H H_KV N_CTX ROUND_CTX NKV_CTX off size BM ND BN
        ++ Stmt.forRange "start_n" 0 NKV_CTX BN (aft3LoopBodyG sm_scale off size BM ND BN) :: aft3PostLoopG M Out L BM ND := by
  rfl

/-- Case-4 surface body split: the `INIT=0, SLIDING=1` surface lowers to
`aft3PreLoopG_init0 ++ forRange(loop body) :: postLoop`. -/
theorem aft3_body_splitG4 (Q K V M Out L : RegionName) (sm_scale : ℝ)
    (sqz sqh sqm sqk skz skh skn skk svz svh svk svn soz soh som son
      Z H H_KV N_CTX ROUND_CTX NKV_CTX off size BM ND BN : Nat) :
    (attention_fwd_triton3_surface Q K V M Out L sm_scale
      sqz sqh sqm sqk skz skh skn skk svz svh svk svn soz soh som son
      Z H H_KV N_CTX ROUND_CTX NKV_CTX off size 1 1 BM ND BN 1 0 1 0).toAlgKernel.body
      = aft3PreLoopG_init0 Q K V M Out L sm_scale sqz sqh sqm sqk skz skh skn skk svz svh svk svn soz soh som son H H_KV N_CTX ROUND_CTX NKV_CTX off size BM ND BN
        ++ Stmt.forRange "start_n" 0 NKV_CTX BN (aft3LoopBodyG sm_scale off size BM ND BN) :: aft3PostLoopG M Out L BM ND := by
  rfl

set_option maxHeartbeats 1600000 in
set_option maxRecDepth 8000 in
/-- **General body split (case 2, complement).** -/
theorem aft3_body_splitG2 (Q K V M Out L : RegionName) (sm_scale : ℝ)
    (sqz sqh sqm sqk skz skh skn skk svz svh svk svn soz soh som son
      Z H H_KV N_CTX ROUND_CTX NKV_CTX off size BM ND BN : Nat) :
    (attention_fwd_triton3_surface Q K V M Out L sm_scale
      sqz sqh sqm sqk skz skh skn skk svz svh svk svn soz soh som son
      Z H H_KV N_CTX ROUND_CTX NKV_CTX off size 1 1 BM ND BN 1 1 1 1).toAlgKernel.body
      = aft3PreLoopG Q K V M Out L sm_scale sqz sqh sqm sqk skz skh skn skk svz svh svk svn soz soh som son H H_KV N_CTX ROUND_CTX NKV_CTX off size BM ND BN
        ++ Stmt.forRange "start_n" 0 NKV_CTX BN (aft3LoopBodyG2 sm_scale off size BM ND BN) :: aft3PostLoopG M Out L BM ND := by
  rfl

set_option maxHeartbeats 1600000 in
set_option maxRecDepth 8000 in
/-- **General body split (case 3, no window).** -/
theorem aft3_body_splitG3 (Q K V M Out L : RegionName) (sm_scale : ℝ)
    (sqz sqh sqm sqk skz skh skn skk svz svh svk svn soz soh som son
      Z H H_KV N_CTX ROUND_CTX NKV_CTX off BM ND BN : Nat) :
    (attention_fwd_triton3_surface Q K V M Out L sm_scale
      sqz sqh sqm sqk skz skh skn skk svz svh svk svn soz soh som son
      Z H H_KV N_CTX ROUND_CTX NKV_CTX off 0 1 1 BM ND BN 1 1 0 0).toAlgKernel.body
      = aft3PreLoopG Q K V M Out L sm_scale sqz sqh sqm sqk skz skh skn skk svz svh svk svn soz soh som son H H_KV N_CTX ROUND_CTX NKV_CTX off 0 BM ND BN
        ++ Stmt.forRange "start_n" 0 NKV_CTX BN (aft3LoopBodyG3 sm_scale off BM ND BN) :: aft3PostLoopG M Out L BM ND := by
  rfl

/-- General case-1 sliding-window mask cell. -/
noncomputable def aft3MaskCell1G (SM SN off size BM BN : Nat) (idx : TileIndex [BM, BN]) : Bool :=
  ComparableDType.nat.ge (((idx.1.val - idx.2.1.val) + SM * BM - SN) + off) 0
    && ComparableDType.nat.lt (((idx.1.val - idx.2.1.val) + SM * BM - SN) + off) size

/-- General case-2 complement-window mask cell. -/
noncomputable def aft3MaskCell2G (SM SN off size BM BN : Nat) (idx : TileIndex [BM, BN]) : Bool :=
  ComparableDType.nat.ge (((idx.1.val - idx.2.1.val) + SM * BM - SN) + off) size

set_option maxHeartbeats 1600000 in
set_option maxRecDepth 8000 in
/-- General sliding-window block (case 1). -/
theorem aft3_window1_stepsG (s : BlockState) (SM SN off size BM BN : Nat)
    (hax1 : 1 < [BM].length.succ) (hax0 : 0 < [BN].length.succ)
    (qktile : Tile .real [BM, BN])
    (hsm : s.regs .nat [] "start_m" = some (Tile.scalar SM))
    (hsn : s.regs .nat [] "start_n" = some (Tile.scalar SN))
    (hqk : s.regs .real [BM, BN] "qk" = some qktile) :
    stepStmts [ Stmt.assign TileDType.nat [BM, BN] "dist" (Op.add NumericDType.nat Broadcast.scalarR (Op.sub NumericDType.nat Broadcast.scalarR (Op.add NumericDType.nat Broadcast.scalarR (Op.sub NumericDType.nat Broadcast.nil.consL.consR (Op.expandDim ⟨1, hax1⟩ (Op.arange BM)) (Op.expandDim ⟨0, hax0⟩ (Op.arange BN))) (Op.mul NumericDType.nat Broadcast.nil (Op.ref TileDType.nat [] "start_m") (Op.constNat BM))) (Op.ref TileDType.nat [] "start_n")) (Op.constNat off)),
        Stmt.ifThenElse (Op.ne ComparableDType.nat Broadcast.nil (Op.constNat 0) (Op.constNat 0)) [Stmt.assign TileDType.bool [BM, BN] "mask" (Op.ge ComparableDType.nat Broadcast.scalarR (Op.ref TileDType.nat [BM, BN] "dist") (Op.constNat size))] [Stmt.assign TileDType.bool [BM, BN] "mask" (Op.boolAnd Broadcast.nil.consSame.consSame (Op.ge ComparableDType.nat Broadcast.scalarR (Op.ref TileDType.nat [BM, BN] "dist") (Op.constNat 0)) (Op.lt ComparableDType.nat Broadcast.scalarR (Op.ref TileDType.nat [BM, BN] "dist") (Op.constNat size)))],
        Stmt.assign TileDType.real [BM, BN] "qk" ((Op.ref TileDType.bool [BM, BN] "mask").where (Op.ref TileDType.real [BM, BN] "qk") (Op.negInf.broadcast [BM, BN]))] s
      = some ((((s.setReg "dist" .nat [BM, BN] ⟨fun idx : TileIndex [BM, BN] => ((idx.1.val - idx.2.1.val) + SM * BM - SN) + off⟩).setReg
          "mask" .bool [BM, BN] ⟨fun idx : TileIndex [BM, BN] => aft3MaskCell1G SM SN off size BM BN idx⟩).setReg
          "qk" .real [BM, BN] ⟨fun idx : TileIndex [BM, BN] =>
            if aft3MaskCell1G SM SN off size BM BN idx then qktile.data idx else (⊥ : WithBot ℝ)⟩)) := by
  set disttile : Tile .nat [BM, BN] :=
    ⟨fun idx : TileIndex [BM, BN] => ((idx.1.val - idx.2.1.val) + SM * BM - SN) + off⟩ with hdist
  set masktile : Tile .bool [BM, BN] :=
    ⟨fun idx : TileIndex [BM, BN] =>
      ComparableDType.nat.ge (disttile.data idx) 0 && ComparableDType.nat.lt (disttile.data idx) size⟩ with hmtile
  have hmaskeq : masktile = ⟨fun idx : TileIndex [BM, BN] => aft3MaskCell1G SM SN off size BM BN idx⟩ := by
    refine Tile.ext (fun idx => ?_); simp only [hmtile, aft3MaskCell1G, hdist]
  rw [stepStmts.cons_some (stepStmt_assign_eq_some (aft3_dist_evalG s SM SN BM BN off hax1 hax0 hsm hsn))]
  rw [stepStmts.cons_some
    (show stepStmt _ (s.setReg "dist" .nat [BM, BN] disttile) = some _ from by
      rw [aft3_ifThenElse_false (aft3_ne_zero_zero_false _)]
      rw [stepStmts.cons_some (stepStmt_assign_eq_some
        (aft3_mask_case1_evalG (s.setReg "dist" .nat [BM, BN] disttile) BM BN size disttile
          (by rw [BlockState.setReg_same])))]
      rw [stepStmts.nil])]
  rw [stepStmts.cons_some (stepStmt_assign_eq_some
    (aft3_where_evalG _ BM BN masktile qktile
      (by rw [BlockState.setReg_same])
      (by simp only [BlockState.setReg_ne_name, ne_eq, String.reduceEq, not_false_eq_true,
            BlockState.setReg_same]; exact hqk)))]
  rw [stepStmts.nil]
  rw [hmaskeq]; rfl

set_option maxHeartbeats 1600000 in
set_option maxRecDepth 8000 in
/-- General complement sliding-window block (case 2). -/
theorem aft3_window2_stepsG (s : BlockState) (SM SN off size BM BN : Nat)
    (hax1 : 1 < [BM].length.succ) (hax0 : 0 < [BN].length.succ)
    (qktile : Tile .real [BM, BN])
    (hsm : s.regs .nat [] "start_m" = some (Tile.scalar SM))
    (hsn : s.regs .nat [] "start_n" = some (Tile.scalar SN))
    (hqk : s.regs .real [BM, BN] "qk" = some qktile) :
    stepStmts [ Stmt.assign TileDType.nat [BM, BN] "dist" (Op.add NumericDType.nat Broadcast.scalarR (Op.sub NumericDType.nat Broadcast.scalarR (Op.add NumericDType.nat Broadcast.scalarR (Op.sub NumericDType.nat Broadcast.nil.consL.consR (Op.expandDim ⟨1, hax1⟩ (Op.arange BM)) (Op.expandDim ⟨0, hax0⟩ (Op.arange BN))) (Op.mul NumericDType.nat Broadcast.nil (Op.ref TileDType.nat [] "start_m") (Op.constNat BM))) (Op.ref TileDType.nat [] "start_n")) (Op.constNat off)),
        Stmt.ifThenElse (Op.ne ComparableDType.nat Broadcast.nil (Op.constNat 1) (Op.constNat 0)) [Stmt.assign TileDType.bool [BM, BN] "mask" (Op.ge ComparableDType.nat Broadcast.scalarR (Op.ref TileDType.nat [BM, BN] "dist") (Op.constNat size))] [Stmt.assign TileDType.bool [BM, BN] "mask" (Op.boolAnd Broadcast.nil.consSame.consSame (Op.ge ComparableDType.nat Broadcast.scalarR (Op.ref TileDType.nat [BM, BN] "dist") (Op.constNat 0)) (Op.lt ComparableDType.nat Broadcast.scalarR (Op.ref TileDType.nat [BM, BN] "dist") (Op.constNat size)))],
        Stmt.assign TileDType.real [BM, BN] "qk" ((Op.ref TileDType.bool [BM, BN] "mask").where (Op.ref TileDType.real [BM, BN] "qk") (Op.negInf.broadcast [BM, BN]))] s
      = some ((((s.setReg "dist" .nat [BM, BN] ⟨fun idx : TileIndex [BM, BN] => ((idx.1.val - idx.2.1.val) + SM * BM - SN) + off⟩).setReg
          "mask" .bool [BM, BN] ⟨fun idx : TileIndex [BM, BN] => aft3MaskCell2G SM SN off size BM BN idx⟩).setReg
          "qk" .real [BM, BN] ⟨fun idx : TileIndex [BM, BN] =>
            if aft3MaskCell2G SM SN off size BM BN idx then qktile.data idx else (⊥ : WithBot ℝ)⟩)) := by
  set disttile : Tile .nat [BM, BN] :=
    ⟨fun idx : TileIndex [BM, BN] => ((idx.1.val - idx.2.1.val) + SM * BM - SN) + off⟩ with hdist
  set masktile : Tile .bool [BM, BN] :=
    ⟨fun idx : TileIndex [BM, BN] => ComparableDType.nat.ge (disttile.data idx) size⟩ with hmtile
  have hmaskeq : masktile = ⟨fun idx : TileIndex [BM, BN] => aft3MaskCell2G SM SN off size BM BN idx⟩ := by
    refine Tile.ext (fun idx => ?_); simp only [hmtile, aft3MaskCell2G, hdist]
  rw [stepStmts.cons_some (stepStmt_assign_eq_some (aft3_dist_evalG s SM SN BM BN off hax1 hax0 hsm hsn))]
  rw [stepStmts.cons_some
    (show stepStmt _ (s.setReg "dist" .nat [BM, BN] disttile) = some _ from by
      rw [aft3_ifThenElse_true (aft3_ne_one_zero_true _)]
      rw [stepStmts.cons_some (stepStmt_assign_eq_some
        (aft3_mask_case2_evalG (s.setReg "dist" .nat [BM, BN] disttile) BM BN size disttile
          (by rw [BlockState.setReg_same])))]
      rw [stepStmts.nil])]
  rw [stepStmts.cons_some (stepStmt_assign_eq_some
    (aft3_where_evalG _ BM BN masktile qktile
      (by rw [BlockState.setReg_same])
      (by simp only [BlockState.setReg_ne_name, ne_eq, String.reduceEq, not_false_eq_true,
            BlockState.setReg_same]; exact hqk)))]
  rw [stepStmts.nil]
  rw [hmaskeq]; rfl

set_option maxHeartbeats 1600000 in
set_option maxRecDepth 8000 in
/-- General p-mask block. -/
theorem aft3_pmask1_stepsG (s : BlockState) (BM BN : Nat) (masktile : Tile .bool [BM, BN])
    (ptile : Tile .real [BM, BN])
    (hmask : s.regs .bool [BM, BN] "mask" = some masktile)
    (hp : s.regs .real [BM, BN] "p" = some ptile) :
    stepStmts [ Stmt.assign TileDType.real [BM, BN] "p" ((Op.ref TileDType.bool [BM, BN] "mask").where (Op.ref TileDType.real [BM, BN] "p") ((Op.const 0.0).broadcast [BM, BN]))] s
      = some (s.setReg "p" .real [BM, BN] ⟨fun idx : TileIndex [BM, BN] =>
          if masktile.data idx then ptile.data idx else (some (0.0 : ℝ) : WithBot ℝ)⟩) := by
  rw [stepStmts.cons_some (stepStmt_assign_eq_some (aft3_p_mask_evalG s BM BN masktile ptile hmask hp))]
  rw [stepStmts.nil]

set_option maxHeartbeats 4000000 in
set_option maxRecDepth 8000 in
/-- **General loop-body execution chain (case 1).** -/
theorem aft3LoopBodyG_steps (sin : BlockState) (SM SN off size : Nat)
    (Kreg Vreg : RegionName) (kbase vbase kcol vrow : Nat)
    (skk skn svk svn ND NKV_CTX BM BN : Nat) (hBN : 0 < BN)
    (qtile : Tile .real [BM, ND]) (mtile ltile : Tile .real [BM]) (acctile : Tile .real [BM, ND])
    (ktile : Tile .real [ND, BN]) (vtile : Tile .real [BN, ND]) (sc : ℝ)
    (hsm : sin.regs .nat [] "start_m" = some (Tile.scalar SM))
    (hsn : sin.regs .nat [] "start_n" = some (Tile.scalar SN))
    (hq : sin.regs .real [BM, ND] "q" = some qtile)
    (hqs : sin.regs .real [] "qk_scale" = some (Tile.scalar (some sc)))
    (hmi : sin.regs .real [BM] "m_i" = some mtile)
    (hli : sin.regs .real [BM] "l_i" = some ltile)
    (hacc : sin.regs .real [BM, ND] "acc" = some acctile)
    (hKp : sin.regs .blockPtr [ND, BN] "K_block_ptr" = some
      (⟨fun _ : TileIndex [ND, BN] =>
        { region := Kreg, baseOffset := kbase, parentShape := [ND, NKV_CTX],
          blockShape := [ND, BN], strides := [skk, skn], offsets := [0, kcol] }⟩))
    (hVp : sin.regs .blockPtr [BN, ND] "V_block_ptr" = some
      (⟨fun _ : TileIndex [BN, ND] =>
        { region := Vreg, baseOffset := vbase, parentShape := [NKV_CTX, ND],
          blockShape := [BN, ND], strides := [svk, svn], offsets := [vrow, 0] }⟩))
    (hkload : ∀ idx : TileIndex [ND, BN],
      ktile.data idx = some (sin.readMem Kreg (kbase + idx.1.val * skk + (kcol + idx.2.1.val) * skn)))
    (hvload : ∀ idx : TileIndex [BN, ND],
      vtile.data idx = some (sin.readMem Vreg (vbase + (vrow + idx.1.val) * svk + idx.2.1.val * svn)))
    (hundef : ∀ rg o, sin.undef rg o = 0) :
    ∃ sF, stepStmts (aft3LoopBodyG sc off size BM ND BN) sin = some sF
      ∧ sF.pids = sin.pids ∧ sF.mem = sin.mem ∧ (∀ rg o, sF.undef rg o = 0)
      ∧ sF.regs .real [BM, ND] "q" = some qtile
      ∧ sF.regs .real [] "qk_scale" = some (Tile.scalar (some sc))
      ∧ sF.regs .nat [] "start_m" = some (Tile.scalar SM)
      ∧ sF.regs .blockPtr [ND, BN] "K_block_ptr" = some
          (⟨fun _ : TileIndex [ND, BN] =>
            { region := Kreg, baseOffset := kbase, parentShape := [ND, NKV_CTX],
              blockShape := [ND, BN], strides := [skk, skn], offsets := [0, kcol + BN] }⟩)
      ∧ sF.regs .blockPtr [BN, ND] "V_block_ptr" = some
          (⟨fun _ : TileIndex [BN, ND] =>
            { region := Vreg, baseOffset := vbase, parentShape := [NKV_CTX, ND],
              blockShape := [BN, ND], strides := [svk, svn], offsets := [vrow + BN, 0] }⟩)
      ∧ sF.regs .nat [] "off_hz" = sin.regs .nat [] "off_hz"
      ∧ sF.regs .ptr [BM] "m_ptrs" = sin.regs .ptr [BM] "m_ptrs"
      ∧ sF.regs .ptr [BM] "l_ptrs" = sin.regs .ptr [BM] "l_ptrs"
      ∧ sF.regs .blockPtr [BM, ND] "O_block_ptr" = sin.regs .blockPtr [BM, ND] "O_block_ptr"
      ∧ ∃ (qkT : Tile .real [BM, BN]) (rmaxT mijT alphaT lijT : Tile .real [BM])
            (pT pmT : Tile .real [BM, BN]) (acc1T : Tile .real [BM, ND]),
          (qkT = ⟨fun idx : TileIndex [BM, BN] =>
            if aft3MaskCell1G SM SN off size BM BN idx
            then (Tile.bop NumericDType.real.mul Broadcast.scalarR
                    (Tile.bop NumericDType.real.add
                      (Broadcast.consSame (Broadcast.consSame Broadcast.nil))
                      (⟨fun _ => some (0 : ℝ)⟩ : Tile .real [BM, BN]) (Tile.dot [] qtile ktile))
                    (Tile.scalar (some sc))).data idx
            else (⊥ : WithBot ℝ)⟩)
          ∧ Tile.reduceMaxDrop (⟨1, by simp⟩ : Fin [BM, BN].length) qkT = some rmaxT
          ∧ mijT = Tile.select (Tile.cop ComparableDType.real.gt (Broadcast.consSame Broadcast.nil) mtile rmaxT) mtile rmaxT
          ∧ alphaT = Tile.uop WithBot.realExp2 (Tile.bop NumericDType.real.sub (Broadcast.consSame Broadcast.nil) mtile mijT)
          ∧ pT = Tile.uop WithBot.realExp2 (Tile.bop NumericDType.real.sub (Broadcast.consSame (Broadcast.consR Broadcast.nil)) qkT (Tile.expandDim ⟨1, by simp⟩ mijT))
          ∧ pmT = ⟨fun idx : TileIndex [BM, BN] =>
              if aft3MaskCell1G SM SN off size BM BN idx then pT.data idx else (some (0.0 : ℝ) : WithBot ℝ)⟩
          ∧ lijT = Tile.reduceSumDrop (⟨1, by simp⟩ : Fin [BM, BN].length) pmT
          ∧ acc1T = Tile.bop NumericDType.real.mul (Broadcast.consSame (Broadcast.consR Broadcast.nil)) acctile (Tile.expandDim ⟨1, by simp⟩ alphaT)
          ∧ sF.regs .real [BM] "m_i" = some mijT
          ∧ sF.regs .real [BM] "l_i" = some (Tile.bop NumericDType.real.add (Broadcast.consSame Broadcast.nil)
              (Tile.bop NumericDType.real.mul (Broadcast.consSame Broadcast.nil) ltile alphaT) lijT)
          ∧ sF.regs .real [BM, ND] "acc" = some (Tile.bop NumericDType.real.add
              (Broadcast.consSame (Broadcast.consSame Broadcast.nil)) acc1T (Tile.dot [] pmT vtile)) := by
  set qkSeedT : Tile .real [BM, BN] :=
    Tile.bop NumericDType.real.mul Broadcast.scalarR
      (Tile.bop NumericDType.real.add (Broadcast.consSame (Broadcast.consSame Broadcast.nil))
        (⟨fun _ => some (0 : ℝ)⟩ : Tile .real [BM, BN]) (Tile.dot [] qtile ktile))
      (Tile.scalar (some sc)) with hqkSeed
  set maskT : Tile .bool [BM, BN] := ⟨fun idx : TileIndex [BM, BN] => aft3MaskCell1G SM SN off size BM BN idx⟩ with hmaskT
  set qkT : Tile .real [BM, BN] :=
    ⟨fun idx : TileIndex [BM, BN] =>
      if maskT.data idx then qkSeedT.data idx else (⊥ : WithBot ℝ)⟩ with hqkT
  obtain ⟨rmaxT, hrm⟩ : ∃ t, Tile.reduceMaxDrop (⟨1, by simp⟩ : Fin [BM, BN].length) qkT = some t :=
    ⟨_, by unfold Tile.reduceMaxDrop; rw [dif_pos (show 0 < TileShape.axisDim [BM, BN] (⟨1, by simp⟩ : Fin [BM, BN].length) from by simpa [TileShape.axisDim] using hBN)]⟩
  set mijT : Tile .real [BM] := Tile.select (Tile.cop ComparableDType.real.gt (Broadcast.consSame Broadcast.nil) mtile rmaxT) mtile rmaxT with hmij
  set alphaT : Tile .real [BM] := Tile.uop WithBot.realExp2 (Tile.bop NumericDType.real.sub (Broadcast.consSame Broadcast.nil) mtile mijT) with halpha
  set pT : Tile .real [BM, BN] := Tile.uop WithBot.realExp2 (Tile.bop NumericDType.real.sub (Broadcast.consSame (Broadcast.consR Broadcast.nil)) qkT (Tile.expandDim ⟨1, by simp⟩ mijT)) with hpT
  set pmT : Tile .real [BM, BN] := ⟨fun idx : TileIndex [BM, BN] => if maskT.data idx then pT.data idx else (some (0.0 : ℝ) : WithBot ℝ)⟩ with hpmT
  set lijT : Tile .real [BM] := Tile.reduceSumDrop (⟨1, by simp⟩ : Fin [BM, BN].length) pmT with hlij
  set acc1T : Tile .real [BM, ND] := Tile.bop NumericDType.real.mul (Broadcast.consSame (Broadcast.consR Broadcast.nil)) acctile (Tile.expandDim ⟨1, by simp⟩ alphaT) with hacc1
  unfold aft3LoopBodyG
  -- L1: k = load K_block_ptr
  rw [stepStmts.cons_some (stepStmt_assign_eq_some
    (show evalOp (Op.load TileDType.real (MemAccess.blockPtr (Op.ref TileDType.blockPtr [ND, BN] "K_block_ptr") []) MaskOpt.none .unspecified) sin
        = some ktile from by
      rw [aft3_load_k_eval Kreg kbase ND NKV_CTX ND BN skk skn kcol (Op.ref TileDType.blockPtr [ND, BN] "K_block_ptr") sin
        (by rw [evalOp_ref]; exact hKp)]
      refine congrArg some ?_; refine Tile.ext (fun idx => ?_); rw [hkload idx]))]
  -- L2: qk = zeros
  rw [stepStmts.cons_some (stepStmt_assign_eq_some (aft3_qkzeros_eval _ BM BN))]
  -- L3: qk += dot q k
  rw [stepStmts.cons_some (stepStmt_assign_eq_some
    (aft3_qk_dot_eval _ BM BN ND (⟨fun _ => some (0 : ℝ)⟩ : Tile .real [BM, BN]) qtile ktile
      (by rw [BlockState.setReg_same])
      (by simp only [BlockState.setReg_ne_name, ne_eq, String.reduceEq, not_false_eq_true,
            BlockState.setReg_same]; exact hq)
      (by simp only [BlockState.setReg_ne_name, ne_eq, String.reduceEq, not_false_eq_true,
            BlockState.setReg_same])))]
  -- L4: qk *= qk_scale
  rw [stepStmts.cons_some (stepStmt_assign_eq_some
    (aft3_qk_scale_ref_eval _ BM BN sc
      (Tile.bop NumericDType.real.add (Broadcast.consSame (Broadcast.consSame Broadcast.nil))
        (⟨fun _ => some (0 : ℝ)⟩ : Tile .real [BM, BN]) (Tile.dot [] qtile ktile))
      (by rw [BlockState.setReg_same])
      (by simp only [BlockState.setReg_ne_name, ne_eq, String.reduceEq, not_false_eq_true]; exact hqs)))]
  -- L5: window ifThen (SLIDING_WINDOW true)
  rw [stepStmts.cons_some
    (show stepStmt _ _ = some _ from
      (aft3_ifThen_true (aft3_ne_one_zero_true _)).trans
        (aft3_window1_stepsG _ SM SN off size BM BN (by simp) (by simp) qkSeedT
          (by simp only [BlockState.setReg_ne_name, ne_eq, String.reduceEq, not_false_eq_true]; exact hsm)
          (by simp only [BlockState.setReg_ne_name, ne_eq, String.reduceEq, not_false_eq_true]; exact hsn)
          (by rw [BlockState.setReg_same])))]
  -- L6: m_ij = maximum(m_i, max(qk,1))
  rw [stepStmts.cons_some (stepStmt_assign_eq_some
    (aft3_mij_evalG _ BM BN mtile qkT rmaxT (by simp)
      (by simp only [BlockState.setReg_ne_name, ne_eq, String.reduceEq, not_false_eq_true]; exact hmi)
      (by rw [BlockState.setReg_same])
      hrm))]
  -- L7: qk -= m_ij[:, None]
  rw [stepStmts.cons_some (stepStmt_assign_eq_some
    (aft3_qk_sub_evalG _ BM BN (by simp) qkT mijT
      (by simp only [BlockState.setReg_ne_name, ne_eq, String.reduceEq, not_false_eq_true,
            BlockState.setReg_same] <;> try rfl)
      (by rw [BlockState.setReg_same])))]
  -- L8: p = exp2 qk
  rw [stepStmts.cons_some (stepStmt_assign_eq_some
    (aft3_p_evalG _ BM BN (Tile.bop NumericDType.real.sub (Broadcast.consSame (Broadcast.consR Broadcast.nil)) qkT (Tile.expandDim ⟨1, by simp⟩ mijT))
      (by rw [BlockState.setReg_same])))]
  -- L9: pmask ifThen (SLIDING_WINDOW true)
  rw [stepStmts.cons_some
    (show stepStmt _ _ = some _ from
      (aft3_ifThen_true (aft3_ne_one_zero_true _)).trans
        (aft3_pmask1_stepsG _ BM BN maskT pT
          (by simp only [BlockState.setReg_ne_name, ne_eq, String.reduceEq, not_false_eq_true,
                BlockState.setReg_same] <;> try rfl)
          (by rw [BlockState.setReg_same])))]
  -- L10: l_ij = sum p 1
  rw [stepStmts.cons_some (@stepStmt_assign_eq_some .real [BM] "l_ij"
    (Op.reduceSum (⟨1, by simp⟩ : Fin [BM, BN].length) Bool.false (Op.ref .real [BM, BN] "p")) _ lijT
    (aft3_lij_evalG _ BM BN pmT (by simp) (by rw [BlockState.setReg_same])))]
  -- L11: tmp = m_i - m_ij
  rw [stepStmts.cons_some (stepStmt_assign_eq_some
    (aft3_tmp_evalG _ BM mtile mijT
      (by simp only [BlockState.setReg_ne_name, ne_eq, String.reduceEq, not_false_eq_true]; exact hmi)
      (by simp only [BlockState.setReg_ne_name, ne_eq, String.reduceEq, not_false_eq_true,
            BlockState.setReg_same] <;> try rfl)))]
  -- L12: alpha = exp2 tmp
  rw [stepStmts.cons_some (stepStmt_assign_eq_some
    (aft3_alpha_evalG _ BM (Tile.bop NumericDType.real.sub (Broadcast.consSame Broadcast.nil) mtile mijT)
      (by rw [BlockState.setReg_same])))]
  -- L13: l_i = l_i * alpha + l_ij
  rw [stepStmts.cons_some (stepStmt_assign_eq_some
    (aft3_li_evalG _ BM ltile alphaT lijT
      (by simp only [BlockState.setReg_ne_name, ne_eq, String.reduceEq, not_false_eq_true]; exact hli)
      (by simp only [BlockState.setReg_ne_name, ne_eq, String.reduceEq, not_false_eq_true,
            BlockState.setReg_same] <;> try rfl)
      (by simp only [BlockState.setReg_ne_name, ne_eq, String.reduceEq, not_false_eq_true,
            BlockState.setReg_same] <;> try rfl)))]
  -- L14: acc = acc * alpha[:, None]
  rw [stepStmts.cons_some (stepStmt_assign_eq_some
    (aft3_acc_rescale_evalG _ BM ND (by simp) acctile alphaT
      (by simp only [BlockState.setReg_ne_name, ne_eq, String.reduceEq, not_false_eq_true]; exact hacc)
      (by simp only [BlockState.setReg_ne_name, ne_eq, String.reduceEq, not_false_eq_true,
            BlockState.setReg_same] <;> try rfl)))]
  -- L15: v = load V_block_ptr
  rw [stepStmts.cons_some (stepStmt_assign_eq_some
    (show evalOp (Op.load TileDType.real (MemAccess.blockPtr (Op.ref TileDType.blockPtr [BN, ND] "V_block_ptr") []) MaskOpt.none .unspecified) _
        = some vtile from by
      rw [aft3_load_v_eval Vreg vbase NKV_CTX ND BN ND svk svn vrow (Op.ref TileDType.blockPtr [BN, ND] "V_block_ptr") _
        (by rw [evalOp_ref]
            simp only [BlockState.setReg_ne_name, ne_eq, String.reduceEq, not_false_eq_true]
            exact hVp)]
      refine congrArg some ?_; refine Tile.ext (fun idx => ?_)
      simp only [BlockState.setReg_readMem]; rw [hvload idx]))]
  -- L16: acc += dot p v
  rw [stepStmts.cons_some (stepStmt_assign_eq_some
    (aft3_acc_eval _ BM BN ND acc1T pmT vtile
      (by simp only [BlockState.setReg_ne_name, ne_eq, String.reduceEq, not_false_eq_true,
            BlockState.setReg_same] <;> try rfl)
      (by simp only [BlockState.setReg_ne_name, ne_eq, String.reduceEq, not_false_eq_true,
            BlockState.setReg_same] <;> try rfl)
      (by rw [BlockState.setReg_same])))]
  -- L17: m_i = m_ij
  rw [stepStmts.cons_some (stepStmt_assign_eq_some
    (aft3_mi_carry_evalG _ BM mijT
      (by simp only [BlockState.setReg_ne_name, ne_eq, String.reduceEq, not_false_eq_true,
            BlockState.setReg_same] <;> try rfl)))]
  -- L18: V_block_ptr = advance [BN, 0]
  rw [stepStmts.cons_some (stepStmt_assign_eq_some
    (aft3_advance_v_eval _ Vreg vbase NKV_CTX ND BN ND svk svn vrow BN "V_block_ptr"
      (by simp only [BlockState.setReg_ne_name, ne_eq, String.reduceEq, not_false_eq_true]; exact hVp)))]
  -- L19: K_block_ptr = advance [0, BN]
  rw [stepStmts.cons_some (stepStmt_assign_eq_some
    (aft3_advance_k_eval _ Kreg kbase ND NKV_CTX ND BN skk skn kcol BN "K_block_ptr"
      (by simp only [BlockState.setReg_ne_name, ne_eq, String.reduceEq, not_false_eq_true]; exact hKp)))]
  rw [stepStmts.nil]
  refine ⟨_, rfl, ?_, ?_, ?_, ?_, ?_, ?_, ?_, ?_, ?_, ?_, ?_, ?_, qkT, rmaxT, mijT, alphaT, lijT, pT, pmT, acc1T,
    rfl, hrm, rfl, rfl, rfl, rfl, rfl, rfl, ?_, ?_, ?_⟩
  · simp only [BlockState.setReg_pids]
  · funext rg o; simp only [BlockState.setReg_mem]
  · intro rg o; simp only [BlockState.setReg_undef]; exact hundef rg o
  · simp only [BlockState.setReg_ne_name, ne_eq, String.reduceEq, not_false_eq_true,
      BlockState.setReg_same]; exact hq
  · simp only [BlockState.setReg_ne_name, ne_eq, String.reduceEq, not_false_eq_true,
      BlockState.setReg_same]; exact hqs
  · simp only [BlockState.setReg_ne_name, ne_eq, String.reduceEq, not_false_eq_true,
      BlockState.setReg_same]; exact hsm
  · simp only [BlockState.setReg_same]
  · simp only [BlockState.setReg_ne_name, ne_eq, String.reduceEq, not_false_eq_true,
      BlockState.setReg_same]
  · simp only [BlockState.setReg_ne_name, ne_eq, String.reduceEq, not_false_eq_true,
      BlockState.setReg_same]
  · simp only [BlockState.setReg_ne_name, ne_eq, String.reduceEq, not_false_eq_true,
      BlockState.setReg_same]
  · simp only [BlockState.setReg_ne_name, ne_eq, String.reduceEq, not_false_eq_true,
      BlockState.setReg_same]
  · simp only [BlockState.setReg_ne_name, ne_eq, String.reduceEq, not_false_eq_true,
      BlockState.setReg_same]
  · simp only [BlockState.setReg_ne_name, ne_eq, String.reduceEq, not_false_eq_true,
      BlockState.setReg_same]
  · simp only [BlockState.setReg_ne_name, ne_eq, String.reduceEq, not_false_eq_true,
      BlockState.setReg_same]
  · simp only [BlockState.setReg_ne_name, ne_eq, String.reduceEq, not_false_eq_true,
      BlockState.setReg_same]


set_option maxHeartbeats 4000000 in
set_option maxRecDepth 8000 in
/-- **General loop-body execution chain (case 2, complement).** -/
theorem aft3LoopBodyG2_steps (sin : BlockState) (SM SN off size : Nat)
    (Kreg Vreg : RegionName) (kbase vbase kcol vrow : Nat)
    (skk skn svk svn ND NKV_CTX BM BN : Nat) (hBN : 0 < BN)
    (qtile : Tile .real [BM, ND]) (mtile ltile : Tile .real [BM]) (acctile : Tile .real [BM, ND])
    (ktile : Tile .real [ND, BN]) (vtile : Tile .real [BN, ND]) (sc : ℝ)
    (hsm : sin.regs .nat [] "start_m" = some (Tile.scalar SM))
    (hsn : sin.regs .nat [] "start_n" = some (Tile.scalar SN))
    (hq : sin.regs .real [BM, ND] "q" = some qtile)
    (hqs : sin.regs .real [] "qk_scale" = some (Tile.scalar (some sc)))
    (hmi : sin.regs .real [BM] "m_i" = some mtile)
    (hli : sin.regs .real [BM] "l_i" = some ltile)
    (hacc : sin.regs .real [BM, ND] "acc" = some acctile)
    (hKp : sin.regs .blockPtr [ND, BN] "K_block_ptr" = some
      (⟨fun _ : TileIndex [ND, BN] =>
        { region := Kreg, baseOffset := kbase, parentShape := [ND, NKV_CTX],
          blockShape := [ND, BN], strides := [skk, skn], offsets := [0, kcol] }⟩))
    (hVp : sin.regs .blockPtr [BN, ND] "V_block_ptr" = some
      (⟨fun _ : TileIndex [BN, ND] =>
        { region := Vreg, baseOffset := vbase, parentShape := [NKV_CTX, ND],
          blockShape := [BN, ND], strides := [svk, svn], offsets := [vrow, 0] }⟩))
    (hkload : ∀ idx : TileIndex [ND, BN],
      ktile.data idx = some (sin.readMem Kreg (kbase + idx.1.val * skk + (kcol + idx.2.1.val) * skn)))
    (hvload : ∀ idx : TileIndex [BN, ND],
      vtile.data idx = some (sin.readMem Vreg (vbase + (vrow + idx.1.val) * svk + idx.2.1.val * svn)))
    (hundef : ∀ rg o, sin.undef rg o = 0) :
    ∃ sF, stepStmts (aft3LoopBodyG2 sc off size BM ND BN) sin = some sF
      ∧ sF.pids = sin.pids ∧ sF.mem = sin.mem ∧ (∀ rg o, sF.undef rg o = 0)
      ∧ sF.regs .real [BM, ND] "q" = some qtile
      ∧ sF.regs .real [] "qk_scale" = some (Tile.scalar (some sc))
      ∧ sF.regs .nat [] "start_m" = some (Tile.scalar SM)
      ∧ sF.regs .blockPtr [ND, BN] "K_block_ptr" = some
          (⟨fun _ : TileIndex [ND, BN] =>
            { region := Kreg, baseOffset := kbase, parentShape := [ND, NKV_CTX],
              blockShape := [ND, BN], strides := [skk, skn], offsets := [0, kcol + BN] }⟩)
      ∧ sF.regs .blockPtr [BN, ND] "V_block_ptr" = some
          (⟨fun _ : TileIndex [BN, ND] =>
            { region := Vreg, baseOffset := vbase, parentShape := [NKV_CTX, ND],
              blockShape := [BN, ND], strides := [svk, svn], offsets := [vrow + BN, 0] }⟩)
      ∧ sF.regs .nat [] "off_hz" = sin.regs .nat [] "off_hz"
      ∧ sF.regs .ptr [BM] "m_ptrs" = sin.regs .ptr [BM] "m_ptrs"
      ∧ sF.regs .ptr [BM] "l_ptrs" = sin.regs .ptr [BM] "l_ptrs"
      ∧ sF.regs .blockPtr [BM, ND] "O_block_ptr" = sin.regs .blockPtr [BM, ND] "O_block_ptr"
      ∧ ∃ (qkT : Tile .real [BM, BN]) (rmaxT mijT alphaT lijT : Tile .real [BM])
            (pT pmT : Tile .real [BM, BN]) (acc1T : Tile .real [BM, ND]),
          (qkT = ⟨fun idx : TileIndex [BM, BN] =>
            if aft3MaskCell2G SM SN off size BM BN idx
            then (Tile.bop NumericDType.real.mul Broadcast.scalarR
                    (Tile.bop NumericDType.real.add
                      (Broadcast.consSame (Broadcast.consSame Broadcast.nil))
                      (⟨fun _ => some (0 : ℝ)⟩ : Tile .real [BM, BN]) (Tile.dot [] qtile ktile))
                    (Tile.scalar (some sc))).data idx
            else (⊥ : WithBot ℝ)⟩)
          ∧ Tile.reduceMaxDrop (⟨1, by simp⟩ : Fin [BM, BN].length) qkT = some rmaxT
          ∧ mijT = Tile.select (Tile.cop ComparableDType.real.gt (Broadcast.consSame Broadcast.nil) mtile rmaxT) mtile rmaxT
          ∧ alphaT = Tile.uop WithBot.realExp2 (Tile.bop NumericDType.real.sub (Broadcast.consSame Broadcast.nil) mtile mijT)
          ∧ pT = Tile.uop WithBot.realExp2 (Tile.bop NumericDType.real.sub (Broadcast.consSame (Broadcast.consR Broadcast.nil)) qkT (Tile.expandDim ⟨1, by simp⟩ mijT))
          ∧ pmT = ⟨fun idx : TileIndex [BM, BN] =>
              if aft3MaskCell2G SM SN off size BM BN idx then pT.data idx else (some (0.0 : ℝ) : WithBot ℝ)⟩
          ∧ lijT = Tile.reduceSumDrop (⟨1, by simp⟩ : Fin [BM, BN].length) pmT
          ∧ acc1T = Tile.bop NumericDType.real.mul (Broadcast.consSame (Broadcast.consR Broadcast.nil)) acctile (Tile.expandDim ⟨1, by simp⟩ alphaT)
          ∧ sF.regs .real [BM] "m_i" = some mijT
          ∧ sF.regs .real [BM] "l_i" = some (Tile.bop NumericDType.real.add (Broadcast.consSame Broadcast.nil)
              (Tile.bop NumericDType.real.mul (Broadcast.consSame Broadcast.nil) ltile alphaT) lijT)
          ∧ sF.regs .real [BM, ND] "acc" = some (Tile.bop NumericDType.real.add
              (Broadcast.consSame (Broadcast.consSame Broadcast.nil)) acc1T (Tile.dot [] pmT vtile)) := by
  set qkSeedT : Tile .real [BM, BN] :=
    Tile.bop NumericDType.real.mul Broadcast.scalarR
      (Tile.bop NumericDType.real.add (Broadcast.consSame (Broadcast.consSame Broadcast.nil))
        (⟨fun _ => some (0 : ℝ)⟩ : Tile .real [BM, BN]) (Tile.dot [] qtile ktile))
      (Tile.scalar (some sc)) with hqkSeed
  set maskT : Tile .bool [BM, BN] := ⟨fun idx : TileIndex [BM, BN] => aft3MaskCell2G SM SN off size BM BN idx⟩ with hmaskT
  set qkT : Tile .real [BM, BN] :=
    ⟨fun idx : TileIndex [BM, BN] =>
      if maskT.data idx then qkSeedT.data idx else (⊥ : WithBot ℝ)⟩ with hqkT
  obtain ⟨rmaxT, hrm⟩ : ∃ t, Tile.reduceMaxDrop (⟨1, by simp⟩ : Fin [BM, BN].length) qkT = some t :=
    ⟨_, by unfold Tile.reduceMaxDrop; rw [dif_pos (show 0 < TileShape.axisDim [BM, BN] (⟨1, by simp⟩ : Fin [BM, BN].length) from by simpa [TileShape.axisDim] using hBN)]⟩
  set mijT : Tile .real [BM] := Tile.select (Tile.cop ComparableDType.real.gt (Broadcast.consSame Broadcast.nil) mtile rmaxT) mtile rmaxT with hmij
  set alphaT : Tile .real [BM] := Tile.uop WithBot.realExp2 (Tile.bop NumericDType.real.sub (Broadcast.consSame Broadcast.nil) mtile mijT) with halpha
  set pT : Tile .real [BM, BN] := Tile.uop WithBot.realExp2 (Tile.bop NumericDType.real.sub (Broadcast.consSame (Broadcast.consR Broadcast.nil)) qkT (Tile.expandDim ⟨1, by simp⟩ mijT)) with hpT
  set pmT : Tile .real [BM, BN] := ⟨fun idx : TileIndex [BM, BN] => if maskT.data idx then pT.data idx else (some (0.0 : ℝ) : WithBot ℝ)⟩ with hpmT
  set lijT : Tile .real [BM] := Tile.reduceSumDrop (⟨1, by simp⟩ : Fin [BM, BN].length) pmT with hlij
  set acc1T : Tile .real [BM, ND] := Tile.bop NumericDType.real.mul (Broadcast.consSame (Broadcast.consR Broadcast.nil)) acctile (Tile.expandDim ⟨1, by simp⟩ alphaT) with hacc1
  unfold aft3LoopBodyG2
  -- L1: k = load K_block_ptr
  rw [stepStmts.cons_some (stepStmt_assign_eq_some
    (show evalOp (Op.load TileDType.real (MemAccess.blockPtr (Op.ref TileDType.blockPtr [ND, BN] "K_block_ptr") []) MaskOpt.none .unspecified) sin
        = some ktile from by
      rw [aft3_load_k_eval Kreg kbase ND NKV_CTX ND BN skk skn kcol (Op.ref TileDType.blockPtr [ND, BN] "K_block_ptr") sin
        (by rw [evalOp_ref]; exact hKp)]
      refine congrArg some ?_; refine Tile.ext (fun idx => ?_); rw [hkload idx]))]
  -- L2: qk = zeros
  rw [stepStmts.cons_some (stepStmt_assign_eq_some (aft3_qkzeros_eval _ BM BN))]
  -- L3: qk += dot q k
  rw [stepStmts.cons_some (stepStmt_assign_eq_some
    (aft3_qk_dot_eval _ BM BN ND (⟨fun _ => some (0 : ℝ)⟩ : Tile .real [BM, BN]) qtile ktile
      (by rw [BlockState.setReg_same])
      (by simp only [BlockState.setReg_ne_name, ne_eq, String.reduceEq, not_false_eq_true,
            BlockState.setReg_same]; exact hq)
      (by simp only [BlockState.setReg_ne_name, ne_eq, String.reduceEq, not_false_eq_true,
            BlockState.setReg_same])))]
  -- L4: qk *= qk_scale
  rw [stepStmts.cons_some (stepStmt_assign_eq_some
    (aft3_qk_scale_ref_eval _ BM BN sc
      (Tile.bop NumericDType.real.add (Broadcast.consSame (Broadcast.consSame Broadcast.nil))
        (⟨fun _ => some (0 : ℝ)⟩ : Tile .real [BM, BN]) (Tile.dot [] qtile ktile))
      (by rw [BlockState.setReg_same])
      (by simp only [BlockState.setReg_ne_name, ne_eq, String.reduceEq, not_false_eq_true]; exact hqs)))]
  -- L5: window ifThen (SLIDING_WINDOW true)
  rw [stepStmts.cons_some
    (show stepStmt _ _ = some _ from
      (aft3_ifThen_true (aft3_ne_one_zero_true _)).trans
        (aft3_window2_stepsG _ SM SN off size BM BN (by simp) (by simp) qkSeedT
          (by simp only [BlockState.setReg_ne_name, ne_eq, String.reduceEq, not_false_eq_true]; exact hsm)
          (by simp only [BlockState.setReg_ne_name, ne_eq, String.reduceEq, not_false_eq_true]; exact hsn)
          (by rw [BlockState.setReg_same])))]
  -- L6: m_ij = maximum(m_i, max(qk,1))
  rw [stepStmts.cons_some (stepStmt_assign_eq_some
    (aft3_mij_evalG _ BM BN mtile qkT rmaxT (by simp)
      (by simp only [BlockState.setReg_ne_name, ne_eq, String.reduceEq, not_false_eq_true]; exact hmi)
      (by rw [BlockState.setReg_same])
      hrm))]
  -- L7: qk -= m_ij[:, None]
  rw [stepStmts.cons_some (stepStmt_assign_eq_some
    (aft3_qk_sub_evalG _ BM BN (by simp) qkT mijT
      (by simp only [BlockState.setReg_ne_name, ne_eq, String.reduceEq, not_false_eq_true,
            BlockState.setReg_same] <;> try rfl)
      (by rw [BlockState.setReg_same])))]
  -- L8: p = exp2 qk
  rw [stepStmts.cons_some (stepStmt_assign_eq_some
    (aft3_p_evalG _ BM BN (Tile.bop NumericDType.real.sub (Broadcast.consSame (Broadcast.consR Broadcast.nil)) qkT (Tile.expandDim ⟨1, by simp⟩ mijT))
      (by rw [BlockState.setReg_same])))]
  -- L9: pmask ifThen (SLIDING_WINDOW true)
  rw [stepStmts.cons_some
    (show stepStmt _ _ = some _ from
      (aft3_ifThen_true (aft3_ne_one_zero_true _)).trans
        (aft3_pmask1_stepsG _ BM BN maskT pT
          (by simp only [BlockState.setReg_ne_name, ne_eq, String.reduceEq, not_false_eq_true,
                BlockState.setReg_same] <;> try rfl)
          (by rw [BlockState.setReg_same])))]
  -- L10: l_ij = sum p 1
  rw [stepStmts.cons_some (@stepStmt_assign_eq_some .real [BM] "l_ij"
    (Op.reduceSum (⟨1, by simp⟩ : Fin [BM, BN].length) Bool.false (Op.ref .real [BM, BN] "p")) _ lijT
    (aft3_lij_evalG _ BM BN pmT (by simp) (by rw [BlockState.setReg_same])))]
  -- L11: tmp = m_i - m_ij
  rw [stepStmts.cons_some (stepStmt_assign_eq_some
    (aft3_tmp_evalG _ BM mtile mijT
      (by simp only [BlockState.setReg_ne_name, ne_eq, String.reduceEq, not_false_eq_true]; exact hmi)
      (by simp only [BlockState.setReg_ne_name, ne_eq, String.reduceEq, not_false_eq_true,
            BlockState.setReg_same] <;> try rfl)))]
  -- L12: alpha = exp2 tmp
  rw [stepStmts.cons_some (stepStmt_assign_eq_some
    (aft3_alpha_evalG _ BM (Tile.bop NumericDType.real.sub (Broadcast.consSame Broadcast.nil) mtile mijT)
      (by rw [BlockState.setReg_same])))]
  -- L13: l_i = l_i * alpha + l_ij
  rw [stepStmts.cons_some (stepStmt_assign_eq_some
    (aft3_li_evalG _ BM ltile alphaT lijT
      (by simp only [BlockState.setReg_ne_name, ne_eq, String.reduceEq, not_false_eq_true]; exact hli)
      (by simp only [BlockState.setReg_ne_name, ne_eq, String.reduceEq, not_false_eq_true,
            BlockState.setReg_same] <;> try rfl)
      (by simp only [BlockState.setReg_ne_name, ne_eq, String.reduceEq, not_false_eq_true,
            BlockState.setReg_same] <;> try rfl)))]
  -- L14: acc = acc * alpha[:, None]
  rw [stepStmts.cons_some (stepStmt_assign_eq_some
    (aft3_acc_rescale_evalG _ BM ND (by simp) acctile alphaT
      (by simp only [BlockState.setReg_ne_name, ne_eq, String.reduceEq, not_false_eq_true]; exact hacc)
      (by simp only [BlockState.setReg_ne_name, ne_eq, String.reduceEq, not_false_eq_true,
            BlockState.setReg_same] <;> try rfl)))]
  -- L15: v = load V_block_ptr
  rw [stepStmts.cons_some (stepStmt_assign_eq_some
    (show evalOp (Op.load TileDType.real (MemAccess.blockPtr (Op.ref TileDType.blockPtr [BN, ND] "V_block_ptr") []) MaskOpt.none .unspecified) _
        = some vtile from by
      rw [aft3_load_v_eval Vreg vbase NKV_CTX ND BN ND svk svn vrow (Op.ref TileDType.blockPtr [BN, ND] "V_block_ptr") _
        (by rw [evalOp_ref]
            simp only [BlockState.setReg_ne_name, ne_eq, String.reduceEq, not_false_eq_true]
            exact hVp)]
      refine congrArg some ?_; refine Tile.ext (fun idx => ?_)
      simp only [BlockState.setReg_readMem]; rw [hvload idx]))]
  -- L16: acc += dot p v
  rw [stepStmts.cons_some (stepStmt_assign_eq_some
    (aft3_acc_eval _ BM BN ND acc1T pmT vtile
      (by simp only [BlockState.setReg_ne_name, ne_eq, String.reduceEq, not_false_eq_true,
            BlockState.setReg_same] <;> try rfl)
      (by simp only [BlockState.setReg_ne_name, ne_eq, String.reduceEq, not_false_eq_true,
            BlockState.setReg_same] <;> try rfl)
      (by rw [BlockState.setReg_same])))]
  -- L17: m_i = m_ij
  rw [stepStmts.cons_some (stepStmt_assign_eq_some
    (aft3_mi_carry_evalG _ BM mijT
      (by simp only [BlockState.setReg_ne_name, ne_eq, String.reduceEq, not_false_eq_true,
            BlockState.setReg_same] <;> try rfl)))]
  -- L18: V_block_ptr = advance [BN, 0]
  rw [stepStmts.cons_some (stepStmt_assign_eq_some
    (aft3_advance_v_eval _ Vreg vbase NKV_CTX ND BN ND svk svn vrow BN "V_block_ptr"
      (by simp only [BlockState.setReg_ne_name, ne_eq, String.reduceEq, not_false_eq_true]; exact hVp)))]
  -- L19: K_block_ptr = advance [0, BN]
  rw [stepStmts.cons_some (stepStmt_assign_eq_some
    (aft3_advance_k_eval _ Kreg kbase ND NKV_CTX ND BN skk skn kcol BN "K_block_ptr"
      (by simp only [BlockState.setReg_ne_name, ne_eq, String.reduceEq, not_false_eq_true]; exact hKp)))]
  rw [stepStmts.nil]
  refine ⟨_, rfl, ?_, ?_, ?_, ?_, ?_, ?_, ?_, ?_, ?_, ?_, ?_, ?_, qkT, rmaxT, mijT, alphaT, lijT, pT, pmT, acc1T,
    rfl, hrm, rfl, rfl, rfl, rfl, rfl, rfl, ?_, ?_, ?_⟩
  · simp only [BlockState.setReg_pids]
  · funext rg o; simp only [BlockState.setReg_mem]
  · intro rg o; simp only [BlockState.setReg_undef]; exact hundef rg o
  · simp only [BlockState.setReg_ne_name, ne_eq, String.reduceEq, not_false_eq_true,
      BlockState.setReg_same]; exact hq
  · simp only [BlockState.setReg_ne_name, ne_eq, String.reduceEq, not_false_eq_true,
      BlockState.setReg_same]; exact hqs
  · simp only [BlockState.setReg_ne_name, ne_eq, String.reduceEq, not_false_eq_true,
      BlockState.setReg_same]; exact hsm
  · simp only [BlockState.setReg_same]
  · simp only [BlockState.setReg_ne_name, ne_eq, String.reduceEq, not_false_eq_true,
      BlockState.setReg_same]
  · simp only [BlockState.setReg_ne_name, ne_eq, String.reduceEq, not_false_eq_true,
      BlockState.setReg_same]
  · simp only [BlockState.setReg_ne_name, ne_eq, String.reduceEq, not_false_eq_true,
      BlockState.setReg_same]
  · simp only [BlockState.setReg_ne_name, ne_eq, String.reduceEq, not_false_eq_true,
      BlockState.setReg_same]
  · simp only [BlockState.setReg_ne_name, ne_eq, String.reduceEq, not_false_eq_true,
      BlockState.setReg_same]
  · simp only [BlockState.setReg_ne_name, ne_eq, String.reduceEq, not_false_eq_true,
      BlockState.setReg_same]
  · simp only [BlockState.setReg_ne_name, ne_eq, String.reduceEq, not_false_eq_true,
      BlockState.setReg_same]
  · simp only [BlockState.setReg_ne_name, ne_eq, String.reduceEq, not_false_eq_true,
      BlockState.setReg_same]

set_option maxHeartbeats 4000000 in
set_option maxRecDepth 8000 in
/-- **General loop-body execution chain (case 3, no window).** -/
theorem aft3LoopBodyG3_steps (sin : BlockState) (SM SN ohz off : Nat)
    (Kreg Vreg : RegionName) (kbase vbase kcol vrow : Nat)
    (skk skn svk svn ND NKV_CTX BM BN : Nat) (hBN : 0 < BN)
    (qtile : Tile .real [BM, ND]) (mtile ltile : Tile .real [BM]) (acctile : Tile .real [BM, ND])
    (ktile : Tile .real [ND, BN]) (vtile : Tile .real [BN, ND]) (sc : ℝ)
    (mptrs lptrs : Tile .ptr [BM]) (oblk : Tile .blockPtr [BM, ND])
    (hmptrs : sin.regs .ptr [BM] "m_ptrs" = some mptrs)
    (hlptrs : sin.regs .ptr [BM] "l_ptrs" = some lptrs)
    (hoblk : sin.regs .blockPtr [BM, ND] "O_block_ptr" = some oblk)
    (hsm : sin.regs .nat [] "start_m" = some (Tile.scalar SM))
    (hoff : sin.regs .nat [] "off_hz" = some (Tile.scalar ohz))
    (hsn : sin.regs .nat [] "start_n" = some (Tile.scalar SN))
    (hq : sin.regs .real [BM, ND] "q" = some qtile)
    (hqs : sin.regs .real [] "qk_scale" = some (Tile.scalar (some sc)))
    (hmi : sin.regs .real [BM] "m_i" = some mtile)
    (hli : sin.regs .real [BM] "l_i" = some ltile)
    (hacc : sin.regs .real [BM, ND] "acc" = some acctile)
    (hKp : sin.regs .blockPtr [ND, BN] "K_block_ptr" = some
      (⟨fun _ : TileIndex [ND, BN] =>
        { region := Kreg, baseOffset := kbase, parentShape := [ND, NKV_CTX],
          blockShape := [ND, BN], strides := [skk, skn], offsets := [0, kcol] }⟩))
    (hVp : sin.regs .blockPtr [BN, ND] "V_block_ptr" = some
      (⟨fun _ : TileIndex [BN, ND] =>
        { region := Vreg, baseOffset := vbase, parentShape := [NKV_CTX, ND],
          blockShape := [BN, ND], strides := [svk, svn], offsets := [vrow, 0] }⟩))
    (hkload : ∀ idx : TileIndex [ND, BN],
      ktile.data idx = some (sin.readMem Kreg (kbase + idx.1.val * skk + (kcol + idx.2.1.val) * skn)))
    (hvload : ∀ idx : TileIndex [BN, ND],
      vtile.data idx = some (sin.readMem Vreg (vbase + (vrow + idx.1.val) * svk + idx.2.1.val * svn)))
    (hundef : ∀ rg o, sin.undef rg o = 0) :
    ∃ sF, stepStmts (aft3LoopBodyG3 sc off BM ND BN) sin = some sF
      ∧ sF.pids = sin.pids ∧ sF.mem = sin.mem ∧ (∀ rg o, sF.undef rg o = 0)
      ∧ sF.regs .real [BM, ND] "q" = some qtile
      ∧ sF.regs .real [] "qk_scale" = some (Tile.scalar (some sc))
      ∧ sF.regs .nat [] "start_m" = some (Tile.scalar SM)
      ∧ sF.regs .nat [] "off_hz" = some (Tile.scalar ohz)
      ∧ sF.regs .blockPtr [ND, BN] "K_block_ptr" = some
          (⟨fun _ : TileIndex [ND, BN] =>
            { region := Kreg, baseOffset := kbase, parentShape := [ND, NKV_CTX],
              blockShape := [ND, BN], strides := [skk, skn], offsets := [0, kcol + BN] }⟩)
      ∧ sF.regs .blockPtr [BN, ND] "V_block_ptr" = some
          (⟨fun _ : TileIndex [BN, ND] =>
            { region := Vreg, baseOffset := vbase, parentShape := [NKV_CTX, ND],
              blockShape := [BN, ND], strides := [svk, svn], offsets := [vrow + BN, 0] }⟩)
      ∧ sF.regs .ptr [BM] "m_ptrs" = some mptrs
      ∧ sF.regs .ptr [BM] "l_ptrs" = some lptrs
      ∧ sF.regs .blockPtr [BM, ND] "O_block_ptr" = some oblk
      ∧ ∃ (qkT : Tile .real [BM, BN]) (rmaxT mijT alphaT lijT : Tile .real [BM])
            (pT : Tile .real [BM, BN]) (acc1T : Tile .real [BM, ND]),
          (qkT = Tile.bop NumericDType.real.mul Broadcast.scalarR
                    (Tile.bop NumericDType.real.add
                      (Broadcast.consSame (Broadcast.consSame Broadcast.nil))
                      (⟨fun _ => some (0 : ℝ)⟩ : Tile .real [BM, BN]) (Tile.dot [] qtile ktile))
                    (Tile.scalar (some sc)))
          ∧ Tile.reduceMaxDrop (⟨1, by simp⟩ : Fin [BM, BN].length) qkT = some rmaxT
          ∧ mijT = Tile.select (Tile.cop ComparableDType.real.gt (Broadcast.consSame Broadcast.nil) mtile rmaxT) mtile rmaxT
          ∧ alphaT = Tile.uop WithBot.realExp2 (Tile.bop NumericDType.real.sub (Broadcast.consSame Broadcast.nil) mtile mijT)
          ∧ pT = Tile.uop WithBot.realExp2 (Tile.bop NumericDType.real.sub (Broadcast.consSame (Broadcast.consR Broadcast.nil)) qkT (Tile.expandDim ⟨1, by simp⟩ mijT))
          ∧ lijT = Tile.reduceSumDrop (⟨1, by simp⟩ : Fin [BM, BN].length) pT
          ∧ acc1T = Tile.bop NumericDType.real.mul (Broadcast.consSame (Broadcast.consR Broadcast.nil)) acctile (Tile.expandDim ⟨1, by simp⟩ alphaT)
          ∧ sF.regs .real [BM] "m_i" = some mijT
          ∧ sF.regs .real [BM] "l_i" = some (Tile.bop NumericDType.real.add (Broadcast.consSame Broadcast.nil)
              (Tile.bop NumericDType.real.mul (Broadcast.consSame Broadcast.nil) ltile alphaT) lijT)
          ∧ sF.regs .real [BM, ND] "acc" = some (Tile.bop NumericDType.real.add
              (Broadcast.consSame (Broadcast.consSame Broadcast.nil)) acc1T (Tile.dot [] pT vtile)) := by
  set qkT : Tile .real [BM, BN] :=
    Tile.bop NumericDType.real.mul Broadcast.scalarR
      (Tile.bop NumericDType.real.add (Broadcast.consSame (Broadcast.consSame Broadcast.nil))
        (⟨fun _ => some (0 : ℝ)⟩ : Tile .real [BM, BN]) (Tile.dot [] qtile ktile))
      (Tile.scalar (some sc)) with hqkT
  obtain ⟨rmaxT, hrm⟩ : ∃ t, Tile.reduceMaxDrop (⟨1, by simp⟩ : Fin [BM, BN].length) qkT = some t :=
    ⟨_, by unfold Tile.reduceMaxDrop; rw [dif_pos (show 0 < TileShape.axisDim [BM, BN] (⟨1, by simp⟩ : Fin [BM, BN].length) from by simpa [TileShape.axisDim] using hBN)]⟩
  set mijT : Tile .real [BM] := Tile.select (Tile.cop ComparableDType.real.gt (Broadcast.consSame Broadcast.nil) mtile rmaxT) mtile rmaxT with hmij
  set alphaT : Tile .real [BM] := Tile.uop WithBot.realExp2 (Tile.bop NumericDType.real.sub (Broadcast.consSame Broadcast.nil) mtile mijT) with halpha
  set pT : Tile .real [BM, BN] := Tile.uop WithBot.realExp2 (Tile.bop NumericDType.real.sub (Broadcast.consSame (Broadcast.consR Broadcast.nil)) qkT (Tile.expandDim ⟨1, by simp⟩ mijT)) with hpT
  set lijT : Tile .real [BM] := Tile.reduceSumDrop (⟨1, by simp⟩ : Fin [BM, BN].length) pT with hlij
  set acc1T : Tile .real [BM, ND] := Tile.bop NumericDType.real.mul (Broadcast.consSame (Broadcast.consR Broadcast.nil)) acctile (Tile.expandDim ⟨1, by simp⟩ alphaT) with hacc1
  unfold aft3LoopBodyG3
  -- L1: k = load K_block_ptr
  rw [stepStmts.cons_some (stepStmt_assign_eq_some
    (show evalOp (Op.load TileDType.real (MemAccess.blockPtr (Op.ref TileDType.blockPtr [ND, BN] "K_block_ptr") []) MaskOpt.none .unspecified) sin
        = some ktile from by
      rw [aft3_load_k_eval Kreg kbase ND NKV_CTX ND BN skk skn kcol (Op.ref TileDType.blockPtr [ND, BN] "K_block_ptr") sin
        (by rw [evalOp_ref]; exact hKp)]
      refine congrArg some ?_; refine Tile.ext (fun idx => ?_); rw [hkload idx]))]
  -- L2: qk = zeros
  rw [stepStmts.cons_some (stepStmt_assign_eq_some (aft3_qkzeros_eval _ BM BN))]
  -- L3: qk += dot q k
  rw [stepStmts.cons_some (stepStmt_assign_eq_some
    (aft3_qk_dot_eval _ BM BN ND (⟨fun _ => some (0 : ℝ)⟩ : Tile .real [BM, BN]) qtile ktile
      (by rw [BlockState.setReg_same])
      (by simp only [BlockState.setReg_ne_name, ne_eq, String.reduceEq, not_false_eq_true,
            BlockState.setReg_same]; exact hq)
      (by simp only [BlockState.setReg_ne_name, ne_eq, String.reduceEq, not_false_eq_true,
            BlockState.setReg_same] <;> try rfl)))]
  -- L4: qk *= qk_scale
  rw [stepStmts.cons_some (stepStmt_assign_eq_some
    (aft3_qk_scale_ref_eval _ BM BN sc
      (Tile.bop NumericDType.real.add (Broadcast.consSame (Broadcast.consSame Broadcast.nil))
        (⟨fun _ => some (0 : ℝ)⟩ : Tile .real [BM, BN]) (Tile.dot [] qtile ktile))
      (by rw [BlockState.setReg_same])
      (by simp only [BlockState.setReg_ne_name, ne_eq, String.reduceEq, not_false_eq_true]; exact hqs)))]
  -- L5: window ifThen (SLIDING_WINDOW false) → skipped
  rw [stepStmts.cons_some (aft3_ifThen_false (aft3_ne_zero_zero_false _))]
  -- L6: m_ij = maximum(m_i, max(qk,1))
  rw [stepStmts.cons_some (stepStmt_assign_eq_some
    (aft3_mij_evalG _ BM BN mtile qkT rmaxT (by simp)
      (by simp only [BlockState.setReg_ne_name, ne_eq, String.reduceEq, not_false_eq_true]; exact hmi)
      (by rw [BlockState.setReg_same] <;> try rfl)
      hrm))]
  -- L7: qk -= m_ij[:, None]
  rw [stepStmts.cons_some (stepStmt_assign_eq_some
    (aft3_qk_sub_evalG _ BM BN (by simp) qkT mijT
      (by simp only [BlockState.setReg_ne_name, ne_eq, String.reduceEq, not_false_eq_true,
            BlockState.setReg_same] <;> try rfl)
      (by rw [BlockState.setReg_same])))]
  -- L8: p = exp2 qk
  rw [stepStmts.cons_some (stepStmt_assign_eq_some
    (aft3_p_evalG _ BM BN (Tile.bop NumericDType.real.sub (Broadcast.consSame (Broadcast.consR Broadcast.nil)) qkT (Tile.expandDim ⟨1, by simp⟩ mijT))
      (by rw [BlockState.setReg_same])))]
  -- L9: pmask ifThen (SLIDING_WINDOW false) → skipped
  rw [stepStmts.cons_some (aft3_ifThen_false (aft3_ne_zero_zero_false _))]
  -- L10: l_ij = sum p 1
  rw [stepStmts.cons_some (@stepStmt_assign_eq_some .real [BM] "l_ij"
    (Op.reduceSum (⟨1, by simp⟩ : Fin [BM, BN].length) Bool.false (Op.ref .real [BM, BN] "p")) _ lijT
    (aft3_lij_evalG _ BM BN pT (by simp) (by rw [BlockState.setReg_same])))]
  -- L11: tmp = m_i - m_ij
  rw [stepStmts.cons_some (stepStmt_assign_eq_some
    (aft3_tmp_evalG _ BM mtile mijT
      (by simp only [BlockState.setReg_ne_name, ne_eq, String.reduceEq, not_false_eq_true]; exact hmi)
      (by simp only [BlockState.setReg_ne_name, ne_eq, String.reduceEq, not_false_eq_true,
            BlockState.setReg_same] <;> try rfl)))]
  -- L12: alpha = exp2 tmp
  rw [stepStmts.cons_some (stepStmt_assign_eq_some
    (aft3_alpha_evalG _ BM (Tile.bop NumericDType.real.sub (Broadcast.consSame Broadcast.nil) mtile mijT)
      (by rw [BlockState.setReg_same])))]
  -- L13: l_i = l_i * alpha + l_ij
  rw [stepStmts.cons_some (stepStmt_assign_eq_some
    (aft3_li_evalG _ BM ltile alphaT lijT
      (by simp only [BlockState.setReg_ne_name, ne_eq, String.reduceEq, not_false_eq_true]; exact hli)
      (by simp only [BlockState.setReg_ne_name, ne_eq, String.reduceEq, not_false_eq_true,
            BlockState.setReg_same] <;> try rfl)
      (by simp only [BlockState.setReg_ne_name, ne_eq, String.reduceEq, not_false_eq_true,
            BlockState.setReg_same] <;> try rfl)))]
  -- L14: acc = acc * alpha[:, None]
  rw [stepStmts.cons_some (stepStmt_assign_eq_some
    (aft3_acc_rescale_evalG _ BM ND (by simp) acctile alphaT
      (by simp only [BlockState.setReg_ne_name, ne_eq, String.reduceEq, not_false_eq_true]; exact hacc)
      (by simp only [BlockState.setReg_ne_name, ne_eq, String.reduceEq, not_false_eq_true,
            BlockState.setReg_same] <;> try rfl)))]
  -- L15: v = load V_block_ptr
  rw [stepStmts.cons_some (stepStmt_assign_eq_some
    (show evalOp (Op.load TileDType.real (MemAccess.blockPtr (Op.ref TileDType.blockPtr [BN, ND] "V_block_ptr") []) MaskOpt.none .unspecified) _
        = some vtile from by
      rw [aft3_load_v_eval Vreg vbase NKV_CTX ND BN ND svk svn vrow (Op.ref TileDType.blockPtr [BN, ND] "V_block_ptr") _
        (by rw [evalOp_ref]
            simp only [BlockState.setReg_ne_name, ne_eq, String.reduceEq, not_false_eq_true]
            exact hVp)]
      refine congrArg some ?_; refine Tile.ext (fun idx => ?_)
      simp only [BlockState.setReg_readMem]; rw [hvload idx]))]
  -- L16: acc += dot p v
  rw [stepStmts.cons_some (stepStmt_assign_eq_some
    (aft3_acc_eval _ BM BN ND acc1T pT vtile
      (by simp only [BlockState.setReg_ne_name, ne_eq, String.reduceEq, not_false_eq_true,
            BlockState.setReg_same] <;> try rfl)
      (by simp only [BlockState.setReg_ne_name, ne_eq, String.reduceEq, not_false_eq_true,
            BlockState.setReg_same] <;> try rfl)
      (by rw [BlockState.setReg_same])))]
  -- L17: m_i = m_ij
  rw [stepStmts.cons_some (stepStmt_assign_eq_some
    (aft3_mi_carry_evalG _ BM mijT
      (by simp only [BlockState.setReg_ne_name, ne_eq, String.reduceEq, not_false_eq_true,
            BlockState.setReg_same] <;> try rfl)))]
  -- L18: V_block_ptr = advance [BN, 0]
  rw [stepStmts.cons_some (stepStmt_assign_eq_some
    (aft3_advance_v_eval _ Vreg vbase NKV_CTX ND BN ND svk svn vrow BN "V_block_ptr"
      (by simp only [BlockState.setReg_ne_name, ne_eq, String.reduceEq, not_false_eq_true]; exact hVp)))]
  -- L19: K_block_ptr = advance [0, BN]
  rw [stepStmts.cons_some (stepStmt_assign_eq_some
    (aft3_advance_k_eval _ Kreg kbase ND NKV_CTX ND BN skk skn kcol BN "K_block_ptr"
      (by simp only [BlockState.setReg_ne_name, ne_eq, String.reduceEq, not_false_eq_true]; exact hKp)))]
  rw [stepStmts.nil]
  refine ⟨_, rfl, ?_, ?_, ?_, ?_, ?_, ?_, ?_, ?_, ?_, ?_, ?_, ?_, qkT, rmaxT, mijT, alphaT, lijT, pT, acc1T,
    rfl, hrm, rfl, rfl, rfl, rfl, rfl, ?_, ?_, ?_⟩
  · simp only [BlockState.setReg_pids]
  · funext rg o; simp only [BlockState.setReg_mem]
  · intro rg o; simp only [BlockState.setReg_undef]; exact hundef rg o
  · simp only [BlockState.setReg_ne_name, ne_eq, String.reduceEq, not_false_eq_true,
      BlockState.setReg_same]; exact hq
  · simp only [BlockState.setReg_ne_name, ne_eq, String.reduceEq, not_false_eq_true,
      BlockState.setReg_same]; exact hqs
  · simp only [BlockState.setReg_ne_name, ne_eq, String.reduceEq, not_false_eq_true,
      BlockState.setReg_same]; exact hsm
  · simp only [BlockState.setReg_ne_name, ne_eq, String.reduceEq, not_false_eq_true,
      BlockState.setReg_same]; exact hoff
  · simp only [BlockState.setReg_same]
  · simp only [BlockState.setReg_ne_name, ne_eq, String.reduceEq, not_false_eq_true,
      BlockState.setReg_same]
  · simp only [BlockState.setReg_ne_name, ne_eq, String.reduceEq, not_false_eq_true,
      BlockState.setReg_same]; exact hmptrs
  · simp only [BlockState.setReg_ne_name, ne_eq, String.reduceEq, not_false_eq_true,
      BlockState.setReg_same]; exact hlptrs
  · simp only [BlockState.setReg_ne_name, ne_eq, String.reduceEq, not_false_eq_true,
      BlockState.setReg_same]; exact hoblk
  · simp only [BlockState.setReg_ne_name, ne_eq, String.reduceEq, not_false_eq_true,
      BlockState.setReg_same]
  · simp only [BlockState.setReg_ne_name, ne_eq, String.reduceEq, not_false_eq_true,
      BlockState.setReg_same]
  · simp only [BlockState.setReg_ne_name, ne_eq, String.reduceEq, not_false_eq_true,
      BlockState.setReg_same]

/-! ## Dimension-general math-bridge layer (cases 1/2/3)

The dimension-general register bridges
(`aft3_score_cellG`/`aft3_mij_reg_eqG`/`aft3_denom_reg_eqG`/`aft3_acc_reg_eqG` and
their masked variants), parameterized over `BM`/`ND`/`NC`/`BN`. The generic
⊥-seed/foldl helpers (`aft3OsStepBot_block_*`, `aft3_filterMap_finRange_sum`,
`aft3_mem_le_foldr_sup`) and the G-foundation (`aft3StateBotG_*`,
`aft3KeysUptoG_*`) are reused directly. -/

/-- Global key index bound: block-`c` local lane `jL < BN` with `(c+1)·BN ≤ NC`. -/
theorem aft3_block_idx_lt (BN c NC : Nat) (jLval : Nat) (hjL : jLval < BN)
    (hwin : (c + 1) * BN ≤ NC) : c * BN + jLval < NC :=
  calc c * BN + jLval < c * BN + BN := by omega
    _ = (c + 1) * BN := by ring
    _ ≤ NC := hwin

/-- General block→Finset sum recipe. -/
theorem aft3BlockG_map_sum {BM ND NC : Nat}
    (qT : TileIndex [BM, ND] → ℝ) (kT vT : TileIndex [NC, ND] → ℝ)
    (keyScale : Fin NC → ℝ) (keep : Fin BM → Fin NC → Prop)
    [∀ i j, Decidable (keep i j)] (BN c : Nat) (i : Fin BM) (d : Fin ND)
    (hwin : (c + 1) * BN ≤ NC) (h : ℝ × ℝ → ℝ) :
    ((aft3BlockG qT kT vT keyScale keep BN c i d).map h).sum
      = ∑ jL : Fin BN,
          (if keep i ⟨c * BN + jL.val, aft3_block_idx_lt BN c NC jL.val jL.isLt hwin⟩ then
            h (keyScale ⟨c * BN + jL.val, aft3_block_idx_lt BN c NC jL.val jL.isLt hwin⟩ *
                Finset.univ.sum (fun e : Fin ND =>
                  qT (i, e, PUnit.unit) * kT (⟨c * BN + jL.val, aft3_block_idx_lt BN c NC jL.val jL.isLt hwin⟩, e, PUnit.unit)),
                vT (⟨c * BN + jL.val, aft3_block_idx_lt BN c NC jL.val jL.isLt hwin⟩, d, PUnit.unit))
           else 0) := by
  rw [aft3BlockG, aft3_filterMap_finRange_sum NC
    (fun j => c * BN ≤ j.val ∧ j.val < (c + 1) * BN ∧ keep i j)
    (fun j => (keyScale j * Finset.univ.sum (fun e : Fin ND =>
        qT (i, e, PUnit.unit) * kT (j, e, PUnit.unit)), vT (j, d, PUnit.unit))) h]
  rw [show (∑ j : Fin NC, if c * BN ≤ j.val ∧ j.val < (c + 1) * BN ∧ keep i j
            then h (keyScale j * Finset.univ.sum (fun e : Fin ND =>
                  qT (i, e, PUnit.unit) * kT (j, e, PUnit.unit)), vT (j, d, PUnit.unit)) else 0)
        = ∑ j ∈ Finset.univ.filter (fun j : Fin NC => c * BN ≤ j.val ∧ j.val < (c + 1) * BN),
            (if keep i j then h (keyScale j * Finset.univ.sum (fun e : Fin ND =>
                qT (i, e, PUnit.unit) * kT (j, e, PUnit.unit)), vT (j, d, PUnit.unit)) else 0) from by
    rw [Finset.sum_filter]
    refine Finset.sum_congr rfl (fun j _ => ?_)
    by_cases hwj : c * BN ≤ j.val ∧ j.val < (c + 1) * BN
    · by_cases hcj : keep i j
      · rw [if_pos ⟨hwj.1, hwj.2, hcj⟩, if_pos hwj, if_pos hcj]
      · rw [if_neg (fun hh => hcj hh.2.2), if_pos hwj, if_neg hcj]
    · rw [if_neg (fun hh => hwj ⟨hh.1, hh.2.1⟩), if_neg hwj]]
  symm
  have hexp : (c + 1) * BN = c * BN + BN := by ring
  refine Finset.sum_bij
    (i := fun jL _ => (⟨c * BN + jL.val, aft3_block_idx_lt BN c NC jL.val jL.isLt hwin⟩ : Fin NC)) ?_ ?_ ?_ ?_
  · intro jL _
    simp only [Finset.mem_filter, Finset.mem_univ, true_and]
    have := jL.isLt; omega
  · intro a _ b _ hab
    apply Fin.ext
    have : c * BN + a.val = c * BN + b.val := by simpa using congrArg Fin.val hab
    omega
  · intro j hj
    have hj2 : c * BN ≤ j.val ∧ j.val < (c + 1) * BN := (Finset.mem_filter.mp hj).2
    exact ⟨⟨j.val - c * BN, by omega⟩, Finset.mem_univ _, by apply Fin.ext; simp only; omega⟩
  · intro jL _; rfl

/-- General `aft3RunningMaxG` one-block advance. -/
theorem aft3RunningMaxG_succ {BM ND NC : Nat}
    (qT : TileIndex [BM, ND] → ℝ) (kT vT : TileIndex [NC, ND] → ℝ)
    (keyScale : Fin NC → ℝ) (keep : Fin BM → Fin NC → Prop)
    [∀ i j, Decidable (keep i j)] (BN c : Nat) (i : Fin BM) (d : Fin ND) :
    aft3RunningMaxG qT kT vT keyScale keep ((c + 1) * BN) i d
      = aft3RunningMaxG qT kT vT keyScale keep (c * BN) i d
        ⊔ ((aft3BlockG qT kT vT keyScale keep BN c i d).map (fun p => ((p.1 : ℝ) : WithBot ℝ))).foldr (· ⊔ ·) ⊥ := by
  unfold aft3RunningMaxG
  rw [aft3KeysUptoG_succ, List.map_append, List.foldr_append]
  generalize (List.map (fun p => ((p.1 : ℝ) : WithBot ℝ)) (aft3BlockG qT kT vT keyScale keep BN c i d)).foldr (· ⊔ ·) ⊥ = B
  induction (aft3KeysUptoG qT kT vT keyScale keep (c * BN) i d).map (fun p => ((p.1 : ℝ) : WithBot ℝ)) with
  | nil => simp
  | cons a t ih => simp only [List.foldr_cons, ih, sup_assoc]

/-- General seed-1 vs seed-0 split at any window. -/
theorem aft3StateBot1G_eq_or_bot {BM ND NC : Nat}
    (qT : TileIndex [BM, ND] → ℝ) (kT vT : TileIndex [NC, ND] → ℝ)
    (keyScale : Fin NC → ℝ) (keep : Fin BM → Fin NC → Prop)
    [∀ i j, Decidable (keep i j)] (hi : Nat) (i : Fin BM) (d : Fin ND) :
    aft3StateBot1G qT kT vT keyScale keep hi i d = aft3StateBotG qT kT vT keyScale keep hi i d
      ∨ aft3RunningMaxG qT kT vT keyScale keep hi i d = ⊥ := by
  by_cases h : aft3RunningMaxG qT kT vT keyScale keep hi i d = ⊥
  · exact Or.inr h
  · exact Or.inl (aft3StateBot1G_eq_aft3StateBotG qT kT vT keyScale keep hi i d h)

/-- General ⊥-seeded denominator anchor. -/
theorem aft3_denomG_anchor {BM ND NC : Nat}
    (qT : TileIndex [BM, ND] → ℝ) (kT vT : TileIndex [NC, ND] → ℝ)
    (keyScale : Fin NC → ℝ) (keep : Fin BM → Fin NC → Prop)
    [∀ i j, Decidable (keep i j)] (hi : Nat) (i : Fin BM) (d : Fin ND) :
    (aft3StateBotG qT kT vT keyScale keep hi i d).2.1
      = ((aft3StateBotG qT kT vT keyScale keep hi i d).1.elim 0 (fun r => pow2 (-r)))
        * (0 + ((aft3KeysUptoG qT kT vT keyScale keep hi i d).map (fun p => pow2 p.1)).sum) := by
  rw [aft3StateBotG_snd_fst, aft3StateBotG_fst_eq_runningMax, zero_add]

/-- General ⊥-seeded accumulator anchor. -/
theorem aft3_accG_anchor {BM ND NC : Nat}
    (qT : TileIndex [BM, ND] → ℝ) (kT vT : TileIndex [NC, ND] → ℝ)
    (keyScale : Fin NC → ℝ) (keep : Fin BM → Fin NC → Prop)
    [∀ i j, Decidable (keep i j)] (hi : Nat) (i : Fin BM) (d : Fin ND) :
    (aft3StateBotG qT kT vT keyScale keep hi i d).2.2
      = ((aft3StateBotG qT kT vT keyScale keep hi i d).1.elim 0 (fun r => pow2 (-r)))
        * (0 + ((aft3KeysUptoG qT kT vT keyScale keep hi i d).map (fun p => pow2 p.1 * p.2)).sum) := by
  rw [aft3StateBotG_snd_snd, aft3StateBotG_fst_eq_runningMax, zero_add]

/-- General running max over a nonempty no-window prefix is `≠ ⊥`. -/
theorem aft3RunningMaxG_noWindow_ne_bot {BM ND NC : Nat}
    (qT : TileIndex [BM, ND] → ℝ) (kT vT : TileIndex [NC, ND] → ℝ)
    (keyScale : Fin NC → ℝ) (hi : Nat) (hhi : 0 < hi) (hNC : 0 < NC)
    (i : Fin BM) (d : Fin ND) :
    aft3RunningMaxG qT kT vT keyScale (fun (i : Fin BM) (j : Fin NC) => noWindowKeep i j) hi i d ≠ ⊥ := by
  unfold aft3RunningMaxG aft3KeysUptoG
  set j0 : Fin NC := ⟨0, hNC⟩ with hj0
  set sc := keyScale j0 *
      Finset.univ.sum (fun e : Fin ND => qT (i, e, PUnit.unit) * kT (j0, e, PUnit.unit)) with hsc
  set L := ((List.finRange NC).filterMap (fun j : Fin NC =>
      if j.val < hi ∧ noWindowKeep i j then
        some (keyScale j * Finset.univ.sum (fun e : Fin ND =>
                qT (i, e, PUnit.unit) * kT (j, e, PUnit.unit)),
              vT (j, d, PUnit.unit))
      else none)).map (fun p => ((p.1 : ℝ) : WithBot ℝ)) with hL
  have hmemL : ((sc : ℝ) : WithBot ℝ) ∈ L := by
    rw [hL, List.mem_map]
    refine ⟨(sc, vT (j0, d, PUnit.unit)), ?_, rfl⟩
    rw [List.mem_filterMap]
    refine ⟨j0, List.mem_finRange _, ?_⟩
    rw [if_pos ⟨hhi, trivial⟩]
  have hle : ((sc : ℝ) : WithBot ℝ) ≤ L.foldr (· ⊔ ·) ⊥ := aft3_mem_le_foldr_sup _ L hmemL
  intro hbot
  exact absurd (le_bot_iff.mp (hbot ▸ hle)) WithBot.coe_ne_bot

/-- Canonical axis-1 index of a `[BM, BN]` tile. -/
abbrev aft3Ax1G (BM BN : Nat) : Fin [BM, BN].length := ⟨1, by simp⟩

/-- **General `reduceMaxDrop` row.** -/
theorem aft3_reduceMaxDrop_rowG (BM BN : Nat) (hBN : 0 < BN)
    (qk : Tile .real [BM, BN]) (rmaxT : Tile .real [BM])
    (hrm : Tile.reduceMaxDrop (aft3Ax1G BM BN) qk = some rmaxT)
    (i : Fin BM) (g : Fin BN → WithBot ℝ)
    (hqk : ∀ jL : Fin BN, qk.data (i, jL, PUnit.unit) = g jL) :
    rmaxT.data (i, PUnit.unit) = Finset.univ.sup g := by
  unfold Tile.reduceMaxDrop at hrm
  rw [dif_pos (show 0 < TileShape.axisDim [BM, BN] (⟨1, by simp⟩ : Fin [BM, BN].length) from by
    simpa [TileShape.axisDim] using hBN)] at hrm
  rw [← Option.some.inj hrm]
  simp only [Finset.sup'_eq_sup]
  exact Finset.sup_congr rfl (fun jL _ => hqk jL)

/-- **General `q·k` score cell (case 3).** -/
theorem aft3_score_cellG (s0 : BlockState) (Q K : RegionName)
    (base BM ND NC sqm sqk skn skk : Nat) (sc : ℝ) (BN c : Nat)
    (i : Fin BM) (jL : Fin BN) (hjL : c * BN + jL.val < NC)
    (qtile : Tile .real [BM, ND]) (ktile : Tile .real [ND, BN])
    (hq : qtile = ⟨fun idx : TileIndex [BM, ND] => some (qTile3G s0 Q base BM ND sqm sqk idx)⟩)
    (hk : ∀ idx : TileIndex [ND, BN],
        ktile.data idx = some (s0.readMem K (base + idx.1.val * skk + (c * BN + idx.2.1.val) * skn))) :
    (Tile.bop NumericDType.real.mul Broadcast.scalarR
        (Tile.bop NumericDType.real.add (Broadcast.consSame (Broadcast.consSame Broadcast.nil))
          (⟨fun _ => some (0 : ℝ)⟩ : Tile .real [BM, BN]) (Tile.dot [] qtile ktile))
        (Tile.scalar (some sc))).data (i, jL, PUnit.unit)
      = some (sc * Finset.univ.sum (fun e : Fin ND =>
          qTile3G s0 Q base BM ND sqm sqk (i, e, PUnit.unit)
            * kTile3G s0 K base NC ND skn skk (⟨c * BN + jL.val, hjL⟩, e, PUnit.unit))) := by
  have hdot : (Tile.dot [] qtile ktile).data (i, jL, PUnit.unit)
      = some (Finset.univ.sum (fun e : Fin ND =>
          qTile3G s0 Q base BM ND sqm sqk (i, e, PUnit.unit)
            * kTile3G s0 K base NC ND skn skk (⟨c * BN + jL.val, hjL⟩, e, PUnit.unit))) := by
    rw [Tile.dot_nil_data]
    rw [show (@Finset.sum (Fin ND) (WithBot ℝ) _ Finset.univ
          (fun e => Option.map₂ (· * ·) (qtile.data (i, e, PUnit.unit)) (ktile.data (e, jL, PUnit.unit))))
        = @Finset.sum (Fin ND) (WithBot ℝ) _ Finset.univ
          (fun e => (some (qTile3G s0 Q base BM ND sqm sqk (i, e, PUnit.unit)
              * kTile3G s0 K base NC ND skn skk (⟨c * BN + jL.val, hjL⟩, e, PUnit.unit)) : WithBot ℝ))
        from Finset.sum_congr rfl (fun e _ => by
          simp only [hq, hk (e, jL, PUnit.unit), Option.map₂, Option.bind, Option.map]
          refine congrArg some ?_
          rw [show kTile3G s0 K base NC ND skn skk (⟨c * BN + jL.val, hjL⟩, e, PUnit.unit)
                = s0.readMem K (base + e.val * skk + (c * BN + jL.val) * skn) from by
            simp only [kTile3G]; congr 1; ring])]
    rw [WithBot.sum_someTerm_eq_some]
  simp only [Tile.bop_data, Broadcast.leftIndex, Broadcast.rightIndex, Broadcast.scalarR,
    Tile.scalar_data, NumericDType.mul, NumericDType.add, hdot]
  show some _ = _
  refine congrArg some ?_
  simp only [WithBot.realMul, WithBot.realAdd, Option.map₂, Option.bind, Option.map, zero_add]
  ring

/-! ### General case-3 (no-window) register bridges -/

set_option maxHeartbeats 1600000 in
/-- **General block sup (case 3).** -/
theorem aft3Block_noWindow_blockSupG (s0 : BlockState) (Q K V : RegionName)
    (base BM ND NC sqm sqk skn skk svk svn : Nat) (sc : ℝ) (BN c : Nat)
    (hc1 : (c + 1) * BN ≤ NC) (i : Fin BM) (d : Fin ND) :
    Finset.univ.sup (fun jL : Fin BN =>
        ((sc * Finset.univ.sum (fun e : Fin ND =>
            qTile3G s0 Q base BM ND sqm sqk (i, e, PUnit.unit) *
              kTile3G s0 K base NC ND skn skk (⟨c * BN + jL.val, aft3_block_idx_lt BN c NC jL.val jL.isLt hc1⟩, e, PUnit.unit)) : ℝ) : WithBot ℝ))
      = ((aft3BlockG (qTile3G s0 Q base BM ND sqm sqk) (kTile3G s0 K base NC ND skn skk)
          (vTile3G s0 V base NC ND svk svn) (keyScale3G sc NC)
          (fun (i : Fin BM) (j : Fin NC) => noWindowKeep i j) BN c i d).map (fun p => ((p.1 : ℝ) : WithBot ℝ))).foldr (· ⊔ ·) ⊥ := by
  rw [show (aft3BlockG (qTile3G s0 Q base BM ND sqm sqk) (kTile3G s0 K base NC ND skn skk)
        (vTile3G s0 V base NC ND svk svn) (keyScale3G sc NC)
        (fun (i : Fin BM) (j : Fin NC) => noWindowKeep i j) BN c i d).map (fun p => ((p.1 : ℝ) : WithBot ℝ))
      = ((List.finRange NC).filterMap (fun j : Fin NC =>
          if c * BN ≤ j.val ∧ j.val < (c + 1) * BN
          then some (keyScale3G sc NC j * Finset.univ.sum (fun e : Fin ND =>
                qTile3G s0 Q base BM ND sqm sqk (i, e, PUnit.unit) * kTile3G s0 K base NC ND skn skk (j, e, PUnit.unit))) else none)).map
            (fun x => ((x : ℝ) : WithBot ℝ)) from by
    unfold aft3BlockG
    rw [List.map_filterMap, List.map_filterMap]
    apply List.filterMap_congr
    intro j _
    by_cases hj : c * BN ≤ j.val ∧ j.val < (c + 1) * BN <;>
      simp [hj, noWindowKeep]]
  rw [aft3_filterMap_foldr_sup NC
    (fun j => c * BN ≤ j.val ∧ j.val < (c + 1) * BN)
    (fun j => keyScale3G sc NC j * Finset.univ.sum (fun e : Fin ND =>
        qTile3G s0 Q base BM ND sqm sqk (i, e, PUnit.unit) * kTile3G s0 K base NC ND skn skk (j, e, PUnit.unit)))]
  symm
  have hexp : (c + 1) * BN = c * BN + BN := by ring
  apply le_antisymm
  · apply Finset.sup_le; intro j _
    by_cases hj : c * BN ≤ j.val ∧ j.val < (c + 1) * BN
    · rw [if_pos hj]
      have hjL : j.val - c * BN < BN := by omega
      refine le_trans ?_ (Finset.le_sup (Finset.mem_univ (⟨j.val - c * BN, hjL⟩ : Fin BN)))
      simp only
      have hfin : (⟨c * BN + (j.val - c * BN), by omega⟩ : Fin NC) = j := by apply Fin.ext; simp; omega
      apply le_of_eq
      simp only [keyScale3G]
      congr 1; rw [hfin]
    · rw [if_neg hj]; exact bot_le
  · apply Finset.sup_le; intro jL _
    have hb : c * BN + jL.val < NC := aft3_block_idx_lt BN c NC jL.val jL.isLt hc1
    refine le_trans ?_ (Finset.le_sup (Finset.mem_univ (⟨c * BN + jL.val, hb⟩ : Fin NC)))
    simp only
    rw [if_pos (by have := jL.isLt; exact ⟨by omega, by omega⟩)]
    apply le_of_eq
    simp only [keyScale3G]

set_option maxHeartbeats 1600000 in
/-- **General `m_ij = aft3RunningMaxG((c+1)·BN)` (case 3).** -/
theorem aft3_mij_reg_eqG (s0 : BlockState) (Q K V : RegionName)
    (base BM ND NC sqm sqk skn skk svk svn : Nat) (sc : ℝ) (BN c : Nat) (hBN : 0 < BN)
    (hc1 : (c + 1) * BN ≤ NC) (i : Fin BM) (d : Fin ND)
    (qtile : Tile .real [BM, ND]) (ktile : Tile .real [ND, BN]) (mtile rmaxT : Tile .real [BM])
    (qkT : Tile .real [BM, BN])
    (hq : qtile = ⟨fun idx : TileIndex [BM, ND] => some (qTile3G s0 Q base BM ND sqm sqk idx)⟩)
    (hk : ∀ idx : TileIndex [ND, BN],
        ktile.data idx = some (s0.readMem K (base + idx.1.val * skk + (c * BN + idx.2.1.val) * skn)))
    (hqkT : qkT = Tile.bop NumericDType.real.mul Broadcast.scalarR
              (Tile.bop NumericDType.real.add (Broadcast.consSame (Broadcast.consSame Broadcast.nil))
                (⟨fun _ => some (0 : ℝ)⟩ : Tile .real [BM, BN]) (Tile.dot [] qtile ktile))
              (Tile.scalar (some sc)))
    (hmtile : mtile.data (i, PUnit.unit)
        = aft3RunningMaxG (qTile3G s0 Q base BM ND sqm sqk) (kTile3G s0 K base NC ND skn skk)
            (vTile3G s0 V base NC ND svk svn) (keyScale3G sc NC)
            (fun (i : Fin BM) (j : Fin NC) => noWindowKeep i j) (c * BN) i d)
    (hrmax : Tile.reduceMaxDrop (aft3Ax1G BM BN) qkT = some rmaxT) :
    (Tile.select (Tile.cop ComparableDType.real.gt (Broadcast.consSame Broadcast.nil) mtile rmaxT) mtile rmaxT).data (i, PUnit.unit)
      = aft3RunningMaxG (qTile3G s0 Q base BM ND sqm sqk) (kTile3G s0 K base NC ND skn skk)
          (vTile3G s0 V base NC ND svk svn) (keyScale3G sc NC)
          (fun (i : Fin BM) (j : Fin NC) => noWindowKeep i j) ((c + 1) * BN) i d := by
  have hrmaxcell : rmaxT.data (i, PUnit.unit)
      = ((aft3BlockG (qTile3G s0 Q base BM ND sqm sqk) (kTile3G s0 K base NC ND skn skk)
          (vTile3G s0 V base NC ND svk svn) (keyScale3G sc NC)
          (fun (i : Fin BM) (j : Fin NC) => noWindowKeep i j) BN c i d).map
          (fun p => ((p.1 : ℝ) : WithBot ℝ))).foldr (· ⊔ ·) ⊥ := by
    rw [aft3_reduceMaxDrop_rowG BM BN hBN qkT rmaxT hrmax i
      (fun jL => ((sc * Finset.univ.sum (fun e : Fin ND =>
          qTile3G s0 Q base BM ND sqm sqk (i, e, PUnit.unit) *
            kTile3G s0 K base NC ND skn skk (⟨c * BN + jL.val, aft3_block_idx_lt BN c NC jL.val jL.isLt hc1⟩, e, PUnit.unit)) : ℝ) : WithBot ℝ))
      ?_]
    · exact aft3Block_noWindow_blockSupG s0 Q K V base BM ND NC sqm sqk skn skk svk svn sc BN c hc1 i d
    · intro jL
      rw [hqkT]
      exact aft3_score_cellG s0 Q K base BM ND NC sqm sqk skn skk sc BN c i jL
        (aft3_block_idx_lt BN c NC jL.val jL.isLt hc1) qtile ktile hq hk
  rw [aft3RunningMaxG_succ (qTile3G s0 Q base BM ND sqm sqk) (kTile3G s0 K base NC ND skn skk)
      (vTile3G s0 V base NC ND svk svn) (keyScale3G sc NC)
      (fun (i : Fin BM) (j : Fin NC) => noWindowKeep i j) BN c i d]
  rw [Tile.select_data, Tile.cop_data]
  simp only [Broadcast.leftIndex, Broadcast.rightIndex, ComparableDType.gt, hmtile, hrmaxcell]
  set M := aft3RunningMaxG (qTile3G s0 Q base BM ND sqm sqk) (kTile3G s0 K base NC ND skn skk)
      (vTile3G s0 V base NC ND svk svn) (keyScale3G sc NC)
      (fun (i : Fin BM) (j : Fin NC) => noWindowKeep i j) (c * BN) i d
  set S := ((aft3BlockG (qTile3G s0 Q base BM ND sqm sqk) (kTile3G s0 K base NC ND skn skk)
      (vTile3G s0 V base NC ND svk svn) (keyScale3G sc NC)
      (fun (i : Fin BM) (j : Fin NC) => noWindowKeep i j) BN c i d).map
      (fun p => ((p.1 : ℝ) : WithBot ℝ))).foldr (· ⊔ ·) ⊥
  by_cases h : M ≤ S
  · rw [if_neg (by simp [not_lt.mpr h]), max_eq_right h]
  · rw [if_pos (by simpa using not_le.mp h), max_eq_left (le_of_lt (not_le.mp h))]

set_option maxHeartbeats 1600000 in
/-- **General `Σ_jL p[i,jL] = aft3BlockG` pow2-score sum (case 3).** -/
theorem aft3_nume_row_sumG (s0 : BlockState) (Q K V : RegionName)
    (base BM ND NC sqm sqk skn skk svk svn : Nat) (sc : ℝ) (BN c : Nat) (hBN : 0 < BN)
    (hc1 : (c + 1) * BN ≤ NC) (i : Fin BM) (d : Fin ND)
    (qtile : Tile .real [BM, ND]) (ktile : Tile .real [ND, BN]) (mijT : Tile .real [BM]) (pT : Tile .real [BM, BN])
    (qkT : Tile .real [BM, BN])
    (hq : qtile = ⟨fun idx : TileIndex [BM, ND] => some (qTile3G s0 Q base BM ND sqm sqk idx)⟩)
    (hk : ∀ idx : TileIndex [ND, BN],
        ktile.data idx = some (s0.readMem K (base + idx.1.val * skk + (c * BN + idx.2.1.val) * skn)))
    (hqkT : qkT = Tile.bop NumericDType.real.mul Broadcast.scalarR
              (Tile.bop NumericDType.real.add (Broadcast.consSame (Broadcast.consSame Broadcast.nil))
                (⟨fun _ => some (0 : ℝ)⟩ : Tile .real [BM, BN]) (Tile.dot [] qtile ktile))
              (Tile.scalar (some sc)))
    (Mr : ℝ) (hmij : mijT.data (i, PUnit.unit) = (Mr : WithBot ℝ))
    (hpT : pT = Tile.uop WithBot.realExp2 (Tile.bop NumericDType.real.sub
        (Broadcast.consSame (Broadcast.consR Broadcast.nil)) qkT (Tile.expandDim ⟨1, by simp⟩ mijT))) :
    (Tile.reduceSumDrop (aft3Ax1G BM BN) pT).data (i, PUnit.unit)
      = some ((aft3BlockG (qTile3G s0 Q base BM ND sqm sqk) (kTile3G s0 K base NC ND skn skk)
          (vTile3G s0 V base NC ND svk svn) (keyScale3G sc NC)
          (fun (i : Fin BM) (j : Fin NC) => noWindowKeep i j) BN c i d).map (fun p => pow2 (p.1 - Mr))).sum := by
  rw [Tile.reduceSumDrop_data]
  have hcell : ∀ jL : Fin BN,
      pT.data (TileShape.insertAxisIndex [BM, BN] (⟨1, by simp⟩ : Fin [BM, BN].length) (i, PUnit.unit) jL)
        = some (pow2 ((sc * Finset.univ.sum (fun e : Fin ND =>
              qTile3G s0 Q base BM ND sqm sqk (i, e, PUnit.unit) *
                kTile3G s0 K base NC ND skn skk (⟨c * BN + jL.val, aft3_block_idx_lt BN c NC jL.val jL.isLt hc1⟩, e, PUnit.unit))) - Mr)) := by
    intro jL
    rw [show (TileShape.insertAxisIndex [BM, BN] (⟨1, by simp⟩ : Fin [BM, BN].length) (i, PUnit.unit) jL) = (i, jL, PUnit.unit) from rfl]
    rw [hpT]
    show WithBot.realExp2 _ = _
    simp only [Tile.bop_data, Broadcast.leftIndex, Broadcast.rightIndex, Tile.expandDim_data,
      TileShape.dropInsertedIndex, NumericDType.sub, hmij]
    rw [hqkT, aft3_score_cellG s0 Q K base BM ND NC sqm sqk skn skk sc BN c i jL
      (aft3_block_idx_lt BN c NC jL.val jL.isLt hc1) qtile ktile hq hk]
    simp only [WithBot.realSub, Option.map₂, Option.bind, Option.map, WithBot.realExp2_some]
    refine congrArg some ?_; simp only [pow2]; ring_nf
  simp only [hcell]
  rw [WithBot.sum_someTerm_eq_some]
  refine congrArg some ?_
  rw [aft3BlockG_map_sum (qTile3G s0 Q base BM ND sqm sqk) (kTile3G s0 K base NC ND skn skk)
      (vTile3G s0 V base NC ND svk svn) (keyScale3G sc NC)
      (fun (i : Fin BM) (j : Fin NC) => noWindowKeep i j) BN c i d hc1 (fun p => pow2 (p.1 - Mr))]
  refine Finset.sum_congr rfl (fun jL _ => ?_)
  rw [if_pos (by trivial)]
  simp only [keyScale3G]

set_option maxHeartbeats 1600000 in
/-- **General `Σ_jL p[i,jL]·v[jL,d] = aft3BlockG` pow2-score·v sum (case 3).** -/
theorem aft3_acc_dot_blockG (s0 : BlockState) (Q K V : RegionName)
    (base BM ND NC sqm sqk skn skk svk svn : Nat) (sc : ℝ) (BN c : Nat) (hBN : 0 < BN)
    (hc1 : (c + 1) * BN ≤ NC) (i : Fin BM) (d : Fin ND)
    (qtile : Tile .real [BM, ND]) (ktile : Tile .real [ND, BN]) (vtile : Tile .real [BN, ND])
    (mijT : Tile .real [BM]) (pT : Tile .real [BM, BN]) (qkT : Tile .real [BM, BN])
    (hq : qtile = ⟨fun idx : TileIndex [BM, ND] => some (qTile3G s0 Q base BM ND sqm sqk idx)⟩)
    (hk : ∀ idx : TileIndex [ND, BN],
        ktile.data idx = some (s0.readMem K (base + idx.1.val * skk + (c * BN + idx.2.1.val) * skn)))
    (hv : ∀ idx : TileIndex [BN, ND],
        vtile.data idx = some (s0.readMem V (base + (c * BN + idx.1.val) * svk + idx.2.1.val * svn)))
    (hqkT : qkT = Tile.bop NumericDType.real.mul Broadcast.scalarR
              (Tile.bop NumericDType.real.add (Broadcast.consSame (Broadcast.consSame Broadcast.nil))
                (⟨fun _ => some (0 : ℝ)⟩ : Tile .real [BM, BN]) (Tile.dot [] qtile ktile))
              (Tile.scalar (some sc)))
    (Mr : ℝ) (hmij : mijT.data (i, PUnit.unit) = (Mr : WithBot ℝ))
    (hpT : pT = Tile.uop WithBot.realExp2 (Tile.bop NumericDType.real.sub
        (Broadcast.consSame (Broadcast.consR Broadcast.nil)) qkT (Tile.expandDim ⟨1, by simp⟩ mijT))) :
    (Tile.dot [] pT vtile).data (i, d, PUnit.unit)
      = some ((aft3BlockG (qTile3G s0 Q base BM ND sqm sqk) (kTile3G s0 K base NC ND skn skk)
          (vTile3G s0 V base NC ND svk svn) (keyScale3G sc NC)
          (fun (i : Fin BM) (j : Fin NC) => noWindowKeep i j) BN c i d).map (fun p => pow2 (p.1 - Mr) * p.2)).sum := by
  rw [Tile.dot_nil_data]
  have hcell : ∀ jL : Fin BN,
      Option.map₂ (· * ·) (pT.data (i, jL, PUnit.unit)) (vtile.data (jL, d, PUnit.unit))
        = some (pow2 ((sc * Finset.univ.sum (fun e : Fin ND =>
              qTile3G s0 Q base BM ND sqm sqk (i, e, PUnit.unit) *
                kTile3G s0 K base NC ND skn skk (⟨c * BN + jL.val, aft3_block_idx_lt BN c NC jL.val jL.isLt hc1⟩, e, PUnit.unit))) - Mr)
              * vTile3G s0 V base NC ND svk svn (⟨c * BN + jL.val, aft3_block_idx_lt BN c NC jL.val jL.isLt hc1⟩, d, PUnit.unit)) := by
    intro jL
    have hpcell : pT.data (i, jL, PUnit.unit)
        = some (pow2 ((sc * Finset.univ.sum (fun e : Fin ND =>
            qTile3G s0 Q base BM ND sqm sqk (i, e, PUnit.unit) *
              kTile3G s0 K base NC ND skn skk (⟨c * BN + jL.val, aft3_block_idx_lt BN c NC jL.val jL.isLt hc1⟩, e, PUnit.unit))) - Mr)) := by
      rw [hpT]
      show WithBot.realExp2 _ = _
      simp only [Tile.bop_data, Broadcast.leftIndex, Broadcast.rightIndex, Tile.expandDim_data,
        TileShape.dropInsertedIndex, NumericDType.sub, hmij]
      rw [hqkT, aft3_score_cellG s0 Q K base BM ND NC sqm sqk skn skk sc BN c i jL
        (aft3_block_idx_lt BN c NC jL.val jL.isLt hc1) qtile ktile hq hk]
      simp only [WithBot.realSub, Option.map₂, Option.bind, Option.map, WithBot.realExp2_some]
      refine congrArg some ?_; simp only [pow2]; ring_nf
    rw [hpcell, hv (jL, d, PUnit.unit)]
    rw [show s0.readMem V (base + (c * BN + jL.val) * svk + d.val * svn)
          = vTile3G s0 V base NC ND svk svn (⟨c * BN + jL.val, aft3_block_idx_lt BN c NC jL.val jL.isLt hc1⟩, d, PUnit.unit) from by
      simp only [vTile3G]]
    simp only [Option.map₂, Option.bind, Option.map]
  rw [show (@Finset.sum (Fin BN) (WithBot ℝ) _ Finset.univ
        (fun k => Option.map₂ (· * ·) (pT.data (i, k, PUnit.unit)) (vtile.data (k, d, PUnit.unit))))
      = @Finset.sum (Fin BN) (WithBot ℝ) _ Finset.univ (fun jL =>
          (some (pow2 ((sc * Finset.univ.sum (fun e : Fin ND =>
                qTile3G s0 Q base BM ND sqm sqk (i, e, PUnit.unit) *
                  kTile3G s0 K base NC ND skn skk (⟨c * BN + jL.val, aft3_block_idx_lt BN c NC jL.val jL.isLt hc1⟩, e, PUnit.unit))) - Mr)
              * vTile3G s0 V base NC ND svk svn (⟨c * BN + jL.val, aft3_block_idx_lt BN c NC jL.val jL.isLt hc1⟩, d, PUnit.unit)) : WithBot ℝ))
      from Finset.sum_congr rfl (fun jL _ => hcell jL)]
  rw [WithBot.sum_someTerm_eq_some]
  refine congrArg some ?_
  rw [aft3BlockG_map_sum (qTile3G s0 Q base BM ND sqm sqk) (kTile3G s0 K base NC ND skn skk)
      (vTile3G s0 V base NC ND svk svn) (keyScale3G sc NC)
      (fun (i : Fin BM) (j : Fin NC) => noWindowKeep i j) BN c i d hc1 (fun p => pow2 (p.1 - Mr) * p.2)]
  refine Finset.sum_congr rfl (fun jL _ => ?_)
  rw [if_pos (by trivial)]
  simp only [keyScale3G]

set_option maxHeartbeats 1600000 in
/-- **General `l_i' = aft3StateBotG((c+1)·BN).2.1` (case 3).** -/
theorem aft3_denom_reg_eqG (s0 : BlockState) (Q K V : RegionName)
    (base BM ND NC sqm sqk skn skk svk svn : Nat) (sc : ℝ) (BN c : Nat) (hBN : 0 < BN) (hNC : 0 < NC)
    (hc1 : (c + 1) * BN ≤ NC) (i : Fin BM) (d : Fin ND)
    (qtile : Tile .real [BM, ND]) (ktile : Tile .real [ND, BN]) (qkT : Tile .real [BM, BN])
    (ltile mtile mijT alphaT : Tile .real [BM]) (pT : Tile .real [BM, BN])
    (hq : qtile = ⟨fun idx : TileIndex [BM, ND] => some (qTile3G s0 Q base BM ND sqm sqk idx)⟩)
    (hk : ∀ idx : TileIndex [ND, BN],
        ktile.data idx = some (s0.readMem K (base + idx.1.val * skk + (c * BN + idx.2.1.val) * skn)))
    (hqkT : qkT = Tile.bop NumericDType.real.mul Broadcast.scalarR
              (Tile.bop NumericDType.real.add (Broadcast.consSame (Broadcast.consSame Broadcast.nil))
                (⟨fun _ => some (0 : ℝ)⟩ : Tile .real [BM, BN]) (Tile.dot [] qtile ktile))
              (Tile.scalar (some sc)))
    (hltile : ltile.data (i, PUnit.unit) = some
        ((aft3StateBot1G (qTile3G s0 Q base BM ND sqm sqk) (kTile3G s0 K base NC ND skn skk)
            (vTile3G s0 V base NC ND svk svn) (keyScale3G sc NC)
            (fun (i : Fin BM) (j : Fin NC) => noWindowKeep i j) (c * BN) i d).2.1))
    (hmtile : mtile.data (i, PUnit.unit)
        = aft3RunningMaxG (qTile3G s0 Q base BM ND sqm sqk) (kTile3G s0 K base NC ND skn skk)
            (vTile3G s0 V base NC ND svk svn) (keyScale3G sc NC)
            (fun (i : Fin BM) (j : Fin NC) => noWindowKeep i j) (c * BN) i d)
    (hmij : mijT.data (i, PUnit.unit)
        = aft3RunningMaxG (qTile3G s0 Q base BM ND sqm sqk) (kTile3G s0 K base NC ND skn skk)
            (vTile3G s0 V base NC ND svk svn) (keyScale3G sc NC)
            (fun (i : Fin BM) (j : Fin NC) => noWindowKeep i j) ((c + 1) * BN) i d)
    (halpha : alphaT = Tile.uop WithBot.realExp2
        (Tile.bop NumericDType.real.sub (Broadcast.consSame Broadcast.nil) mtile mijT))
    (hpT : pT = Tile.uop WithBot.realExp2 (Tile.bop NumericDType.real.sub
        (Broadcast.consSame (Broadcast.consR Broadcast.nil)) qkT (Tile.expandDim ⟨1, by simp⟩ mijT))) :
    (Tile.bop NumericDType.real.add (Broadcast.consSame Broadcast.nil)
        (Tile.bop NumericDType.real.mul (Broadcast.consSame Broadcast.nil) ltile alphaT)
        (Tile.reduceSumDrop (aft3Ax1G BM BN) pT)).data (i, PUnit.unit)
      = some ((aft3StateBotG (qTile3G s0 Q base BM ND sqm sqk) (kTile3G s0 K base NC ND skn skk)
          (vTile3G s0 V base NC ND svk svn) (keyScale3G sc NC)
          (fun (i : Fin BM) (j : Fin NC) => noWindowKeep i j) ((c + 1) * BN) i d).2.1) := by
  set qT := qTile3G s0 Q base BM ND sqm sqk
  set kT := kTile3G s0 K base NC ND skn skk
  set vT := vTile3G s0 V base NC ND svk svn
  set ks := keyScale3G sc NC
  set kp : Fin BM → Fin NC → Prop := fun i j => noWindowKeep i j
  set m := (aft3StateBotG qT kT vT ks kp (c * BN) i d).1 with hm_def
  set Mc := aft3RunningMaxG qT kT vT ks kp (c * BN) i d with hMc
  set Mc1 := aft3RunningMaxG qT kT vT ks kp ((c + 1) * BN) i d with hMc1
  have hmMc : m = Mc := by rw [hm_def, hMc, aft3StateBotG_fst_eq_runningMax]
  have hne : Mc1 ≠ ⊥ := by
    rw [hMc1]
    exact aft3RunningMaxG_noWindow_ne_bot qT kT vT ks ((c + 1) * BN) (by positivity) hNC i d
  obtain ⟨Mr, hMr⟩ : ∃ Mr : ℝ, Mc1 = (Mr : WithBot ℝ) := by
    cases hh : Mc1 with
    | bot => exact absurd hh hne
    | coe x => exact ⟨x, rfl⟩
  have hMsucc : Mc1 = m ⊔ ((aft3BlockG qT kT vT ks kp BN c i d).map
        (fun p => ((p.1 : ℝ) : WithBot ℝ))).foldr (· ⊔ ·) ⊥ := by
    have h1 : Mc1 = (aft3StateBotG qT kT vT ks kp ((c + 1) * BN) i d).1 := by
      rw [hMc1, aft3StateBotG_fst_eq_runningMax]
    rw [h1, aft3StateBotG_succ, aft3OsStepBot_block_fst m
        ((aft3StateBotG qT kT vT ks kp (c * BN) i d).2.1)
        ((aft3StateBotG qT kT vT ks kp (c * BN) i d).2.2)]
  have halphaVal : alphaT.data (i, PUnit.unit) = WithBot.realExp2 (WithBot.realSub m Mc1) := by
    rw [halpha]; show WithBot.realExp2 _ = _
    simp only [Tile.bop_data, Broadcast.leftIndex, Broadcast.rightIndex, hmtile, hmij,
      NumericDType.sub, ← hMc, ← hMc1, hmMc]
  have hsum := aft3_nume_row_sumG s0 Q K V base BM ND NC sqm sqk skn skk svk svn sc BN c hBN hc1 i d
    qtile ktile mijT pT qkT hq hk hqkT Mr (by rw [hmij]; exact hMr) hpT
  have hblockEq := aft3OsStepBot_block_eq m
    ((aft3StateBotG qT kT vT ks kp (c * BN) i d).2.1)
    ((aft3StateBotG qT kT vT ks kp (c * BN) i d).2.2)
    ((aft3KeysUptoG qT kT vT ks kp (c * BN) i d).map (fun p => pow2 p.1 * p.2)).sum
    ((aft3KeysUptoG qT kT vT ks kp (c * BN) i d).map (fun p => pow2 p.1)).sum
    (aft3BlockG qT kT vT ks kp BN c i d)
    (by rw [aft3_denomG_anchor, zero_add, hm_def])
    (by rw [aft3_accG_anchor, zero_add, hm_def])
    (fun hbot => aft3KeysUptoG_sum_zero_of_bot qT kT vT ks kp (c * BN) i d
      (by rw [← aft3StateBotG_fst_eq_runningMax, ← hm_def]; exact hbot) _)
    (fun hbot => aft3KeysUptoG_sum_zero_of_bot qT kT vT ks kp (c * BN) i d
      (by rw [← aft3StateBotG_fst_eq_runningMax, ← hm_def]; exact hbot) _)
  rw [← hMsucc] at hblockEq
  rw [show (aft3StateBotG qT kT vT ks kp ((c + 1) * BN) i d).2.1
        = (Mc1, (aft3StateBotG qT kT vT ks kp (c * BN) i d).2.1
              * (WithBot.realExp2 (WithBot.realSub m Mc1)).unbotD 0
              + ((aft3BlockG qT kT vT ks kp BN c i d).map (fun p => pow2 (p.1 - Mc1.unbotD 0))).sum,
            _).2.1 from by
    rw [aft3StateBotG_succ]; rw [← hblockEq]]
  set α : ℝ := (WithBot.realExp2 (WithBot.realSub m Mc1)).unbotD 0 with hαdef
  have hαsome : WithBot.realExp2 (WithBot.realSub m Mc1) = some α := by
    rw [hαdef]; cases WithBot.realSub m Mc1 <;> rfl
  have hl1 : (aft3StateBot1G qT kT vT ks kp (c * BN) i d).2.1 * α
      = (aft3StateBotG qT kT vT ks kp (c * BN) i d).2.1 * α := by
    rcases aft3StateBot1G_eq_or_bot qT kT vT ks kp (c * BN) i d with heq | hbot
    · rw [heq]
    · have hmbot : m = ⊥ := by rw [hm_def, aft3StateBotG_fst_eq_runningMax]; exact hbot
      have hα0 : α = 0 := by rw [hαdef, hmbot, WithBot.realSub_bot_left, WithBot.realExp2_bot]; rfl
      rw [hα0, mul_zero, mul_zero]
  rw [Tile.bop_data]
  simp only [Broadcast.leftIndex, Broadcast.rightIndex]
  erw [hsum]
  rw [Tile.bop_data]
  simp only [Broadcast.leftIndex, Broadcast.rightIndex, NumericDType.add, NumericDType.mul,
    hltile, halphaVal, hαsome]
  simp only [WithBot.realAdd, WithBot.realMul, Option.map₂, Option.bind, Option.map]
  refine congrArg some ?_
  rw [show (aft3StateBot1G qT kT vT ks kp (c * BN) i d).2.1 * α
        = (aft3StateBotG qT kT vT ks kp (c * BN) i d).2.1 * α from hl1]
  rw [hMr, WithBot.unbotD_coe]

set_option maxHeartbeats 1600000 in
/-- **General `acc' = aft3StateBotG((c+1)·BN).2.2` (case 3, per channel `d`).** -/
theorem aft3_acc_reg_eqG (s0 : BlockState) (Q K V : RegionName)
    (base BM ND NC sqm sqk skn skk svk svn : Nat) (sc : ℝ) (BN c : Nat) (hBN : 0 < BN) (hNC : 0 < NC)
    (hc1 : (c + 1) * BN ≤ NC) (i : Fin BM) (d : Fin ND)
    (qtile : Tile .real [BM, ND]) (ktile : Tile .real [ND, BN]) (vtile : Tile .real [BN, ND])
    (qkT pT : Tile .real [BM, BN]) (acctile acc1T : Tile .real [BM, ND])
    (mtile mijT alphaT : Tile .real [BM])
    (hq : qtile = ⟨fun idx : TileIndex [BM, ND] => some (qTile3G s0 Q base BM ND sqm sqk idx)⟩)
    (hk : ∀ idx : TileIndex [ND, BN],
        ktile.data idx = some (s0.readMem K (base + idx.1.val * skk + (c * BN + idx.2.1.val) * skn)))
    (hv : ∀ idx : TileIndex [BN, ND],
        vtile.data idx = some (s0.readMem V (base + (c * BN + idx.1.val) * svk + idx.2.1.val * svn)))
    (hqkT : qkT = Tile.bop NumericDType.real.mul Broadcast.scalarR
              (Tile.bop NumericDType.real.add (Broadcast.consSame (Broadcast.consSame Broadcast.nil))
                (⟨fun _ => some (0 : ℝ)⟩ : Tile .real [BM, BN]) (Tile.dot [] qtile ktile))
              (Tile.scalar (some sc)))
    (hacctile : acctile.data (i, d, PUnit.unit) = some
        ((aft3StateBot1G (qTile3G s0 Q base BM ND sqm sqk) (kTile3G s0 K base NC ND skn skk)
            (vTile3G s0 V base NC ND svk svn) (keyScale3G sc NC)
            (fun (i : Fin BM) (j : Fin NC) => noWindowKeep i j) (c * BN) i d).2.2))
    (hmtile : mtile.data (i, PUnit.unit)
        = aft3RunningMaxG (qTile3G s0 Q base BM ND sqm sqk) (kTile3G s0 K base NC ND skn skk)
            (vTile3G s0 V base NC ND svk svn) (keyScale3G sc NC)
            (fun (i : Fin BM) (j : Fin NC) => noWindowKeep i j) (c * BN) i d)
    (hmij : mijT.data (i, PUnit.unit)
        = aft3RunningMaxG (qTile3G s0 Q base BM ND sqm sqk) (kTile3G s0 K base NC ND skn skk)
            (vTile3G s0 V base NC ND svk svn) (keyScale3G sc NC)
            (fun (i : Fin BM) (j : Fin NC) => noWindowKeep i j) ((c + 1) * BN) i d)
    (halpha : alphaT = Tile.uop WithBot.realExp2
        (Tile.bop NumericDType.real.sub (Broadcast.consSame Broadcast.nil) mtile mijT))
    (hacc1 : acc1T = Tile.bop NumericDType.real.mul (Broadcast.consSame (Broadcast.consR Broadcast.nil)) acctile (Tile.expandDim ⟨1, by simp⟩ alphaT))
    (hpT : pT = Tile.uop WithBot.realExp2 (Tile.bop NumericDType.real.sub
        (Broadcast.consSame (Broadcast.consR Broadcast.nil)) qkT (Tile.expandDim ⟨1, by simp⟩ mijT))) :
    (Tile.bop NumericDType.real.add (Broadcast.consSame (Broadcast.consSame Broadcast.nil))
        acc1T (Tile.dot [] pT vtile)).data (i, d, PUnit.unit)
      = some ((aft3StateBotG (qTile3G s0 Q base BM ND sqm sqk) (kTile3G s0 K base NC ND skn skk)
          (vTile3G s0 V base NC ND svk svn) (keyScale3G sc NC)
          (fun (i : Fin BM) (j : Fin NC) => noWindowKeep i j) ((c + 1) * BN) i d).2.2) := by
  set qT := qTile3G s0 Q base BM ND sqm sqk
  set kT := kTile3G s0 K base NC ND skn skk
  set vT := vTile3G s0 V base NC ND svk svn
  set ks := keyScale3G sc NC
  set kp : Fin BM → Fin NC → Prop := fun i j => noWindowKeep i j
  set m := (aft3StateBotG qT kT vT ks kp (c * BN) i d).1 with hm_def
  set Mc := aft3RunningMaxG qT kT vT ks kp (c * BN) i d with hMc
  set Mc1 := aft3RunningMaxG qT kT vT ks kp ((c + 1) * BN) i d with hMc1
  have hmMc : m = Mc := by rw [hm_def, hMc, aft3StateBotG_fst_eq_runningMax]
  have hne : Mc1 ≠ ⊥ := by
    rw [hMc1]
    exact aft3RunningMaxG_noWindow_ne_bot qT kT vT ks ((c + 1) * BN) (by positivity) hNC i d
  obtain ⟨Mr, hMr⟩ : ∃ Mr : ℝ, Mc1 = (Mr : WithBot ℝ) := by
    cases hh : Mc1 with
    | bot => exact absurd hh hne
    | coe x => exact ⟨x, rfl⟩
  have hMsucc : Mc1 = m ⊔ ((aft3BlockG qT kT vT ks kp BN c i d).map
        (fun p => ((p.1 : ℝ) : WithBot ℝ))).foldr (· ⊔ ·) ⊥ := by
    have h1 : Mc1 = (aft3StateBotG qT kT vT ks kp ((c + 1) * BN) i d).1 := by
      rw [hMc1, aft3StateBotG_fst_eq_runningMax]
    rw [h1, aft3StateBotG_succ, aft3OsStepBot_block_fst m
        ((aft3StateBotG qT kT vT ks kp (c * BN) i d).2.1)
        ((aft3StateBotG qT kT vT ks kp (c * BN) i d).2.2)]
  have halphaVal : alphaT.data (i, PUnit.unit) = WithBot.realExp2 (WithBot.realSub m Mc1) := by
    rw [halpha]; show WithBot.realExp2 _ = _
    simp only [Tile.bop_data, Broadcast.leftIndex, Broadcast.rightIndex, hmtile, hmij,
      NumericDType.sub, ← hMc, ← hMc1, hmMc]
  have hdot := aft3_acc_dot_blockG s0 Q K V base BM ND NC sqm sqk skn skk svk svn sc BN c hBN hc1 i d
    qtile ktile vtile mijT pT qkT hq hk hv hqkT Mr (by rw [hmij]; exact hMr) hpT
  have hblockEq := aft3OsStepBot_block_eq m
    ((aft3StateBotG qT kT vT ks kp (c * BN) i d).2.1)
    ((aft3StateBotG qT kT vT ks kp (c * BN) i d).2.2)
    ((aft3KeysUptoG qT kT vT ks kp (c * BN) i d).map (fun p => pow2 p.1 * p.2)).sum
    ((aft3KeysUptoG qT kT vT ks kp (c * BN) i d).map (fun p => pow2 p.1)).sum
    (aft3BlockG qT kT vT ks kp BN c i d)
    (by rw [aft3_denomG_anchor, zero_add, hm_def])
    (by rw [aft3_accG_anchor, zero_add, hm_def])
    (fun hbot => aft3KeysUptoG_sum_zero_of_bot qT kT vT ks kp (c * BN) i d
      (by rw [← aft3StateBotG_fst_eq_runningMax, ← hm_def]; exact hbot) _)
    (fun hbot => aft3KeysUptoG_sum_zero_of_bot qT kT vT ks kp (c * BN) i d
      (by rw [← aft3StateBotG_fst_eq_runningMax, ← hm_def]; exact hbot) _)
  rw [← hMsucc] at hblockEq
  rw [show (aft3StateBotG qT kT vT ks kp ((c + 1) * BN) i d).2.2
        = (Mc1, _,
            (aft3StateBotG qT kT vT ks kp (c * BN) i d).2.2
              * (WithBot.realExp2 (WithBot.realSub m Mc1)).unbotD 0
              + ((aft3BlockG qT kT vT ks kp BN c i d).map (fun p => pow2 (p.1 - Mc1.unbotD 0) * p.2)).sum).2.2
        from by rw [aft3StateBotG_succ]; rw [← hblockEq]]
  set α : ℝ := (WithBot.realExp2 (WithBot.realSub m Mc1)).unbotD 0 with hαdef
  have hαsome : WithBot.realExp2 (WithBot.realSub m Mc1) = some α := by
    rw [hαdef]; cases WithBot.realSub m Mc1 <;> rfl
  have hacc1cancel : (aft3StateBot1G qT kT vT ks kp (c * BN) i d).2.2 * α
      = (aft3StateBotG qT kT vT ks kp (c * BN) i d).2.2 * α := by
    rcases aft3StateBot1G_eq_or_bot qT kT vT ks kp (c * BN) i d with heq | hbot
    · rw [heq]
    · have hmbot : m = ⊥ := by rw [hm_def, aft3StateBotG_fst_eq_runningMax]; exact hbot
      have hα0 : α = 0 := by rw [hαdef, hmbot, WithBot.realSub_bot_left, WithBot.realExp2_bot]; rfl
      rw [hα0, mul_zero, mul_zero]
  rw [Tile.bop_data]
  simp only [Broadcast.leftIndex, Broadcast.rightIndex]
  erw [hdot]
  rw [hacc1, Tile.bop_data]
  simp only [Broadcast.leftIndex, Broadcast.rightIndex, Tile.expandDim_data,
    TileShape.dropInsertedIndex, NumericDType.add, NumericDType.mul, hacctile, halphaVal, hαsome]
  simp only [WithBot.realAdd, WithBot.realMul, Option.map₂, Option.bind, Option.map]
  refine congrArg some ?_
  rw [show (aft3StateBot1G qT kT vT ks kp (c * BN) i d).2.2 * α
        = (aft3StateBotG qT kT vT ks kp (c * BN) i d).2.2 * α from hacc1cancel]
  rw [hMr, WithBot.unbotD_coe]

/-! ### General masked (cases 1/2) register bridges -/

/-- **General masked `q·k` score cell (cases 1/2).** -/
theorem aft3_score_cell_maskedG (s0 : BlockState) (Q K : RegionName)
    (base BM ND NC sqm sqk skn skk : Nat) (sc : ℝ) (BN c : Nat)
    (i : Fin BM) (jL : Fin BN) (hjL : c * BN + jL.val < NC) (mc : Bool)
    (qtile : Tile .real [BM, ND]) (ktile : Tile .real [ND, BN])
    (hq : qtile = ⟨fun idx : TileIndex [BM, ND] => some (qTile3G s0 Q base BM ND sqm sqk idx)⟩)
    (hk : ∀ idx : TileIndex [ND, BN],
        ktile.data idx = some (s0.readMem K (base + idx.1.val * skk + (c * BN + idx.2.1.val) * skn))) :
    (if mc then
        (Tile.bop NumericDType.real.mul Broadcast.scalarR
          (Tile.bop NumericDType.real.add (Broadcast.consSame (Broadcast.consSame Broadcast.nil))
            (⟨fun _ => some (0 : ℝ)⟩ : Tile .real [BM, BN]) (Tile.dot [] qtile ktile))
          (Tile.scalar (some sc))).data (i, jL, PUnit.unit)
      else (⊥ : WithBot ℝ))
      = if mc then some (sc * Finset.univ.sum (fun e : Fin ND =>
          qTile3G s0 Q base BM ND sqm sqk (i, e, PUnit.unit)
            * kTile3G s0 K base NC ND skn skk (⟨c * BN + jL.val, hjL⟩, e, PUnit.unit)))
        else (⊥ : WithBot ℝ) := by
  match mc with
  | Bool.false => rfl
  | Bool.true => exact aft3_score_cellG s0 Q K base BM ND NC sqm sqk skn skk sc BN c i jL hjL qtile ktile hq hk

set_option maxHeartbeats 1600000 in
/-- **General masked block sup (cases 1/2).** -/
theorem aft3Block_masked_blockSupG (s0 : BlockState) (Q K V : RegionName)
    (base BM ND NC sqm sqk skn skk svk svn : Nat) (sc : ℝ) (BN c : Nat)
    (hc1 : (c + 1) * BN ≤ NC) (i : Fin BM) (d : Fin ND)
    (keep : Fin BM → Fin NC → Prop) [∀ i j, Decidable (keep i j)]
    (mc : Fin BN → Bool)
    (hmc : ∀ jL : Fin BN, mc jL = decide (keep i ⟨c * BN + jL.val, aft3_block_idx_lt BN c NC jL.val jL.isLt hc1⟩)) :
    Finset.univ.sup (fun jL : Fin BN =>
        if mc jL then
          ((sc * Finset.univ.sum (fun e : Fin ND =>
              qTile3G s0 Q base BM ND sqm sqk (i, e, PUnit.unit) *
                kTile3G s0 K base NC ND skn skk (⟨c * BN + jL.val, aft3_block_idx_lt BN c NC jL.val jL.isLt hc1⟩, e, PUnit.unit)) : ℝ) : WithBot ℝ)
        else (⊥ : WithBot ℝ))
      = ((aft3BlockG (qTile3G s0 Q base BM ND sqm sqk) (kTile3G s0 K base NC ND skn skk)
          (vTile3G s0 V base NC ND svk svn) (keyScale3G sc NC)
          keep BN c i d).map (fun p => ((p.1 : ℝ) : WithBot ℝ))).foldr (· ⊔ ·) ⊥ := by
  have hexp : (c + 1) * BN = c * BN + BN := by ring
  rw [show (fun jL : Fin BN =>
        if mc jL then
          ((sc * Finset.univ.sum (fun e : Fin ND =>
              qTile3G s0 Q base BM ND sqm sqk (i, e, PUnit.unit) *
                kTile3G s0 K base NC ND skn skk (⟨c * BN + jL.val, aft3_block_idx_lt BN c NC jL.val jL.isLt hc1⟩, e, PUnit.unit)) : ℝ) : WithBot ℝ)
        else (⊥ : WithBot ℝ))
      = (fun jL : Fin BN =>
          if keep i ⟨c * BN + jL.val, aft3_block_idx_lt BN c NC jL.val jL.isLt hc1⟩ then
            ((sc * Finset.univ.sum (fun e : Fin ND =>
                qTile3G s0 Q base BM ND sqm sqk (i, e, PUnit.unit) *
                  kTile3G s0 K base NC ND skn skk (⟨c * BN + jL.val, aft3_block_idx_lt BN c NC jL.val jL.isLt hc1⟩, e, PUnit.unit)) : ℝ) : WithBot ℝ)
          else (⊥ : WithBot ℝ)) from by
    funext jL
    rw [hmc jL]
    by_cases hk : keep i ⟨c * BN + jL.val, aft3_block_idx_lt BN c NC jL.val jL.isLt hc1⟩
    · rw [if_pos (by exact decide_eq_true hk), if_pos hk]
    · rw [if_neg (by simp [hk]), if_neg hk]]
  rw [show (aft3BlockG (qTile3G s0 Q base BM ND sqm sqk) (kTile3G s0 K base NC ND skn skk)
        (vTile3G s0 V base NC ND svk svn) (keyScale3G sc NC)
        keep BN c i d).map (fun p => ((p.1 : ℝ) : WithBot ℝ))
      = ((List.finRange NC).filterMap (fun j : Fin NC =>
          if c * BN ≤ j.val ∧ j.val < (c + 1) * BN ∧ keep i j
          then some (keyScale3G sc NC j * Finset.univ.sum (fun e : Fin ND =>
                qTile3G s0 Q base BM ND sqm sqk (i, e, PUnit.unit) * kTile3G s0 K base NC ND skn skk (j, e, PUnit.unit))) else none)).map
            (fun x => ((x : ℝ) : WithBot ℝ)) from by
    unfold aft3BlockG
    rw [List.map_filterMap, List.map_filterMap]
    apply List.filterMap_congr
    intro j _
    by_cases hj : c * BN ≤ j.val ∧ j.val < (c + 1) * BN ∧ keep i j <;> simp [hj]]
  rw [aft3_filterMap_foldr_sup NC
    (fun j => c * BN ≤ j.val ∧ j.val < (c + 1) * BN ∧ keep i j)
    (fun j => keyScale3G sc NC j * Finset.univ.sum (fun e : Fin ND =>
        qTile3G s0 Q base BM ND sqm sqk (i, e, PUnit.unit) * kTile3G s0 K base NC ND skn skk (j, e, PUnit.unit)))]
  symm
  apply le_antisymm
  · apply Finset.sup_le; intro j _
    by_cases hj : c * BN ≤ j.val ∧ j.val < (c + 1) * BN ∧ keep i j
    · rw [if_pos hj]
      have hjL : j.val - c * BN < BN := by omega
      refine le_trans ?_ (Finset.le_sup (Finset.mem_univ (⟨j.val - c * BN, hjL⟩ : Fin BN)))
      simp only
      have hfin : (⟨c * BN + (j.val - c * BN), by omega⟩ : Fin NC) = j := by
        apply Fin.ext; simp only; omega
      rw [if_pos (show keep i ⟨c * BN + (j.val - c * BN), by omega⟩ from by rw [hfin]; exact hj.2.2)]
      apply le_of_eq
      simp only [keyScale3G]
      congr 1; rw [hfin]
    · rw [if_neg hj]; exact bot_le
  · apply Finset.sup_le; intro jL _
    have hb : c * BN + jL.val < NC := aft3_block_idx_lt BN c NC jL.val jL.isLt hc1
    by_cases hkeep : keep i ⟨c * BN + jL.val, hb⟩
    · rw [if_pos hkeep]
      refine le_trans ?_ (Finset.le_sup (Finset.mem_univ (⟨c * BN + jL.val, hb⟩ : Fin NC)))
      simp only
      rw [if_pos (by have := jL.isLt; exact ⟨by omega, by omega, hkeep⟩)]
      apply le_of_eq
      simp only [keyScale3G]
    · rw [if_neg hkeep]; exact bot_le

set_option maxHeartbeats 1600000 in
/-- **General masked `m_ij = aft3RunningMaxG((c+1)·BN)` (cases 1/2).** -/
theorem aft3_mij_reg_eq_maskedG (s0 : BlockState) (Q K V : RegionName)
    (base BM ND NC sqm sqk skn skk svk svn : Nat) (sc : ℝ) (BN c : Nat) (hBN : 0 < BN)
    (hc1 : (c + 1) * BN ≤ NC) (i : Fin BM) (d : Fin ND)
    (keep : Fin BM → Fin NC → Prop) [∀ i j, Decidable (keep i j)]
    (mc : Fin BN → Bool)
    (hmc : ∀ jL : Fin BN, mc jL = decide (keep i ⟨c * BN + jL.val, aft3_block_idx_lt BN c NC jL.val jL.isLt hc1⟩))
    (qtile : Tile .real [BM, ND]) (ktile : Tile .real [ND, BN]) (mtile rmaxT : Tile .real [BM])
    (qkT : Tile .real [BM, BN])
    (hq : qtile = ⟨fun idx : TileIndex [BM, ND] => some (qTile3G s0 Q base BM ND sqm sqk idx)⟩)
    (hk : ∀ idx : TileIndex [ND, BN],
        ktile.data idx = some (s0.readMem K (base + idx.1.val * skk + (c * BN + idx.2.1.val) * skn)))
    (hqkT : ∀ jL : Fin BN, qkT.data (i, jL, PUnit.unit) =
        if mc jL then
          (Tile.bop NumericDType.real.mul Broadcast.scalarR
            (Tile.bop NumericDType.real.add (Broadcast.consSame (Broadcast.consSame Broadcast.nil))
              (⟨fun _ => some (0 : ℝ)⟩ : Tile .real [BM, BN]) (Tile.dot [] qtile ktile))
            (Tile.scalar (some sc))).data (i, jL, PUnit.unit)
        else (⊥ : WithBot ℝ))
    (hmtile : mtile.data (i, PUnit.unit)
        = aft3RunningMaxG (qTile3G s0 Q base BM ND sqm sqk) (kTile3G s0 K base NC ND skn skk)
            (vTile3G s0 V base NC ND svk svn) (keyScale3G sc NC) keep (c * BN) i d)
    (hrmax : Tile.reduceMaxDrop (aft3Ax1G BM BN) qkT = some rmaxT) :
    (Tile.select (Tile.cop ComparableDType.real.gt (Broadcast.consSame Broadcast.nil) mtile rmaxT) mtile rmaxT).data (i, PUnit.unit)
      = aft3RunningMaxG (qTile3G s0 Q base BM ND sqm sqk) (kTile3G s0 K base NC ND skn skk)
          (vTile3G s0 V base NC ND svk svn) (keyScale3G sc NC) keep ((c + 1) * BN) i d := by
  have hrmaxcell : rmaxT.data (i, PUnit.unit)
      = ((aft3BlockG (qTile3G s0 Q base BM ND sqm sqk) (kTile3G s0 K base NC ND skn skk)
          (vTile3G s0 V base NC ND svk svn) (keyScale3G sc NC) keep BN c i d).map
          (fun p => ((p.1 : ℝ) : WithBot ℝ))).foldr (· ⊔ ·) ⊥ := by
    rw [aft3_reduceMaxDrop_rowG BM BN hBN qkT rmaxT hrmax i
      (fun jL => if mc jL then
          ((sc * Finset.univ.sum (fun e : Fin ND =>
              qTile3G s0 Q base BM ND sqm sqk (i, e, PUnit.unit) *
                kTile3G s0 K base NC ND skn skk (⟨c * BN + jL.val, aft3_block_idx_lt BN c NC jL.val jL.isLt hc1⟩, e, PUnit.unit)) : ℝ) : WithBot ℝ)
          else (⊥ : WithBot ℝ))
      ?_]
    · exact aft3Block_masked_blockSupG s0 Q K V base BM ND NC sqm sqk skn skk svk svn sc BN c hc1 i d keep mc hmc
    · intro jL
      rw [hqkT jL]
      exact aft3_score_cell_maskedG s0 Q K base BM ND NC sqm sqk skn skk sc BN c i jL
        (aft3_block_idx_lt BN c NC jL.val jL.isLt hc1) (mc jL) qtile ktile hq hk
  rw [aft3RunningMaxG_succ (qTile3G s0 Q base BM ND sqm sqk) (kTile3G s0 K base NC ND skn skk)
      (vTile3G s0 V base NC ND svk svn) (keyScale3G sc NC) keep BN c i d]
  rw [Tile.select_data, Tile.cop_data]
  simp only [Broadcast.leftIndex, Broadcast.rightIndex, ComparableDType.gt, hmtile, hrmaxcell]
  set M := aft3RunningMaxG (qTile3G s0 Q base BM ND sqm sqk) (kTile3G s0 K base NC ND skn skk)
      (vTile3G s0 V base NC ND svk svn) (keyScale3G sc NC) keep (c * BN) i d
  set S := ((aft3BlockG (qTile3G s0 Q base BM ND sqm sqk) (kTile3G s0 K base NC ND skn skk)
      (vTile3G s0 V base NC ND svk svn) (keyScale3G sc NC) keep BN c i d).map
      (fun p => ((p.1 : ℝ) : WithBot ℝ))).foldr (· ⊔ ·) ⊥
  by_cases h : M ≤ S
  · rw [if_neg (by simp [not_lt.mpr h]), max_eq_right h]
  · rw [if_pos (by simpa using not_le.mp h), max_eq_left (le_of_lt (not_le.mp h))]

/-- **Seeded masked `mij` reconciliation (case 4).** Same as `aft3_mij_reg_eq_maskedG`
but the old/new running max carry the resume-seeded fold `aft3StateSeededG`. -/
theorem aft3_mij_reg_eq_seededG (s0 : BlockState) (Q K V : RegionName)
    (base BM ND NC sqm sqk skn skk svk svn : Nat) (sc : ℝ) (BN c : Nat) (hBN : 0 < BN)
    (hc1 : (c + 1) * BN ≤ NC) (i : Fin BM) (d : Fin ND)
    (keep : Fin BM → Fin NC → Prop) [∀ i j, Decidable (keep i j)]
    (seed : Fin BM → Fin ND → WithBot ℝ × ℝ × ℝ)
    (mc : Fin BN → Bool)
    (hmc : ∀ jL : Fin BN, mc jL = decide (keep i ⟨c * BN + jL.val, aft3_block_idx_lt BN c NC jL.val jL.isLt hc1⟩))
    (qtile : Tile .real [BM, ND]) (ktile : Tile .real [ND, BN]) (mtile rmaxT : Tile .real [BM])
    (qkT : Tile .real [BM, BN])
    (hq : qtile = ⟨fun idx : TileIndex [BM, ND] => some (qTile3G s0 Q base BM ND sqm sqk idx)⟩)
    (hk : ∀ idx : TileIndex [ND, BN],
        ktile.data idx = some (s0.readMem K (base + idx.1.val * skk + (c * BN + idx.2.1.val) * skn)))
    (hqkT : ∀ jL : Fin BN, qkT.data (i, jL, PUnit.unit) =
        if mc jL then
          (Tile.bop NumericDType.real.mul Broadcast.scalarR
            (Tile.bop NumericDType.real.add (Broadcast.consSame (Broadcast.consSame Broadcast.nil))
              (⟨fun _ => some (0 : ℝ)⟩ : Tile .real [BM, BN]) (Tile.dot [] qtile ktile))
            (Tile.scalar (some sc))).data (i, jL, PUnit.unit)
        else (⊥ : WithBot ℝ))
    (hmtile : mtile.data (i, PUnit.unit)
        = (aft3StateSeededG (qTile3G s0 Q base BM ND sqm sqk) (kTile3G s0 K base NC ND skn skk)
            (vTile3G s0 V base NC ND svk svn) (keyScale3G sc NC) keep seed (c * BN) i d).1)
    (hrmax : Tile.reduceMaxDrop (aft3Ax1G BM BN) qkT = some rmaxT) :
    (Tile.select (Tile.cop ComparableDType.real.gt (Broadcast.consSame Broadcast.nil) mtile rmaxT) mtile rmaxT).data (i, PUnit.unit)
      = (aft3StateSeededG (qTile3G s0 Q base BM ND sqm sqk) (kTile3G s0 K base NC ND skn skk)
          (vTile3G s0 V base NC ND svk svn) (keyScale3G sc NC) keep seed ((c + 1) * BN) i d).1 := by
  have hrmaxcell : rmaxT.data (i, PUnit.unit)
      = ((aft3BlockG (qTile3G s0 Q base BM ND sqm sqk) (kTile3G s0 K base NC ND skn skk)
          (vTile3G s0 V base NC ND svk svn) (keyScale3G sc NC) keep BN c i d).map
          (fun p => ((p.1 : ℝ) : WithBot ℝ))).foldr (· ⊔ ·) ⊥ := by
    rw [aft3_reduceMaxDrop_rowG BM BN hBN qkT rmaxT hrmax i
      (fun jL => if mc jL then
          ((sc * Finset.univ.sum (fun e : Fin ND =>
              qTile3G s0 Q base BM ND sqm sqk (i, e, PUnit.unit) *
                kTile3G s0 K base NC ND skn skk (⟨c * BN + jL.val, aft3_block_idx_lt BN c NC jL.val jL.isLt hc1⟩, e, PUnit.unit)) : ℝ) : WithBot ℝ)
          else (⊥ : WithBot ℝ))
      ?_]
    · exact aft3Block_masked_blockSupG s0 Q K V base BM ND NC sqm sqk skn skk svk svn sc BN c hc1 i d keep mc hmc
    · intro jL
      rw [hqkT jL]
      exact aft3_score_cell_maskedG s0 Q K base BM ND NC sqm sqk skn skk sc BN c i jL
        (aft3_block_idx_lt BN c NC jL.val jL.isLt hc1) (mc jL) qtile ktile hq hk
  rw [aft3StateSeededG_fst, aft3RunningMaxG_succ (qTile3G s0 Q base BM ND sqm sqk) (kTile3G s0 K base NC ND skn skk)
      (vTile3G s0 V base NC ND svk svn) (keyScale3G sc NC) keep BN c i d]
  rw [Tile.select_data, Tile.cop_data]
  simp only [Broadcast.leftIndex, Broadcast.rightIndex, ComparableDType.gt, hmtile, hrmaxcell,
    aft3StateSeededG_fst]
  rw [← sup_assoc]
  set M := (seed i d).1 ⊔ aft3RunningMaxG (qTile3G s0 Q base BM ND sqm sqk) (kTile3G s0 K base NC ND skn skk)
      (vTile3G s0 V base NC ND svk svn) (keyScale3G sc NC) keep (c * BN) i d with hM
  set S := ((aft3BlockG (qTile3G s0 Q base BM ND sqm sqk) (kTile3G s0 K base NC ND skn skk)
      (vTile3G s0 V base NC ND svk svn) (keyScale3G sc NC) keep BN c i d).map
      (fun p => ((p.1 : ℝ) : WithBot ℝ))).foldr (· ⊔ ·) ⊥ with hS
  by_cases h : M ≤ S
  · rw [if_neg (by simp [not_lt.mpr h]), max_eq_right h]
  · rw [if_pos (by simpa using not_le.mp h), max_eq_left (le_of_lt (not_le.mp h))]

/-- **General masked `pmT` cell (cases 1/2).** -/
theorem aft3_pmT_cell_maskedG (s0 : BlockState) (Q K : RegionName)
    (base BM ND NC sqm sqk skn skk : Nat) (sc : ℝ) (BN c : Nat)
    (i : Fin BM) (jL : Fin BN) (hjL : c * BN + jL.val < NC) (mcj : Bool)
    (qtile : Tile .real [BM, ND]) (ktile : Tile .real [ND, BN]) (mijT : Tile .real [BM]) (Mc1 : WithBot ℝ)
    (qkT pT : Tile .real [BM, BN])
    (hq : qtile = ⟨fun idx : TileIndex [BM, ND] => some (qTile3G s0 Q base BM ND sqm sqk idx)⟩)
    (hk : ∀ idx : TileIndex [ND, BN],
        ktile.data idx = some (s0.readMem K (base + idx.1.val * skk + (c * BN + idx.2.1.val) * skn)))
    (hqkTcell : qkT.data (i, jL, PUnit.unit)
        = if mcj then
            (Tile.bop NumericDType.real.mul Broadcast.scalarR
              (Tile.bop NumericDType.real.add (Broadcast.consSame (Broadcast.consSame Broadcast.nil))
                (⟨fun _ => some (0 : ℝ)⟩ : Tile .real [BM, BN]) (Tile.dot [] qtile ktile))
              (Tile.scalar (some sc))).data (i, jL, PUnit.unit)
          else (⊥ : WithBot ℝ))
    (hmij : mijT.data (i, PUnit.unit) = Mc1)
    (hkeptbot : mcj = Bool.true → Mc1 ≠ ⊥)
    (hpT : pT = Tile.uop WithBot.realExp2 (Tile.bop NumericDType.real.sub
        (Broadcast.consSame (Broadcast.consR Broadcast.nil)) qkT (Tile.expandDim ⟨1, by simp⟩ mijT))) :
    (if mcj then pT.data (i, jL, PUnit.unit) else (some (0.0 : ℝ) : WithBot ℝ))
      = some (if mcj then
          pow2 ((sc * Finset.univ.sum (fun e : Fin ND =>
            qTile3G s0 Q base BM ND sqm sqk (i, e, PUnit.unit) *
              kTile3G s0 K base NC ND skn skk (⟨c * BN + jL.val, hjL⟩, e, PUnit.unit))) - Mc1.unbotD 0)
          else 0) := by
  match mcj with
  | Bool.false => show (some (0.0 : ℝ) : WithBot ℝ) = some (0 : ℝ); norm_num
  | Bool.true =>
       obtain ⟨Mr, hMr⟩ : ∃ Mr : ℝ, Mc1 = (Mr : WithBot ℝ) := by
         cases hh : Mc1 with
         | coe x => exact ⟨x, rfl⟩
         | bot => exact absurd hh (hkeptbot rfl)
       show pT.data (i, jL, PUnit.unit) = some (pow2 _ )
       rw [hpT]
       show WithBot.realExp2 _ = _
       simp only [Tile.bop_data, Broadcast.leftIndex, Broadcast.rightIndex, Tile.expandDim_data,
         TileShape.dropInsertedIndex, NumericDType.sub, hmij, hMr, WithBot.unbotD_coe]
       rw [show qkT.data (i, jL, PUnit.unit) =
             (Tile.bop NumericDType.real.mul Broadcast.scalarR
              (Tile.bop NumericDType.real.add (Broadcast.consSame (Broadcast.consSame Broadcast.nil))
                (⟨fun _ => some (0 : ℝ)⟩ : Tile .real [BM, BN]) (Tile.dot [] qtile ktile))
              (Tile.scalar (some sc))).data (i, jL, PUnit.unit) from hqkTcell]
       rw [aft3_score_cellG s0 Q K base BM ND NC sqm sqk skn skk sc BN c i jL hjL qtile ktile hq hk]
       simp only [WithBot.realSub, Option.map₂, Option.bind, Option.map, WithBot.realExp2_some]
       refine congrArg some ?_; simp only [pow2]; ring_nf

/-- A kept lane in block `c` forces the running max over `[0,(c+1)·BN)` to be `≠ ⊥`. -/
theorem aft3_kept_lane_ne_botG (s0 : BlockState) (Q K V : RegionName)
    (base BM ND NC sqm sqk skn skk svk svn : Nat) (sc : ℝ) (BN c : Nat)
    (hc1 : (c + 1) * BN ≤ NC) (i : Fin BM) (d : Fin ND)
    (keep : Fin BM → Fin NC → Prop) [∀ i j, Decidable (keep i j)]
    (jL : Fin BN) (hkp : keep i ⟨c * BN + jL.val, aft3_block_idx_lt BN c NC jL.val jL.isLt hc1⟩) :
    aft3RunningMaxG (qTile3G s0 Q base BM ND sqm sqk) (kTile3G s0 K base NC ND skn skk)
        (vTile3G s0 V base NC ND svk svn) (keyScale3G sc NC) keep ((c + 1) * BN) i d ≠ ⊥ := by
  have hb : c * BN + jL.val < NC := aft3_block_idx_lt BN c NC jL.val jL.isLt hc1
  unfold aft3RunningMaxG aft3KeysUptoG
  intro hbot
  set sc' := keyScale3G sc NC (⟨c * BN + jL.val, hb⟩ : Fin NC) *
      Finset.univ.sum (fun e : Fin ND => qTile3G s0 Q base BM ND sqm sqk (i, e, PUnit.unit) *
        kTile3G s0 K base NC ND skn skk (⟨c * BN + jL.val, hb⟩, e, PUnit.unit)) with hsc'
  have hmem : ((sc' : ℝ) : WithBot ℝ) ∈
      ((List.finRange NC).filterMap (fun j : Fin NC =>
        if j.val < (c + 1) * BN ∧ keep i j then
          some (keyScale3G sc NC j * Finset.univ.sum (fun e : Fin ND =>
                  qTile3G s0 Q base BM ND sqm sqk (i, e, PUnit.unit) * kTile3G s0 K base NC ND skn skk (j, e, PUnit.unit)),
                vTile3G s0 V base NC ND svk svn (j, d, PUnit.unit))
        else none)).map (fun p => ((p.1 : ℝ) : WithBot ℝ)) := by
    rw [List.mem_map]
    refine ⟨(sc', vTile3G s0 V base NC ND svk svn (⟨c * BN + jL.val, hb⟩, d, PUnit.unit)), ?_, rfl⟩
    rw [List.mem_filterMap]
    refine ⟨⟨c * BN + jL.val, hb⟩, List.mem_finRange _, ?_⟩
    have hlt : (⟨c * BN + jL.val, hb⟩ : Fin NC).val < (c + 1) * BN := by
      show c * BN + jL.val < (c + 1) * BN
      have h1 := jL.isLt
      have h2 : (c + 1) * BN = c * BN + BN := by ring
      omega
    rw [if_pos ⟨hlt, hkp⟩]
  have hle := aft3_mem_le_foldr_sup _ _ hmem
  exact absurd (le_bot_iff.mp (hbot ▸ hle)) WithBot.coe_ne_bot

set_option maxHeartbeats 1600000 in
/-- **General masked `Σ_jL pm[i,jL] = aft3BlockG` pow2-score sum (cases 1/2).** -/
theorem aft3_nume_row_sum_maskedG (s0 : BlockState) (Q K V : RegionName)
    (base BM ND NC sqm sqk skn skk svk svn : Nat) (sc : ℝ) (BN c : Nat) (hBN : 0 < BN)
    (hc1 : (c + 1) * BN ≤ NC) (i : Fin BM) (d : Fin ND)
    (keep : Fin BM → Fin NC → Prop) [∀ i j, Decidable (keep i j)]
    (mc : Fin BN → Bool)
    (hmc : ∀ jL : Fin BN, mc jL = decide (keep i ⟨c * BN + jL.val, aft3_block_idx_lt BN c NC jL.val jL.isLt hc1⟩))
    (qtile : Tile .real [BM, ND]) (ktile : Tile .real [ND, BN]) (mijT : Tile .real [BM]) (pT pmT : Tile .real [BM, BN])
    (qkT : Tile .real [BM, BN])
    (hq : qtile = ⟨fun idx : TileIndex [BM, ND] => some (qTile3G s0 Q base BM ND sqm sqk idx)⟩)
    (hk : ∀ idx : TileIndex [ND, BN],
        ktile.data idx = some (s0.readMem K (base + idx.1.val * skk + (c * BN + idx.2.1.val) * skn)))
    (hqkT : ∀ jL : Fin BN, qkT.data (i, jL, PUnit.unit) =
        if mc jL then
          (Tile.bop NumericDType.real.mul Broadcast.scalarR
            (Tile.bop NumericDType.real.add (Broadcast.consSame (Broadcast.consSame Broadcast.nil))
              (⟨fun _ => some (0 : ℝ)⟩ : Tile .real [BM, BN]) (Tile.dot [] qtile ktile))
            (Tile.scalar (some sc))).data (i, jL, PUnit.unit)
        else (⊥ : WithBot ℝ))
    (hmij : mijT.data (i, PUnit.unit)
        = aft3RunningMaxG (qTile3G s0 Q base BM ND sqm sqk) (kTile3G s0 K base NC ND skn skk)
            (vTile3G s0 V base NC ND svk svn) (keyScale3G sc NC) keep ((c + 1) * BN) i d)
    (hpT : pT = Tile.uop WithBot.realExp2 (Tile.bop NumericDType.real.sub
        (Broadcast.consSame (Broadcast.consR Broadcast.nil)) qkT (Tile.expandDim ⟨1, by simp⟩ mijT)))
    (hpmT : ∀ jL : Fin BN, pmT.data (i, jL, PUnit.unit) =
        if mc jL then pT.data (i, jL, PUnit.unit) else (some (0.0 : ℝ) : WithBot ℝ)) :
    (Tile.reduceSumDrop (aft3Ax1G BM BN) pmT).data (i, PUnit.unit)
      = some ((aft3BlockG (qTile3G s0 Q base BM ND sqm sqk) (kTile3G s0 K base NC ND skn skk)
          (vTile3G s0 V base NC ND svk svn) (keyScale3G sc NC) keep BN c i d).map (fun p =>
            pow2 (p.1 - (aft3RunningMaxG (qTile3G s0 Q base BM ND sqm sqk) (kTile3G s0 K base NC ND skn skk)
              (vTile3G s0 V base NC ND svk svn) (keyScale3G sc NC) keep ((c + 1) * BN) i d).unbotD 0))).sum := by
  set Mc1 := aft3RunningMaxG (qTile3G s0 Q base BM ND sqm sqk) (kTile3G s0 K base NC ND skn skk)
      (vTile3G s0 V base NC ND svk svn) (keyScale3G sc NC) keep ((c + 1) * BN) i d with hMc1
  rw [Tile.reduceSumDrop_data]
  have hcell : ∀ jL : Fin BN,
      pmT.data (TileShape.insertAxisIndex [BM, BN] (⟨1, by simp⟩ : Fin [BM, BN].length) (i, PUnit.unit) jL)
        = some (if keep i ⟨c * BN + jL.val, aft3_block_idx_lt BN c NC jL.val jL.isLt hc1⟩ then
            pow2 ((sc * Finset.univ.sum (fun e : Fin ND =>
              qTile3G s0 Q base BM ND sqm sqk (i, e, PUnit.unit) *
                kTile3G s0 K base NC ND skn skk (⟨c * BN + jL.val, aft3_block_idx_lt BN c NC jL.val jL.isLt hc1⟩, e, PUnit.unit))) - Mc1.unbotD 0)
            else 0) := by
    intro jL
    rw [show (TileShape.insertAxisIndex [BM, BN] (⟨1, by simp⟩ : Fin [BM, BN].length) (i, PUnit.unit) jL) = (i, jL, PUnit.unit) from rfl]
    rw [hpmT jL]
    rw [aft3_pmT_cell_maskedG s0 Q K base BM ND NC sqm sqk skn skk sc BN c i jL
      (aft3_block_idx_lt BN c NC jL.val jL.isLt hc1) (mc jL) qtile ktile mijT Mc1 qkT pT hq hk (hqkT jL) (by rw [hmij]) ?_ hpT]
    · rw [hmc jL]
      by_cases hkp : keep i ⟨c * BN + jL.val, aft3_block_idx_lt BN c NC jL.val jL.isLt hc1⟩
      · rw [if_pos hkp, if_pos (decide_eq_true hkp)]
      · rw [if_neg hkp, if_neg (by simp [hkp])]
    · intro hmcj
      exact aft3_kept_lane_ne_botG s0 Q K V base BM ND NC sqm sqk skn skk svk svn sc BN c hc1 i d keep jL
        (by have := (hmc jL).symm.trans hmcj; exact of_decide_eq_true this)
  simp only [hcell]
  rw [WithBot.sum_someTerm_eq_some]
  refine congrArg some ?_
  rw [aft3BlockG_map_sum (qTile3G s0 Q base BM ND sqm sqk) (kTile3G s0 K base NC ND skn skk)
      (vTile3G s0 V base NC ND svk svn) (keyScale3G sc NC) keep BN c i d hc1 (fun p => pow2 (p.1 - Mc1.unbotD 0))]
  refine Finset.sum_congr rfl (fun jL _ => ?_)
  by_cases hkp : keep i ⟨c * BN + jL.val, aft3_block_idx_lt BN c NC jL.val jL.isLt hc1⟩
  · rw [if_pos hkp, if_pos hkp]; simp only [keyScale3G]
  · rw [if_neg hkp, if_neg hkp]

set_option maxHeartbeats 1600000 in
/-- **General masked `Σ_jL pm[i,jL]·v[jL,d] = aft3BlockG` pow2-score·v sum (cases 1/2).** -/
theorem aft3_acc_dot_block_maskedG (s0 : BlockState) (Q K V : RegionName)
    (base BM ND NC sqm sqk skn skk svk svn : Nat) (sc : ℝ) (BN c : Nat) (hBN : 0 < BN)
    (hc1 : (c + 1) * BN ≤ NC) (i : Fin BM) (d : Fin ND)
    (keep : Fin BM → Fin NC → Prop) [∀ i j, Decidable (keep i j)]
    (mc : Fin BN → Bool)
    (hmc : ∀ jL : Fin BN, mc jL = decide (keep i ⟨c * BN + jL.val, aft3_block_idx_lt BN c NC jL.val jL.isLt hc1⟩))
    (qtile : Tile .real [BM, ND]) (ktile : Tile .real [ND, BN]) (vtile : Tile .real [BN, ND])
    (mijT : Tile .real [BM]) (pT pmT : Tile .real [BM, BN]) (qkT : Tile .real [BM, BN])
    (hq : qtile = ⟨fun idx : TileIndex [BM, ND] => some (qTile3G s0 Q base BM ND sqm sqk idx)⟩)
    (hk : ∀ idx : TileIndex [ND, BN],
        ktile.data idx = some (s0.readMem K (base + idx.1.val * skk + (c * BN + idx.2.1.val) * skn)))
    (hv : ∀ idx : TileIndex [BN, ND],
        vtile.data idx = some (s0.readMem V (base + (c * BN + idx.1.val) * svk + idx.2.1.val * svn)))
    (hqkT : ∀ jL : Fin BN, qkT.data (i, jL, PUnit.unit) =
        if mc jL then
          (Tile.bop NumericDType.real.mul Broadcast.scalarR
            (Tile.bop NumericDType.real.add (Broadcast.consSame (Broadcast.consSame Broadcast.nil))
              (⟨fun _ => some (0 : ℝ)⟩ : Tile .real [BM, BN]) (Tile.dot [] qtile ktile))
            (Tile.scalar (some sc))).data (i, jL, PUnit.unit)
        else (⊥ : WithBot ℝ))
    (hmij : mijT.data (i, PUnit.unit)
        = aft3RunningMaxG (qTile3G s0 Q base BM ND sqm sqk) (kTile3G s0 K base NC ND skn skk)
            (vTile3G s0 V base NC ND svk svn) (keyScale3G sc NC) keep ((c + 1) * BN) i d)
    (hpT : pT = Tile.uop WithBot.realExp2 (Tile.bop NumericDType.real.sub
        (Broadcast.consSame (Broadcast.consR Broadcast.nil)) qkT (Tile.expandDim ⟨1, by simp⟩ mijT)))
    (hpmT : ∀ jL : Fin BN, pmT.data (i, jL, PUnit.unit) =
        if mc jL then pT.data (i, jL, PUnit.unit) else (some (0.0 : ℝ) : WithBot ℝ)) :
    (Tile.dot [] pmT vtile).data (i, d, PUnit.unit)
      = some ((aft3BlockG (qTile3G s0 Q base BM ND sqm sqk) (kTile3G s0 K base NC ND skn skk)
          (vTile3G s0 V base NC ND svk svn) (keyScale3G sc NC) keep BN c i d).map (fun p =>
            pow2 (p.1 - (aft3RunningMaxG (qTile3G s0 Q base BM ND sqm sqk) (kTile3G s0 K base NC ND skn skk)
              (vTile3G s0 V base NC ND svk svn) (keyScale3G sc NC) keep ((c + 1) * BN) i d).unbotD 0) * p.2)).sum := by
  set Mc1 := aft3RunningMaxG (qTile3G s0 Q base BM ND sqm sqk) (kTile3G s0 K base NC ND skn skk)
      (vTile3G s0 V base NC ND svk svn) (keyScale3G sc NC) keep ((c + 1) * BN) i d with hMc1
  rw [Tile.dot_nil_data]
  have hcell : ∀ jL : Fin BN,
      Option.map₂ (· * ·) (pmT.data (i, jL, PUnit.unit)) (vtile.data (jL, d, PUnit.unit))
        = some (if keep i ⟨c * BN + jL.val, aft3_block_idx_lt BN c NC jL.val jL.isLt hc1⟩ then
            pow2 ((sc * Finset.univ.sum (fun e : Fin ND =>
              qTile3G s0 Q base BM ND sqm sqk (i, e, PUnit.unit) *
                kTile3G s0 K base NC ND skn skk (⟨c * BN + jL.val, aft3_block_idx_lt BN c NC jL.val jL.isLt hc1⟩, e, PUnit.unit))) - Mc1.unbotD 0)
              * vTile3G s0 V base NC ND svk svn (⟨c * BN + jL.val, aft3_block_idx_lt BN c NC jL.val jL.isLt hc1⟩, d, PUnit.unit)
            else 0) := by
    intro jL
    have hpmcell : pmT.data (i, jL, PUnit.unit)
        = some (if keep i ⟨c * BN + jL.val, aft3_block_idx_lt BN c NC jL.val jL.isLt hc1⟩ then
            pow2 ((sc * Finset.univ.sum (fun e : Fin ND =>
              qTile3G s0 Q base BM ND sqm sqk (i, e, PUnit.unit) *
                kTile3G s0 K base NC ND skn skk (⟨c * BN + jL.val, aft3_block_idx_lt BN c NC jL.val jL.isLt hc1⟩, e, PUnit.unit))) - Mc1.unbotD 0)
            else 0) := by
      rw [hpmT jL]
      rw [aft3_pmT_cell_maskedG s0 Q K base BM ND NC sqm sqk skn skk sc BN c i jL
        (aft3_block_idx_lt BN c NC jL.val jL.isLt hc1) (mc jL) qtile ktile mijT Mc1 qkT pT hq hk (hqkT jL) (by rw [hmij]) ?_ hpT]
      · rw [hmc jL]
        by_cases hkp : keep i ⟨c * BN + jL.val, aft3_block_idx_lt BN c NC jL.val jL.isLt hc1⟩
        · rw [if_pos hkp, if_pos (decide_eq_true hkp)]
        · rw [if_neg hkp, if_neg (by simp [hkp])]
      · intro hmcj
        exact aft3_kept_lane_ne_botG s0 Q K V base BM ND NC sqm sqk skn skk svk svn sc BN c hc1 i d keep jL
          (by have := (hmc jL).symm.trans hmcj; exact of_decide_eq_true this)
    rw [hpmcell, hv (jL, d, PUnit.unit)]
    rw [show s0.readMem V (base + (c * BN + jL.val) * svk + d.val * svn)
          = vTile3G s0 V base NC ND svk svn (⟨c * BN + jL.val, aft3_block_idx_lt BN c NC jL.val jL.isLt hc1⟩, d, PUnit.unit) from by
      simp only [vTile3G]]
    by_cases hkp : keep i ⟨c * BN + jL.val, aft3_block_idx_lt BN c NC jL.val jL.isLt hc1⟩
    · rw [if_pos hkp, if_pos hkp]; rfl
    · rw [if_neg hkp, if_neg hkp]
      simp only [Option.map₂, Option.bind, Option.map]; rw [zero_mul]
  rw [show (@Finset.sum (Fin BN) (WithBot ℝ) _ Finset.univ
        (fun k => Option.map₂ (· * ·) (pmT.data (i, k, PUnit.unit)) (vtile.data (k, d, PUnit.unit))))
      = @Finset.sum (Fin BN) (WithBot ℝ) _ Finset.univ (fun jL =>
          (some (if keep i ⟨c * BN + jL.val, aft3_block_idx_lt BN c NC jL.val jL.isLt hc1⟩ then
              pow2 ((sc * Finset.univ.sum (fun e : Fin ND =>
                qTile3G s0 Q base BM ND sqm sqk (i, e, PUnit.unit) *
                  kTile3G s0 K base NC ND skn skk (⟨c * BN + jL.val, aft3_block_idx_lt BN c NC jL.val jL.isLt hc1⟩, e, PUnit.unit))) - Mc1.unbotD 0)
                * vTile3G s0 V base NC ND svk svn (⟨c * BN + jL.val, aft3_block_idx_lt BN c NC jL.val jL.isLt hc1⟩, d, PUnit.unit)
              else 0) : WithBot ℝ))
      from Finset.sum_congr rfl (fun jL _ => hcell jL)]
  rw [WithBot.sum_someTerm_eq_some]
  refine congrArg some ?_
  rw [aft3BlockG_map_sum (qTile3G s0 Q base BM ND sqm sqk) (kTile3G s0 K base NC ND skn skk)
      (vTile3G s0 V base NC ND svk svn) (keyScale3G sc NC) keep BN c i d hc1 (fun p => pow2 (p.1 - Mc1.unbotD 0) * p.2)]
  refine Finset.sum_congr rfl (fun jL _ => ?_)
  by_cases hkp : keep i ⟨c * BN + jL.val, aft3_block_idx_lt BN c NC jL.val jL.isLt hc1⟩
  · rw [if_pos hkp, if_pos hkp]; simp only [keyScale3G]
  · rw [if_neg hkp, if_neg hkp]

set_option maxHeartbeats 1600000 in
/-- **Generic-normalizer denom block sum (case 4 / any seed).** Like
`aft3_nume_row_sum_maskedG` but with an arbitrary normalizer `M` (the seeded fold's
running max), with `M ≠ ⊥` on kept lanes supplied as a hypothesis. -/
theorem aft3_nume_row_sum_masked_genG (s0 : BlockState) (Q K V : RegionName)
    (base BM ND NC sqm sqk skn skk svk svn : Nat) (sc : ℝ) (BN c : Nat) (hBN : 0 < BN)
    (hc1 : (c + 1) * BN ≤ NC) (i : Fin BM) (d : Fin ND)
    (keep : Fin BM → Fin NC → Prop) [∀ i j, Decidable (keep i j)]
    (mc : Fin BN → Bool)
    (hmc : ∀ jL : Fin BN, mc jL = decide (keep i ⟨c * BN + jL.val, aft3_block_idx_lt BN c NC jL.val jL.isLt hc1⟩))
    (qtile : Tile .real [BM, ND]) (ktile : Tile .real [ND, BN]) (mijT : Tile .real [BM]) (pT pmT : Tile .real [BM, BN])
    (qkT : Tile .real [BM, BN]) (M : WithBot ℝ)
    (hq : qtile = ⟨fun idx : TileIndex [BM, ND] => some (qTile3G s0 Q base BM ND sqm sqk idx)⟩)
    (hk : ∀ idx : TileIndex [ND, BN],
        ktile.data idx = some (s0.readMem K (base + idx.1.val * skk + (c * BN + idx.2.1.val) * skn)))
    (hqkT : ∀ jL : Fin BN, qkT.data (i, jL, PUnit.unit) =
        if mc jL then
          (Tile.bop NumericDType.real.mul Broadcast.scalarR
            (Tile.bop NumericDType.real.add (Broadcast.consSame (Broadcast.consSame Broadcast.nil))
              (⟨fun _ => some (0 : ℝ)⟩ : Tile .real [BM, BN]) (Tile.dot [] qtile ktile))
            (Tile.scalar (some sc))).data (i, jL, PUnit.unit)
        else (⊥ : WithBot ℝ))
    (hmij : mijT.data (i, PUnit.unit) = M)
    (hMnebot : ∀ jL : Fin BN, mc jL = Bool.true → M ≠ ⊥)
    (hpT : pT = Tile.uop WithBot.realExp2 (Tile.bop NumericDType.real.sub
        (Broadcast.consSame (Broadcast.consR Broadcast.nil)) qkT (Tile.expandDim ⟨1, by simp⟩ mijT)))
    (hpmT : ∀ jL : Fin BN, pmT.data (i, jL, PUnit.unit) =
        if mc jL then pT.data (i, jL, PUnit.unit) else (some (0.0 : ℝ) : WithBot ℝ)) :
    (Tile.reduceSumDrop (aft3Ax1G BM BN) pmT).data (i, PUnit.unit)
      = some ((aft3BlockG (qTile3G s0 Q base BM ND sqm sqk) (kTile3G s0 K base NC ND skn skk)
          (vTile3G s0 V base NC ND svk svn) (keyScale3G sc NC) keep BN c i d).map (fun p =>
            pow2 (p.1 - M.unbotD 0))).sum := by
  rw [Tile.reduceSumDrop_data]
  have hcell : ∀ jL : Fin BN,
      pmT.data (TileShape.insertAxisIndex [BM, BN] (⟨1, by simp⟩ : Fin [BM, BN].length) (i, PUnit.unit) jL)
        = some (if keep i ⟨c * BN + jL.val, aft3_block_idx_lt BN c NC jL.val jL.isLt hc1⟩ then
            pow2 ((sc * Finset.univ.sum (fun e : Fin ND =>
              qTile3G s0 Q base BM ND sqm sqk (i, e, PUnit.unit) *
                kTile3G s0 K base NC ND skn skk (⟨c * BN + jL.val, aft3_block_idx_lt BN c NC jL.val jL.isLt hc1⟩, e, PUnit.unit))) - M.unbotD 0)
            else 0) := by
    intro jL
    rw [show (TileShape.insertAxisIndex [BM, BN] (⟨1, by simp⟩ : Fin [BM, BN].length) (i, PUnit.unit) jL) = (i, jL, PUnit.unit) from rfl]
    rw [hpmT jL]
    rw [aft3_pmT_cell_maskedG s0 Q K base BM ND NC sqm sqk skn skk sc BN c i jL
      (aft3_block_idx_lt BN c NC jL.val jL.isLt hc1) (mc jL) qtile ktile mijT M qkT pT hq hk (hqkT jL) (by rw [hmij]) ?_ hpT]
    · rw [hmc jL]
      by_cases hkp : keep i ⟨c * BN + jL.val, aft3_block_idx_lt BN c NC jL.val jL.isLt hc1⟩
      · rw [if_pos hkp, if_pos (decide_eq_true hkp)]
      · rw [if_neg hkp, if_neg (by simp [hkp])]
    · intro hmcj; exact hMnebot jL hmcj
  simp only [hcell]
  rw [WithBot.sum_someTerm_eq_some]
  refine congrArg some ?_
  rw [aft3BlockG_map_sum (qTile3G s0 Q base BM ND sqm sqk) (kTile3G s0 K base NC ND skn skk)
      (vTile3G s0 V base NC ND svk svn) (keyScale3G sc NC) keep BN c i d hc1 (fun p => pow2 (p.1 - M.unbotD 0))]
  refine Finset.sum_congr rfl (fun jL _ => ?_)
  by_cases hkp : keep i ⟨c * BN + jL.val, aft3_block_idx_lt BN c NC jL.val jL.isLt hc1⟩
  · rw [if_pos hkp, if_pos hkp]; simp only [keyScale3G]
  · rw [if_neg hkp, if_neg hkp]

set_option maxHeartbeats 1600000 in
/-- **Generic-normalizer acc block dot sum (case 4 / any seed).** Like
`aft3_acc_dot_block_maskedG` but with an arbitrary normalizer `M`. -/
theorem aft3_acc_dot_block_masked_genG (s0 : BlockState) (Q K V : RegionName)
    (base BM ND NC sqm sqk skn skk svk svn : Nat) (sc : ℝ) (BN c : Nat) (hBN : 0 < BN)
    (hc1 : (c + 1) * BN ≤ NC) (i : Fin BM) (d : Fin ND)
    (keep : Fin BM → Fin NC → Prop) [∀ i j, Decidable (keep i j)]
    (mc : Fin BN → Bool)
    (hmc : ∀ jL : Fin BN, mc jL = decide (keep i ⟨c * BN + jL.val, aft3_block_idx_lt BN c NC jL.val jL.isLt hc1⟩))
    (qtile : Tile .real [BM, ND]) (ktile : Tile .real [ND, BN]) (vtile : Tile .real [BN, ND])
    (mijT : Tile .real [BM]) (pT pmT : Tile .real [BM, BN]) (qkT : Tile .real [BM, BN]) (M : WithBot ℝ)
    (hq : qtile = ⟨fun idx : TileIndex [BM, ND] => some (qTile3G s0 Q base BM ND sqm sqk idx)⟩)
    (hk : ∀ idx : TileIndex [ND, BN],
        ktile.data idx = some (s0.readMem K (base + idx.1.val * skk + (c * BN + idx.2.1.val) * skn)))
    (hv : ∀ idx : TileIndex [BN, ND],
        vtile.data idx = some (s0.readMem V (base + (c * BN + idx.1.val) * svk + idx.2.1.val * svn)))
    (hqkT : ∀ jL : Fin BN, qkT.data (i, jL, PUnit.unit) =
        if mc jL then
          (Tile.bop NumericDType.real.mul Broadcast.scalarR
            (Tile.bop NumericDType.real.add (Broadcast.consSame (Broadcast.consSame Broadcast.nil))
              (⟨fun _ => some (0 : ℝ)⟩ : Tile .real [BM, BN]) (Tile.dot [] qtile ktile))
            (Tile.scalar (some sc))).data (i, jL, PUnit.unit)
        else (⊥ : WithBot ℝ))
    (hmij : mijT.data (i, PUnit.unit) = M)
    (hMnebot : ∀ jL : Fin BN, mc jL = Bool.true → M ≠ ⊥)
    (hpT : pT = Tile.uop WithBot.realExp2 (Tile.bop NumericDType.real.sub
        (Broadcast.consSame (Broadcast.consR Broadcast.nil)) qkT (Tile.expandDim ⟨1, by simp⟩ mijT)))
    (hpmT : ∀ jL : Fin BN, pmT.data (i, jL, PUnit.unit) =
        if mc jL then pT.data (i, jL, PUnit.unit) else (some (0.0 : ℝ) : WithBot ℝ)) :
    (Tile.dot [] pmT vtile).data (i, d, PUnit.unit)
      = some ((aft3BlockG (qTile3G s0 Q base BM ND sqm sqk) (kTile3G s0 K base NC ND skn skk)
          (vTile3G s0 V base NC ND svk svn) (keyScale3G sc NC) keep BN c i d).map (fun p =>
            pow2 (p.1 - M.unbotD 0) * p.2)).sum := by
  rw [Tile.dot_nil_data]
  have hcell : ∀ jL : Fin BN,
      Option.map₂ (· * ·) (pmT.data (i, jL, PUnit.unit)) (vtile.data (jL, d, PUnit.unit))
        = some (if keep i ⟨c * BN + jL.val, aft3_block_idx_lt BN c NC jL.val jL.isLt hc1⟩ then
            pow2 ((sc * Finset.univ.sum (fun e : Fin ND =>
              qTile3G s0 Q base BM ND sqm sqk (i, e, PUnit.unit) *
                kTile3G s0 K base NC ND skn skk (⟨c * BN + jL.val, aft3_block_idx_lt BN c NC jL.val jL.isLt hc1⟩, e, PUnit.unit))) - M.unbotD 0)
              * vTile3G s0 V base NC ND svk svn (⟨c * BN + jL.val, aft3_block_idx_lt BN c NC jL.val jL.isLt hc1⟩, d, PUnit.unit)
            else 0) := by
    intro jL
    have hpmcell : pmT.data (i, jL, PUnit.unit)
        = some (if keep i ⟨c * BN + jL.val, aft3_block_idx_lt BN c NC jL.val jL.isLt hc1⟩ then
            pow2 ((sc * Finset.univ.sum (fun e : Fin ND =>
              qTile3G s0 Q base BM ND sqm sqk (i, e, PUnit.unit) *
                kTile3G s0 K base NC ND skn skk (⟨c * BN + jL.val, aft3_block_idx_lt BN c NC jL.val jL.isLt hc1⟩, e, PUnit.unit))) - M.unbotD 0)
            else 0) := by
      rw [hpmT jL]
      rw [aft3_pmT_cell_maskedG s0 Q K base BM ND NC sqm sqk skn skk sc BN c i jL
        (aft3_block_idx_lt BN c NC jL.val jL.isLt hc1) (mc jL) qtile ktile mijT M qkT pT hq hk (hqkT jL) (by rw [hmij]) ?_ hpT]
      · rw [hmc jL]
        by_cases hkp : keep i ⟨c * BN + jL.val, aft3_block_idx_lt BN c NC jL.val jL.isLt hc1⟩
        · rw [if_pos hkp, if_pos (decide_eq_true hkp)]
        · rw [if_neg hkp, if_neg (by simp [hkp])]
      · intro hmcj; exact hMnebot jL hmcj
    rw [hpmcell, hv (jL, d, PUnit.unit)]
    rw [show s0.readMem V (base + (c * BN + jL.val) * svk + d.val * svn)
          = vTile3G s0 V base NC ND svk svn (⟨c * BN + jL.val, aft3_block_idx_lt BN c NC jL.val jL.isLt hc1⟩, d, PUnit.unit) from by
      simp only [vTile3G]]
    by_cases hkp : keep i ⟨c * BN + jL.val, aft3_block_idx_lt BN c NC jL.val jL.isLt hc1⟩
    · rw [if_pos hkp, if_pos hkp]; rfl
    · rw [if_neg hkp, if_neg hkp]
      simp only [Option.map₂, Option.bind, Option.map]; rw [zero_mul]
  rw [show (@Finset.sum (Fin BN) (WithBot ℝ) _ Finset.univ
        (fun k => Option.map₂ (· * ·) (pmT.data (i, k, PUnit.unit)) (vtile.data (k, d, PUnit.unit))))
      = @Finset.sum (Fin BN) (WithBot ℝ) _ Finset.univ (fun jL =>
          (some (if keep i ⟨c * BN + jL.val, aft3_block_idx_lt BN c NC jL.val jL.isLt hc1⟩ then
              pow2 ((sc * Finset.univ.sum (fun e : Fin ND =>
                qTile3G s0 Q base BM ND sqm sqk (i, e, PUnit.unit) *
                  kTile3G s0 K base NC ND skn skk (⟨c * BN + jL.val, aft3_block_idx_lt BN c NC jL.val jL.isLt hc1⟩, e, PUnit.unit))) - M.unbotD 0)
                * vTile3G s0 V base NC ND svk svn (⟨c * BN + jL.val, aft3_block_idx_lt BN c NC jL.val jL.isLt hc1⟩, d, PUnit.unit)
              else 0) : WithBot ℝ))
      from Finset.sum_congr rfl (fun jL _ => hcell jL)]
  rw [WithBot.sum_someTerm_eq_some]
  refine congrArg some ?_
  rw [aft3BlockG_map_sum (qTile3G s0 Q base BM ND sqm sqk) (kTile3G s0 K base NC ND skn skk)
      (vTile3G s0 V base NC ND svk svn) (keyScale3G sc NC) keep BN c i d hc1 (fun p => pow2 (p.1 - M.unbotD 0) * p.2)]
  refine Finset.sum_congr rfl (fun jL _ => ?_)
  by_cases hkp : keep i ⟨c * BN + jL.val, aft3_block_idx_lt BN c NC jL.val jL.isLt hc1⟩
  · rw [if_pos hkp, if_pos hkp]; simp only [keyScale3G]
  · rw [if_neg hkp, if_neg hkp]

set_option maxHeartbeats 1600000 in
/-- **General masked `l_i' = aft3StateBotG((c+1)·BN).2.1` (cases 1/2).** -/
theorem aft3_denom_reg_eq_maskedG (s0 : BlockState) (Q K V : RegionName)
    (base BM ND NC sqm sqk skn skk svk svn : Nat) (sc : ℝ) (BN c : Nat) (hBN : 0 < BN)
    (hc1 : (c + 1) * BN ≤ NC) (i : Fin BM) (d : Fin ND)
    (keep : Fin BM → Fin NC → Prop) [∀ i j, Decidable (keep i j)]
    (mc : Fin BN → Bool)
    (hmc : ∀ jL : Fin BN, mc jL = decide (keep i ⟨c * BN + jL.val, aft3_block_idx_lt BN c NC jL.val jL.isLt hc1⟩))
    (qtile : Tile .real [BM, ND]) (ktile : Tile .real [ND, BN]) (qkT : Tile .real [BM, BN])
    (ltile mtile mijT alphaT : Tile .real [BM]) (pT pmT : Tile .real [BM, BN])
    (hq : qtile = ⟨fun idx : TileIndex [BM, ND] => some (qTile3G s0 Q base BM ND sqm sqk idx)⟩)
    (hk : ∀ idx : TileIndex [ND, BN],
        ktile.data idx = some (s0.readMem K (base + idx.1.val * skk + (c * BN + idx.2.1.val) * skn)))
    (hqkT : ∀ jL : Fin BN, qkT.data (i, jL, PUnit.unit) =
        if mc jL then
          (Tile.bop NumericDType.real.mul Broadcast.scalarR
            (Tile.bop NumericDType.real.add (Broadcast.consSame (Broadcast.consSame Broadcast.nil))
              (⟨fun _ => some (0 : ℝ)⟩ : Tile .real [BM, BN]) (Tile.dot [] qtile ktile))
            (Tile.scalar (some sc))).data (i, jL, PUnit.unit)
        else (⊥ : WithBot ℝ))
    (hltile : ltile.data (i, PUnit.unit) = some
        ((aft3StateBotKG (qTile3G s0 Q base BM ND sqm sqk) (kTile3G s0 K base NC ND skn skk)
            (vTile3G s0 V base NC ND svk svn) (keyScale3G sc NC) keep (c * BN) i d).2.1))
    (hmtile : mtile.data (i, PUnit.unit)
        = aft3RunningMaxG (qTile3G s0 Q base BM ND sqm sqk) (kTile3G s0 K base NC ND skn skk)
            (vTile3G s0 V base NC ND svk svn) (keyScale3G sc NC) keep (c * BN) i d)
    (hmij : mijT.data (i, PUnit.unit)
        = aft3RunningMaxG (qTile3G s0 Q base BM ND sqm sqk) (kTile3G s0 K base NC ND skn skk)
            (vTile3G s0 V base NC ND svk svn) (keyScale3G sc NC) keep ((c + 1) * BN) i d)
    (halpha : alphaT = Tile.uop WithBot.realExp2
        (Tile.bop NumericDType.real.sub (Broadcast.consSame Broadcast.nil) mtile mijT))
    (hpT : pT = Tile.uop WithBot.realExp2 (Tile.bop NumericDType.real.sub
        (Broadcast.consSame (Broadcast.consR Broadcast.nil)) qkT (Tile.expandDim ⟨1, by simp⟩ mijT)))
    (hpmT : ∀ jL : Fin BN, pmT.data (i, jL, PUnit.unit) =
        if mc jL then pT.data (i, jL, PUnit.unit) else (some (0.0 : ℝ) : WithBot ℝ)) :
    (Tile.bop NumericDType.real.add (Broadcast.consSame Broadcast.nil)
        (Tile.bop NumericDType.real.mul (Broadcast.consSame Broadcast.nil) ltile alphaT)
        (Tile.reduceSumDrop (aft3Ax1G BM BN) pmT)).data (i, PUnit.unit)
      = some ((aft3StateBotG (qTile3G s0 Q base BM ND sqm sqk) (kTile3G s0 K base NC ND skn skk)
          (vTile3G s0 V base NC ND svk svn) (keyScale3G sc NC) keep ((c + 1) * BN) i d).2.1) := by
  set qT := qTile3G s0 Q base BM ND sqm sqk
  set kT := kTile3G s0 K base NC ND skn skk
  set vT := vTile3G s0 V base NC ND svk svn
  set ks := keyScale3G sc NC
  set m := (aft3StateBotG qT kT vT ks keep (c * BN) i d).1 with hm_def
  set Mc := aft3RunningMaxG qT kT vT ks keep (c * BN) i d with hMc
  set Mc1 := aft3RunningMaxG qT kT vT ks keep ((c + 1) * BN) i d with hMc1
  have hmMc : m = Mc := by rw [hm_def, hMc, aft3StateBotG_fst_eq_runningMax]
  have hMsucc : Mc1 = m ⊔ ((aft3BlockG qT kT vT ks keep BN c i d).map
        (fun p => ((p.1 : ℝ) : WithBot ℝ))).foldr (· ⊔ ·) ⊥ := by
    have h1 : Mc1 = (aft3StateBotG qT kT vT ks keep ((c + 1) * BN) i d).1 := by
      rw [hMc1, aft3StateBotG_fst_eq_runningMax]
    rw [h1, aft3StateBotG_succ, aft3OsStepBot_block_fst m
        ((aft3StateBotG qT kT vT ks keep (c * BN) i d).2.1)
        ((aft3StateBotG qT kT vT ks keep (c * BN) i d).2.2)]
  have halphaVal : alphaT.data (i, PUnit.unit) = WithBot.realExp2 (WithBot.realSub m Mc1) := by
    rw [halpha]; show WithBot.realExp2 _ = _
    simp only [Tile.bop_data, Broadcast.leftIndex, Broadcast.rightIndex, hmtile, hmij,
      NumericDType.sub, ← hMc, ← hMc1, hmMc]
  have hsum := aft3_nume_row_sum_maskedG s0 Q K V base BM ND NC sqm sqk skn skk svk svn sc BN c hBN hc1 i d
    keep mc hmc qtile ktile mijT pT pmT qkT hq hk hqkT hmij hpT hpmT
  have hblockEq := aft3OsStepBot_block_eq m
    ((aft3StateBotG qT kT vT ks keep (c * BN) i d).2.1)
    ((aft3StateBotG qT kT vT ks keep (c * BN) i d).2.2)
    ((aft3KeysUptoG qT kT vT ks keep (c * BN) i d).map (fun p => pow2 p.1 * p.2)).sum
    ((aft3KeysUptoG qT kT vT ks keep (c * BN) i d).map (fun p => pow2 p.1)).sum
    (aft3BlockG qT kT vT ks keep BN c i d)
    (by rw [aft3_denomG_anchor, zero_add, hm_def])
    (by rw [aft3_accG_anchor, zero_add, hm_def])
    (fun hbot => aft3KeysUptoG_sum_zero_of_bot qT kT vT ks keep (c * BN) i d
      (by rw [← aft3StateBotG_fst_eq_runningMax, ← hm_def]; exact hbot) _)
    (fun hbot => aft3KeysUptoG_sum_zero_of_bot qT kT vT ks keep (c * BN) i d
      (by rw [← aft3StateBotG_fst_eq_runningMax, ← hm_def]; exact hbot) _)
  rw [← hMsucc] at hblockEq
  rw [show (aft3StateBotG qT kT vT ks keep ((c + 1) * BN) i d).2.1
        = (Mc1, (aft3StateBotG qT kT vT ks keep (c * BN) i d).2.1
              * (WithBot.realExp2 (WithBot.realSub m Mc1)).unbotD 0
              + ((aft3BlockG qT kT vT ks keep BN c i d).map (fun p => pow2 (p.1 - Mc1.unbotD 0))).sum,
            _).2.1 from by
    rw [aft3StateBotG_succ]; rw [← hblockEq]]
  set α : ℝ := (WithBot.realExp2 (WithBot.realSub m Mc1)).unbotD 0 with hαdef
  have hαsome : WithBot.realExp2 (WithBot.realSub m Mc1) = some α := by
    rw [hαdef]; cases WithBot.realSub m Mc1 <;> rfl
  have hcancel := (aft3StateBotKG_cancel qT kT vT ks keep BN c hBN i d Mc1).1
  rw [Tile.bop_data]
  simp only [Broadcast.leftIndex, Broadcast.rightIndex]
  erw [hsum]
  rw [Tile.bop_data]
  simp only [Broadcast.leftIndex, Broadcast.rightIndex, NumericDType.add, NumericDType.mul,
    hltile, halphaVal, hαsome]
  simp only [WithBot.realAdd, WithBot.realMul, Option.map₂, Option.bind, Option.map]
  refine congrArg some ?_
  rw [show (aft3StateBotKG qT kT vT ks keep (c * BN) i d).2.1 * α
        = (aft3StateBotG qT kT vT ks keep (c * BN) i d).2.1 * α from hcancel]

set_option maxHeartbeats 1600000 in
/-- **Seeded masked denom reconciliation (case 4).** `l_i' = (seededfold((c+1)·BN)).2.1`. -/
theorem aft3_denom_reg_eq_seededG (s0 : BlockState) (Q K V : RegionName)
    (base BM ND NC sqm sqk skn skk svk svn : Nat) (sc : ℝ) (BN c : Nat) (hBN : 0 < BN)
    (hc1 : (c + 1) * BN ≤ NC) (i : Fin BM) (d : Fin ND)
    (keep : Fin BM → Fin NC → Prop) [∀ i j, Decidable (keep i j)]
    (seed : Fin BM → Fin ND → WithBot ℝ × ℝ × ℝ) (Lseed Tseed : ℝ)
    (hseedL : (seed i d).2.1 = ((seed i d).1.elim 0 (fun r => pow2 (-r))) * Lseed)
    (hseedT : (seed i d).2.2 = ((seed i d).1.elim 0 (fun r => pow2 (-r))) * Tseed)
    (hseedmL : (seed i d).1 = ⊥ → Lseed = 0) (hseedmT : (seed i d).1 = ⊥ → Tseed = 0)
    (mc : Fin BN → Bool)
    (hmc : ∀ jL : Fin BN, mc jL = decide (keep i ⟨c * BN + jL.val, aft3_block_idx_lt BN c NC jL.val jL.isLt hc1⟩))
    (qtile : Tile .real [BM, ND]) (ktile : Tile .real [ND, BN]) (qkT : Tile .real [BM, BN])
    (ltile mtile mijT alphaT : Tile .real [BM]) (pT pmT : Tile .real [BM, BN])
    (hq : qtile = ⟨fun idx : TileIndex [BM, ND] => some (qTile3G s0 Q base BM ND sqm sqk idx)⟩)
    (hk : ∀ idx : TileIndex [ND, BN],
        ktile.data idx = some (s0.readMem K (base + idx.1.val * skk + (c * BN + idx.2.1.val) * skn)))
    (hqkT : ∀ jL : Fin BN, qkT.data (i, jL, PUnit.unit) =
        if mc jL then
          (Tile.bop NumericDType.real.mul Broadcast.scalarR
            (Tile.bop NumericDType.real.add (Broadcast.consSame (Broadcast.consSame Broadcast.nil))
              (⟨fun _ => some (0 : ℝ)⟩ : Tile .real [BM, BN]) (Tile.dot [] qtile ktile))
            (Tile.scalar (some sc))).data (i, jL, PUnit.unit)
        else (⊥ : WithBot ℝ))
    (hltile : ltile.data (i, PUnit.unit) = some
        ((aft3StateSeededG (qTile3G s0 Q base BM ND sqm sqk) (kTile3G s0 K base NC ND skn skk)
            (vTile3G s0 V base NC ND svk svn) (keyScale3G sc NC) keep seed (c * BN) i d).2.1))
    (hmtile : mtile.data (i, PUnit.unit)
        = (aft3StateSeededG (qTile3G s0 Q base BM ND sqm sqk) (kTile3G s0 K base NC ND skn skk)
            (vTile3G s0 V base NC ND svk svn) (keyScale3G sc NC) keep seed (c * BN) i d).1)
    (hmij : mijT.data (i, PUnit.unit)
        = (aft3StateSeededG (qTile3G s0 Q base BM ND sqm sqk) (kTile3G s0 K base NC ND skn skk)
            (vTile3G s0 V base NC ND svk svn) (keyScale3G sc NC) keep seed ((c + 1) * BN) i d).1)
    (halpha : alphaT = Tile.uop WithBot.realExp2
        (Tile.bop NumericDType.real.sub (Broadcast.consSame Broadcast.nil) mtile mijT))
    (hpT : pT = Tile.uop WithBot.realExp2 (Tile.bop NumericDType.real.sub
        (Broadcast.consSame (Broadcast.consR Broadcast.nil)) qkT (Tile.expandDim ⟨1, by simp⟩ mijT)))
    (hpmT : ∀ jL : Fin BN, pmT.data (i, jL, PUnit.unit) =
        if mc jL then pT.data (i, jL, PUnit.unit) else (some (0.0 : ℝ) : WithBot ℝ)) :
    (Tile.bop NumericDType.real.add (Broadcast.consSame Broadcast.nil)
        (Tile.bop NumericDType.real.mul (Broadcast.consSame Broadcast.nil) ltile alphaT)
        (Tile.reduceSumDrop (aft3Ax1G BM BN) pmT)).data (i, PUnit.unit)
      = some ((aft3StateSeededG (qTile3G s0 Q base BM ND sqm sqk) (kTile3G s0 K base NC ND skn skk)
          (vTile3G s0 V base NC ND svk svn) (keyScale3G sc NC) keep seed ((c + 1) * BN) i d).2.1) := by
  set qT := qTile3G s0 Q base BM ND sqm sqk
  set kT := kTile3G s0 K base NC ND skn skk
  set vT := vTile3G s0 V base NC ND svk svn
  set ks := keyScale3G sc NC
  set m := (aft3StateSeededG qT kT vT ks keep seed (c * BN) i d).1 with hm_def
  set Mc1 := (aft3StateSeededG qT kT vT ks keep seed ((c + 1) * BN) i d).1 with hMc1
  have hMsucc : Mc1 = m ⊔ ((aft3BlockG qT kT vT ks keep BN c i d).map
        (fun p => ((p.1 : ℝ) : WithBot ℝ))).foldr (· ⊔ ·) ⊥ := by
    rw [hMc1, aft3StateSeededG_succ, aft3OsStepBot_block_fst m
        ((aft3StateSeededG qT kT vT ks keep seed (c * BN) i d).2.1)
        ((aft3StateSeededG qT kT vT ks keep seed (c * BN) i d).2.2)]
  have hMc1bot : ∀ jL : Fin BN, mc jL = Bool.true → Mc1 ≠ ⊥ := by
    intro jL hmcj
    have hkp : keep i ⟨c * BN + jL.val, aft3_block_idx_lt BN c NC jL.val jL.isLt hc1⟩ :=
      of_decide_eq_true ((hmc jL).symm.trans hmcj)
    have hne := aft3_kept_lane_ne_botG s0 Q K V base BM ND NC sqm sqk skn skk svk svn sc BN c hc1 i d keep jL hkp
    intro hMbot
    rw [hMc1, aft3StateSeededG_fst] at hMbot
    exact hne (le_bot_iff.mp (le_sup_right.trans (le_of_eq hMbot)))
  have halphaVal : alphaT.data (i, PUnit.unit) = WithBot.realExp2 (WithBot.realSub m Mc1) := by
    rw [halpha]; show WithBot.realExp2 _ = _
    simp only [Tile.bop_data, Broadcast.leftIndex, Broadcast.rightIndex, hmtile, hmij,
      NumericDType.sub]
  have hsum := aft3_nume_row_sum_masked_genG s0 Q K V base BM ND NC sqm sqk skn skk svk svn sc BN c hBN hc1 i d
    keep mc hmc qtile ktile mijT pT pmT qkT Mc1 hq hk hqkT hmij hMc1bot hpT hpmT
  have hcons := aft3StateSeededG_consistent qT kT vT ks keep seed Lseed Tseed (c * BN) i d
    hseedL hseedT hseedmL hseedmT
  have hblockEq := aft3OsStepBot_block_eq m
    ((aft3StateSeededG qT kT vT ks keep seed (c * BN) i d).2.1)
    ((aft3StateSeededG qT kT vT ks keep seed (c * BN) i d).2.2)
    (Tseed + ((aft3KeysUptoG qT kT vT ks keep (c * BN) i d).map (fun p => pow2 p.1 * p.2)).sum)
    (Lseed + ((aft3KeysUptoG qT kT vT ks keep (c * BN) i d).map (fun p => pow2 p.1)).sum)
    (aft3BlockG qT kT vT ks keep BN c i d)
    hcons.1 hcons.2
    (fun hbot => by
      rw [hm_def, aft3StateSeededG_fst] at hbot
      rw [hseedmL (le_bot_iff.mp (le_sup_left.trans (le_of_eq hbot))),
        aft3KeysUptoG_sum_zero_of_bot qT kT vT ks keep (c * BN) i d
          (le_bot_iff.mp (le_sup_right.trans (le_of_eq hbot))) (fun p => pow2 p.1)]; ring)
    (fun hbot => by
      rw [hm_def, aft3StateSeededG_fst] at hbot
      rw [hseedmT (le_bot_iff.mp (le_sup_left.trans (le_of_eq hbot))),
        aft3KeysUptoG_sum_zero_of_bot qT kT vT ks keep (c * BN) i d
          (le_bot_iff.mp (le_sup_right.trans (le_of_eq hbot))) (fun p => pow2 p.1 * p.2)]; ring)
  rw [← hMsucc] at hblockEq
  rw [show (aft3StateSeededG qT kT vT ks keep seed ((c + 1) * BN) i d).2.1
        = (Mc1, (aft3StateSeededG qT kT vT ks keep seed (c * BN) i d).2.1
              * (WithBot.realExp2 (WithBot.realSub m Mc1)).unbotD 0
              + ((aft3BlockG qT kT vT ks keep BN c i d).map (fun p => pow2 (p.1 - Mc1.unbotD 0))).sum,
            _).2.1 from by
    rw [aft3StateSeededG_succ]; rw [← hblockEq]]
  set α : ℝ := (WithBot.realExp2 (WithBot.realSub m Mc1)).unbotD 0 with hαdef
  have hαsome : WithBot.realExp2 (WithBot.realSub m Mc1) = some α := by
    rw [hαdef]; cases WithBot.realSub m Mc1 <;> rfl
  rw [Tile.bop_data]
  simp only [Broadcast.leftIndex, Broadcast.rightIndex]
  erw [hsum]
  rw [Tile.bop_data]
  simp only [Broadcast.leftIndex, Broadcast.rightIndex, NumericDType.add, NumericDType.mul,
    hltile, halphaVal, hαsome]
  simp only [WithBot.realAdd, WithBot.realMul, Option.map₂, Option.bind, Option.map]
  rfl

set_option maxHeartbeats 1600000 in
/-- **General masked `acc' = aft3StateBotG((c+1)·BN).2.2` (cases 1/2).** -/
theorem aft3_acc_reg_eq_maskedG (s0 : BlockState) (Q K V : RegionName)
    (base BM ND NC sqm sqk skn skk svk svn : Nat) (sc : ℝ) (BN c : Nat) (hBN : 0 < BN)
    (hc1 : (c + 1) * BN ≤ NC) (i : Fin BM) (d : Fin ND)
    (keep : Fin BM → Fin NC → Prop) [∀ i j, Decidable (keep i j)]
    (mc : Fin BN → Bool)
    (hmc : ∀ jL : Fin BN, mc jL = decide (keep i ⟨c * BN + jL.val, aft3_block_idx_lt BN c NC jL.val jL.isLt hc1⟩))
    (qtile : Tile .real [BM, ND]) (ktile : Tile .real [ND, BN]) (vtile : Tile .real [BN, ND])
    (qkT pT pmT : Tile .real [BM, BN]) (acctile acc1T : Tile .real [BM, ND])
    (mtile mijT alphaT : Tile .real [BM])
    (hq : qtile = ⟨fun idx : TileIndex [BM, ND] => some (qTile3G s0 Q base BM ND sqm sqk idx)⟩)
    (hk : ∀ idx : TileIndex [ND, BN],
        ktile.data idx = some (s0.readMem K (base + idx.1.val * skk + (c * BN + idx.2.1.val) * skn)))
    (hv : ∀ idx : TileIndex [BN, ND],
        vtile.data idx = some (s0.readMem V (base + (c * BN + idx.1.val) * svk + idx.2.1.val * svn)))
    (hqkT : ∀ jL : Fin BN, qkT.data (i, jL, PUnit.unit) =
        if mc jL then
          (Tile.bop NumericDType.real.mul Broadcast.scalarR
            (Tile.bop NumericDType.real.add (Broadcast.consSame (Broadcast.consSame Broadcast.nil))
              (⟨fun _ => some (0 : ℝ)⟩ : Tile .real [BM, BN]) (Tile.dot [] qtile ktile))
            (Tile.scalar (some sc))).data (i, jL, PUnit.unit)
        else (⊥ : WithBot ℝ))
    (hacctile : acctile.data (i, d, PUnit.unit) = some
        ((aft3StateBotKG (qTile3G s0 Q base BM ND sqm sqk) (kTile3G s0 K base NC ND skn skk)
            (vTile3G s0 V base NC ND svk svn) (keyScale3G sc NC) keep (c * BN) i d).2.2))
    (hmtile : mtile.data (i, PUnit.unit)
        = aft3RunningMaxG (qTile3G s0 Q base BM ND sqm sqk) (kTile3G s0 K base NC ND skn skk)
            (vTile3G s0 V base NC ND svk svn) (keyScale3G sc NC) keep (c * BN) i d)
    (hmij : mijT.data (i, PUnit.unit)
        = aft3RunningMaxG (qTile3G s0 Q base BM ND sqm sqk) (kTile3G s0 K base NC ND skn skk)
            (vTile3G s0 V base NC ND svk svn) (keyScale3G sc NC) keep ((c + 1) * BN) i d)
    (halpha : alphaT = Tile.uop WithBot.realExp2
        (Tile.bop NumericDType.real.sub (Broadcast.consSame Broadcast.nil) mtile mijT))
    (hacc1 : acc1T = Tile.bop NumericDType.real.mul (Broadcast.consSame (Broadcast.consR Broadcast.nil)) acctile (Tile.expandDim ⟨1, by simp⟩ alphaT))
    (hpT : pT = Tile.uop WithBot.realExp2 (Tile.bop NumericDType.real.sub
        (Broadcast.consSame (Broadcast.consR Broadcast.nil)) qkT (Tile.expandDim ⟨1, by simp⟩ mijT)))
    (hpmT : ∀ jL : Fin BN, pmT.data (i, jL, PUnit.unit) =
        if mc jL then pT.data (i, jL, PUnit.unit) else (some (0.0 : ℝ) : WithBot ℝ)) :
    (Tile.bop NumericDType.real.add (Broadcast.consSame (Broadcast.consSame Broadcast.nil))
        acc1T (Tile.dot [] pmT vtile)).data (i, d, PUnit.unit)
      = some ((aft3StateBotG (qTile3G s0 Q base BM ND sqm sqk) (kTile3G s0 K base NC ND skn skk)
          (vTile3G s0 V base NC ND svk svn) (keyScale3G sc NC) keep ((c + 1) * BN) i d).2.2) := by
  set qT := qTile3G s0 Q base BM ND sqm sqk
  set kT := kTile3G s0 K base NC ND skn skk
  set vT := vTile3G s0 V base NC ND svk svn
  set ks := keyScale3G sc NC
  set m := (aft3StateBotG qT kT vT ks keep (c * BN) i d).1 with hm_def
  set Mc := aft3RunningMaxG qT kT vT ks keep (c * BN) i d with hMc
  set Mc1 := aft3RunningMaxG qT kT vT ks keep ((c + 1) * BN) i d with hMc1
  have hmMc : m = Mc := by rw [hm_def, hMc, aft3StateBotG_fst_eq_runningMax]
  have hMsucc : Mc1 = m ⊔ ((aft3BlockG qT kT vT ks keep BN c i d).map
        (fun p => ((p.1 : ℝ) : WithBot ℝ))).foldr (· ⊔ ·) ⊥ := by
    have h1 : Mc1 = (aft3StateBotG qT kT vT ks keep ((c + 1) * BN) i d).1 := by
      rw [hMc1, aft3StateBotG_fst_eq_runningMax]
    rw [h1, aft3StateBotG_succ, aft3OsStepBot_block_fst m
        ((aft3StateBotG qT kT vT ks keep (c * BN) i d).2.1)
        ((aft3StateBotG qT kT vT ks keep (c * BN) i d).2.2)]
  have halphaVal : alphaT.data (i, PUnit.unit) = WithBot.realExp2 (WithBot.realSub m Mc1) := by
    rw [halpha]; show WithBot.realExp2 _ = _
    simp only [Tile.bop_data, Broadcast.leftIndex, Broadcast.rightIndex, hmtile, hmij,
      NumericDType.sub, ← hMc, ← hMc1, hmMc]
  have hdot := aft3_acc_dot_block_maskedG s0 Q K V base BM ND NC sqm sqk skn skk svk svn sc BN c hBN hc1 i d
    keep mc hmc qtile ktile vtile mijT pT pmT qkT hq hk hv hqkT hmij hpT hpmT
  have hblockEq := aft3OsStepBot_block_eq m
    ((aft3StateBotG qT kT vT ks keep (c * BN) i d).2.1)
    ((aft3StateBotG qT kT vT ks keep (c * BN) i d).2.2)
    ((aft3KeysUptoG qT kT vT ks keep (c * BN) i d).map (fun p => pow2 p.1 * p.2)).sum
    ((aft3KeysUptoG qT kT vT ks keep (c * BN) i d).map (fun p => pow2 p.1)).sum
    (aft3BlockG qT kT vT ks keep BN c i d)
    (by rw [aft3_denomG_anchor, zero_add, hm_def])
    (by rw [aft3_accG_anchor, zero_add, hm_def])
    (fun hbot => aft3KeysUptoG_sum_zero_of_bot qT kT vT ks keep (c * BN) i d
      (by rw [← aft3StateBotG_fst_eq_runningMax, ← hm_def]; exact hbot) _)
    (fun hbot => aft3KeysUptoG_sum_zero_of_bot qT kT vT ks keep (c * BN) i d
      (by rw [← aft3StateBotG_fst_eq_runningMax, ← hm_def]; exact hbot) _)
  rw [← hMsucc] at hblockEq
  rw [show (aft3StateBotG qT kT vT ks keep ((c + 1) * BN) i d).2.2
        = (Mc1, _,
            (aft3StateBotG qT kT vT ks keep (c * BN) i d).2.2
              * (WithBot.realExp2 (WithBot.realSub m Mc1)).unbotD 0
              + ((aft3BlockG qT kT vT ks keep BN c i d).map (fun p => pow2 (p.1 - Mc1.unbotD 0) * p.2)).sum).2.2
        from by rw [aft3StateBotG_succ]; rw [← hblockEq]]
  set α : ℝ := (WithBot.realExp2 (WithBot.realSub m Mc1)).unbotD 0 with hαdef
  have hαsome : WithBot.realExp2 (WithBot.realSub m Mc1) = some α := by
    rw [hαdef]; cases WithBot.realSub m Mc1 <;> rfl
  have hcancel := (aft3StateBotKG_cancel qT kT vT ks keep BN c hBN i d Mc1).2
  rw [Tile.bop_data]
  simp only [Broadcast.leftIndex, Broadcast.rightIndex]
  erw [hdot]
  rw [hacc1, Tile.bop_data]
  simp only [Broadcast.leftIndex, Broadcast.rightIndex, Tile.expandDim_data,
    TileShape.dropInsertedIndex, NumericDType.add, NumericDType.mul, hacctile, halphaVal, hαsome]
  simp only [WithBot.realAdd, WithBot.realMul, Option.map₂, Option.bind, Option.map]
  refine congrArg some ?_
  rw [show (aft3StateBotKG qT kT vT ks keep (c * BN) i d).2.2 * α
        = (aft3StateBotG qT kT vT ks keep (c * BN) i d).2.2 * α from hcancel]

set_option maxHeartbeats 1600000 in
/-- **Seeded masked acc reconciliation (case 4).** `acc' = (seededfold((c+1)·BN)).2.2`. -/
theorem aft3_acc_reg_eq_seededG (s0 : BlockState) (Q K V : RegionName)
    (base BM ND NC sqm sqk skn skk svk svn : Nat) (sc : ℝ) (BN c : Nat) (hBN : 0 < BN)
    (hc1 : (c + 1) * BN ≤ NC) (i : Fin BM) (d : Fin ND)
    (keep : Fin BM → Fin NC → Prop) [∀ i j, Decidable (keep i j)]
    (seed : Fin BM → Fin ND → WithBot ℝ × ℝ × ℝ) (Lseed Tseed : ℝ)
    (hseedL : (seed i d).2.1 = ((seed i d).1.elim 0 (fun r => pow2 (-r))) * Lseed)
    (hseedT : (seed i d).2.2 = ((seed i d).1.elim 0 (fun r => pow2 (-r))) * Tseed)
    (hseedmL : (seed i d).1 = ⊥ → Lseed = 0) (hseedmT : (seed i d).1 = ⊥ → Tseed = 0)
    (mc : Fin BN → Bool)
    (hmc : ∀ jL : Fin BN, mc jL = decide (keep i ⟨c * BN + jL.val, aft3_block_idx_lt BN c NC jL.val jL.isLt hc1⟩))
    (qtile : Tile .real [BM, ND]) (ktile : Tile .real [ND, BN]) (vtile : Tile .real [BN, ND])
    (qkT pT pmT : Tile .real [BM, BN]) (acctile acc1T : Tile .real [BM, ND])
    (mtile mijT alphaT : Tile .real [BM])
    (hq : qtile = ⟨fun idx : TileIndex [BM, ND] => some (qTile3G s0 Q base BM ND sqm sqk idx)⟩)
    (hk : ∀ idx : TileIndex [ND, BN],
        ktile.data idx = some (s0.readMem K (base + idx.1.val * skk + (c * BN + idx.2.1.val) * skn)))
    (hv : ∀ idx : TileIndex [BN, ND],
        vtile.data idx = some (s0.readMem V (base + (c * BN + idx.1.val) * svk + idx.2.1.val * svn)))
    (hqkT : ∀ jL : Fin BN, qkT.data (i, jL, PUnit.unit) =
        if mc jL then
          (Tile.bop NumericDType.real.mul Broadcast.scalarR
            (Tile.bop NumericDType.real.add (Broadcast.consSame (Broadcast.consSame Broadcast.nil))
              (⟨fun _ => some (0 : ℝ)⟩ : Tile .real [BM, BN]) (Tile.dot [] qtile ktile))
            (Tile.scalar (some sc))).data (i, jL, PUnit.unit)
        else (⊥ : WithBot ℝ))
    (hacctile : acctile.data (i, d, PUnit.unit) = some
        ((aft3StateSeededG (qTile3G s0 Q base BM ND sqm sqk) (kTile3G s0 K base NC ND skn skk)
            (vTile3G s0 V base NC ND svk svn) (keyScale3G sc NC) keep seed (c * BN) i d).2.2))
    (hmtile : mtile.data (i, PUnit.unit)
        = (aft3StateSeededG (qTile3G s0 Q base BM ND sqm sqk) (kTile3G s0 K base NC ND skn skk)
            (vTile3G s0 V base NC ND svk svn) (keyScale3G sc NC) keep seed (c * BN) i d).1)
    (hmij : mijT.data (i, PUnit.unit)
        = (aft3StateSeededG (qTile3G s0 Q base BM ND sqm sqk) (kTile3G s0 K base NC ND skn skk)
            (vTile3G s0 V base NC ND svk svn) (keyScale3G sc NC) keep seed ((c + 1) * BN) i d).1)
    (halpha : alphaT = Tile.uop WithBot.realExp2
        (Tile.bop NumericDType.real.sub (Broadcast.consSame Broadcast.nil) mtile mijT))
    (hacc1 : acc1T = Tile.bop NumericDType.real.mul (Broadcast.consSame (Broadcast.consR Broadcast.nil)) acctile (Tile.expandDim ⟨1, by simp⟩ alphaT))
    (hpT : pT = Tile.uop WithBot.realExp2 (Tile.bop NumericDType.real.sub
        (Broadcast.consSame (Broadcast.consR Broadcast.nil)) qkT (Tile.expandDim ⟨1, by simp⟩ mijT)))
    (hpmT : ∀ jL : Fin BN, pmT.data (i, jL, PUnit.unit) =
        if mc jL then pT.data (i, jL, PUnit.unit) else (some (0.0 : ℝ) : WithBot ℝ)) :
    (Tile.bop NumericDType.real.add (Broadcast.consSame (Broadcast.consSame Broadcast.nil))
        acc1T (Tile.dot [] pmT vtile)).data (i, d, PUnit.unit)
      = some ((aft3StateSeededG (qTile3G s0 Q base BM ND sqm sqk) (kTile3G s0 K base NC ND skn skk)
          (vTile3G s0 V base NC ND svk svn) (keyScale3G sc NC) keep seed ((c + 1) * BN) i d).2.2) := by
  set qT := qTile3G s0 Q base BM ND sqm sqk
  set kT := kTile3G s0 K base NC ND skn skk
  set vT := vTile3G s0 V base NC ND svk svn
  set ks := keyScale3G sc NC
  set m := (aft3StateSeededG qT kT vT ks keep seed (c * BN) i d).1 with hm_def
  set Mc1 := (aft3StateSeededG qT kT vT ks keep seed ((c + 1) * BN) i d).1 with hMc1
  have hMsucc : Mc1 = m ⊔ ((aft3BlockG qT kT vT ks keep BN c i d).map
        (fun p => ((p.1 : ℝ) : WithBot ℝ))).foldr (· ⊔ ·) ⊥ := by
    rw [hMc1, aft3StateSeededG_succ, aft3OsStepBot_block_fst m
        ((aft3StateSeededG qT kT vT ks keep seed (c * BN) i d).2.1)
        ((aft3StateSeededG qT kT vT ks keep seed (c * BN) i d).2.2)]
  have hMc1bot : ∀ jL : Fin BN, mc jL = Bool.true → Mc1 ≠ ⊥ := by
    intro jL hmcj
    have hkp : keep i ⟨c * BN + jL.val, aft3_block_idx_lt BN c NC jL.val jL.isLt hc1⟩ :=
      of_decide_eq_true ((hmc jL).symm.trans hmcj)
    have hne := aft3_kept_lane_ne_botG s0 Q K V base BM ND NC sqm sqk skn skk svk svn sc BN c hc1 i d keep jL hkp
    intro hMbot
    rw [hMc1, aft3StateSeededG_fst] at hMbot
    exact hne (le_bot_iff.mp (le_sup_right.trans (le_of_eq hMbot)))
  have halphaVal : alphaT.data (i, PUnit.unit) = WithBot.realExp2 (WithBot.realSub m Mc1) := by
    rw [halpha]; show WithBot.realExp2 _ = _
    simp only [Tile.bop_data, Broadcast.leftIndex, Broadcast.rightIndex, hmtile, hmij,
      NumericDType.sub]
  have hdot := aft3_acc_dot_block_masked_genG s0 Q K V base BM ND NC sqm sqk skn skk svk svn sc BN c hBN hc1 i d
    keep mc hmc qtile ktile vtile mijT pT pmT qkT Mc1 hq hk hv hqkT hmij hMc1bot hpT hpmT
  have hcons := aft3StateSeededG_consistent qT kT vT ks keep seed Lseed Tseed (c * BN) i d
    hseedL hseedT hseedmL hseedmT
  have hblockEq := aft3OsStepBot_block_eq m
    ((aft3StateSeededG qT kT vT ks keep seed (c * BN) i d).2.1)
    ((aft3StateSeededG qT kT vT ks keep seed (c * BN) i d).2.2)
    (Tseed + ((aft3KeysUptoG qT kT vT ks keep (c * BN) i d).map (fun p => pow2 p.1 * p.2)).sum)
    (Lseed + ((aft3KeysUptoG qT kT vT ks keep (c * BN) i d).map (fun p => pow2 p.1)).sum)
    (aft3BlockG qT kT vT ks keep BN c i d)
    hcons.1 hcons.2
    (fun hbot => by
      rw [hm_def, aft3StateSeededG_fst] at hbot
      rw [hseedmL (le_bot_iff.mp (le_sup_left.trans (le_of_eq hbot))),
        aft3KeysUptoG_sum_zero_of_bot qT kT vT ks keep (c * BN) i d
          (le_bot_iff.mp (le_sup_right.trans (le_of_eq hbot))) (fun p => pow2 p.1)]; ring)
    (fun hbot => by
      rw [hm_def, aft3StateSeededG_fst] at hbot
      rw [hseedmT (le_bot_iff.mp (le_sup_left.trans (le_of_eq hbot))),
        aft3KeysUptoG_sum_zero_of_bot qT kT vT ks keep (c * BN) i d
          (le_bot_iff.mp (le_sup_right.trans (le_of_eq hbot))) (fun p => pow2 p.1 * p.2)]; ring)
  rw [← hMsucc] at hblockEq
  rw [show (aft3StateSeededG qT kT vT ks keep seed ((c + 1) * BN) i d).2.2
        = (Mc1, _,
            (aft3StateSeededG qT kT vT ks keep seed (c * BN) i d).2.2
              * (WithBot.realExp2 (WithBot.realSub m Mc1)).unbotD 0
              + ((aft3BlockG qT kT vT ks keep BN c i d).map (fun p => pow2 (p.1 - Mc1.unbotD 0) * p.2)).sum).2.2
        from by rw [aft3StateSeededG_succ]; rw [← hblockEq]]
  set α : ℝ := (WithBot.realExp2 (WithBot.realSub m Mc1)).unbotD 0 with hαdef
  have hαsome : WithBot.realExp2 (WithBot.realSub m Mc1) = some α := by
    rw [hαdef]; cases WithBot.realSub m Mc1 <;> rfl
  rw [Tile.bop_data]
  simp only [Broadcast.leftIndex, Broadcast.rightIndex]
  erw [hdot]
  rw [hacc1, Tile.bop_data]
  simp only [Broadcast.leftIndex, Broadcast.rightIndex, Tile.expandDim_data,
    TileShape.dropInsertedIndex, NumericDType.add, NumericDType.mul, hacctile, halphaVal, hαsome]
  simp only [WithBot.realAdd, WithBot.realMul, Option.map₂, Option.bind, Option.map]
  rfl

/-! ## Dimension-general invariant + preLoop (cases 1/2/3)

The general loop invariant `attnInvariantKG` carries the faithful kernel state
`aft3StateBotKG` (seed-1 at window 0, seed-0 ⊥-state after) over symbolic
dimensions and a single shared base `base` (the common q/k/v/o offset). The
preLoop establishes it from a clean state for a surface whose four block-pointer
offsets coincide at `base`. -/

/-- General loop invariant carrying the faithful ⊥-carry kernel state. -/
noncomputable def attnInvariantKG
    (Q K V M Out L : RegionName) (s0 : BlockState)
    (base BM ND NC BN sqm sqk skn skk svk svn som son ROUND_CTX : Nat) (hND : 0 < ND) (sc : ℝ)
    (keep : Fin BM → Fin NC → Prop) [∀ i j, Decidable (keep i j)]
    (i : Nat) (s : BlockState) : Prop :=
  let qT := qTile3G s0 Q base BM ND sqm sqk
  let kT := kTile3G s0 K base NC ND skn skk
  let vT := vTile3G s0 V base NC ND svk svn
  s.pids = s0.pids ∧ i % BN = 0 ∧ i ≤ NC ∧
  (s.regs .real [BM] "m_i" = some ⟨fun r : TileIndex [BM] =>
      aft3RunningMaxG qT kT vT (keyScale3G sc NC) keep i r.1 ⟨0, hND⟩⟩) ∧
  (s.regs .real [BM] "l_i" = some ⟨fun r : TileIndex [BM] =>
      ((aft3StateBotKG qT kT vT (keyScale3G sc NC) keep i r.1 ⟨0, hND⟩).2.1 : ℝ)⟩) ∧
  (s.regs .real [BM, ND] "acc" = some ⟨fun idx : TileIndex [BM, ND] =>
      ((aft3StateBotKG qT kT vT (keyScale3G sc NC) keep i idx.1 idx.2.1).2.2 : ℝ)⟩) ∧
  (s.regs .real [BM, ND] "q" = some ⟨fun idx : TileIndex [BM, ND] => some (qT idx)⟩) ∧
  (s.regs .real [] "qk_scale" = some (Tile.scalar (some sc))) ∧
  (s.regs .nat [] "start_m" = some (Tile.scalar (s0.pids 0))) ∧
  (s.regs .nat [] "off_hz" = some (Tile.scalar (s0.pids 1))) ∧
  (s.regs .blockPtr [ND, BN] "K_block_ptr" = some
    (⟨fun _ : TileIndex [ND, BN] =>
      { region := K, baseOffset := base, parentShape := [ND, NC], blockShape := [ND, BN],
        strides := [skk, skn], offsets := [0, i] }⟩)) ∧
  (s.regs .blockPtr [BN, ND] "V_block_ptr" = some
    (⟨fun _ : TileIndex [BN, ND] =>
      { region := V, baseOffset := base, parentShape := [NC, ND], blockShape := [BN, ND],
        strides := [svk, svn], offsets := [i, 0] }⟩)) ∧
  (s.regs .ptr [BM] "m_ptrs" = some
    (Tile.ptrAdd Broadcast.scalarL (Tile.scalar (M.cast, (0 : Nat)))
      (Tile.bop NumericDType.nat.add Broadcast.scalarL (Tile.scalar (s0.pids 1 * ROUND_CTX))
        (Tile.vec (fun r : Fin BM => s0.pids 0 * BM + r.val))))) ∧
  (s.regs .ptr [BM] "l_ptrs" = some
    (Tile.ptrAdd Broadcast.scalarL (Tile.scalar (L.cast, (0 : Nat)))
      (Tile.bop NumericDType.nat.add Broadcast.scalarL (Tile.scalar (s0.pids 1 * ROUND_CTX))
        (Tile.vec (fun r : Fin BM => s0.pids 0 * BM + r.val))))) ∧
  (s.regs .blockPtr [BM, ND] "O_block_ptr" = some
    (⟨fun _ : TileIndex [BM, ND] =>
      { region := Out, baseOffset := base, parentShape := [ROUND_CTX, ND], blockShape := [BM, ND],
        strides := [som, son], offsets := [s0.pids 0 * BM, 0] }⟩)) ∧
  (∀ rg o, s.undef rg o = 0) ∧ (s.mem = s0.mem)

/-- The resume-seeded fold at the empty window `hi = 0` is just the seed. -/
theorem aft3StateSeededG_zero {BM ND NC : Nat}
    (qT : TileIndex [BM, ND] → ℝ) (kT vT : TileIndex [NC, ND] → ℝ)
    (keyScale : Fin NC → ℝ) (keep : Fin BM → Fin NC → Prop)
    [∀ i j, Decidable (keep i j)]
    (seed : Fin BM → Fin ND → WithBot ℝ × ℝ × ℝ) (i : Fin BM) (d : Fin ND) :
    aft3StateSeededG qT kT vT keyScale keep seed 0 i d = seed i d := by
  unfold aft3StateSeededG aft3KeysUptoG
  rw [show (List.finRange NC).filterMap
        (fun j : Fin NC => if j.val < 0 ∧ keep i j
          then some (keyScale j * Finset.univ.sum (fun e : Fin ND =>
                qT (i, e, PUnit.unit) * kT (j, e, PUnit.unit)), vT (j, d, PUnit.unit))
          else none) = [] from by
    apply List.filterMap_eq_nil_iff.mpr; intro j _; simp]
  rfl

/-- **Seeded loop invariant (case 4, `INIT=False` resume).** Like `attnInvariantKG`
but `m_i`/`l_i`/`acc` carry the resume-seeded fold `aft3StateSeededG` from `seed`
(the loaded prior `(m_i, l_i, acc)`), rather than the ⊥-seeded `aft3StateBotKG`.
No `hi=0` special case is needed — the seed IS the loop-entry state. -/
noncomputable def attnInvariantSeededG
    (Q K V M Out L : RegionName) (s0 : BlockState)
    (base BM ND NC BN sqm sqk skn skk svk svn som son ROUND_CTX : Nat) (hND : 0 < ND) (sc : ℝ)
    (keep : Fin BM → Fin NC → Prop) [∀ i j, Decidable (keep i j)]
    (seed : Fin BM → Fin ND → WithBot ℝ × ℝ × ℝ)
    (i : Nat) (s : BlockState) : Prop :=
  let qT := qTile3G s0 Q base BM ND sqm sqk
  let kT := kTile3G s0 K base NC ND skn skk
  let vT := vTile3G s0 V base NC ND svk svn
  s.pids = s0.pids ∧ i % BN = 0 ∧ i ≤ NC ∧
  (s.regs .real [BM] "m_i" = some ⟨fun r : TileIndex [BM] =>
      (aft3StateSeededG qT kT vT (keyScale3G sc NC) keep seed i r.1 ⟨0, hND⟩).1⟩) ∧
  (s.regs .real [BM] "l_i" = some ⟨fun r : TileIndex [BM] =>
      ((aft3StateSeededG qT kT vT (keyScale3G sc NC) keep seed i r.1 ⟨0, hND⟩).2.1 : ℝ)⟩) ∧
  (s.regs .real [BM, ND] "acc" = some ⟨fun idx : TileIndex [BM, ND] =>
      ((aft3StateSeededG qT kT vT (keyScale3G sc NC) keep seed i idx.1 idx.2.1).2.2 : ℝ)⟩) ∧
  (s.regs .real [BM, ND] "q" = some ⟨fun idx : TileIndex [BM, ND] => some (qT idx)⟩) ∧
  (s.regs .real [] "qk_scale" = some (Tile.scalar (some sc))) ∧
  (s.regs .nat [] "start_m" = some (Tile.scalar (s0.pids 0))) ∧
  (s.regs .nat [] "off_hz" = some (Tile.scalar (s0.pids 1))) ∧
  (s.regs .blockPtr [ND, BN] "K_block_ptr" = some
    (⟨fun _ : TileIndex [ND, BN] =>
      { region := K, baseOffset := base, parentShape := [ND, NC], blockShape := [ND, BN],
        strides := [skk, skn], offsets := [0, i] }⟩)) ∧
  (s.regs .blockPtr [BN, ND] "V_block_ptr" = some
    (⟨fun _ : TileIndex [BN, ND] =>
      { region := V, baseOffset := base, parentShape := [NC, ND], blockShape := [BN, ND],
        strides := [svk, svn], offsets := [i, 0] }⟩)) ∧
  (s.regs .ptr [BM] "m_ptrs" = some
    (Tile.ptrAdd Broadcast.scalarL (Tile.scalar (M.cast, (0 : Nat)))
      (Tile.bop NumericDType.nat.add Broadcast.scalarL (Tile.scalar (s0.pids 1 * ROUND_CTX))
        (Tile.vec (fun r : Fin BM => s0.pids 0 * BM + r.val))))) ∧
  (s.regs .ptr [BM] "l_ptrs" = some
    (Tile.ptrAdd Broadcast.scalarL (Tile.scalar (L.cast, (0 : Nat)))
      (Tile.bop NumericDType.nat.add Broadcast.scalarL (Tile.scalar (s0.pids 1 * ROUND_CTX))
        (Tile.vec (fun r : Fin BM => s0.pids 0 * BM + r.val))))) ∧
  (s.regs .blockPtr [BM, ND] "O_block_ptr" = some
    (⟨fun _ : TileIndex [BM, ND] =>
      { region := Out, baseOffset := base, parentShape := [ROUND_CTX, ND], blockShape := [BM, ND],
        strides := [som, son], offsets := [s0.pids 0 * BM, 0] }⟩)) ∧
  (∀ rg o, s.undef rg o = 0) ∧ (s.mem = s0.mem)

/-- **General no-⊥-carry loop invariant (case 3, `aft3StateBot1G`).** Identical to
`attnInvariantKG` but with the `l_i`/`acc` carrying `aft3StateBot1G` (seed-1) — the
form the case-3 streaming loop maintains (no fully-masked rows). -/
noncomputable def attnInvariantG
    (Q K V M Out L : RegionName) (s0 : BlockState)
    (base BM ND NC BN sqm sqk skn skk svk svn som son ROUND_CTX : Nat) (hND : 0 < ND) (sc : ℝ)
    (keep : Fin BM → Fin NC → Prop) [∀ i j, Decidable (keep i j)]
    (i : Nat) (s : BlockState) : Prop :=
  let qT := qTile3G s0 Q base BM ND sqm sqk
  let kT := kTile3G s0 K base NC ND skn skk
  let vT := vTile3G s0 V base NC ND svk svn
  s.pids = s0.pids ∧ i % BN = 0 ∧ i ≤ NC ∧
  (s.regs .real [BM] "m_i" = some ⟨fun r : TileIndex [BM] =>
      aft3RunningMaxG qT kT vT (keyScale3G sc NC) keep i r.1 ⟨0, hND⟩⟩) ∧
  (s.regs .real [BM] "l_i" = some ⟨fun r : TileIndex [BM] =>
      ((aft3StateBot1G qT kT vT (keyScale3G sc NC) keep i r.1 ⟨0, hND⟩).2.1 : ℝ)⟩) ∧
  (s.regs .real [BM, ND] "acc" = some ⟨fun idx : TileIndex [BM, ND] =>
      ((aft3StateBot1G qT kT vT (keyScale3G sc NC) keep i idx.1 idx.2.1).2.2 : ℝ)⟩) ∧
  (s.regs .real [BM, ND] "q" = some ⟨fun idx : TileIndex [BM, ND] => some (qT idx)⟩) ∧
  (s.regs .real [] "qk_scale" = some (Tile.scalar (some sc))) ∧
  (s.regs .nat [] "start_m" = some (Tile.scalar (s0.pids 0))) ∧
  (s.regs .nat [] "off_hz" = some (Tile.scalar (s0.pids 1))) ∧
  (s.regs .blockPtr [ND, BN] "K_block_ptr" = some
    (⟨fun _ : TileIndex [ND, BN] =>
      { region := K, baseOffset := base, parentShape := [ND, NC], blockShape := [ND, BN],
        strides := [skk, skn], offsets := [0, i] }⟩)) ∧
  (s.regs .blockPtr [BN, ND] "V_block_ptr" = some
    (⟨fun _ : TileIndex [BN, ND] =>
      { region := V, baseOffset := base, parentShape := [NC, ND], blockShape := [BN, ND],
        strides := [svk, svn], offsets := [i, 0] }⟩)) ∧
  (s.regs .ptr [BM] "m_ptrs" = some
    (Tile.ptrAdd Broadcast.scalarL (Tile.scalar (M.cast, (0 : Nat)))
      (Tile.bop NumericDType.nat.add Broadcast.scalarL (Tile.scalar (s0.pids 1 * ROUND_CTX))
        (Tile.vec (fun r : Fin BM => s0.pids 0 * BM + r.val))))) ∧
  (s.regs .ptr [BM] "l_ptrs" = some
    (Tile.ptrAdd Broadcast.scalarL (Tile.scalar (L.cast, (0 : Nat)))
      (Tile.bop NumericDType.nat.add Broadcast.scalarL (Tile.scalar (s0.pids 1 * ROUND_CTX))
        (Tile.vec (fun r : Fin BM => s0.pids 0 * BM + r.val))))) ∧
  (s.regs .blockPtr [BM, ND] "O_block_ptr" = some
    (⟨fun _ : TileIndex [BM, ND] =>
      { region := Out, baseOffset := base, parentShape := [ROUND_CTX, ND], blockShape := [BM, ND],
        strides := [som, son], offsets := [s0.pids 0 * BM, 0] }⟩)) ∧
  (∀ rg o, s.undef rg o = 0) ∧ (s.mem = s0.mem)

/-- The base case: `attnInvariantG … 0` (which carries `aft3StateBot1G`) yields
`attnInvariantKG … 0` (which carries `aft3StateBotKG`), since both equal the seed
`(⊥,1,0)` at window 0. -/
theorem attnInvariant_zero_to_KG
    (Q K V M Out L : RegionName) (s0 : BlockState)
    (base BM ND NC BN sqm sqk skn skk svk svn som son ROUND_CTX : Nat) (hND : 0 < ND) (sc : ℝ)
    (keep : Fin BM → Fin NC → Prop) [∀ i j, Decidable (keep i j)]
    (s : BlockState)
    (h : attnInvariantG Q K V M Out L s0 base BM ND NC BN sqm sqk skn skk svk svn som son ROUND_CTX hND sc keep 0 s) :
    attnInvariantKG Q K V M Out L s0 base BM ND NC BN sqm sqk skn skk svk svn som son ROUND_CTX hND sc keep 0 s := by
  obtain ⟨hpids, hmod, hile, hmi, hli, hacc, hq, hqs, hsm, hoff, hKp, hVp, hMptr, hLptr, hOp, hundef, hmem⟩ := h
  refine ⟨hpids, hmod, hile, hmi, ?_, ?_, hq, hqs, hsm, hoff, hKp, hVp, hMptr, hLptr, hOp, hundef, hmem⟩
  · rw [hli]; simp only [aft3StateBotKG_zero]
  · rw [hacc]; simp only [aft3StateBotKG_zero]

/-! ## General preLoop execution -/

/-- The prefix of `aft3PreLoopG` before the `INIT` branch (stmts 0–15). -/
noncomputable def aft3PreLoopScalarsG (Q K V M Out L : RegionName) (sm_scale : ℝ)
    (sqz sqh sqm sqk skz skh skn skk svz svh svk svn soz soh som son
      H H_KV N_CTX ROUND_CTX NKV_CTX off size BM ND BN : Nat) : List Stmt :=
  (aft3PreLoopG Q K V M Out L sm_scale sqz sqh sqm sqk skz skh skn skk svz svh svk svn soz soh som son H H_KV N_CTX ROUND_CTX NKV_CTX off size BM ND BN).take 16

set_option maxHeartbeats 1600000 in
set_option maxRecDepth 8000 in
/-- The scalar/pointer/index prefix steps to a state exposing the register
readbacks the `INIT`/`qk_scale`/`q`-load chunks need. Requires the stride-regime
equalities `skz=svz=soz=sqz`, `skh=svh=soh=sqh`, and `H_KV=H` (so all four
`q/k/v/o` plane offsets coincide at `base := pids1/H·sqz + pids1%H·sqh`). -/
theorem aft3PreLoopScalarsG_eval (Q K V M Out L : RegionName) (sm_scale : ℝ)
    (sqz sqh sqm sqk skz skh skn skk svz svh svk svn soz soh som son
      H H_KV N_CTX ROUND_CTX NKV_CTX off size BM ND BN : Nat) (s : BlockState)
    (hH : 0 < H) (hHKV : H_KV = H)
    (hskz : skz = sqz) (hskh : skh = sqh) (hsvz : svz = sqz) (hsvh : svh = sqh)
    (hsoz : soz = sqz) (hsoh : soh = sqh) :
    ∃ s11, stepStmts (aft3PreLoopScalarsG Q K V M Out L sm_scale sqz sqh sqm sqk skz skh skn skk svz svh svk svn soz soh som son H H_KV N_CTX ROUND_CTX NKV_CTX off size BM ND BN) s = some s11
      ∧ s11.pids = s.pids ∧ s11.mem = s.mem ∧ s11.undef = s.undef
      ∧ s11.regs .nat [] "start_m" = some (Tile.scalar (s.pids 0))
      ∧ s11.regs .nat [] "off_hz" = some (Tile.scalar (s.pids 1))
      ∧ s11.regs .blockPtr [BM, ND] "Q_block_ptr" = some
          (⟨fun _ : TileIndex [BM, ND] =>
            { region := Q, baseOffset := s.pids 1 / H * sqz + s.pids 1 % H * sqh,
              parentShape := [N_CTX, ND], blockShape := [BM, ND], strides := [sqm, sqk],
              offsets := [s.pids 0 * BM, 0] }⟩)
      ∧ s11.regs .blockPtr [ND, BN] "K_block_ptr" = some
          (⟨fun _ : TileIndex [ND, BN] =>
            { region := K, baseOffset := s.pids 1 / H * sqz + s.pids 1 % H * sqh,
              parentShape := [ND, NKV_CTX], blockShape := [ND, BN], strides := [skk, skn],
              offsets := [0, 0] }⟩)
      ∧ s11.regs .blockPtr [BN, ND] "V_block_ptr" = some
          (⟨fun _ : TileIndex [BN, ND] =>
            { region := V, baseOffset := s.pids 1 / H * sqz + s.pids 1 % H * sqh,
              parentShape := [NKV_CTX, ND], blockShape := [BN, ND], strides := [svk, svn],
              offsets := [0, 0] }⟩)
      ∧ s11.regs .blockPtr [BM, ND] "O_block_ptr" = some
          (⟨fun _ : TileIndex [BM, ND] =>
            { region := Out, baseOffset := s.pids 1 / H * sqz + s.pids 1 % H * sqh,
              parentShape := [ROUND_CTX, ND], blockShape := [BM, ND], strides := [som, son],
              offsets := [s.pids 0 * BM, 0] }⟩)
      ∧ s11.regs .ptr [BM] "m_ptrs" = some
          (Tile.ptrAdd Broadcast.scalarL (Tile.scalar (M.cast, (0 : Nat)))
            (Tile.bop NumericDType.nat.add Broadcast.scalarL (Tile.scalar (s.pids 1 * ROUND_CTX))
              (Tile.vec (fun r : Fin BM => s.pids 0 * BM + r.val))))
      ∧ s11.regs .ptr [BM] "l_ptrs" = some
          (Tile.ptrAdd Broadcast.scalarL (Tile.scalar (L.cast, (0 : Nat)))
            (Tile.bop NumericDType.nat.add Broadcast.scalarL (Tile.scalar (s.pids 1 * ROUND_CTX))
              (Tile.vec (fun r : Fin BM => s.pids 0 * BM + r.val)))) := by
  subst skz skh svz svh soz soh
  have hHdiv : H / H_KV = 1 := by rw [hHKV]; exact Nat.div_self hH
  unfold aft3PreLoopScalarsG aft3PreLoopG
  simp only [List.take_succ_cons, List.take_zero, List.append_nil]
  -- stmt 0: start_m
  rw [stepStmts.cons_some (stepStmt_assign_eq_some (evalOp_programId 0 s))]
  -- stmt 1: off_hz
  rw [stepStmts.cons_some (stepStmt_assign_eq_some (evalOp_programId 1 _))]
  -- stmt 2: off_z = off_hz / H
  rw [stepStmts.cons_some (stepStmt_assign_eq_some
    (show evalOp (Op.floorDiv IntegralDType.nat Broadcast.nil (Op.ref TileDType.nat [] "off_hz") (Op.constNat H)) _
        = some (Tile.scalar (s.pids 1 / H)) from by
      rw [aft3_evalOp_floorDiv]
      simp only [evalOp_ref, evalOp_constNat, BlockState.setReg_same, BlockState.setReg_pids,
        Option.bind_eq_bind, Option.bind_some]; rfl))]
  -- stmt 3: off_h = off_hz % H
  rw [stepStmts.cons_some (stepStmt_assign_eq_some
    (show evalOp (Op.mod IntegralDType.nat Broadcast.nil (Op.ref TileDType.nat [] "off_hz") (Op.constNat H)) _
        = some (Tile.scalar (s.pids 1 % H)) from by
      rw [aft3_evalOp_mod]
      simp only [evalOp_ref, evalOp_constNat, BlockState.setReg_same, BlockState.setReg_ne_name,
        ne_eq, String.reduceEq, not_false_eq_true, BlockState.setReg_pids,
        Option.bind_eq_bind, Option.bind_some]; rfl))]
  -- stmt 4: off_hkv = off_h / (H / H) = off_h / 1 = off_h
  rw [stepStmts.cons_some (stepStmt_assign_eq_some
    (show evalOp (Op.floorDiv IntegralDType.nat Broadcast.nil (Op.ref TileDType.nat [] "off_h") (Op.floorDiv IntegralDType.nat Broadcast.nil (Op.constNat H) (Op.constNat H_KV))) _
        = some (Tile.scalar (s.pids 1 % H / (H / H_KV))) from by
      rw [aft3_evalOp_floorDiv, aft3_evalOp_floorDiv]
      simp only [evalOp_ref, evalOp_constNat, BlockState.setReg_same, BlockState.setReg_ne_name,
        ne_eq, String.reduceEq, not_false_eq_true, BlockState.setReg_pids,
        Option.bind_eq_bind, Option.bind_some]; rfl))]
  -- stmt 5: q_offset = off_z*sqz + off_h*sqh
  rw [stepStmts.cons_some (stepStmt_assign_eq_some
    (show evalOp (Op.add NumericDType.nat Broadcast.nil (Op.mul NumericDType.nat Broadcast.nil (Op.ref TileDType.nat [] "off_z") (Op.constNat sqz)) (Op.mul NumericDType.nat Broadcast.nil (Op.ref TileDType.nat [] "off_h") (Op.constNat sqh))) _
        = some (Tile.scalar (s.pids 1 / H * sqz + s.pids 1 % H * sqh)) from by
      rw [evalOp_add, evalOp_mul, evalOp_mul]
      simp only [evalOp_ref, evalOp_constNat, BlockState.setReg_same, BlockState.setReg_ne_name,
        ne_eq, String.reduceEq, not_false_eq_true, BlockState.setReg_pids,
        Option.bind_eq_bind, Option.bind_some]; rfl))]
  -- stmt 6: k_offset = off_z*sqz + off_hkv*sqh = base
  rw [stepStmts.cons_some (stepStmt_assign_eq_some
    (show evalOp (Op.add NumericDType.nat Broadcast.nil (Op.mul NumericDType.nat Broadcast.nil (Op.ref TileDType.nat [] "off_z") (Op.constNat sqz)) (Op.mul NumericDType.nat Broadcast.nil (Op.ref TileDType.nat [] "off_hkv") (Op.constNat sqh))) _
        = some (Tile.scalar (s.pids 1 / H * sqz + s.pids 1 % H * sqh)) from by
      rw [evalOp_add, evalOp_mul, evalOp_mul]
      simp only [evalOp_ref, evalOp_constNat, BlockState.setReg_same, BlockState.setReg_ne_name,
        ne_eq, String.reduceEq, not_false_eq_true, BlockState.setReg_pids,
        Option.bind_eq_bind, Option.bind_some, hHdiv, Nat.div_one]; rfl))]
  -- stmt 7: v_offset = off_z*sqz + off_hkv*sqh = base
  rw [stepStmts.cons_some (stepStmt_assign_eq_some
    (show evalOp (Op.add NumericDType.nat Broadcast.nil (Op.mul NumericDType.nat Broadcast.nil (Op.ref TileDType.nat [] "off_z") (Op.constNat sqz)) (Op.mul NumericDType.nat Broadcast.nil (Op.ref TileDType.nat [] "off_hkv") (Op.constNat sqh))) _
        = some (Tile.scalar (s.pids 1 / H * sqz + s.pids 1 % H * sqh)) from by
      rw [evalOp_add, evalOp_mul, evalOp_mul]
      simp only [evalOp_ref, evalOp_constNat, BlockState.setReg_same, BlockState.setReg_ne_name,
        ne_eq, String.reduceEq, not_false_eq_true, BlockState.setReg_pids,
        Option.bind_eq_bind, Option.bind_some, hHdiv, Nat.div_one]; rfl))]
  -- stmt 8: o_offset = off_z*sqz + off_h*sqh = base
  rw [stepStmts.cons_some (stepStmt_assign_eq_some
    (show evalOp (Op.add NumericDType.nat Broadcast.nil (Op.mul NumericDType.nat Broadcast.nil (Op.ref TileDType.nat [] "off_z") (Op.constNat sqz)) (Op.mul NumericDType.nat Broadcast.nil (Op.ref TileDType.nat [] "off_h") (Op.constNat sqh))) _
        = some (Tile.scalar (s.pids 1 / H * sqz + s.pids 1 % H * sqh)) from by
      rw [evalOp_add, evalOp_mul, evalOp_mul]
      simp only [evalOp_ref, evalOp_constNat, BlockState.setReg_same, BlockState.setReg_ne_name,
        ne_eq, String.reduceEq, not_false_eq_true, BlockState.setReg_pids,
        Option.bind_eq_bind, Option.bind_some]; rfl))]
  -- stmt 9: Q_block_ptr
  rw [stepStmts.cons_some (stepStmt_assign_eq_some
    (aft3_makeBlockPtr_rowcol_eval Q (Op.ref TileDType.nat [] "q_offset") [N_CTX, ND] [BM, ND] [sqm, sqk]
      (Op.mul NumericDType.nat Broadcast.nil (Op.ref TileDType.nat [] "start_m") (Op.constNat BM)) _
      (s.pids 1 / H * sqz + s.pids 1 % H * sqh) (s.pids 0 * BM)
      (by rw [evalOp_ref]; simp [BlockState.setReg_ne_name, BlockState.setReg_same])
      (by rw [evalOp_mul]; simp only [evalOp_ref, evalOp_constNat, BlockState.setReg_ne_name,
            ne_eq, String.reduceEq, not_false_eq_true, BlockState.setReg_same, BlockState.setReg_pids,
            Option.bind_eq_bind, Option.bind_some]; rfl)))]
  -- stmt 10: V_block_ptr
  rw [stepStmts.cons_some (stepStmt_assign_eq_some
    (aft3_makeBlockPtrDyn_eval V (Op.ref TileDType.nat [] "v_offset") [NKV_CTX, ND] [BN, ND] [svk, svn] [0, 0] _
      (s.pids 1 / H * sqz + s.pids 1 % H * sqh)
      (by rw [evalOp_ref]; simp [BlockState.setReg_ne_name, BlockState.setReg_same])))]
  -- stmt 11: K_block_ptr
  rw [stepStmts.cons_some (stepStmt_assign_eq_some
    (aft3_makeBlockPtrDyn_eval K (Op.ref TileDType.nat [] "k_offset") [ND, NKV_CTX] [ND, BN] [skk, skn] [0, 0] _
      (s.pids 1 / H * sqz + s.pids 1 % H * sqh)
      (by rw [evalOp_ref]; simp [BlockState.setReg_ne_name, BlockState.setReg_same])))]
  -- stmt 12: O_block_ptr
  rw [stepStmts.cons_some (stepStmt_assign_eq_some
    (aft3_makeBlockPtr_rowcol_eval Out (Op.ref TileDType.nat [] "o_offset") [ROUND_CTX, ND] [BM, ND] [som, son]
      (Op.mul NumericDType.nat Broadcast.nil (Op.ref TileDType.nat [] "start_m") (Op.constNat BM)) _
      (s.pids 1 / H * sqz + s.pids 1 % H * sqh) (s.pids 0 * BM)
      (by rw [evalOp_ref]; simp [BlockState.setReg_ne_name, BlockState.setReg_same])
      (by rw [evalOp_mul]; simp only [evalOp_ref, evalOp_constNat, BlockState.setReg_ne_name,
            ne_eq, String.reduceEq, not_false_eq_true, BlockState.setReg_same, BlockState.setReg_pids,
            Option.bind_eq_bind, Option.bind_some]; rfl)))]
  -- stmt 13: offs_m
  rw [stepStmts.cons_some (stepStmt_assign_eq_some
    (show evalOp (Op.add NumericDType.nat Broadcast.scalarL (Op.mul NumericDType.nat Broadcast.nil (Op.ref TileDType.nat [] "start_m") (Op.constNat BM)) (Op.arange BM)) _
        = some (Tile.vec (fun r : Fin BM => s.pids 0 * BM + r.val)) from by
      rw [evalOp_add, evalOp_mul]
      simp only [evalOp_ref, evalOp_constNat, evalOp_arange, BlockState.setReg_ne_name,
        ne_eq, String.reduceEq, not_false_eq_true, BlockState.setReg_same, BlockState.setReg_pids,
        Option.bind_eq_bind, Option.bind_some]
      refine congrArg some ?_; ext idx
      simp only [Tile.bop_data, Tile.scalar_data, Tile.vec_data, Broadcast.leftIndex,
        Broadcast.rightIndex, NumericDType.add, NumericDType.mul]))]
  -- stmt 14: m_ptrs
  rw [stepStmts.cons_some (stepStmt_assign_eq_some
    (show evalOp (Op.ptrAdd Broadcast.scalarL (Op.ptrBase M) (Op.add NumericDType.nat Broadcast.scalarL (Op.mul NumericDType.nat Broadcast.nil (Op.ref TileDType.nat [] "off_hz") (Op.constNat ROUND_CTX)) (Op.ref TileDType.nat [BM] "offs_m"))) _
        = some (Tile.ptrAdd Broadcast.scalarL (Tile.scalar (M.cast, (0 : Nat)))
            (Tile.bop NumericDType.nat.add Broadcast.scalarL (Tile.scalar (s.pids 1 * ROUND_CTX))
              (Tile.vec (fun r : Fin BM => s.pids 0 * BM + r.val)))) from by
      rw [aft3_evalOp_ptrAdd, evalOp_add, evalOp_mul]
      simp only [evalOp_ref, evalOp_constNat, aft3_evalOp_ptrBase, BlockState.setReg_ne_name,
        ne_eq, String.reduceEq, not_false_eq_true, BlockState.setReg_same, BlockState.setReg_pids,
        Option.bind_eq_bind, Option.bind_some]; rfl))]
  -- stmt 15: l_ptrs
  rw [stepStmts.cons_some (stepStmt_assign_eq_some
    (show evalOp (Op.ptrAdd Broadcast.scalarL (Op.ptrBase L) (Op.add NumericDType.nat Broadcast.scalarL (Op.mul NumericDType.nat Broadcast.nil (Op.ref TileDType.nat [] "off_hz") (Op.constNat ROUND_CTX)) (Op.ref TileDType.nat [BM] "offs_m"))) _
        = some (Tile.ptrAdd Broadcast.scalarL (Tile.scalar (L.cast, (0 : Nat)))
            (Tile.bop NumericDType.nat.add Broadcast.scalarL (Tile.scalar (s.pids 1 * ROUND_CTX))
              (Tile.vec (fun r : Fin BM => s.pids 0 * BM + r.val)))) from by
      rw [aft3_evalOp_ptrAdd, evalOp_add, evalOp_mul]
      simp only [evalOp_ref, evalOp_constNat, aft3_evalOp_ptrBase, BlockState.setReg_ne_name,
        ne_eq, String.reduceEq, not_false_eq_true, BlockState.setReg_same, BlockState.setReg_pids,
        Option.bind_eq_bind, Option.bind_some]; rfl))]
  rw [stepStmts.nil]
  refine ⟨_, rfl, ?_, ?_, ?_, ?_, ?_, ?_, ?_, ?_, ?_, ?_, ?_⟩
  · simp only [BlockState.setReg_pids]
  · funext rg o; simp only [BlockState.setReg_mem]
  · funext rg o; simp only [BlockState.setReg_undef]
  · simp only [BlockState.setReg_ne_name, ne_eq, String.reduceEq, not_false_eq_true,
      BlockState.setReg_same]
  · simp only [BlockState.setReg_ne_name, ne_eq, String.reduceEq, not_false_eq_true,
      BlockState.setReg_same, BlockState.setReg_pids]
  · simp only [BlockState.setReg_ne_name, ne_eq, String.reduceEq, not_false_eq_true,
      BlockState.setReg_same]
  · simp only [BlockState.setReg_ne_name, ne_eq, String.reduceEq, not_false_eq_true,
      BlockState.setReg_same]
  · simp only [BlockState.setReg_ne_name, ne_eq, String.reduceEq, not_false_eq_true,
      BlockState.setReg_same]
  · simp only [BlockState.setReg_ne_name, ne_eq, String.reduceEq, not_false_eq_true,
      BlockState.setReg_same]
  · simp only [BlockState.setReg_ne_name, ne_eq, String.reduceEq, not_false_eq_true,
      BlockState.setReg_same, BlockState.setReg_pids]
  · simp only [BlockState.setReg_ne_name, ne_eq, String.reduceEq, not_false_eq_true,
      BlockState.setReg_same, BlockState.setReg_pids]

/-- The 3 general `INIT` then-branch statements step `m_i = ⊥`, `l_i = 1`, `acc = 0`. -/
theorem aft3_init_stepsG (s : BlockState) (BM ND : Nat) :
    stepStmts [Stmt.assign TileDType.real [BM] "m_i" ((Op.add NumericDType.real Broadcast.scalarR (Op.full [BM] (Op.const 0)) Op.negInf)),
        Stmt.assign TileDType.real [BM] "l_i" ((Op.add NumericDType.real Broadcast.scalarR (Op.full [BM] (Op.const 0)) (Op.const 1.0))),
        Stmt.assign TileDType.real [BM, ND] "acc" (Op.full [BM, ND] (Op.const 0))] s
      = some (((s.setReg "m_i" .real [BM] ⟨fun _ : TileIndex [BM] => (⊥ : WithBot ℝ)⟩).setReg
          "l_i" .real [BM] ⟨fun _ : TileIndex [BM] => some (1 : ℝ)⟩).setReg
          "acc" .real [BM, ND] ⟨fun _ : TileIndex [BM, ND] => some (0 : ℝ)⟩) := by
  rw [stepStmts.cons_some (stepStmt_assign_eq_some
    (show evalOp (Op.add NumericDType.real Broadcast.scalarR (Op.full [BM] (Op.const 0)) Op.negInf) s
        = some (⟨fun _ : TileIndex [BM] => (⊥ : WithBot ℝ)⟩ : Tile .real [BM]) from by
      rw [evalOp_add]
      simp only [evalOp_full, evalOp_const, evalOp_negInf, Option.bind_eq_bind, Option.bind_some]
      refine congrArg some ?_; ext idx
      simp only [Tile.bop_data, Tile.scalar_data, Broadcast.leftIndex, Broadcast.rightIndex,
        NumericDType.add, WithBot.realAdd, Option.map₂, Option.bind, Option.map]; rfl))]
  rw [stepStmts.cons_some (stepStmt_assign_eq_some
    (show evalOp (Op.add NumericDType.real Broadcast.scalarR (Op.full [BM] (Op.const 0)) (Op.const 1.0)) _
        = some (⟨fun _ : TileIndex [BM] => some (1 : ℝ)⟩ : Tile .real [BM]) from by
      rw [evalOp_add]
      simp only [evalOp_full, evalOp_const, Option.bind_eq_bind, Option.bind_some]
      refine congrArg some ?_; ext idx
      simp only [Tile.bop_data, Tile.scalar_data, Broadcast.leftIndex, Broadcast.rightIndex,
        NumericDType.add, WithBot.realAdd, Option.map₂, Option.bind, Option.map]
      refine congrArg some ?_; norm_num))]
  rw [stepStmts.cons_some (stepStmt_assign_eq_some
    (show evalOp (Op.full [BM, ND] (Op.const 0)) _
        = some (⟨fun _ : TileIndex [BM, ND] => some (0 : ℝ)⟩ : Tile .real [BM, ND]) from by
      simp [evalOp_full, evalOp_const]))]
  rw [stepStmts.nil]

set_option maxHeartbeats 1600000 in
/-- The 3 general `INIT` ELSE-branch (`INIT=False` resume) statements load
`m_i = M[…]`, `l_i = L[…]`, `acc = Out[…]` from the input buffers via `m_ptrs`,
`l_ptrs`, `O_block_ptr`. Case-4 analogue of `aft3_init_stepsG`. -/
theorem aft3_load_stepsG (s : BlockState) (M Out L : RegionName)
    (BM ND base som son ROUND_CTX : Nat)
    (hM : s.regs .ptr [BM] "m_ptrs" = some
      (Tile.ptrAdd Broadcast.scalarL (Tile.scalar (M.cast, (0 : Nat)))
        (Tile.bop NumericDType.nat.add Broadcast.scalarL (Tile.scalar (s.pids 1 * ROUND_CTX))
          (Tile.vec (fun r : Fin BM => s.pids 0 * BM + r.val)))))
    (hL : s.regs .ptr [BM] "l_ptrs" = some
      (Tile.ptrAdd Broadcast.scalarL (Tile.scalar (L.cast, (0 : Nat)))
        (Tile.bop NumericDType.nat.add Broadcast.scalarL (Tile.scalar (s.pids 1 * ROUND_CTX))
          (Tile.vec (fun r : Fin BM => s.pids 0 * BM + r.val)))))
    (hO : s.regs .blockPtr [BM, ND] "O_block_ptr" = some
      (⟨fun _ : TileIndex [BM, ND] =>
        { region := Out, baseOffset := base, parentShape := [ROUND_CTX, ND],
          blockShape := [BM, ND], strides := [som, son], offsets := [s.pids 0 * BM, 0] }⟩)) :
    stepStmts [Stmt.assign TileDType.real [BM] "m_i" (Op.load TileDType.real (MemAccess.ptr (Op.ref TileDType.ptr [BM] "m_ptrs")) MaskOpt.none),
        Stmt.assign TileDType.real [BM] "l_i" (Op.load TileDType.real (MemAccess.ptr (Op.ref TileDType.ptr [BM] "l_ptrs")) MaskOpt.none),
        Stmt.assign TileDType.real [BM, ND] "acc" (Op.load TileDType.real (MemAccess.blockPtr (Op.ref TileDType.blockPtr [BM, ND] "O_block_ptr") []) MaskOpt.none .unspecified)] s
      = some (((s.setReg "m_i" .real [BM] ⟨fun r : TileIndex [BM] =>
            some (s.readMem M (s.pids 1 * ROUND_CTX + (s.pids 0 * BM + r.1.val)))⟩).setReg
          "l_i" .real [BM] ⟨fun r : TileIndex [BM] =>
            some (s.readMem L (s.pids 1 * ROUND_CTX + (s.pids 0 * BM + r.1.val)))⟩).setReg
          "acc" .real [BM, ND] ⟨fun idx : TileIndex [BM, ND] =>
            some (s.readMem Out (base + (s.pids 0 * BM + idx.1.val) * som + idx.2.1.val * son))⟩) := by
  rw [stepStmts.cons_some (stepStmt_assign_eq_some
    (show evalOp (Op.load TileDType.real (MemAccess.ptr (Op.ref TileDType.ptr [BM] "m_ptrs")) MaskOpt.none) s
        = some ⟨fun r : TileIndex [BM] => some (s.readMem M (s.pids 1 * ROUND_CTX + (s.pids 0 * BM + r.1.val)))⟩ from by
      have hp : evalOp (Op.ref TileDType.ptr [BM] "m_ptrs") s = some
          (Tile.ptrAdd Broadcast.scalarL (Tile.scalar (M.cast, (0 : Nat)))
            (Tile.bop NumericDType.nat.add Broadcast.scalarL (Tile.scalar (s.pids 1 * ROUND_CTX))
              (Tile.vec (fun r : Fin BM => s.pids 0 * BM + r.val)))) := by
        rw [evalOp_ref]; exact hM
      simp only [evalOp, hp]
      refine congrArg some ?_
      ext r
      simp [Tile.ptrAdd_data, Tile.scalar_data, Tile.bop_data, Tile.vec_data,
        Broadcast.leftIndex, Broadcast.rightIndex, BlockState.readMemValue_real,
        NumericDType.add, Nat.zero_add]))]
  rw [stepStmts.cons_some (stepStmt_assign_eq_some
    (show evalOp (Op.load TileDType.real (MemAccess.ptr (Op.ref TileDType.ptr [BM] "l_ptrs")) MaskOpt.none) _
        = some ⟨fun r : TileIndex [BM] => some (s.readMem L (s.pids 1 * ROUND_CTX + (s.pids 0 * BM + r.1.val)))⟩ from by
      have hp : evalOp (Op.ref TileDType.ptr [BM] "l_ptrs")
          (s.setReg "m_i" .real [BM] ⟨fun r : TileIndex [BM] =>
            some (s.readMem M (s.pids 1 * ROUND_CTX + (s.pids 0 * BM + r.1.val)))⟩) = some
          (Tile.ptrAdd Broadcast.scalarL (Tile.scalar (L.cast, (0 : Nat)))
            (Tile.bop NumericDType.nat.add Broadcast.scalarL (Tile.scalar (s.pids 1 * ROUND_CTX))
              (Tile.vec (fun r : Fin BM => s.pids 0 * BM + r.val)))) := by
        rw [evalOp_ref]
        simp only [BlockState.setReg_ne_name, ne_eq, String.reduceEq, not_false_eq_true,
          BlockState.setReg_pids]
        exact hL
      simp only [evalOp, hp, BlockState.setReg_pids]
      refine congrArg some ?_
      ext r
      simp [Tile.ptrAdd_data, Tile.scalar_data, Tile.bop_data, Tile.vec_data,
        Broadcast.leftIndex, Broadcast.rightIndex, BlockState.readMemValue_real,
        NumericDType.add, Nat.zero_add, BlockState.setReg_readMem]))]
  rw [stepStmts.cons_some (stepStmt_assign_eq_some
    (show evalOp (Op.load TileDType.real (MemAccess.blockPtr (Op.ref TileDType.blockPtr [BM, ND] "O_block_ptr") []) MaskOpt.none .unspecified) _
        = some ⟨fun idx : TileIndex [BM, ND] =>
            some (s.readMem Out (base + (s.pids 0 * BM + idx.1.val) * som + idx.2.1.val * son))⟩ from by
      refine (aft3_load_v_eval Out base ROUND_CTX ND BM ND som son (s.pids 0 * BM)
        (Op.ref TileDType.blockPtr [BM, ND] "O_block_ptr") _ ?_).trans ?_
      · rw [evalOp_ref]
        simp only [BlockState.setReg_ne_name, ne_eq, String.reduceEq, not_false_eq_true]
        exact hO
      · refine congrArg some ?_
        ext idx
        simp [BlockState.setReg_readMem]))]
  rw [stepStmts.nil]

set_option maxHeartbeats 1600000 in
set_option maxRecDepth 8000 in
/-- **General preLoop execution.** Establishes `attnInvariantG … 0` for any case
`keep`, under the stride-regime equalities and `0 < ND`. -/
theorem aft3PreLoop_evalG
    (Q K V M Out L : RegionName) (sm_scale : ℝ)
    (sqz sqh sqm sqk skz skh skn skk svz svh svk svn soz soh som son
      H H_KV N_CTX ROUND_CTX NKV_CTX off size BM ND BN : Nat) (s : BlockState)
    (hND : 0 < ND) (hH : 0 < H) (hHKV : H_KV = H)
    (hskz : skz = sqz) (hskh : skh = sqh) (hsvz : svz = sqz) (hsvh : svh = sqh)
    (hsoz : soz = sqz) (hsoh : soh = sqh)
    (keep : Fin BM → Fin NKV_CTX → Prop) [∀ i j, Decidable (keep i j)]
    (hundef : ∀ rg o, s.undef rg o = 0) :
    ∃ s', stepStmts (aft3PreLoopG Q K V M Out L sm_scale sqz sqh sqm sqk skz skh skn skk svz svh svk svn soz soh som son H H_KV N_CTX ROUND_CTX NKV_CTX off size BM ND BN) s = some s'
      ∧ attnInvariantG Q K V M Out L s (s.pids 1 / H * sqz + s.pids 1 % H * sqh) BM ND NKV_CTX BN sqm sqk skn skk svk svn som son ROUND_CTX hND (sm_scale * 1.4426950408889634) keep 0 s' := by
  obtain ⟨s11, h11, hpids, hmem, huf, hstart, hoffhz, hQp, hKp, hVp, hOp, hMptr, hLptr⟩ :=
    aft3PreLoopScalarsG_eval Q K V M Out L sm_scale sqz sqh sqm sqk skz skh skn skk svz svh svk svn soz soh som son H H_KV N_CTX ROUND_CTX NKV_CTX off size BM ND BN s hH hHKV hskz hskh hsvz hsvh hsoz hsoh
  rw [show aft3PreLoopG Q K V M Out L sm_scale sqz sqh sqm sqk skz skh skn skk svz svh svk svn soz soh som son H H_KV N_CTX ROUND_CTX NKV_CTX off size BM ND BN
      = aft3PreLoopScalarsG Q K V M Out L sm_scale sqz sqh sqm sqk skz skh skn skk svz svh svk svn soz soh som son H H_KV N_CTX ROUND_CTX NKV_CTX off size BM ND BN ++ (aft3PreLoopG Q K V M Out L sm_scale sqz sqh sqm sqk skz skh skn skk svz svh svk svn soz soh som son H H_KV N_CTX ROUND_CTX NKV_CTX off size BM ND BN).drop 16 from by
    rw [aft3PreLoopScalarsG]; rw [List.take_append_drop]]
  rw [stepStmts.append_some h11]
  rw [show (aft3PreLoopG Q K V M Out L sm_scale sqz sqh sqm sqk skz skh skn skk svz svh svk svn soz soh som son H H_KV N_CTX ROUND_CTX NKV_CTX off size BM ND BN).drop 16
      = [ Stmt.ifThenElse (Op.ne ComparableDType.nat Broadcast.nil (Op.constNat 1) (Op.constNat 0)) [Stmt.assign TileDType.real [BM] "m_i" ((Op.add NumericDType.real Broadcast.scalarR (Op.full [BM] (Op.const 0)) Op.negInf)), Stmt.assign TileDType.real [BM] "l_i" ((Op.add NumericDType.real Broadcast.scalarR (Op.full [BM] (Op.const 0)) (Op.const 1.0))), Stmt.assign TileDType.real [BM, ND] "acc" (Op.full [BM, ND] (Op.const 0))] [Stmt.assign TileDType.real [BM] "m_i" (Op.load TileDType.real (MemAccess.ptr (Op.ref TileDType.ptr [BM] "m_ptrs")) MaskOpt.none), Stmt.assign TileDType.real [BM] "l_i" (Op.load TileDType.real (MemAccess.ptr (Op.ref TileDType.ptr [BM] "l_ptrs")) MaskOpt.none), Stmt.assign TileDType.real [BM, ND] "acc" (Op.load TileDType.real (MemAccess.blockPtr (Op.ref TileDType.blockPtr [BM, ND] "O_block_ptr") []) MaskOpt.none .unspecified)],
          Stmt.assign TileDType.real [] "qk_scale" (Op.mul NumericDType.real Broadcast.nil (Op.const sm_scale) (Op.const 1.0)),
          Stmt.assign TileDType.real [] "qk_scale" (Op.mul NumericDType.real Broadcast.nil (Op.ref TileDType.real [] "qk_scale") (Op.const 1.4426950408889634)),
          Stmt.ifThenElse (Op.ne ComparableDType.nat Broadcast.nil (Op.constNat 1) (Op.constNat 0)) [Stmt.assign TileDType.real [BM, ND] "q" (Op.load TileDType.real (MemAccess.blockPtr (Op.ref TileDType.blockPtr [BM, ND] "Q_block_ptr") []) MaskOpt.none .unspecified)] [Stmt.assign TileDType.real [BM, ND] "q" (Op.load TileDType.real (MemAccess.blockPtr (Op.ref TileDType.blockPtr [BM, ND] "Q_block_ptr") [0, 1]) MaskOpt.none)] ] from by rfl]
  rw [stepStmts.cons_some
    (show stepStmt _ s11 = some _ from by
      rw [aft3_ifThenElse_true (aft3_ne_one_zero_true s11), aft3_init_stepsG s11 BM ND])]
  rw [stepStmts.cons_some (stepStmt_assign_eq_some
    (show evalOp (Op.mul NumericDType.real Broadcast.nil (Op.const sm_scale) (Op.const 1.0)) _
        = some (Tile.scalar (some (sm_scale * 1.0))) from by
      rw [evalOp_mul]
      simp only [evalOp_const, Option.bind_eq_bind, Option.bind_some]
      refine congrArg some (congrArg Tile.scalar ?_)
      simp only [NumericDType.mul, WithBot.realMul, Option.map₂, Option.bind, Option.map]))]
  rw [stepStmts.cons_some (stepStmt_assign_eq_some
    (show evalOp (Op.mul NumericDType.real Broadcast.nil (Op.ref TileDType.real [] "qk_scale") (Op.const 1.4426950408889634)) _
        = some (Tile.scalar (some (sm_scale * 1.4426950408889634))) from by
      rw [evalOp_mul]
      simp only [evalOp_ref, evalOp_const, BlockState.setReg_same, Option.bind_eq_bind,
        Option.bind_some]
      refine congrArg some (congrArg Tile.scalar ?_)
      simp only [NumericDType.mul, WithBot.realMul, Option.map₂, Option.bind, Option.map]
      refine congrArg some ?_; norm_num))]
  rw [stepStmts.cons_some
    (show stepStmt _ _ = some _ from by
      rw [aft3_ifThenElse_true (aft3_ne_one_zero_true _)]
      rw [stepStmts.cons_some (stepStmt_assign_eq_some
        (aft3_load_v_eval Q (s.pids 1 / H * sqz + s.pids 1 % H * sqh) N_CTX ND BM ND sqm sqk (s.pids 0 * BM)
          (Op.ref TileDType.blockPtr [BM, ND] "Q_block_ptr") _
          (by rw [evalOp_ref]
              simp only [BlockState.setReg_ne_name, ne_eq, String.reduceEq, not_false_eq_true,
                BlockState.setReg_same]
              exact hQp)))]
      rw [stepStmts.nil])]
  rw [stepStmts.nil]
  refine ⟨_, rfl, ?_⟩
  simp only [attnInvariantG]
  refine ⟨?_, ?_, ?_, ?_, ?_, ?_, ?_, ?_, ?_, ?_, ?_, ?_, ?_, ?_, ?_, ?_, ?_⟩
  · simp only [BlockState.setReg_pids]; exact hpids
  · trivial
  · exact Nat.zero_le _
  · simp only [BlockState.setReg_ne_name, ne_eq, String.reduceEq, not_false_eq_true,
      BlockState.setReg_same]
    refine congrArg some ?_
    refine Tile.ext (fun r => ?_)
    simp only [aft3RunningMaxG_zero]
  · simp only [BlockState.setReg_ne_name, ne_eq, String.reduceEq, not_false_eq_true,
      BlockState.setReg_same]
    refine congrArg some ?_
    refine Tile.ext (fun r => ?_)
    have hz : aft3StateBot1G (qTile3G s Q (s.pids 1 / H * sqz + s.pids 1 % H * sqh) BM ND sqm sqk) (kTile3G s K (s.pids 1 / H * sqz + s.pids 1 % H * sqh) NKV_CTX ND skn skk) (vTile3G s V (s.pids 1 / H * sqz + s.pids 1 % H * sqh) NKV_CTX ND svk svn) (keyScale3G (sm_scale * 1.4426950408889634) NKV_CTX) keep 0 r.1 ⟨0, hND⟩
          = (⊥, 1, 0) := by
      unfold aft3StateBot1G aft3KeysUptoG
      rw [show (List.finRange NKV_CTX).filterMap
            (fun j : Fin NKV_CTX => if j.val < 0 ∧ keep r.1 j
              then some (keyScale3G (sm_scale * 1.4426950408889634) NKV_CTX j * Finset.univ.sum (fun e : Fin ND =>
                    qTile3G s Q (s.pids 1 / H * sqz + s.pids 1 % H * sqh) BM ND sqm sqk (r.1, e, PUnit.unit) * kTile3G s K (s.pids 1 / H * sqz + s.pids 1 % H * sqh) NKV_CTX ND skn skk (j, e, PUnit.unit)), vTile3G s V (s.pids 1 / H * sqz + s.pids 1 % H * sqh) NKV_CTX ND svk svn (j, ⟨0, hND⟩, PUnit.unit))
              else none) = [] from by
        apply List.filterMap_eq_nil_iff.mpr; intro j _; simp]
      rfl
    simp only [hz]; rfl
  · simp only [BlockState.setReg_ne_name, ne_eq, String.reduceEq, not_false_eq_true,
      BlockState.setReg_same]
    refine congrArg some ?_
    refine Tile.ext (fun idx => ?_)
    have hz : aft3StateBot1G (qTile3G s Q (s.pids 1 / H * sqz + s.pids 1 % H * sqh) BM ND sqm sqk) (kTile3G s K (s.pids 1 / H * sqz + s.pids 1 % H * sqh) NKV_CTX ND skn skk) (vTile3G s V (s.pids 1 / H * sqz + s.pids 1 % H * sqh) NKV_CTX ND svk svn) (keyScale3G (sm_scale * 1.4426950408889634) NKV_CTX) keep 0 idx.1 idx.2.1
          = (⊥, 1, 0) := by
      unfold aft3StateBot1G aft3KeysUptoG
      rw [show (List.finRange NKV_CTX).filterMap
            (fun j : Fin NKV_CTX => if j.val < 0 ∧ keep idx.1 j
              then some (keyScale3G (sm_scale * 1.4426950408889634) NKV_CTX j * Finset.univ.sum (fun e : Fin ND =>
                    qTile3G s Q (s.pids 1 / H * sqz + s.pids 1 % H * sqh) BM ND sqm sqk (idx.1, e, PUnit.unit) * kTile3G s K (s.pids 1 / H * sqz + s.pids 1 % H * sqh) NKV_CTX ND skn skk (j, e, PUnit.unit)), vTile3G s V (s.pids 1 / H * sqz + s.pids 1 % H * sqh) NKV_CTX ND svk svn (j, idx.2.1, PUnit.unit))
              else none) = [] from by
        apply List.filterMap_eq_nil_iff.mpr; intro j _; simp]
      rfl
    simp only [hz]; rfl
  · simp only [BlockState.setReg_same]
    refine congrArg some ?_
    refine Tile.ext (fun idx => ?_)
    simp only [qTile3G, BlockState.setReg_readMem]
    refine congrArg some ?_
    rw [show s11.readMem Q (s.pids 1 / H * sqz + s.pids 1 % H * sqh + (s.pids 0 * BM + idx.1.val) * sqm + idx.2.1.val * sqk)
          = s.readMem Q (s.pids 1 / H * sqz + s.pids 1 % H * sqh + (s.pids 0 * BM + idx.1.val) * sqm + idx.2.1.val * sqk) from by
      unfold BlockState.readMem; rw [hmem]]
  · simp only [BlockState.setReg_ne_name, ne_eq, String.reduceEq, not_false_eq_true,
      BlockState.setReg_same]
  · simp only [BlockState.setReg_ne_name, ne_eq, String.reduceEq, not_false_eq_true,
      BlockState.setReg_same]
    rw [hstart]
  · simp only [BlockState.setReg_ne_name, ne_eq, String.reduceEq, not_false_eq_true,
      BlockState.setReg_same]
    rw [hoffhz]
  · simp only [BlockState.setReg_ne_name, ne_eq, String.reduceEq, not_false_eq_true,
      BlockState.setReg_same]
    rw [hKp]
  · simp only [BlockState.setReg_ne_name, ne_eq, String.reduceEq, not_false_eq_true,
      BlockState.setReg_same]
    rw [hVp]
  · simp only [BlockState.setReg_ne_name, ne_eq, String.reduceEq, not_false_eq_true,
      BlockState.setReg_same]
    rw [hMptr]
  · simp only [BlockState.setReg_ne_name, ne_eq, String.reduceEq, not_false_eq_true,
      BlockState.setReg_same]
    rw [hLptr]
  · simp only [BlockState.setReg_ne_name, ne_eq, String.reduceEq, not_false_eq_true,
      BlockState.setReg_same]
    rw [hOp]
  · intro rg o
    simp only [BlockState.setReg_undef]
    rw [huf]; exact hundef rg o
  · funext rg o
    simp only [BlockState.setReg_mem]
    rw [show s11.mem rg o = s.mem rg o from by rw [hmem]]

set_option maxHeartbeats 1600000 in
/-- **Case-4 (`INIT=False` resume) preLoop execution.** Establishes
`attnInvariantSeededG … (aft3Case4Seed …) 0` for any `keep`: the `INIT=0` else
branch loads the prior `m_i/l_i/acc` from `M/L/Out` (the resume seed), so the
loop-entry state is the seed. -/
theorem aft3PreLoop_evalG_init0
    (Q K V M Out L : RegionName) (sm_scale : ℝ)
    (sqz sqh sqm sqk skz skh skn skk svz svh svk svn soz soh som son
      H H_KV N_CTX ROUND_CTX NKV_CTX off size BM ND BN : Nat) (s : BlockState)
    (hND : 0 < ND) (hH : 0 < H) (hHKV : H_KV = H)
    (hskz : skz = sqz) (hskh : skh = sqh) (hsvz : svz = sqz) (hsvh : svh = sqh)
    (hsoz : soz = sqz) (hsoh : soh = sqh)
    (keep : Fin BM → Fin NKV_CTX → Prop) [∀ i j, Decidable (keep i j)]
    (hundef : ∀ rg o, s.undef rg o = 0) :
    ∃ s', stepStmts (aft3PreLoopG_init0 Q K V M Out L sm_scale sqz sqh sqm sqk skz skh skn skk svz svh svk svn soz soh som son H H_KV N_CTX ROUND_CTX NKV_CTX off size BM ND BN) s = some s'
      ∧ attnInvariantSeededG Q K V M Out L s (s.pids 1 / H * sqz + s.pids 1 % H * sqh) BM ND NKV_CTX BN sqm sqk skn skk svk svn som son ROUND_CTX hND (sm_scale * 1.4426950408889634) keep
          (aft3Case4Seed s M Out L (s.pids 1 / H * sqz + s.pids 1 % H * sqh) BM ND som son ROUND_CTX) 0 s' := by
  obtain ⟨s11, h11, hpids, hmem, huf, hstart, hoffhz, hQp, hKp, hVp, hOp, hMptr, hLptr⟩ :=
    aft3PreLoopScalarsG_eval Q K V M Out L sm_scale sqz sqh sqm sqk skz skh skn skk svz svh svk svn soz soh som son H H_KV N_CTX ROUND_CTX NKV_CTX off size BM ND BN s hH hHKV hskz hskh hsvz hsvh hsoz hsoh
  have hrm : ∀ (R : RegionName) (o : Nat), s11.readMem R o = s.readMem R o := by
    intro R o; unfold BlockState.readMem; rw [hmem]
  rw [show aft3PreLoopG_init0 Q K V M Out L sm_scale sqz sqh sqm sqk skz skh skn skk svz svh svk svn soz soh som son H H_KV N_CTX ROUND_CTX NKV_CTX off size BM ND BN
      = aft3PreLoopScalarsG Q K V M Out L sm_scale sqz sqh sqm sqk skz skh skn skk svz svh svk svn soz soh som son H H_KV N_CTX ROUND_CTX NKV_CTX off size BM ND BN ++ (aft3PreLoopG_init0 Q K V M Out L sm_scale sqz sqh sqm sqk skz skh skn skk svz svh svk svn soz soh som son H H_KV N_CTX ROUND_CTX NKV_CTX off size BM ND BN).drop 16 from by
    rw [show aft3PreLoopScalarsG Q K V M Out L sm_scale sqz sqh sqm sqk skz skh skn skk svz svh svk svn soz soh som son H H_KV N_CTX ROUND_CTX NKV_CTX off size BM ND BN
        = (aft3PreLoopG_init0 Q K V M Out L sm_scale sqz sqh sqm sqk skz skh skn skk svz svh svk svn soz soh som son H H_KV N_CTX ROUND_CTX NKV_CTX off size BM ND BN).take 16 from rfl]
    rw [List.take_append_drop]]
  rw [stepStmts.append_some h11]
  rw [show (aft3PreLoopG_init0 Q K V M Out L sm_scale sqz sqh sqm sqk skz skh skn skk svz svh svk svn soz soh som son H H_KV N_CTX ROUND_CTX NKV_CTX off size BM ND BN).drop 16
      = [ Stmt.ifThenElse (Op.ne ComparableDType.nat Broadcast.nil (Op.constNat 0) (Op.constNat 0)) [Stmt.assign TileDType.real [BM] "m_i" ((Op.add NumericDType.real Broadcast.scalarR (Op.full [BM] (Op.const 0)) Op.negInf)), Stmt.assign TileDType.real [BM] "l_i" ((Op.add NumericDType.real Broadcast.scalarR (Op.full [BM] (Op.const 0)) (Op.const 1.0))), Stmt.assign TileDType.real [BM, ND] "acc" (Op.full [BM, ND] (Op.const 0))] [Stmt.assign TileDType.real [BM] "m_i" (Op.load TileDType.real (MemAccess.ptr (Op.ref TileDType.ptr [BM] "m_ptrs")) MaskOpt.none), Stmt.assign TileDType.real [BM] "l_i" (Op.load TileDType.real (MemAccess.ptr (Op.ref TileDType.ptr [BM] "l_ptrs")) MaskOpt.none), Stmt.assign TileDType.real [BM, ND] "acc" (Op.load TileDType.real (MemAccess.blockPtr (Op.ref TileDType.blockPtr [BM, ND] "O_block_ptr") []) MaskOpt.none .unspecified)],
          Stmt.assign TileDType.real [] "qk_scale" (Op.mul NumericDType.real Broadcast.nil (Op.const sm_scale) (Op.const 1.0)),
          Stmt.assign TileDType.real [] "qk_scale" (Op.mul NumericDType.real Broadcast.nil (Op.ref TileDType.real [] "qk_scale") (Op.const 1.4426950408889634)),
          Stmt.ifThenElse (Op.ne ComparableDType.nat Broadcast.nil (Op.constNat 1) (Op.constNat 0)) [Stmt.assign TileDType.real [BM, ND] "q" (Op.load TileDType.real (MemAccess.blockPtr (Op.ref TileDType.blockPtr [BM, ND] "Q_block_ptr") []) MaskOpt.none .unspecified)] [Stmt.assign TileDType.real [BM, ND] "q" (Op.load TileDType.real (MemAccess.blockPtr (Op.ref TileDType.blockPtr [BM, ND] "Q_block_ptr") [0, 1]) MaskOpt.none)] ] from by rfl]
  rw [stepStmts.cons_some
    (show stepStmt _ s11 = some _ from by
      rw [aft3_ifThenElse_false (aft3_ne_zero_zero_false s11),
        aft3_load_stepsG s11 M Out L BM ND (s.pids 1 / H * sqz + s.pids 1 % H * sqh) som son ROUND_CTX
          (by rw [hpids]; exact hMptr) (by rw [hpids]; exact hLptr) (by rw [hpids]; exact hOp)])]
  rw [stepStmts.cons_some (stepStmt_assign_eq_some
    (show evalOp (Op.mul NumericDType.real Broadcast.nil (Op.const sm_scale) (Op.const 1.0)) _
        = some (Tile.scalar (some (sm_scale * 1.0))) from by
      rw [evalOp_mul]
      simp only [evalOp_const, Option.bind_eq_bind, Option.bind_some]
      refine congrArg some (congrArg Tile.scalar ?_)
      simp only [NumericDType.mul, WithBot.realMul, Option.map₂, Option.bind, Option.map]))]
  rw [stepStmts.cons_some (stepStmt_assign_eq_some
    (show evalOp (Op.mul NumericDType.real Broadcast.nil (Op.ref TileDType.real [] "qk_scale") (Op.const 1.4426950408889634)) _
        = some (Tile.scalar (some (sm_scale * 1.4426950408889634))) from by
      rw [evalOp_mul]
      simp only [evalOp_ref, evalOp_const, BlockState.setReg_same, Option.bind_eq_bind,
        Option.bind_some]
      refine congrArg some (congrArg Tile.scalar ?_)
      simp only [NumericDType.mul, WithBot.realMul, Option.map₂, Option.bind, Option.map]
      refine congrArg some ?_; norm_num))]
  rw [stepStmts.cons_some
    (show stepStmt _ _ = some _ from by
      rw [aft3_ifThenElse_true (aft3_ne_one_zero_true _)]
      rw [stepStmts.cons_some (stepStmt_assign_eq_some
        (aft3_load_v_eval Q (s.pids 1 / H * sqz + s.pids 1 % H * sqh) N_CTX ND BM ND sqm sqk (s.pids 0 * BM)
          (Op.ref TileDType.blockPtr [BM, ND] "Q_block_ptr") _
          (by rw [evalOp_ref]
              simp only [BlockState.setReg_ne_name, ne_eq, String.reduceEq, not_false_eq_true,
                BlockState.setReg_same]
              exact hQp)))]
      rw [stepStmts.nil])]
  rw [stepStmts.nil]
  refine ⟨_, rfl, ?_⟩
  simp only [attnInvariantSeededG]
  refine ⟨?_, ?_, ?_, ?_, ?_, ?_, ?_, ?_, ?_, ?_, ?_, ?_, ?_, ?_, ?_, ?_, ?_⟩
  · simp only [BlockState.setReg_pids]; exact hpids
  · trivial
  · exact Nat.zero_le _
  · simp only [BlockState.setReg_ne_name, ne_eq, String.reduceEq, not_false_eq_true,
      BlockState.setReg_same]
    refine congrArg some ?_
    refine Tile.ext (fun r => ?_)
    simp only [aft3StateSeededG_zero, aft3Case4Seed, mlRow3G, outLane3G, hpids, hrm]
    rfl
  · simp only [BlockState.setReg_ne_name, ne_eq, String.reduceEq, not_false_eq_true,
      BlockState.setReg_same]
    refine congrArg some ?_
    refine Tile.ext (fun r => ?_)
    simp only [aft3StateSeededG_zero, aft3Case4Seed, mlRow3G, outLane3G, hpids, hrm]
    rfl
  · simp only [BlockState.setReg_ne_name, ne_eq, String.reduceEq, not_false_eq_true,
      BlockState.setReg_same]
    refine congrArg some ?_
    refine Tile.ext (fun idx => ?_)
    simp only [aft3StateSeededG_zero, aft3Case4Seed, mlRow3G, outLane3G, hpids, hrm]
    rfl
  · simp only [BlockState.setReg_same]
    refine congrArg some ?_
    refine Tile.ext (fun idx => ?_)
    simp only [qTile3G, BlockState.setReg_readMem]
    refine congrArg some ?_
    rw [show s11.readMem Q (s.pids 1 / H * sqz + s.pids 1 % H * sqh + (s.pids 0 * BM + idx.1.val) * sqm + idx.2.1.val * sqk)
          = s.readMem Q (s.pids 1 / H * sqz + s.pids 1 % H * sqh + (s.pids 0 * BM + idx.1.val) * sqm + idx.2.1.val * sqk) from by
      unfold BlockState.readMem; rw [hmem]]
  · simp only [BlockState.setReg_ne_name, ne_eq, String.reduceEq, not_false_eq_true,
      BlockState.setReg_same]
  · simp only [BlockState.setReg_ne_name, ne_eq, String.reduceEq, not_false_eq_true,
      BlockState.setReg_same]
    rw [hstart]
  · simp only [BlockState.setReg_ne_name, ne_eq, String.reduceEq, not_false_eq_true,
      BlockState.setReg_same]
    rw [hoffhz]
  · simp only [BlockState.setReg_ne_name, ne_eq, String.reduceEq, not_false_eq_true,
      BlockState.setReg_same]
    rw [hKp]
  · simp only [BlockState.setReg_ne_name, ne_eq, String.reduceEq, not_false_eq_true,
      BlockState.setReg_same]
    rw [hVp]
  · simp only [BlockState.setReg_ne_name, ne_eq, String.reduceEq, not_false_eq_true,
      BlockState.setReg_same]
    rw [hMptr]
  · simp only [BlockState.setReg_ne_name, ne_eq, String.reduceEq, not_false_eq_true,
      BlockState.setReg_same]
    rw [hLptr]
  · simp only [BlockState.setReg_ne_name, ne_eq, String.reduceEq, not_false_eq_true,
      BlockState.setReg_same]
    rw [hOp]
  · intro rg o
    simp only [BlockState.setReg_undef]
    rw [huf]; exact hundef rg o
  · funext rg o
    simp only [BlockState.setReg_mem]
    rw [show s11.mem rg o = s.mem rg o from by rw [hmem]]

/-! ## General mask reconciliation (cases 1/2) -/

/-- **General case-1 mask reconciliation.** At `SN = c·BN`, the lowered nat-mask
`aft3MaskCell1G` (`dist ∈ [0, size)`) equals `natSlidingWindowKeepG`. -/
theorem aft3MaskCell1G_eq_keep (SM off size BM BN c : Nat) (i : Fin BM) (jL : Fin BN)
    {NC : Nat} (hb : c * BN + jL.val < NC) :
    aft3MaskCell1G SM (c * BN) off size BM BN (i, jL, PUnit.unit)
      = decide (natSlidingWindowKeepG SM BM BN off size i (⟨c * BN + jL.val, hb⟩ : Fin NC)) := by
  unfold aft3MaskCell1G natSlidingWindowKeepG natDist3G ComparableDType.ge ComparableDType.lt
  have hjL : jL.val < BN := jL.isLt
  have hBN : 0 < BN := Nat.lt_of_le_of_lt (Nat.zero_le _) hjL
  have hmod : ((⟨c * BN + jL.val, hb⟩ : Fin NC).val) % BN = jL.val := by
    show (c * BN + jL.val) % BN = jL.val
    rw [Nat.mul_comm, Nat.mul_add_mod_self_left, Nat.mod_eq_of_lt hjL]
  have hdiv : ((⟨c * BN + jL.val, hb⟩ : Fin NC).val) / BN = c := by
    show (c * BN + jL.val) / BN = c
    rw [Nat.mul_comm, Nat.mul_add_div hBN, Nat.div_eq_of_lt hjL, Nat.add_zero]
  simp only [hmod, hdiv, Nat.zero_le, decide_true, Bool.true_and]

/-- **General case-2 mask reconciliation.** At `SN = c·BN`, the lowered nat-mask
`aft3MaskCell2G` (`dist ≥ size`) equals `natComplementSlidingWindowKeepG`. -/
theorem aft3MaskCell2G_eq_keep (SM off size BM BN c : Nat) (i : Fin BM) (jL : Fin BN)
    {NC : Nat} (hb : c * BN + jL.val < NC) :
    aft3MaskCell2G SM (c * BN) off size BM BN (i, jL, PUnit.unit)
      = decide (natComplementSlidingWindowKeepG SM BM BN off size i (⟨c * BN + jL.val, hb⟩ : Fin NC)) := by
  unfold aft3MaskCell2G natComplementSlidingWindowKeepG natDist3G ComparableDType.ge
  have hjL : jL.val < BN := jL.isLt
  have hBN : 0 < BN := Nat.lt_of_le_of_lt (Nat.zero_le _) hjL
  have hmod : ((⟨c * BN + jL.val, hb⟩ : Fin NC).val) % BN = jL.val := by
    show (c * BN + jL.val) % BN = jL.val
    rw [Nat.mul_comm, Nat.mul_add_mod_self_left, Nat.mod_eq_of_lt hjL]
  have hdiv : ((⟨c * BN + jL.val, hb⟩ : Fin NC).val) / BN = c := by
    show (c * BN + jL.val) / BN = c
    rw [Nat.mul_comm, Nat.mul_add_div hBN, Nat.div_eq_of_lt hjL, Nat.add_zero]
  simp only [hmod, hdiv]

/-! ## General step lemmas (cases 1/2/3) -/

set_option maxHeartbeats 4000000 in
set_option maxRecDepth 8000 in
/-- **General step lemma (case 1, sliding window).** Advances `attnInvariantKG …
natSlidingWindowKeepG` by one key block (`i → i + BN`). -/
theorem aft3_attn_step1G (Q K V M Out L : RegionName) (s0 : BlockState)
    (base BM ND NC BN sqm sqk skn skk svk svn som son ROUND_CTX off size : Nat)
    (hND : 0 < ND) (hBM : 0 < BM) (hBN : 0 < BN) (hBNdvd : BN ∣ NC) (sc : ℝ)
    (i : Nat) (s : BlockState) (hilt : i < NC) (himod : i % BN = 0)
    (hinv : attnInvariantKG Q K V M Out L s0 base BM ND NC BN sqm sqk skn skk svk svn som son ROUND_CTX hND sc
      (fun i j => natSlidingWindowKeepG (s0.pids 0) BM BN off size i j) i s) :
    ∃ s', stepStmts (aft3LoopBodyG sc off size BM ND BN) (s.setReg "start_n" .nat [] (Tile.scalar i)) = some s'
      ∧ attnInvariantKG Q K V M Out L s0 base BM ND NC BN sqm sqk skn skk svk svn som son ROUND_CTX hND sc
          (fun i j => natSlidingWindowKeepG (s0.pids 0) BM BN off size i j) (i + BN) s' := by
  obtain ⟨hpids, hmod, hile, hmi, hli, hacc, hq, hqs, hsm, hoff, hKp, hVp, hMptr, hLptr, hOp, hundef, hmem⟩ := hinv
  have hBNi : BN ∣ i := Nat.dvd_of_mod_eq_zero himod
  set c := i / BN with hc_def
  have hi : i = c * BN := by rw [hc_def, Nat.div_mul_cancel hBNi]
  have hcBN_succ : (c + 1) * BN = i + BN := by rw [Nat.succ_mul, ← hi]
  have hc1 : (c + 1) * BN ≤ NC := by
    rw [hcBN_succ]
    obtain ⟨k, hk⟩ := hBNdvd
    have hck : c < k := by
      have hlt : c * BN < k * BN := by
        rw [← hi]; calc i < NC := hilt
          _ = k * BN := by rw [hk, Nat.mul_comm]
      exact lt_of_mul_lt_mul_right hlt (Nat.zero_le BN)
    have hle : i + BN ≤ k * BN := by
      rw [hi, ← Nat.succ_mul]; exact Nat.mul_le_mul_right BN hck
    rw [hk, Nat.mul_comm]; exact hle
  set qT := qTile3G s0 Q base BM ND sqm sqk with hqT
  set kT := kTile3G s0 K base NC ND skn skk with hkT
  set vT := vTile3G s0 V base NC ND svk svn with hvT
  set ks := keyScale3G sc NC with hks
  set kp : Fin BM → Fin NC → Prop := fun i j => natSlidingWindowKeepG (s0.pids 0) BM BN off size i j with hkp
  obtain ⟨sF, hchain, hpidsF, hmemF, hundefF, hqF, hqsF, hsmF, hKpF, hVpF, hoffF, hMptrF, hLptrF, hOpF,
      qkT, rmaxT, mijT, alphaT, lijT, pT, pmT, acc1T,
      hqkData, hrm, hmijd, halphad, hpTd, hpmTd, hlijd, hacc1d, hmiF, hliF, haccF⟩ :=
    aft3LoopBodyG_steps (s.setReg "start_n" .nat [] (Tile.scalar i)) (s0.pids 0) i off size
      K V base base i i skk skn svk svn ND NC BM BN hBN
      (⟨fun idx : TileIndex [BM, ND] => some (qT idx)⟩)
      (⟨fun r : TileIndex [BM] => aft3RunningMaxG qT kT vT ks kp i r.1 ⟨0, hND⟩⟩)
      (⟨fun r : TileIndex [BM] => ((aft3StateBotKG qT kT vT ks kp i r.1 ⟨0, hND⟩).2.1 : ℝ)⟩)
      (⟨fun idx : TileIndex [BM, ND] => ((aft3StateBotKG qT kT vT ks kp i idx.1 idx.2.1).2.2 : ℝ)⟩)
      (⟨fun idx : TileIndex [ND, BN] => some ((s.setReg "start_n" .nat [] (Tile.scalar i)).readMem K (base + idx.1.val * skk + (i + idx.2.1.val) * skn))⟩)
      (⟨fun idx : TileIndex [BN, ND] => some ((s.setReg "start_n" .nat [] (Tile.scalar i)).readMem V (base + (i + idx.1.val) * svk + idx.2.1.val * svn))⟩)
      sc
      (by rw [BlockState.setReg_ne_name _ _ _ _ _ _ _ _ (by decide)]; exact hsm)
      (by simp [BlockState.setReg_same])
      (by rw [BlockState.setReg_ne_name _ _ _ _ _ _ _ _ (by decide)]; exact hq)
      (by rw [BlockState.setReg_ne_name _ _ _ _ _ _ _ _ (by decide)]; exact hqs)
      (by rw [BlockState.setReg_ne_name _ _ _ _ _ _ _ _ (by decide)]; exact hmi)
      (by rw [BlockState.setReg_ne_name _ _ _ _ _ _ _ _ (by decide)]; exact hli)
      (by rw [BlockState.setReg_ne_name _ _ _ _ _ _ _ _ (by decide)]; exact hacc)
      (by rw [BlockState.setReg_ne_name _ _ _ _ _ _ _ _ (by decide)]; exact hKp)
      (by rw [BlockState.setReg_ne_name _ _ _ _ _ _ _ _ (by decide)]; exact hVp)
      (fun idx => rfl)
      (fun idx => rfl)
      (by intro rg o; rw [BlockState.setReg_undef]; exact hundef rg o)
  refine ⟨sF, hchain, ?_⟩
  have hrmemK : ∀ idx : TileIndex [ND, BN],
      (⟨fun idx : TileIndex [ND, BN] => some ((s.setReg "start_n" .nat [] (Tile.scalar i)).readMem K (base + idx.1.val * skk + (i + idx.2.1.val) * skn))⟩ : Tile .real [ND, BN]).data idx
        = some (s0.readMem K (base + idx.1.val * skk + (c * BN + idx.2.1.val) * skn)) := by
    intro idx
    simp only [BlockState.setReg_readMem]
    unfold BlockState.readMem; rw [hmem, hi]
  have hrmemV : ∀ idx : TileIndex [BN, ND],
      (⟨fun idx : TileIndex [BN, ND] => some ((s.setReg "start_n" .nat [] (Tile.scalar i)).readMem V (base + (i + idx.1.val) * svk + idx.2.1.val * svn))⟩ : Tile .real [BN, ND]).data idx
        = some (s0.readMem V (base + (c * BN + idx.1.val) * svk + idx.2.1.val * svn)) := by
    intro idx
    simp only [BlockState.setReg_readMem]
    unfold BlockState.readMem; rw [hmem, hi]
  set qtileF : Tile .real [BM, ND] := ⟨fun idx : TileIndex [BM, ND] => some (qT idx)⟩ with hqtileF
  -- mask reconciliation
  have hmc_row : ∀ (r : Fin BM) (jL : Fin BN), aft3MaskCell1G (s0.pids 0) i off size BM BN (r, jL, PUnit.unit)
      = decide (kp r ⟨c * BN + jL.val, aft3_block_idx_lt BN c NC jL.val jL.isLt hc1⟩) := by
    intro r jL
    have heq : aft3MaskCell1G (s0.pids 0) i off size BM BN (r, jL, PUnit.unit)
        = aft3MaskCell1G (s0.pids 0) (c * BN) off size BM BN (r, jL, PUnit.unit) := by rw [hi]
    rw [heq, aft3MaskCell1G_eq_keep (s0.pids 0) off size BM BN c r jL
      (aft3_block_idx_lt BN c NC jL.val jL.isLt hc1)]
  have hmicell : ∀ r : Fin BM,
      (⟨fun r : TileIndex [BM] => aft3RunningMaxG qT kT vT ks kp i r.1 ⟨0, hND⟩⟩ : Tile .real [BM]).data (r, PUnit.unit)
        = aft3RunningMaxG qT kT vT ks kp (c * BN) r ⟨0, hND⟩ := by
    intro r; simp only; rw [hi]
  have hmijcell : ∀ r : Fin BM, mijT.data (r, PUnit.unit)
      = aft3RunningMaxG qT kT vT ks kp ((c + 1) * BN) r ⟨0, hND⟩ := by
    intro r
    rw [hmijd]
    refine aft3_mij_reg_eq_maskedG s0 Q K V base BM ND NC sqm sqk skn skk svk svn sc BN c hBN hc1 r ⟨0, hND⟩ kp
      (fun jL => aft3MaskCell1G (s0.pids 0) i off size BM BN (r, jL, PUnit.unit))
      (fun jL => hmc_row r jL)
      qtileF (⟨fun idx : TileIndex [ND, BN] => some ((s.setReg "start_n" .nat [] (Tile.scalar i)).readMem K (base + idx.1.val * skk + (i + idx.2.1.val) * skn))⟩)
      (⟨fun r : TileIndex [BM] => aft3RunningMaxG qT kT vT ks kp i r.1 ⟨0, hND⟩⟩) rmaxT qkT
      hqtileF hrmemK ?_ ?_ ?_
    · intro jL; rw [hqkData]
    · rw [hmicell r]
    · exact hrm
  refine ⟨?_, ?_, ?_, ?_, ?_, ?_, ?_, ?_, ?_, ?_, ?_, ?_, ?_, ?_, ?_, ?_, ?_⟩
  · rw [hpidsF, BlockState.setReg_pids, hpids]
  · simp [Nat.add_mod, himod, Nat.mod_self]
  · rw [← hcBN_succ]; exact hc1
  · rw [hmiF]; refine congrArg some ?_; ext r
    rw [hmijcell r.1, hcBN_succ]
  · rw [hliF]; refine congrArg some ?_; refine Tile.ext (fun r => ?_)
    obtain ⟨r, ⟨⟩⟩ := r
    have hbr := aft3_denom_reg_eq_maskedG s0 Q K V base BM ND NC sqm sqk skn skk svk svn sc BN c hBN hc1 r ⟨0, hND⟩ kp
      (fun jL => aft3MaskCell1G (s0.pids 0) i off size BM BN (r, jL, PUnit.unit)) (fun jL => hmc_row r jL)
      qtileF (⟨fun idx : TileIndex [ND, BN] => some ((s.setReg "start_n" .nat [] (Tile.scalar i)).readMem K (base + idx.1.val * skk + (i + idx.2.1.val) * skn))⟩) qkT
      (⟨fun r : TileIndex [BM] => ((aft3StateBotKG qT kT vT ks kp i r.1 ⟨0, hND⟩).2.1 : ℝ)⟩)
      (⟨fun r : TileIndex [BM] => aft3RunningMaxG qT kT vT ks kp i r.1 ⟨0, hND⟩⟩)
      mijT alphaT pT pmT hqtileF hrmemK
      (fun jL => by rw [hqkData])
      (by simp only [hi]; rfl) (by simp only [hi]; rfl)
      (by rw [hmijcell r]) halphad hpTd
      (fun jL => by rw [hpmTd])
    show (Tile.bop NumericDType.real.add _ _ _).data _ = _
    rw [hlijd, hbr]
    show _ = ((aft3StateBotKG qT kT vT ks kp (i + BN) r ⟨0, hND⟩).2.1 : WithBot ℝ)
    rw [hcBN_succ.symm,
      show aft3StateBotKG qT kT vT ks kp ((c + 1) * BN) r ⟨0, hND⟩
        = aft3StateBotG qT kT vT ks kp ((c + 1) * BN) r ⟨0, hND⟩ from by
        unfold aft3StateBotKG; rw [if_neg (by rw [hcBN_succ]; omega)]]
    rfl
  · rw [haccF]; refine congrArg some ?_; refine Tile.ext (fun idx => ?_)
    obtain ⟨ir, id, ⟨⟩⟩ := idx
    have hbr := aft3_acc_reg_eq_maskedG s0 Q K V base BM ND NC sqm sqk skn skk svk svn sc BN c hBN hc1 ir id kp
      (fun jL => aft3MaskCell1G (s0.pids 0) i off size BM BN (ir, jL, PUnit.unit)) (fun jL => hmc_row ir jL)
      qtileF (⟨fun idx : TileIndex [ND, BN] => some ((s.setReg "start_n" .nat [] (Tile.scalar i)).readMem K (base + idx.1.val * skk + (i + idx.2.1.val) * skn))⟩)
      (⟨fun idx : TileIndex [BN, ND] => some ((s.setReg "start_n" .nat [] (Tile.scalar i)).readMem V (base + (i + idx.1.val) * svk + idx.2.1.val * svn))⟩)
      qkT pT pmT
      (⟨fun idx : TileIndex [BM, ND] => ((aft3StateBotKG qT kT vT ks kp i idx.1 idx.2.1).2.2 : ℝ)⟩)
      acc1T
      (⟨fun r : TileIndex [BM] => aft3RunningMaxG qT kT vT ks kp i r.1 ⟨0, hND⟩⟩)
      mijT alphaT hqtileF hrmemK hrmemV
      (fun jL => by rw [hqkData])
      (by simp only [hi]; rfl)
      (by simp only [hi, hqT, hkT, hvT, hks]
          exact aft3RunningMaxG_eq (qTile3G s0 Q base BM ND sqm sqk) (kTile3G s0 K base NC ND skn skk)
            (vTile3G s0 V base NC ND svk svn) (keyScale3G sc NC) kp (c * BN) ir ⟨0, hND⟩ id)
      (by rw [hmijcell ir]; exact aft3RunningMaxG_eq qT kT vT ks kp ((c + 1) * BN) ir ⟨0, hND⟩ id)
      halphad hacc1d hpTd
      (fun jL => by rw [hpmTd])
    show (Tile.bop NumericDType.real.add _ _ _).data _ = _
    rw [hbr]
    show _ = ((aft3StateBotKG qT kT vT ks kp (i + BN) ir id).2.2 : WithBot ℝ)
    rw [hcBN_succ.symm,
      show aft3StateBotKG qT kT vT ks kp ((c + 1) * BN) ir id
        = aft3StateBotG qT kT vT ks kp ((c + 1) * BN) ir id from by
        unfold aft3StateBotKG; rw [if_neg (by rw [hcBN_succ]; omega)]]
    rfl
  · rw [hqF]
  · rw [hqsF]
  · rw [hsmF]
  · rw [hoffF, BlockState.setReg_ne_name _ _ _ _ _ _ _ _ (by decide)]; exact hoff
  · rw [hKpF, show ((i + BN) : Nat) = i + BN from rfl]
  · rw [hVpF]
  · rw [hMptrF, BlockState.setReg_ne_name _ _ _ _ _ _ _ _ (by decide)]; exact hMptr
  · rw [hLptrF, BlockState.setReg_ne_name _ _ _ _ _ _ _ _ (by decide)]; exact hLptr
  · rw [hOpF, BlockState.setReg_ne_name _ _ _ _ _ _ _ _ (by decide)]; exact hOp
  · exact hundefF
  · rw [hmemF]; funext rg o; rw [BlockState.setReg_mem]; exact congrFun (congrFun hmem rg) o

/-- A resume seed with non-⊥ max is online-softmax-consistent: its `(denom, acc)`
factor as `pow2(-max)·L` / `pow2(-max)·T` with `L = denom·pow2(max)`, `T = acc·pow2(max)`. -/
theorem aft3_seed_consist {BM ND : Nat} (seed : Fin BM → Fin ND → WithBot ℝ × ℝ × ℝ)
    (i : Fin BM) (d : Fin ND) (hne : (seed i d).1 ≠ ⊥) :
    (seed i d).2.1 = ((seed i d).1.elim 0 (fun r => pow2 (-r))) * ((seed i d).2.1 * pow2 ((seed i d).1.unbotD 0))
  ∧ (seed i d).2.2 = ((seed i d).1.elim 0 (fun r => pow2 (-r))) * ((seed i d).2.2 * pow2 ((seed i d).1.unbotD 0)) := by
  obtain ⟨r, hr⟩ : ∃ r, (seed i d).1 = some r := Option.ne_none_iff_exists'.mp hne
  have hpp : pow2 (-r) * pow2 r = 1 := by rw [← pow2_add, neg_add_cancel, pow2_zero]
  refine ⟨?_, ?_⟩ <;>
  · rw [hr]
    show _ = pow2 (-r) * (_ * pow2 r)
    rw [mul_left_comm, hpp, mul_one]

set_option maxHeartbeats 4000000 in
set_option maxRecDepth 8000 in
/-- **Seeded step lemma (case 4, INIT=False resume + sliding window).** Advances
`attnInvariantSeededG` by one key block. Mirrors `aft3_attn_step1G`. -/
theorem aft3_attn_step1_seededG (Q K V M Out L : RegionName) (s0 : BlockState)
    (base BM ND NC BN sqm sqk skn skk svk svn som son ROUND_CTX off size : Nat)
    (hND : 0 < ND) (hBM : 0 < BM) (hBN : 0 < BN) (hBNdvd : BN ∣ NC) (sc : ℝ)
    (seed : Fin BM → Fin ND → WithBot ℝ × ℝ × ℝ) (hseednebot : ∀ i d, (seed i d).1 ≠ ⊥)
    (hseedfst : ∀ (r : Fin BM) (d d' : Fin ND), (seed r d).1 = (seed r d').1)
    (i : Nat) (s : BlockState) (hilt : i < NC) (himod : i % BN = 0)
    (hinv : attnInvariantSeededG Q K V M Out L s0 base BM ND NC BN sqm sqk skn skk svk svn som son ROUND_CTX hND sc
      (fun i j => natSlidingWindowKeepG (s0.pids 0) BM BN off size i j) seed i s) :
    ∃ s', stepStmts (aft3LoopBodyG sc off size BM ND BN) (s.setReg "start_n" .nat [] (Tile.scalar i)) = some s'
      ∧ attnInvariantSeededG Q K V M Out L s0 base BM ND NC BN sqm sqk skn skk svk svn som son ROUND_CTX hND sc
          (fun i j => natSlidingWindowKeepG (s0.pids 0) BM BN off size i j) seed (i + BN) s' := by
  obtain ⟨hpids, hmod, hile, hmi, hli, hacc, hq, hqs, hsm, hoff, hKp, hVp, hMptr, hLptr, hOp, hundef, hmem⟩ := hinv
  have hBNi : BN ∣ i := Nat.dvd_of_mod_eq_zero himod
  set c := i / BN with hc_def
  have hi : i = c * BN := by rw [hc_def, Nat.div_mul_cancel hBNi]
  have hcBN_succ : (c + 1) * BN = i + BN := by rw [Nat.succ_mul, ← hi]
  have hc1 : (c + 1) * BN ≤ NC := by
    rw [hcBN_succ]
    obtain ⟨k, hk⟩ := hBNdvd
    have hck : c < k := by
      have hlt : c * BN < k * BN := by
        rw [← hi]; calc i < NC := hilt
          _ = k * BN := by rw [hk, Nat.mul_comm]
      exact lt_of_mul_lt_mul_right hlt (Nat.zero_le BN)
    have hle : i + BN ≤ k * BN := by
      rw [hi, ← Nat.succ_mul]; exact Nat.mul_le_mul_right BN hck
    rw [hk, Nat.mul_comm]; exact hle
  set qT := qTile3G s0 Q base BM ND sqm sqk with hqT
  set kT := kTile3G s0 K base NC ND skn skk with hkT
  set vT := vTile3G s0 V base NC ND svk svn with hvT
  set ks := keyScale3G sc NC with hks
  set kp : Fin BM → Fin NC → Prop := fun i j => natSlidingWindowKeepG (s0.pids 0) BM BN off size i j with hkp
  obtain ⟨sF, hchain, hpidsF, hmemF, hundefF, hqF, hqsF, hsmF, hKpF, hVpF, hoffF, hMptrF, hLptrF, hOpF,
      qkT, rmaxT, mijT, alphaT, lijT, pT, pmT, acc1T,
      hqkData, hrm, hmijd, halphad, hpTd, hpmTd, hlijd, hacc1d, hmiF, hliF, haccF⟩ :=
    aft3LoopBodyG_steps (s.setReg "start_n" .nat [] (Tile.scalar i)) (s0.pids 0) i off size
      K V base base i i skk skn svk svn ND NC BM BN hBN
      (⟨fun idx : TileIndex [BM, ND] => some (qT idx)⟩)
      (⟨fun r : TileIndex [BM] => (aft3StateSeededG qT kT vT ks kp seed i r.1 ⟨0, hND⟩).1⟩)
      (⟨fun r : TileIndex [BM] => ((aft3StateSeededG qT kT vT ks kp seed i r.1 ⟨0, hND⟩).2.1 : ℝ)⟩)
      (⟨fun idx : TileIndex [BM, ND] => ((aft3StateSeededG qT kT vT ks kp seed i idx.1 idx.2.1).2.2 : ℝ)⟩)
      (⟨fun idx : TileIndex [ND, BN] => some ((s.setReg "start_n" .nat [] (Tile.scalar i)).readMem K (base + idx.1.val * skk + (i + idx.2.1.val) * skn))⟩)
      (⟨fun idx : TileIndex [BN, ND] => some ((s.setReg "start_n" .nat [] (Tile.scalar i)).readMem V (base + (i + idx.1.val) * svk + idx.2.1.val * svn))⟩)
      sc
      (by rw [BlockState.setReg_ne_name _ _ _ _ _ _ _ _ (by decide)]; exact hsm)
      (by simp [BlockState.setReg_same])
      (by rw [BlockState.setReg_ne_name _ _ _ _ _ _ _ _ (by decide)]; exact hq)
      (by rw [BlockState.setReg_ne_name _ _ _ _ _ _ _ _ (by decide)]; exact hqs)
      (by rw [BlockState.setReg_ne_name _ _ _ _ _ _ _ _ (by decide)]; exact hmi)
      (by rw [BlockState.setReg_ne_name _ _ _ _ _ _ _ _ (by decide)]; exact hli)
      (by rw [BlockState.setReg_ne_name _ _ _ _ _ _ _ _ (by decide)]; exact hacc)
      (by rw [BlockState.setReg_ne_name _ _ _ _ _ _ _ _ (by decide)]; exact hKp)
      (by rw [BlockState.setReg_ne_name _ _ _ _ _ _ _ _ (by decide)]; exact hVp)
      (fun idx => rfl)
      (fun idx => rfl)
      (by intro rg o; rw [BlockState.setReg_undef]; exact hundef rg o)
  refine ⟨sF, hchain, ?_⟩
  have hrmemK : ∀ idx : TileIndex [ND, BN],
      (⟨fun idx : TileIndex [ND, BN] => some ((s.setReg "start_n" .nat [] (Tile.scalar i)).readMem K (base + idx.1.val * skk + (i + idx.2.1.val) * skn))⟩ : Tile .real [ND, BN]).data idx
        = some (s0.readMem K (base + idx.1.val * skk + (c * BN + idx.2.1.val) * skn)) := by
    intro idx
    simp only [BlockState.setReg_readMem]
    unfold BlockState.readMem; rw [hmem, hi]
  have hrmemV : ∀ idx : TileIndex [BN, ND],
      (⟨fun idx : TileIndex [BN, ND] => some ((s.setReg "start_n" .nat [] (Tile.scalar i)).readMem V (base + (i + idx.1.val) * svk + idx.2.1.val * svn))⟩ : Tile .real [BN, ND]).data idx
        = some (s0.readMem V (base + (c * BN + idx.1.val) * svk + idx.2.1.val * svn)) := by
    intro idx
    simp only [BlockState.setReg_readMem]
    unfold BlockState.readMem; rw [hmem, hi]
  set qtileF : Tile .real [BM, ND] := ⟨fun idx : TileIndex [BM, ND] => some (qT idx)⟩ with hqtileF
  have hmc_row : ∀ (r : Fin BM) (jL : Fin BN), aft3MaskCell1G (s0.pids 0) i off size BM BN (r, jL, PUnit.unit)
      = decide (kp r ⟨c * BN + jL.val, aft3_block_idx_lt BN c NC jL.val jL.isLt hc1⟩) := by
    intro r jL
    have heq : aft3MaskCell1G (s0.pids 0) i off size BM BN (r, jL, PUnit.unit)
        = aft3MaskCell1G (s0.pids 0) (c * BN) off size BM BN (r, jL, PUnit.unit) := by rw [hi]
    rw [heq, aft3MaskCell1G_eq_keep (s0.pids 0) off size BM BN c r jL
      (aft3_block_idx_lt BN c NC jL.val jL.isLt hc1)]
  have hmicell : ∀ r : Fin BM,
      (⟨fun r : TileIndex [BM] => (aft3StateSeededG qT kT vT ks kp seed i r.1 ⟨0, hND⟩).1⟩ : Tile .real [BM]).data (r, PUnit.unit)
        = (aft3StateSeededG qT kT vT ks kp seed (c * BN) r ⟨0, hND⟩).1 := by
    intro r; simp only; rw [hi]
  have hmijcell : ∀ r : Fin BM, mijT.data (r, PUnit.unit)
      = (aft3StateSeededG qT kT vT ks kp seed ((c + 1) * BN) r ⟨0, hND⟩).1 := by
    intro r
    rw [hmijd]
    refine aft3_mij_reg_eq_seededG s0 Q K V base BM ND NC sqm sqk skn skk svk svn sc BN c hBN hc1 r ⟨0, hND⟩ kp seed
      (fun jL => aft3MaskCell1G (s0.pids 0) i off size BM BN (r, jL, PUnit.unit))
      (fun jL => hmc_row r jL)
      qtileF (⟨fun idx : TileIndex [ND, BN] => some ((s.setReg "start_n" .nat [] (Tile.scalar i)).readMem K (base + idx.1.val * skk + (i + idx.2.1.val) * skn))⟩)
      (⟨fun r : TileIndex [BM] => (aft3StateSeededG qT kT vT ks kp seed i r.1 ⟨0, hND⟩).1⟩) rmaxT qkT
      hqtileF hrmemK ?_ ?_ ?_
    · intro jL; rw [hqkData]
    · rw [hmicell r]
    · exact hrm
  refine ⟨?_, ?_, ?_, ?_, ?_, ?_, ?_, ?_, ?_, ?_, ?_, ?_, ?_, ?_, ?_, ?_, ?_⟩
  · rw [hpidsF, BlockState.setReg_pids, hpids]
  · simp [Nat.add_mod, himod, Nat.mod_self]
  · rw [← hcBN_succ]; exact hc1
  · rw [hmiF]; refine congrArg some ?_; ext r
    rw [hmijcell r.1, hcBN_succ]
  · rw [hliF]; refine congrArg some ?_; refine Tile.ext (fun r => ?_)
    obtain ⟨r, ⟨⟩⟩ := r
    have hbr := aft3_denom_reg_eq_seededG s0 Q K V base BM ND NC sqm sqk skn skk svk svn sc BN c hBN hc1 r ⟨0, hND⟩ kp seed
      ((seed r ⟨0, hND⟩).2.1 * pow2 ((seed r ⟨0, hND⟩).1.unbotD 0))
      ((seed r ⟨0, hND⟩).2.2 * pow2 ((seed r ⟨0, hND⟩).1.unbotD 0))
      (aft3_seed_consist seed r ⟨0, hND⟩ (hseednebot r ⟨0, hND⟩)).1
      (aft3_seed_consist seed r ⟨0, hND⟩ (hseednebot r ⟨0, hND⟩)).2
      (fun h => absurd h (hseednebot r ⟨0, hND⟩)) (fun h => absurd h (hseednebot r ⟨0, hND⟩))
      (fun jL => aft3MaskCell1G (s0.pids 0) i off size BM BN (r, jL, PUnit.unit)) (fun jL => hmc_row r jL)
      qtileF (⟨fun idx : TileIndex [ND, BN] => some ((s.setReg "start_n" .nat [] (Tile.scalar i)).readMem K (base + idx.1.val * skk + (i + idx.2.1.val) * skn))⟩) qkT
      (⟨fun r : TileIndex [BM] => ((aft3StateSeededG qT kT vT ks kp seed i r.1 ⟨0, hND⟩).2.1 : ℝ)⟩)
      (⟨fun r : TileIndex [BM] => (aft3StateSeededG qT kT vT ks kp seed i r.1 ⟨0, hND⟩).1⟩)
      mijT alphaT pT pmT hqtileF hrmemK
      (fun jL => by rw [hqkData])
      (by simp only [hi]; rfl) (by simp only [hi]; rfl)
      (by rw [hmijcell r]) halphad hpTd
      (fun jL => by rw [hpmTd])
    show (Tile.bop NumericDType.real.add _ _ _).data _ = _
    rw [hlijd, hbr, hcBN_succ]
    rfl
  · rw [haccF]; refine congrArg some ?_; refine Tile.ext (fun idx => ?_)
    obtain ⟨ir, id, ⟨⟩⟩ := idx
    have hbr := aft3_acc_reg_eq_seededG s0 Q K V base BM ND NC sqm sqk skn skk svk svn sc BN c hBN hc1 ir id kp seed
      ((seed ir id).2.1 * pow2 ((seed ir id).1.unbotD 0))
      ((seed ir id).2.2 * pow2 ((seed ir id).1.unbotD 0))
      (aft3_seed_consist seed ir id (hseednebot ir id)).1
      (aft3_seed_consist seed ir id (hseednebot ir id)).2
      (fun h => absurd h (hseednebot ir id)) (fun h => absurd h (hseednebot ir id))
      (fun jL => aft3MaskCell1G (s0.pids 0) i off size BM BN (ir, jL, PUnit.unit)) (fun jL => hmc_row ir jL)
      qtileF (⟨fun idx : TileIndex [ND, BN] => some ((s.setReg "start_n" .nat [] (Tile.scalar i)).readMem K (base + idx.1.val * skk + (i + idx.2.1.val) * skn))⟩)
      (⟨fun idx : TileIndex [BN, ND] => some ((s.setReg "start_n" .nat [] (Tile.scalar i)).readMem V (base + (i + idx.1.val) * svk + idx.2.1.val * svn))⟩)
      qkT pT pmT
      (⟨fun idx : TileIndex [BM, ND] => ((aft3StateSeededG qT kT vT ks kp seed i idx.1 idx.2.1).2.2 : ℝ)⟩)
      acc1T
      (⟨fun r : TileIndex [BM] => (aft3StateSeededG qT kT vT ks kp seed i r.1 ⟨0, hND⟩).1⟩)
      mijT alphaT hqtileF hrmemK hrmemV
      (fun jL => by rw [hqkData])
      (by simp only [hi]; rfl)
      (by simp only [hi]
          rw [aft3StateSeededG_fst, aft3StateSeededG_fst,
            aft3RunningMaxG_eq qT kT vT ks kp (c * BN) ir ⟨0, hND⟩ id, hseedfst ir ⟨0, hND⟩ id])
      (by rw [hmijcell ir, aft3StateSeededG_fst, aft3StateSeededG_fst,
            aft3RunningMaxG_eq qT kT vT ks kp ((c + 1) * BN) ir ⟨0, hND⟩ id, hseedfst ir ⟨0, hND⟩ id])
      halphad hacc1d hpTd
      (fun jL => by rw [hpmTd])
    show (Tile.bop NumericDType.real.add _ _ _).data _ = _
    rw [hbr, hcBN_succ]
    rfl
  · rw [hqF]
  · rw [hqsF]
  · rw [hsmF]
  · rw [hoffF, BlockState.setReg_ne_name _ _ _ _ _ _ _ _ (by decide)]; exact hoff
  · rw [hKpF, show ((i + BN) : Nat) = i + BN from rfl]
  · rw [hVpF]
  · rw [hMptrF, BlockState.setReg_ne_name _ _ _ _ _ _ _ _ (by decide)]; exact hMptr
  · rw [hLptrF, BlockState.setReg_ne_name _ _ _ _ _ _ _ _ (by decide)]; exact hLptr
  · rw [hOpF, BlockState.setReg_ne_name _ _ _ _ _ _ _ _ (by decide)]; exact hOp
  · exact hundefF
  · rw [hmemF]; funext rg o; rw [BlockState.setReg_mem]; exact congrFun (congrFun hmem rg) o

theorem aft3_attn_step2G (Q K V M Out L : RegionName) (s0 : BlockState)
    (base BM ND NC BN sqm sqk skn skk svk svn som son ROUND_CTX off size : Nat)
    (hND : 0 < ND) (hBM : 0 < BM) (hBN : 0 < BN) (hBNdvd : BN ∣ NC) (sc : ℝ)
    (i : Nat) (s : BlockState) (hilt : i < NC) (himod : i % BN = 0)
    (hinv : attnInvariantKG Q K V M Out L s0 base BM ND NC BN sqm sqk skn skk svk svn som son ROUND_CTX hND sc
      (fun i j => natComplementSlidingWindowKeepG (s0.pids 0) BM BN off size i j) i s) :
    ∃ s', stepStmts (aft3LoopBodyG2 sc off size BM ND BN) (s.setReg "start_n" .nat [] (Tile.scalar i)) = some s'
      ∧ attnInvariantKG Q K V M Out L s0 base BM ND NC BN sqm sqk skn skk svk svn som son ROUND_CTX hND sc
          (fun i j => natComplementSlidingWindowKeepG (s0.pids 0) BM BN off size i j) (i + BN) s' := by
  obtain ⟨hpids, hmod, hile, hmi, hli, hacc, hq, hqs, hsm, hoff, hKp, hVp, hMptr, hLptr, hOp, hundef, hmem⟩ := hinv
  have hBNi : BN ∣ i := Nat.dvd_of_mod_eq_zero himod
  set c := i / BN with hc_def
  have hi : i = c * BN := by rw [hc_def, Nat.div_mul_cancel hBNi]
  have hcBN_succ : (c + 1) * BN = i + BN := by rw [Nat.succ_mul, ← hi]
  have hc1 : (c + 1) * BN ≤ NC := by
    rw [hcBN_succ]
    obtain ⟨k, hk⟩ := hBNdvd
    have hck : c < k := by
      have hlt : c * BN < k * BN := by
        rw [← hi]; calc i < NC := hilt
          _ = k * BN := by rw [hk, Nat.mul_comm]
      exact lt_of_mul_lt_mul_right hlt (Nat.zero_le BN)
    have hle : i + BN ≤ k * BN := by
      rw [hi, ← Nat.succ_mul]; exact Nat.mul_le_mul_right BN hck
    rw [hk, Nat.mul_comm]; exact hle
  set qT := qTile3G s0 Q base BM ND sqm sqk with hqT
  set kT := kTile3G s0 K base NC ND skn skk with hkT
  set vT := vTile3G s0 V base NC ND svk svn with hvT
  set ks := keyScale3G sc NC with hks
  set kp : Fin BM → Fin NC → Prop := fun i j => natComplementSlidingWindowKeepG (s0.pids 0) BM BN off size i j with hkp
  obtain ⟨sF, hchain, hpidsF, hmemF, hundefF, hqF, hqsF, hsmF, hKpF, hVpF, hoffF, hMptrF, hLptrF, hOpF,
      qkT, rmaxT, mijT, alphaT, lijT, pT, pmT, acc1T,
      hqkData, hrm, hmijd, halphad, hpTd, hpmTd, hlijd, hacc1d, hmiF, hliF, haccF⟩ :=
    aft3LoopBodyG2_steps (s.setReg "start_n" .nat [] (Tile.scalar i)) (s0.pids 0) i off size
      K V base base i i skk skn svk svn ND NC BM BN hBN
      (⟨fun idx : TileIndex [BM, ND] => some (qT idx)⟩)
      (⟨fun r : TileIndex [BM] => aft3RunningMaxG qT kT vT ks kp i r.1 ⟨0, hND⟩⟩)
      (⟨fun r : TileIndex [BM] => ((aft3StateBotKG qT kT vT ks kp i r.1 ⟨0, hND⟩).2.1 : ℝ)⟩)
      (⟨fun idx : TileIndex [BM, ND] => ((aft3StateBotKG qT kT vT ks kp i idx.1 idx.2.1).2.2 : ℝ)⟩)
      (⟨fun idx : TileIndex [ND, BN] => some ((s.setReg "start_n" .nat [] (Tile.scalar i)).readMem K (base + idx.1.val * skk + (i + idx.2.1.val) * skn))⟩)
      (⟨fun idx : TileIndex [BN, ND] => some ((s.setReg "start_n" .nat [] (Tile.scalar i)).readMem V (base + (i + idx.1.val) * svk + idx.2.1.val * svn))⟩)
      sc
      (by rw [BlockState.setReg_ne_name _ _ _ _ _ _ _ _ (by decide)]; exact hsm)
      (by simp [BlockState.setReg_same])
      (by rw [BlockState.setReg_ne_name _ _ _ _ _ _ _ _ (by decide)]; exact hq)
      (by rw [BlockState.setReg_ne_name _ _ _ _ _ _ _ _ (by decide)]; exact hqs)
      (by rw [BlockState.setReg_ne_name _ _ _ _ _ _ _ _ (by decide)]; exact hmi)
      (by rw [BlockState.setReg_ne_name _ _ _ _ _ _ _ _ (by decide)]; exact hli)
      (by rw [BlockState.setReg_ne_name _ _ _ _ _ _ _ _ (by decide)]; exact hacc)
      (by rw [BlockState.setReg_ne_name _ _ _ _ _ _ _ _ (by decide)]; exact hKp)
      (by rw [BlockState.setReg_ne_name _ _ _ _ _ _ _ _ (by decide)]; exact hVp)
      (fun idx => rfl)
      (fun idx => rfl)
      (by intro rg o; rw [BlockState.setReg_undef]; exact hundef rg o)
  refine ⟨sF, hchain, ?_⟩
  have hrmemK : ∀ idx : TileIndex [ND, BN],
      (⟨fun idx : TileIndex [ND, BN] => some ((s.setReg "start_n" .nat [] (Tile.scalar i)).readMem K (base + idx.1.val * skk + (i + idx.2.1.val) * skn))⟩ : Tile .real [ND, BN]).data idx
        = some (s0.readMem K (base + idx.1.val * skk + (c * BN + idx.2.1.val) * skn)) := by
    intro idx
    simp only [BlockState.setReg_readMem]
    unfold BlockState.readMem; rw [hmem, hi]
  have hrmemV : ∀ idx : TileIndex [BN, ND],
      (⟨fun idx : TileIndex [BN, ND] => some ((s.setReg "start_n" .nat [] (Tile.scalar i)).readMem V (base + (i + idx.1.val) * svk + idx.2.1.val * svn))⟩ : Tile .real [BN, ND]).data idx
        = some (s0.readMem V (base + (c * BN + idx.1.val) * svk + idx.2.1.val * svn)) := by
    intro idx
    simp only [BlockState.setReg_readMem]
    unfold BlockState.readMem; rw [hmem, hi]
  set qtileF : Tile .real [BM, ND] := ⟨fun idx : TileIndex [BM, ND] => some (qT idx)⟩ with hqtileF
  -- mask reconciliation
  have hmc_row : ∀ (r : Fin BM) (jL : Fin BN), aft3MaskCell2G (s0.pids 0) i off size BM BN (r, jL, PUnit.unit)
      = decide (kp r ⟨c * BN + jL.val, aft3_block_idx_lt BN c NC jL.val jL.isLt hc1⟩) := by
    intro r jL
    have heq : aft3MaskCell2G (s0.pids 0) i off size BM BN (r, jL, PUnit.unit)
        = aft3MaskCell2G (s0.pids 0) (c * BN) off size BM BN (r, jL, PUnit.unit) := by rw [hi]
    rw [heq, aft3MaskCell2G_eq_keep (s0.pids 0) off size BM BN c r jL
      (aft3_block_idx_lt BN c NC jL.val jL.isLt hc1)]
  have hmicell : ∀ r : Fin BM,
      (⟨fun r : TileIndex [BM] => aft3RunningMaxG qT kT vT ks kp i r.1 ⟨0, hND⟩⟩ : Tile .real [BM]).data (r, PUnit.unit)
        = aft3RunningMaxG qT kT vT ks kp (c * BN) r ⟨0, hND⟩ := by
    intro r; simp only; rw [hi]
  have hmijcell : ∀ r : Fin BM, mijT.data (r, PUnit.unit)
      = aft3RunningMaxG qT kT vT ks kp ((c + 1) * BN) r ⟨0, hND⟩ := by
    intro r
    rw [hmijd]
    refine aft3_mij_reg_eq_maskedG s0 Q K V base BM ND NC sqm sqk skn skk svk svn sc BN c hBN hc1 r ⟨0, hND⟩ kp
      (fun jL => aft3MaskCell2G (s0.pids 0) i off size BM BN (r, jL, PUnit.unit))
      (fun jL => hmc_row r jL)
      qtileF (⟨fun idx : TileIndex [ND, BN] => some ((s.setReg "start_n" .nat [] (Tile.scalar i)).readMem K (base + idx.1.val * skk + (i + idx.2.1.val) * skn))⟩)
      (⟨fun r : TileIndex [BM] => aft3RunningMaxG qT kT vT ks kp i r.1 ⟨0, hND⟩⟩) rmaxT qkT
      hqtileF hrmemK ?_ ?_ ?_
    · intro jL; rw [hqkData]
    · rw [hmicell r]
    · exact hrm
  refine ⟨?_, ?_, ?_, ?_, ?_, ?_, ?_, ?_, ?_, ?_, ?_, ?_, ?_, ?_, ?_, ?_, ?_⟩
  · rw [hpidsF, BlockState.setReg_pids, hpids]
  · simp [Nat.add_mod, himod, Nat.mod_self]
  · rw [← hcBN_succ]; exact hc1
  · rw [hmiF]; refine congrArg some ?_; ext r
    rw [hmijcell r.1, hcBN_succ]
  · rw [hliF]; refine congrArg some ?_; refine Tile.ext (fun r => ?_)
    obtain ⟨r, ⟨⟩⟩ := r
    have hbr := aft3_denom_reg_eq_maskedG s0 Q K V base BM ND NC sqm sqk skn skk svk svn sc BN c hBN hc1 r ⟨0, hND⟩ kp
      (fun jL => aft3MaskCell2G (s0.pids 0) i off size BM BN (r, jL, PUnit.unit)) (fun jL => hmc_row r jL)
      qtileF (⟨fun idx : TileIndex [ND, BN] => some ((s.setReg "start_n" .nat [] (Tile.scalar i)).readMem K (base + idx.1.val * skk + (i + idx.2.1.val) * skn))⟩) qkT
      (⟨fun r : TileIndex [BM] => ((aft3StateBotKG qT kT vT ks kp i r.1 ⟨0, hND⟩).2.1 : ℝ)⟩)
      (⟨fun r : TileIndex [BM] => aft3RunningMaxG qT kT vT ks kp i r.1 ⟨0, hND⟩⟩)
      mijT alphaT pT pmT hqtileF hrmemK
      (fun jL => by rw [hqkData])
      (by simp only [hi]; rfl) (by simp only [hi]; rfl)
      (by rw [hmijcell r]) halphad hpTd
      (fun jL => by rw [hpmTd])
    show (Tile.bop NumericDType.real.add _ _ _).data _ = _
    rw [hlijd, hbr]
    show _ = ((aft3StateBotKG qT kT vT ks kp (i + BN) r ⟨0, hND⟩).2.1 : WithBot ℝ)
    rw [hcBN_succ.symm,
      show aft3StateBotKG qT kT vT ks kp ((c + 1) * BN) r ⟨0, hND⟩
        = aft3StateBotG qT kT vT ks kp ((c + 1) * BN) r ⟨0, hND⟩ from by
        unfold aft3StateBotKG; rw [if_neg (by rw [hcBN_succ]; omega)]]
    rfl
  · rw [haccF]; refine congrArg some ?_; refine Tile.ext (fun idx => ?_)
    obtain ⟨ir, id, ⟨⟩⟩ := idx
    have hbr := aft3_acc_reg_eq_maskedG s0 Q K V base BM ND NC sqm sqk skn skk svk svn sc BN c hBN hc1 ir id kp
      (fun jL => aft3MaskCell2G (s0.pids 0) i off size BM BN (ir, jL, PUnit.unit)) (fun jL => hmc_row ir jL)
      qtileF (⟨fun idx : TileIndex [ND, BN] => some ((s.setReg "start_n" .nat [] (Tile.scalar i)).readMem K (base + idx.1.val * skk + (i + idx.2.1.val) * skn))⟩)
      (⟨fun idx : TileIndex [BN, ND] => some ((s.setReg "start_n" .nat [] (Tile.scalar i)).readMem V (base + (i + idx.1.val) * svk + idx.2.1.val * svn))⟩)
      qkT pT pmT
      (⟨fun idx : TileIndex [BM, ND] => ((aft3StateBotKG qT kT vT ks kp i idx.1 idx.2.1).2.2 : ℝ)⟩)
      acc1T
      (⟨fun r : TileIndex [BM] => aft3RunningMaxG qT kT vT ks kp i r.1 ⟨0, hND⟩⟩)
      mijT alphaT hqtileF hrmemK hrmemV
      (fun jL => by rw [hqkData])
      (by simp only [hi]; rfl)
      (by simp only [hi, hqT, hkT, hvT, hks]
          exact aft3RunningMaxG_eq (qTile3G s0 Q base BM ND sqm sqk) (kTile3G s0 K base NC ND skn skk)
            (vTile3G s0 V base NC ND svk svn) (keyScale3G sc NC) kp (c * BN) ir ⟨0, hND⟩ id)
      (by rw [hmijcell ir]; exact aft3RunningMaxG_eq qT kT vT ks kp ((c + 1) * BN) ir ⟨0, hND⟩ id)
      halphad hacc1d hpTd
      (fun jL => by rw [hpmTd])
    show (Tile.bop NumericDType.real.add _ _ _).data _ = _
    rw [hbr]
    show _ = ((aft3StateBotKG qT kT vT ks kp (i + BN) ir id).2.2 : WithBot ℝ)
    rw [hcBN_succ.symm,
      show aft3StateBotKG qT kT vT ks kp ((c + 1) * BN) ir id
        = aft3StateBotG qT kT vT ks kp ((c + 1) * BN) ir id from by
        unfold aft3StateBotKG; rw [if_neg (by rw [hcBN_succ]; omega)]]
    rfl
  · rw [hqF]
  · rw [hqsF]
  · rw [hsmF]
  · rw [hoffF, BlockState.setReg_ne_name _ _ _ _ _ _ _ _ (by decide)]; exact hoff
  · rw [hKpF, show ((i + BN) : Nat) = i + BN from rfl]
  · rw [hVpF]
  · rw [hMptrF, BlockState.setReg_ne_name _ _ _ _ _ _ _ _ (by decide)]; exact hMptr
  · rw [hLptrF, BlockState.setReg_ne_name _ _ _ _ _ _ _ _ (by decide)]; exact hLptr
  · rw [hOpF, BlockState.setReg_ne_name _ _ _ _ _ _ _ _ (by decide)]; exact hOp
  · exact hundefF
  · rw [hmemF]; funext rg o; rw [BlockState.setReg_mem]; exact congrFun (congrFun hmem rg) o

/-! ## General postLoop evaluation -/

set_option maxHeartbeats 1600000 in
set_option maxRecDepth 8000 in
/-- **General postLoop evaluation (cases 1/2, ⊥-carry).** From a loop-end state
satisfying `attnInvariantKG … keep NC`, the `O` writeback holds the raw
`aft3StateBotKG` ratio and the `M` writeback the raw finalize, for every lane.
Takes the per-lane store-address injectivity directly (true preconditions of a
single-program write). -/
theorem aft3PostLoop_eval_KG
    (Q K V M Out L : RegionName) (s0 : BlockState) (s : BlockState)
    (base BM ND NC BN sqm sqk skn skk svk svn som son ROUND_CTX : Nat) (hND : 0 < ND) (sc : ℝ)
    (hMO : M ≠ Out)
    (keep : Fin BM → Fin NC → Prop) [∀ i j, Decidable (keep i j)]
    (hinjO : Function.Injective
      (fun idx : TileIndex [BM, ND] => base + (s0.pids 0 * BM + idx.1.val) * som + idx.2.1.val * son))
    (hinjM : Function.Injective
      (fun r : TileIndex [BM] => s0.pids 1 * ROUND_CTX + (s0.pids 0 * BM + r.1.val)))
    (hinv : attnInvariantKG Q K V M Out L s0 base BM ND NC BN sqm sqk skn skk svk svn som son ROUND_CTX hND sc keep NC s) :
    ∃ sP, stepStmts (aft3PostLoopG M Out L BM ND) s = some sP
      ∧ (∀ idx : TileIndex [BM, ND],
          sP.readMem Out (base + (s0.pids 0 * BM + idx.1.val) * som + idx.2.1.val * son)
            = ((aft3StateBotKG (qTile3G s0 Q base BM ND sqm sqk) (kTile3G s0 K base NC ND skn skk)
                  (vTile3G s0 V base NC ND svk svn) (keyScale3G sc NC)
                  keep NC idx.1 idx.2.1).2.2)
              / ((aft3StateBotKG (qTile3G s0 Q base BM ND sqm sqk) (kTile3G s0 K base NC ND skn skk)
                  (vTile3G s0 V base NC ND svk svn) (keyScale3G sc NC)
                  keep NC idx.1 ⟨0, hND⟩).2.1))
      ∧ (∀ i : Fin BM,
          sP.readMem M (s0.pids 1 * ROUND_CTX + (s0.pids 0 * BM + i.val))
            = (WithBot.realAdd
                  (aft3RunningMaxG (qTile3G s0 Q base BM ND sqm sqk) (kTile3G s0 K base NC ND skn skk)
                    (vTile3G s0 V base NC ND svk svn) (keyScale3G sc NC)
                    keep NC i ⟨0, hND⟩)
                  (WithBot.realLog2 (((aft3StateBotKG (qTile3G s0 Q base BM ND sqm sqk) (kTile3G s0 K base NC ND skn skk)
                    (vTile3G s0 V base NC ND svk svn) (keyScale3G sc NC)
                    keep NC i ⟨0, hND⟩).2.1 : ℝ) : WithBot ℝ))).unbotD 0) := by
  obtain ⟨hpids, _, _, hmi, hli, hacc, hq, hqs, hsm, hoff, hKp, hVp, hMptr, hLptr, hOp, hundef, hmem⟩ :=
    hinv
  set qT := qTile3G s0 Q base BM ND sqm sqk with hqT
  set kT := kTile3G s0 K base NC ND skn skk with hkT
  set vT := vTile3G s0 V base NC ND svk svn with hvT
  set ks := keyScale3G sc NC with hks
  set miTile : Tile .real [BM] :=
    ⟨fun r : TileIndex [BM] => aft3RunningMaxG qT kT vT ks keep NC r.1 ⟨0, hND⟩⟩ with hmiTile
  set liTile : Tile .real [BM] :=
    ⟨fun r : TileIndex [BM] => ((aft3StateBotKG qT kT vT ks keep NC r.1 ⟨0, hND⟩).2.1 : ℝ)⟩ with hliTile
  set accTile : Tile .real [BM, ND] :=
    ⟨fun idx : TileIndex [BM, ND] => ((aft3StateBotKG qT kT vT ks keep NC idx.1 idx.2.1).2.2 : ℝ)⟩ with haccTile
  unfold aft3PostLoopG
  set miFin : Tile .real [BM] :=
    Tile.bop NumericDType.real.add (Broadcast.consSame Broadcast.nil) miTile
      (Tile.uop WithBot.realLog2 liTile) with hmiFin
  set accFin : Tile .real [BM, ND] :=
    Tile.bop NumericDType.real.div (Broadcast.consSame (Broadcast.consR Broadcast.nil)) accTile
      (Tile.expandDim ⟨1, by simp⟩ liTile) with haccFin
  rw [stepStmts.cons_some
    (show stepStmt _ s = some _ from by
      rw [aft3_ifThenElse_true (aft3_ne_one_zero_true s)]
      rw [stepStmts.cons_some (stepStmt_assign_eq_some
        (show evalOp (Op.add NumericDType.real (Broadcast.consSame Broadcast.nil)
            (Op.ref TileDType.real [BM] "m_i") (Op.ref TileDType.real [BM] "l_i").log2) s
            = some miFin from by
          rw [evalOp_add]
          simp only [evalOp, evalOp.eq_def, evalOp_ref, hmi, hli, Option.bind_eq_bind,
            Option.bind_some]
          rfl))]
      rw [stepStmts.cons_some (stepStmt_assign_eq_some
        (show evalOp (Op.div NumericDType.real (Broadcast.consSame (Broadcast.consR Broadcast.nil))
            (Op.ref TileDType.real [BM, ND] "acc")
            (Op.expandDim ⟨1, by simp⟩ (Op.ref TileDType.real [BM] "l_i"))) _
            = some accFin from by
          have hexp : @evalOp TileDType.real [BM, 1]
                (Op.expandDim ⟨1, by simp⟩ (Op.ref TileDType.real [BM] "l_i"))
                (s.setReg "m_i" .real [BM] miFin)
              = some (Tile.expandDim ⟨1, by simp⟩ liTile) :=
            evalOp_expandDim_ref_of_regs _ _ _ _ _ _
              (by rw [BlockState.setReg_ne_name _ _ _ _ _ _ _ _ (by decide)]; exact hli)
          rw [evalOp_div]
          simp only [evalOp_ref, BlockState.setReg_ne_name, ne_eq, String.reduceEq,
            not_false_eq_true, BlockState.setReg_same, hexp, hacc, Option.bind_eq_bind,
            Option.bind_some]
          rfl))]
      rw [stepStmts.nil])]
  set s2 := (s.setReg "m_i" .real [BM] miFin).setReg "acc" .real [BM, ND] accFin with hs2
  have hMptr2 : s2.regs .ptr [BM] "m_ptrs" = some
      (Tile.ptrAdd Broadcast.scalarL (Tile.scalar (M.cast, (0 : Nat)))
        (Tile.bop NumericDType.nat.add Broadcast.scalarL (Tile.scalar (s0.pids 1 * ROUND_CTX))
          (Tile.vec (fun r : Fin BM => s0.pids 0 * BM + r.val)))) := by
    rw [hs2, BlockState.setReg_ne_name _ _ _ _ _ _ _ _ (by decide),
      BlockState.setReg_ne_name _ _ _ _ _ _ _ _ (by decide)]; exact hMptr
  have hmi2 : s2.regs .real [BM] "m_i" = some miFin := by
    rw [hs2, BlockState.setReg_ne_name _ _ _ _ _ _ _ _ (by decide),
      BlockState.setReg_same]
  set mOffFn : TileIndex [BM] → Nat :=
    fun r => s0.pids 1 * ROUND_CTX + (s0.pids 0 * BM + r.1.val) with hmOffFn
  have hmptrEval : evalOp (Op.ref TileDType.ptr [BM] "m_ptrs") s2
      = some (⟨fun r : TileIndex [BM] => (M.cast, mOffFn r)⟩ : Tile .ptr [BM]) := by
    rw [evalOp_ref, hMptr2]
    refine congrArg some ?_; ext r
    · rfl
    · simp only [Tile.ptrAdd_data, Tile.scalar_data, Tile.bop_data, Tile.vec_data,
        Broadcast.leftIndex_scalarL, Broadcast.rightIndex_scalarL, Broadcast.leftIndex_nil,
        Broadcast.rightIndex_nil, NumericDType.add, Nat.zero_add, hmOffFn]
  have hstore1 : stepStmt (Stmt.store TileDType.real [BM] (MemAccess.ptr (Op.ref TileDType.ptr [BM] "m_ptrs"))
      (Op.ref TileDType.real [BM] "m_i") MaskOpt.none) s2
      = some ((TileShape.allIndices [BM]).foldl
          (fun acc r => acc.writeMemTyped .real M (mOffFn r) (miFin.data r)) s2) := by
    simp only [stepStmt, evalOp_ref, hmi2, hmptrEval, Option.bind_eq_bind, Option.bind_some,
      Option.map_some, if_true, Region.cast_id]
  rw [stepStmts.cons_some hstore1]
  set s3 := (TileShape.allIndices [BM]).foldl
      (fun acc r => acc.writeMemTyped .real M (mOffFn r) (miFin.data r)) s2 with hs3
  have hOp3 : s3.regs .blockPtr [BM, ND] "O_block_ptr" = some
      (⟨fun _ : TileIndex [BM, ND] =>
        { region := Out, baseOffset := base, parentShape := [ROUND_CTX, ND], blockShape := [BM, ND],
          strides := [som, son], offsets := [s0.pids 0 * BM, 0] }⟩) := by
    rw [hs3]
    simp only [BlockState.foldl_writeMemTyped_regs]
    rw [hs2, BlockState.setReg_ne_name _ _ _ _ _ _ _ _ (by decide),
      BlockState.setReg_ne_name _ _ _ _ _ _ _ _ (by decide)]; exact hOp
  have hacc3 : s3.regs .real [BM, ND] "acc" = some accFin := by
    rw [hs3]
    simp only [BlockState.foldl_writeMemTyped_regs]
    rw [hs2, BlockState.setReg_same]
  set oOffFn : TileIndex [BM, ND] → Nat :=
    fun idx => base + (s0.pids 0 * BM + idx.1.val) * som + idx.2.1.val * son with hoOffFn
  set oValFn : TileIndex [BM, ND] → WithBot ℝ := fun idx => accFin.data idx with hoValFn
  have hstore2 : stepStmt (Stmt.store TileDType.real [BM, ND]
      (MemAccess.blockPtr (Op.ref TileDType.blockPtr [BM, ND] "O_block_ptr") [])
      (Op.ref TileDType.real [BM, ND] "acc") MaskOpt.none) s3
      = some ((TileShape.allIndices [BM, ND]).foldl
          (fun acc idx => acc.writeMemTyped .real Out (oOffFn idx) (oValFn idx)) s3) := by
    simp only [stepStmt, evalOp_ref, hacc3, hOp3, Option.bind_eq_bind, Option.bind_some,
      Option.map_some]
    refine congrArg some ?_
    refine List.foldl_ext _ _ s3 ?_
    intro acc idx _
    simp only [TileShape.indexToList, BlockPtr.inBounds, List.all_nil, Bool.and_true,
      Bool.true_and, if_true]
    have haddr : BlockPtr.address
        { region := Out, baseOffset := base, parentShape := [ROUND_CTX, ND], blockShape := [BM, ND],
          strides := [som, son], offsets := [s0.pids 0 * BM, 0] }
        [idx.1.val, idx.2.1.val]
        = oOffFn idx := by
      show base + ((s0.pids 0 * BM + idx.1.val) * som + (0 + idx.2.1.val) * son) = _
      rw [Nat.zero_add, hoOffFn]; ring
    rw [haddr]
  rw [stepStmts.cons_some hstore2, stepStmts.nil]
  refine ⟨_, rfl, ?_, ?_⟩
  · intro idx
    rw [show (base + (s0.pids 0 * BM + idx.1.val) * som + idx.2.1.val * son) = oOffFn idx from by
      simp only [hoOffFn]]
    simp only [BlockState.writeMemTyped_real]
    rw [BlockState.scatter_readback_nd (region := Out) s3 oOffFn
      (fun idx => FloatDType.real.storeValue (oValFn idx)) hinjO idx]
    simp only [FloatDType.real_storeValue, hoValFn, haccFin]
    obtain ⟨ir, id, ⟨⟩⟩ := idx
    simp only [Tile.bop_data, Tile.expandDim_data, TileShape.dropInsertedIndex,
      Broadcast.leftIndex, Broadcast.rightIndex, NumericDType.div, WithBot.realDiv,
      Option.map₂, Option.bind, Option.map, haccTile, hliTile, WithBot.unbotD_coe,
      WithBot.unbotD_some]
  · intro i
    rw [show (s0.pids 1 * ROUND_CTX + (s0.pids 0 * BM + i.val)) = mOffFn (i, PUnit.unit) from by
      simp only [hmOffFn]]
    rw [show ((TileShape.allIndices [BM, ND]).foldl
            (fun acc idx => acc.writeMemTyped .real Out (oOffFn idx) (oValFn idx)) s3).readMem M
              (mOffFn (i, PUnit.unit))
          = s3.readMem M (mOffFn (i, PUnit.unit)) from by
      simp only [BlockState.writeMemTyped_real]
      exact aft3_foldl_writeMem_readMem_other_region M Out hMO oOffFn
        (fun idx => FloatDType.real.storeValue (oValFn idx)) (mOffFn (i, PUnit.unit))
        (TileShape.allIndices [BM, ND]) s3]
    rw [hs3]
    simp only [BlockState.writeMemTyped_real]
    rw [BlockState.scatter_readback_nd (region := M) s2 mOffFn
      (fun r => FloatDType.real.storeValue (miFin.data r)) hinjM (i, PUnit.unit)]
    simp only [FloatDType.real_storeValue, miFin, Tile.bop_data, Tile.uop_data,
      Broadcast.leftIndex, Broadcast.rightIndex, NumericDType.add, hmiTile, hliTile]

set_option maxHeartbeats 4000000 in
set_option maxRecDepth 8000 in
/-- **Seeded postLoop evaluation (case 4).** From `attnInvariantSeededG … NC`, the
END=True finalize stores the normalized resume-seeded fold into `O` and the
`m + log2 l` finalize into `M`. -/
theorem aft3PostLoop_eval_seededG
    (Q K V M Out L : RegionName) (s0 : BlockState) (s : BlockState)
    (base BM ND NC BN sqm sqk skn skk svk svn som son ROUND_CTX : Nat) (hND : 0 < ND) (sc : ℝ)
    (hMO : M ≠ Out)
    (keep : Fin BM → Fin NC → Prop) [∀ i j, Decidable (keep i j)]
    (seed : Fin BM → Fin ND → WithBot ℝ × ℝ × ℝ)
    (hinjO : Function.Injective
      (fun idx : TileIndex [BM, ND] => base + (s0.pids 0 * BM + idx.1.val) * som + idx.2.1.val * son))
    (hinjM : Function.Injective
      (fun r : TileIndex [BM] => s0.pids 1 * ROUND_CTX + (s0.pids 0 * BM + r.1.val)))
    (hinv : attnInvariantSeededG Q K V M Out L s0 base BM ND NC BN sqm sqk skn skk svk svn som son ROUND_CTX hND sc keep seed NC s) :
    ∃ sP, stepStmts (aft3PostLoopG M Out L BM ND) s = some sP
      ∧ (∀ idx : TileIndex [BM, ND],
          sP.readMem Out (base + (s0.pids 0 * BM + idx.1.val) * som + idx.2.1.val * son)
            = ((aft3StateSeededG (qTile3G s0 Q base BM ND sqm sqk) (kTile3G s0 K base NC ND skn skk)
                  (vTile3G s0 V base NC ND svk svn) (keyScale3G sc NC)
                  keep seed NC idx.1 idx.2.1).2.2)
              / ((aft3StateSeededG (qTile3G s0 Q base BM ND sqm sqk) (kTile3G s0 K base NC ND skn skk)
                  (vTile3G s0 V base NC ND svk svn) (keyScale3G sc NC)
                  keep seed NC idx.1 ⟨0, hND⟩).2.1))
      ∧ (∀ i : Fin BM,
          sP.readMem M (s0.pids 1 * ROUND_CTX + (s0.pids 0 * BM + i.val))
            = (WithBot.realAdd
                  (aft3StateSeededG (qTile3G s0 Q base BM ND sqm sqk) (kTile3G s0 K base NC ND skn skk)
                    (vTile3G s0 V base NC ND svk svn) (keyScale3G sc NC)
                    keep seed NC i ⟨0, hND⟩).1
                  (WithBot.realLog2 (((aft3StateSeededG (qTile3G s0 Q base BM ND sqm sqk) (kTile3G s0 K base NC ND skn skk)
                    (vTile3G s0 V base NC ND svk svn) (keyScale3G sc NC)
                    keep seed NC i ⟨0, hND⟩).2.1 : ℝ) : WithBot ℝ))).unbotD 0) := by
  obtain ⟨hpids, _, _, hmi, hli, hacc, hq, hqs, hsm, hoff, hKp, hVp, hMptr, hLptr, hOp, hundef, hmem⟩ :=
    hinv
  set qT := qTile3G s0 Q base BM ND sqm sqk with hqT
  set kT := kTile3G s0 K base NC ND skn skk with hkT
  set vT := vTile3G s0 V base NC ND svk svn with hvT
  set ks := keyScale3G sc NC with hks
  set miTile : Tile .real [BM] :=
    ⟨fun r : TileIndex [BM] => (aft3StateSeededG qT kT vT ks keep seed NC r.1 ⟨0, hND⟩).1⟩ with hmiTile
  set liTile : Tile .real [BM] :=
    ⟨fun r : TileIndex [BM] => ((aft3StateSeededG qT kT vT ks keep seed NC r.1 ⟨0, hND⟩).2.1 : ℝ)⟩ with hliTile
  set accTile : Tile .real [BM, ND] :=
    ⟨fun idx : TileIndex [BM, ND] => ((aft3StateSeededG qT kT vT ks keep seed NC idx.1 idx.2.1).2.2 : ℝ)⟩ with haccTile
  unfold aft3PostLoopG
  set miFin : Tile .real [BM] :=
    Tile.bop NumericDType.real.add (Broadcast.consSame Broadcast.nil) miTile
      (Tile.uop WithBot.realLog2 liTile) with hmiFin
  set accFin : Tile .real [BM, ND] :=
    Tile.bop NumericDType.real.div (Broadcast.consSame (Broadcast.consR Broadcast.nil)) accTile
      (Tile.expandDim ⟨1, by simp⟩ liTile) with haccFin
  rw [stepStmts.cons_some
    (show stepStmt _ s = some _ from by
      rw [aft3_ifThenElse_true (aft3_ne_one_zero_true s)]
      rw [stepStmts.cons_some (stepStmt_assign_eq_some
        (show evalOp (Op.add NumericDType.real (Broadcast.consSame Broadcast.nil)
            (Op.ref TileDType.real [BM] "m_i") (Op.ref TileDType.real [BM] "l_i").log2) s
            = some miFin from by
          rw [evalOp_add]
          simp only [evalOp, evalOp.eq_def, evalOp_ref, hmi, hli, Option.bind_eq_bind,
            Option.bind_some]
          rfl))]
      rw [stepStmts.cons_some (stepStmt_assign_eq_some
        (show evalOp (Op.div NumericDType.real (Broadcast.consSame (Broadcast.consR Broadcast.nil))
            (Op.ref TileDType.real [BM, ND] "acc")
            (Op.expandDim ⟨1, by simp⟩ (Op.ref TileDType.real [BM] "l_i"))) _
            = some accFin from by
          have hexp : @evalOp TileDType.real [BM, 1]
                (Op.expandDim ⟨1, by simp⟩ (Op.ref TileDType.real [BM] "l_i"))
                (s.setReg "m_i" .real [BM] miFin)
              = some (Tile.expandDim ⟨1, by simp⟩ liTile) :=
            evalOp_expandDim_ref_of_regs _ _ _ _ _ _
              (by rw [BlockState.setReg_ne_name _ _ _ _ _ _ _ _ (by decide)]; exact hli)
          rw [evalOp_div]
          simp only [evalOp_ref, BlockState.setReg_ne_name, ne_eq, String.reduceEq,
            not_false_eq_true, BlockState.setReg_same, hexp, hacc, Option.bind_eq_bind,
            Option.bind_some]
          rfl))]
      rw [stepStmts.nil])]
  set s2 := (s.setReg "m_i" .real [BM] miFin).setReg "acc" .real [BM, ND] accFin with hs2
  have hMptr2 : s2.regs .ptr [BM] "m_ptrs" = some
      (Tile.ptrAdd Broadcast.scalarL (Tile.scalar (M.cast, (0 : Nat)))
        (Tile.bop NumericDType.nat.add Broadcast.scalarL (Tile.scalar (s0.pids 1 * ROUND_CTX))
          (Tile.vec (fun r : Fin BM => s0.pids 0 * BM + r.val)))) := by
    rw [hs2, BlockState.setReg_ne_name _ _ _ _ _ _ _ _ (by decide),
      BlockState.setReg_ne_name _ _ _ _ _ _ _ _ (by decide)]; exact hMptr
  have hmi2 : s2.regs .real [BM] "m_i" = some miFin := by
    rw [hs2, BlockState.setReg_ne_name _ _ _ _ _ _ _ _ (by decide),
      BlockState.setReg_same]
  set mOffFn : TileIndex [BM] → Nat :=
    fun r => s0.pids 1 * ROUND_CTX + (s0.pids 0 * BM + r.1.val) with hmOffFn
  have hmptrEval : evalOp (Op.ref TileDType.ptr [BM] "m_ptrs") s2
      = some (⟨fun r : TileIndex [BM] => (M.cast, mOffFn r)⟩ : Tile .ptr [BM]) := by
    rw [evalOp_ref, hMptr2]
    refine congrArg some ?_; ext r
    · rfl
    · simp only [Tile.ptrAdd_data, Tile.scalar_data, Tile.bop_data, Tile.vec_data,
        Broadcast.leftIndex_scalarL, Broadcast.rightIndex_scalarL, Broadcast.leftIndex_nil,
        Broadcast.rightIndex_nil, NumericDType.add, Nat.zero_add, hmOffFn]
  have hstore1 : stepStmt (Stmt.store TileDType.real [BM] (MemAccess.ptr (Op.ref TileDType.ptr [BM] "m_ptrs"))
      (Op.ref TileDType.real [BM] "m_i") MaskOpt.none) s2
      = some ((TileShape.allIndices [BM]).foldl
          (fun acc r => acc.writeMemTyped .real M (mOffFn r) (miFin.data r)) s2) := by
    simp only [stepStmt, evalOp_ref, hmi2, hmptrEval, Option.bind_eq_bind, Option.bind_some,
      Option.map_some, if_true, Region.cast_id]
  rw [stepStmts.cons_some hstore1]
  set s3 := (TileShape.allIndices [BM]).foldl
      (fun acc r => acc.writeMemTyped .real M (mOffFn r) (miFin.data r)) s2 with hs3
  have hOp3 : s3.regs .blockPtr [BM, ND] "O_block_ptr" = some
      (⟨fun _ : TileIndex [BM, ND] =>
        { region := Out, baseOffset := base, parentShape := [ROUND_CTX, ND], blockShape := [BM, ND],
          strides := [som, son], offsets := [s0.pids 0 * BM, 0] }⟩) := by
    rw [hs3]
    simp only [BlockState.foldl_writeMemTyped_regs]
    rw [hs2, BlockState.setReg_ne_name _ _ _ _ _ _ _ _ (by decide),
      BlockState.setReg_ne_name _ _ _ _ _ _ _ _ (by decide)]; exact hOp
  have hacc3 : s3.regs .real [BM, ND] "acc" = some accFin := by
    rw [hs3]
    simp only [BlockState.foldl_writeMemTyped_regs]
    rw [hs2, BlockState.setReg_same]
  set oOffFn : TileIndex [BM, ND] → Nat :=
    fun idx => base + (s0.pids 0 * BM + idx.1.val) * som + idx.2.1.val * son with hoOffFn
  set oValFn : TileIndex [BM, ND] → WithBot ℝ := fun idx => accFin.data idx with hoValFn
  have hstore2 : stepStmt (Stmt.store TileDType.real [BM, ND]
      (MemAccess.blockPtr (Op.ref TileDType.blockPtr [BM, ND] "O_block_ptr") [])
      (Op.ref TileDType.real [BM, ND] "acc") MaskOpt.none) s3
      = some ((TileShape.allIndices [BM, ND]).foldl
          (fun acc idx => acc.writeMemTyped .real Out (oOffFn idx) (oValFn idx)) s3) := by
    simp only [stepStmt, evalOp_ref, hacc3, hOp3, Option.bind_eq_bind, Option.bind_some,
      Option.map_some]
    refine congrArg some ?_
    refine List.foldl_ext _ _ s3 ?_
    intro acc idx _
    simp only [TileShape.indexToList, BlockPtr.inBounds, List.all_nil, Bool.and_true,
      Bool.true_and, if_true]
    have haddr : BlockPtr.address
        { region := Out, baseOffset := base, parentShape := [ROUND_CTX, ND], blockShape := [BM, ND],
          strides := [som, son], offsets := [s0.pids 0 * BM, 0] }
        [idx.1.val, idx.2.1.val]
        = oOffFn idx := by
      show base + ((s0.pids 0 * BM + idx.1.val) * som + (0 + idx.2.1.val) * son) = _
      rw [Nat.zero_add, hoOffFn]; ring
    rw [haddr]
  rw [stepStmts.cons_some hstore2, stepStmts.nil]
  refine ⟨_, rfl, ?_, ?_⟩
  · intro idx
    rw [show (base + (s0.pids 0 * BM + idx.1.val) * som + idx.2.1.val * son) = oOffFn idx from by
      simp only [hoOffFn]]
    simp only [BlockState.writeMemTyped_real]
    rw [BlockState.scatter_readback_nd (region := Out) s3 oOffFn
      (fun idx => FloatDType.real.storeValue (oValFn idx)) hinjO idx]
    simp only [FloatDType.real_storeValue, hoValFn, haccFin]
    obtain ⟨ir, id, ⟨⟩⟩ := idx
    simp only [Tile.bop_data, Tile.expandDim_data, TileShape.dropInsertedIndex,
      Broadcast.leftIndex, Broadcast.rightIndex, NumericDType.div, WithBot.realDiv,
      Option.map₂, Option.bind, Option.map, haccTile, hliTile, WithBot.unbotD_coe,
      WithBot.unbotD_some]
  · intro i
    rw [show (s0.pids 1 * ROUND_CTX + (s0.pids 0 * BM + i.val)) = mOffFn (i, PUnit.unit) from by
      simp only [hmOffFn]]
    rw [show ((TileShape.allIndices [BM, ND]).foldl
            (fun acc idx => acc.writeMemTyped .real Out (oOffFn idx) (oValFn idx)) s3).readMem M
              (mOffFn (i, PUnit.unit))
          = s3.readMem M (mOffFn (i, PUnit.unit)) from by
      simp only [BlockState.writeMemTyped_real]
      exact aft3_foldl_writeMem_readMem_other_region M Out hMO oOffFn
        (fun idx => FloatDType.real.storeValue (oValFn idx)) (mOffFn (i, PUnit.unit))
        (TileShape.allIndices [BM, ND]) s3]
    rw [hs3]
    simp only [BlockState.writeMemTyped_real]
    rw [BlockState.scatter_readback_nd (region := M) s2 mOffFn
      (fun r => FloatDType.real.storeValue (miFin.data r)) hinjM (i, PUnit.unit)]
    simp only [FloatDType.real_storeValue, miFin, Tile.bop_data, Tile.uop_data,
      Broadcast.leftIndex, Broadcast.rightIndex, NumericDType.add, hmiTile, hliTile]

/-- At the full window `NC` with `noWindowKeep` (running max never `⊥` when
`0 < NC`), the no-⊥-carry `aft3StateBot1G` equals the ⊥-carry `aft3StateBotKG`. -/
theorem aft3StateBot1G_full_eq_KG_noWindow {BM ND NC : Nat}
    (qT : TileIndex [BM, ND] → ℝ) (kT vT : TileIndex [NC, ND] → ℝ)
    (keyScale : Fin NC → ℝ) (hNC : 0 < NC) (i : Fin BM) (d : Fin ND) :
    aft3StateBot1G qT kT vT keyScale (fun (i : Fin BM) (j : Fin NC) => noWindowKeep i j) NC i d
      = aft3StateBotKG qT kT vT keyScale (fun (i : Fin BM) (j : Fin NC) => noWindowKeep i j) NC i d := by
  have hne : aft3RunningMaxG qT kT vT keyScale (fun (i : Fin BM) (j : Fin NC) => noWindowKeep i j) NC i d ≠ ⊥ :=
    aft3RunningMaxG_noWindow_ne_bot qT kT vT keyScale NC hNC hNC i d
  rw [aft3StateBot1G_eq_aft3StateBotG qT kT vT keyScale _ NC i d hne]
  unfold aft3StateBotKG; rw [if_neg hNC.ne']

/-- Bridge `attnInvariantG … NC` (case-3, seed-1) to `attnInvariantKG … NC` at the
full window with `noWindowKeep`. -/
theorem attnInvariantG_to_KG_full
    (Q K V M Out L : RegionName) (s0 : BlockState)
    (base BM ND NC BN sqm sqk skn skk svk svn som son ROUND_CTX : Nat) (hND : 0 < ND) (hNC : 0 < NC) (sc : ℝ)
    (s : BlockState)
    (h : attnInvariantG Q K V M Out L s0 base BM ND NC BN sqm sqk skn skk svk svn som son ROUND_CTX hND sc
      (fun i j => noWindowKeep i j) NC s) :
    attnInvariantKG Q K V M Out L s0 base BM ND NC BN sqm sqk skn skk svk svn som son ROUND_CTX hND sc
      (fun i j => noWindowKeep i j) NC s := by
  obtain ⟨hpids, hmod, hile, hmi, hli, hacc, hq, hqs, hsm, hoff, hKp, hVp, hMptr, hLptr, hOp, hundef, hmem⟩ := h
  refine ⟨hpids, hmod, hile, hmi, ?_, ?_, hq, hqs, hsm, hoff, hKp, hVp, hMptr, hLptr, hOp, hundef, hmem⟩
  · rw [hli]; refine congrArg some ?_; refine Tile.ext (fun r => ?_)
    exact congrArg (fun t : WithBot ℝ × ℝ × ℝ => ((t.2.1 : ℝ) : WithBot ℝ))
      (aft3StateBot1G_full_eq_KG_noWindow (qTile3G s0 Q base BM ND sqm sqk) (kTile3G s0 K base NC ND skn skk)
        (vTile3G s0 V base NC ND svk svn) (keyScale3G sc NC) hNC r.1 ⟨0, hND⟩)
  · rw [hacc]; refine congrArg some ?_; refine Tile.ext (fun idx => ?_)
    exact congrArg (fun t : WithBot ℝ × ℝ × ℝ => ((t.2.2 : ℝ) : WithBot ℝ))
      (aft3StateBot1G_full_eq_KG_noWindow (qTile3G s0 Q base BM ND sqm sqk) (kTile3G s0 K base NC ND skn skk)
        (vTile3G s0 V base NC ND svk svn) (keyScale3G sc NC) hNC idx.1 idx.2.1)

set_option maxHeartbeats 4000000 in
set_option maxRecDepth 8000 in
/-- **General postLoop evaluation (case 3, no window).** From `attnInvariantG …
noWindowKeep NC`, the `O` writeback holds the genuine closed form
`attentionFwdTriton3Case3OutSpecG` and `M` holds the case-3 finalize. -/
theorem aft3PostLoop_evalG
    (Q K V M Out L : RegionName) (s0 : BlockState) (s : BlockState)
    (base BM ND NC BN sqm sqk skn skk svk svn som son ROUND_CTX : Nat) (hND : 0 < ND) (hNC : 0 < NC) (sc : ℝ)
    (hMO : M ≠ Out)
    (hinjO : Function.Injective
      (fun idx : TileIndex [BM, ND] => base + (s0.pids 0 * BM + idx.1.val) * som + idx.2.1.val * son))
    (hinjM : Function.Injective
      (fun r : TileIndex [BM] => s0.pids 1 * ROUND_CTX + (s0.pids 0 * BM + r.1.val)))
    (hinv : attnInvariantG Q K V M Out L s0 base BM ND NC BN sqm sqk skn skk svk svn som son ROUND_CTX hND sc
      (fun i j => noWindowKeep i j) NC s) :
    ∃ sP, stepStmts (aft3PostLoopG M Out L BM ND) s = some sP
      ∧ (∀ idx : TileIndex [BM, ND],
          sP.readMem Out (base + (s0.pids 0 * BM + idx.1.val) * som + idx.2.1.val * son)
            = attentionFwdTriton3Case3OutSpecG s0 Q K V base BM ND NC sqm sqk skn skk svk svn sc idx)
      ∧ (∀ i : Fin BM,
          sP.readMem M (s0.pids 1 * ROUND_CTX + (s0.pids 0 * BM + i.val))
            = (aft3RunningMaxG (qTile3G s0 Q base BM ND sqm sqk) (kTile3G s0 K base NC ND skn skk)
                  (vTile3G s0 V base NC ND svk svn) (keyScale3G sc NC)
                  (fun i j => noWindowKeep i j) NC i ⟨0, hND⟩).unbotD 0
              + Real.log
                ((aft3StateBot1G (qTile3G s0 Q base BM ND sqm sqk) (kTile3G s0 K base NC ND skn skk)
                    (vTile3G s0 V base NC ND svk svn) (keyScale3G sc NC)
                    (fun i j => noWindowKeep i j) NC i ⟨0, hND⟩).2.1) / Real.log 2) := by
  obtain ⟨sP, hpost, hO, hM⟩ :=
    aft3PostLoop_eval_KG Q K V M Out L s0 s base BM ND NC BN sqm sqk skn skk svk svn som son ROUND_CTX hND sc hMO
      (fun i j => noWindowKeep i j) hinjO hinjM
      (attnInvariantG_to_KG_full Q K V M Out L s0 base BM ND NC BN sqm sqk skn skk svk svn som son ROUND_CTX hND hNC sc s hinv)
  refine ⟨sP, hpost, ?_, ?_⟩
  · intro idx
    obtain ⟨ir, id, ⟨⟩⟩ := idx
    rw [hO (ir, id, PUnit.unit)]
    rw [aft3StateBotKG_full_eq_streaming (qTile3G s0 Q base BM ND sqm sqk) (kTile3G s0 K base NC ND skn skk)
      (vTile3G s0 V base NC ND svk svn) (keyScale3G sc NC) (fun i j => noWindowKeep i j) hNC ir id ⟨0, hND⟩]
    rw [attentionFwdTriton3Case3OutSpecG_eq_streaming s0 Q K V base BM ND NC sqm sqk skn skk svk svn sc ir id]
    rw [aft3KeysUptoG_full (qTile3G s0 Q base BM ND sqm sqk) (kTile3G s0 K base NC ND skn skk)
      (vTile3G s0 V base NC ND svk svn) (keyScale3G sc NC) (fun i j => noWindowKeep i j) ir id]
  · intro i
    rw [hM i]
    have hne : aft3RunningMaxG (qTile3G s0 Q base BM ND sqm sqk) (kTile3G s0 K base NC ND skn skk)
        (vTile3G s0 V base NC ND svk svn) (keyScale3G sc NC) (fun i j => noWindowKeep i j) NC i ⟨0, hND⟩ ≠ ⊥ :=
      aft3RunningMaxG_noWindow_ne_bot _ _ _ _ NC hNC hNC i ⟨0, hND⟩
    obtain ⟨mr, hmr⟩ := WithBot.ne_bot_iff_exists.mp hne
    rw [← hmr]
    rw [show aft3StateBotKG (qTile3G s0 Q base BM ND sqm sqk) (kTile3G s0 K base NC ND skn skk)
          (vTile3G s0 V base NC ND svk svn) (keyScale3G sc NC) (fun i j => noWindowKeep i j) NC i ⟨0, hND⟩
        = aft3StateBot1G (qTile3G s0 Q base BM ND sqm sqk) (kTile3G s0 K base NC ND skn skk)
          (vTile3G s0 V base NC ND svk svn) (keyScale3G sc NC) (fun i j => noWindowKeep i j) NC i ⟨0, hND⟩ from
        (aft3StateBot1G_full_eq_KG_noWindow _ _ _ _ hNC i ⟨0, hND⟩).symm]
    rw [show ((aft3StateBot1G (qTile3G s0 Q base BM ND sqm sqk) (kTile3G s0 K base NC ND skn skk)
          (vTile3G s0 V base NC ND svk svn) (keyScale3G sc NC) (fun i j => noWindowKeep i j) NC i ⟨0, hND⟩).2.1 : WithBot ℝ)
          = some ((aft3StateBot1G (qTile3G s0 Q base BM ND sqm sqk) (kTile3G s0 K base NC ND skn skk)
          (vTile3G s0 V base NC ND svk svn) (keyScale3G sc NC) (fun i j => noWindowKeep i j) NC i ⟨0, hND⟩).2.1) from rfl]
    rw [WithBot.realLog2_some]
    simp only [WithBot.realAdd, Option.map₂, Option.bind, Option.map, WithBot.unbotD_coe]
    rfl

set_option maxHeartbeats 4000000 in
set_option maxRecDepth 8000 in
/-- **General step lemma (case 3, no window).** Advances `attnInvariantG …
noWindowKeep` by one key block (`i → i + BN`). -/
theorem aft3_attn_step3G (Q K V M Out L : RegionName) (s0 : BlockState)
    (base BM ND NC BN sqm sqk skn skk svk svn som son ROUND_CTX off size : Nat)
    (hND : 0 < ND) (hBM : 0 < BM) (hBN : 0 < BN) (hNC : 0 < NC) (hBNdvd : BN ∣ NC) (sc : ℝ)
    (i : Nat) (s : BlockState) (hilt : i < NC) (himod : i % BN = 0)
    (hinv : attnInvariantG Q K V M Out L s0 base BM ND NC BN sqm sqk skn skk svk svn som son ROUND_CTX hND sc
      (fun i j => noWindowKeep i j) i s) :
    ∃ s', stepStmts (aft3LoopBodyG3 sc off BM ND BN) (s.setReg "start_n" .nat [] (Tile.scalar i)) = some s'
      ∧ attnInvariantG Q K V M Out L s0 base BM ND NC BN sqm sqk skn skk svk svn som son ROUND_CTX hND sc
          (fun i j => noWindowKeep i j) (i + BN) s' := by
  simp only [attnInvariantG] at hinv
  obtain ⟨hpids, hmod, hile, hmi, hli, hacc, hq, hqs, hsm, hoff, hKp, hVp, hMptr, hLptr, hOp, hundef, hmem⟩ := hinv
  have hBNi : BN ∣ i := Nat.dvd_of_mod_eq_zero himod
  set c := i / BN with hc_def
  have hi : i = c * BN := by rw [hc_def, Nat.div_mul_cancel hBNi]
  have hcBN_succ : (c + 1) * BN = i + BN := by rw [Nat.succ_mul, ← hi]
  have hc1 : (c + 1) * BN ≤ NC := by
    rw [hcBN_succ]
    obtain ⟨k, hk⟩ := hBNdvd
    have hck : c < k := by
      have hlt : c * BN < k * BN := by
        rw [← hi]; calc i < NC := hilt
          _ = k * BN := by rw [hk, Nat.mul_comm]
      exact lt_of_mul_lt_mul_right hlt (Nat.zero_le BN)
    have hle : i + BN ≤ k * BN := by
      rw [hi, ← Nat.succ_mul]; exact Nat.mul_le_mul_right BN hck
    rw [hk, Nat.mul_comm]; exact hle
  set qT := qTile3G s0 Q base BM ND sqm sqk with hqT
  set kT := kTile3G s0 K base NC ND skn skk with hkT
  set vT := vTile3G s0 V base NC ND svk svn with hvT
  set ks := keyScale3G sc NC with hks
  set kp : Fin BM → Fin NC → Prop := fun i j => noWindowKeep i j with hkp
  obtain ⟨sF, hchain, hpidsF, hmemF, hundefF, hqF, hqsF, hsmF, hoffF, hKpF, hVpF,
      hMptrF, hLptrF, hOpF,
      qkT, rmaxT, mijT, alphaT, lijT, pT, acc1T,
      hqkData, hrm, hmijd, halphad, hpTd, hlijd, hacc1d, hmiF, hliF, haccF⟩ :=
    aft3LoopBodyG3_steps (s.setReg "start_n" .nat [] (Tile.scalar i)) (s0.pids 0) i (s0.pids 1) off
      K V base base i i skk skn svk svn ND NC BM BN hBN
      (⟨fun idx : TileIndex [BM, ND] => some (qT idx)⟩)
      (⟨fun r : TileIndex [BM] => aft3RunningMaxG qT kT vT ks kp i r.1 ⟨0, hND⟩⟩)
      (⟨fun r : TileIndex [BM] => ((aft3StateBot1G qT kT vT ks kp i r.1 ⟨0, hND⟩).2.1 : ℝ)⟩)
      (⟨fun idx : TileIndex [BM, ND] => ((aft3StateBot1G qT kT vT ks kp i idx.1 idx.2.1).2.2 : ℝ)⟩)
      (⟨fun idx : TileIndex [ND, BN] => some ((s.setReg "start_n" .nat [] (Tile.scalar i)).readMem K (base + idx.1.val * skk + (i + idx.2.1.val) * skn))⟩)
      (⟨fun idx : TileIndex [BN, ND] => some ((s.setReg "start_n" .nat [] (Tile.scalar i)).readMem V (base + (i + idx.1.val) * svk + idx.2.1.val * svn))⟩)
      sc _ _ _
      (by rw [BlockState.setReg_ne_name _ _ _ _ _ _ _ _ (by decide)]; exact hMptr)
      (by rw [BlockState.setReg_ne_name _ _ _ _ _ _ _ _ (by decide)]; exact hLptr)
      (by rw [BlockState.setReg_ne_name _ _ _ _ _ _ _ _ (by decide)]; exact hOp)
      (by rw [BlockState.setReg_ne_name _ _ _ _ _ _ _ _ (by decide)]; exact hsm)
      (by rw [BlockState.setReg_ne_name _ _ _ _ _ _ _ _ (by decide)]; exact hoff)
      (by simp [BlockState.setReg_same])
      (by rw [BlockState.setReg_ne_name _ _ _ _ _ _ _ _ (by decide)]; exact hq)
      (by rw [BlockState.setReg_ne_name _ _ _ _ _ _ _ _ (by decide)]; exact hqs)
      (by rw [BlockState.setReg_ne_name _ _ _ _ _ _ _ _ (by decide)]; exact hmi)
      (by rw [BlockState.setReg_ne_name _ _ _ _ _ _ _ _ (by decide)]; exact hli)
      (by rw [BlockState.setReg_ne_name _ _ _ _ _ _ _ _ (by decide)]; exact hacc)
      (by rw [BlockState.setReg_ne_name _ _ _ _ _ _ _ _ (by decide)]; exact hKp)
      (by rw [BlockState.setReg_ne_name _ _ _ _ _ _ _ _ (by decide)]; exact hVp)
      (fun idx => rfl)
      (fun idx => rfl)
      (by intro rg o; rw [BlockState.setReg_undef]; exact hundef rg o)
  refine ⟨sF, hchain, ?_⟩
  have hrmemK : ∀ idx : TileIndex [ND, BN],
      (⟨fun idx : TileIndex [ND, BN] => some ((s.setReg "start_n" .nat [] (Tile.scalar i)).readMem K (base + idx.1.val * skk + (i + idx.2.1.val) * skn))⟩ : Tile .real [ND, BN]).data idx
        = some (s0.readMem K (base + idx.1.val * skk + (c * BN + idx.2.1.val) * skn)) := by
    intro idx
    simp only [BlockState.setReg_readMem]
    unfold BlockState.readMem; rw [hmem, hi]
  have hrmemV : ∀ idx : TileIndex [BN, ND],
      (⟨fun idx : TileIndex [BN, ND] => some ((s.setReg "start_n" .nat [] (Tile.scalar i)).readMem V (base + (i + idx.1.val) * svk + idx.2.1.val * svn))⟩ : Tile .real [BN, ND]).data idx
        = some (s0.readMem V (base + (c * BN + idx.1.val) * svk + idx.2.1.val * svn)) := by
    intro idx
    simp only [BlockState.setReg_readMem]
    unfold BlockState.readMem; rw [hmem, hi]
  set qtileF : Tile .real [BM, ND] := ⟨fun idx : TileIndex [BM, ND] => some (qT idx)⟩ with hqtileF
  have hmicell : ∀ r : Fin BM,
      (⟨fun r : TileIndex [BM] => aft3RunningMaxG qT kT vT ks kp i r.1 ⟨0, hND⟩⟩ : Tile .real [BM]).data (r, PUnit.unit)
        = aft3RunningMaxG qT kT vT ks kp (c * BN) r ⟨0, hND⟩ := by
    intro r; simp only; rw [hi]
  have hmijcell : ∀ r : Fin BM, mijT.data (r, PUnit.unit)
      = aft3RunningMaxG qT kT vT ks kp ((c + 1) * BN) r ⟨0, hND⟩ := by
    intro r
    rw [hmijd]
    refine aft3_mij_reg_eqG s0 Q K V base BM ND NC sqm sqk skn skk svk svn sc BN c hBN hc1 r ⟨0, hND⟩
      qtileF (⟨fun idx : TileIndex [ND, BN] => some ((s.setReg "start_n" .nat [] (Tile.scalar i)).readMem K (base + idx.1.val * skk + (i + idx.2.1.val) * skn))⟩)
      (⟨fun r : TileIndex [BM] => aft3RunningMaxG qT kT vT ks kp i r.1 ⟨0, hND⟩⟩) rmaxT qkT
      hqtileF hrmemK ?_ ?_ ?_
    · rw [hqkData]
    · rw [hmicell r]
    · exact hrm
  refine ⟨?_, ?_, ?_, ?_, ?_, ?_, ?_, ?_, ?_, ?_, ?_, ?_, ?_, ?_, ?_, ?_, ?_⟩
  · rw [hpidsF, BlockState.setReg_pids, hpids]
  · simp [Nat.add_mod, himod, Nat.mod_self]
  · rw [← hcBN_succ]; exact hc1
  · rw [hmiF]; refine congrArg some ?_; ext r
    rw [hmijcell r.1, hcBN_succ]
  · rw [hliF]; refine congrArg some ?_; refine Tile.ext (fun r => ?_)
    obtain ⟨r, ⟨⟩⟩ := r
    have hbr := aft3_denom_reg_eqG s0 Q K V base BM ND NC sqm sqk skn skk svk svn sc BN c hBN hNC hc1 r ⟨0, hND⟩
      qtileF (⟨fun idx : TileIndex [ND, BN] => some ((s.setReg "start_n" .nat [] (Tile.scalar i)).readMem K (base + idx.1.val * skk + (i + idx.2.1.val) * skn))⟩) qkT
      (⟨fun r : TileIndex [BM] => ((aft3StateBot1G qT kT vT ks kp i r.1 ⟨0, hND⟩).2.1 : ℝ)⟩)
      (⟨fun r : TileIndex [BM] => aft3RunningMaxG qT kT vT ks kp i r.1 ⟨0, hND⟩⟩)
      mijT alphaT pT hqtileF hrmemK (by rw [hqkData]) (by simp only [hi]; rfl) (by simp only [hi]; rfl)
      (by rw [hmijcell r]) halphad hpTd
    have hne : aft3RunningMaxG qT kT vT ks kp ((c + 1) * BN) r ⟨0, hND⟩ ≠ ⊥ :=
      aft3RunningMaxG_noWindow_ne_bot qT kT vT ks ((c + 1) * BN) (by rw [hcBN_succ]; omega) hNC r ⟨0, hND⟩
    show (Tile.bop NumericDType.real.add _ _ _).data _ = _
    rw [hlijd, hbr]
    show _ = ((aft3StateBot1G qT kT vT ks kp (i + BN) r ⟨0, hND⟩).2.1 : WithBot ℝ)
    rw [hcBN_succ.symm,
      aft3StateBot1G_eq_aft3StateBotG qT kT vT ks kp ((c + 1) * BN) r ⟨0, hND⟩ hne]
    rfl
  · rw [haccF]; refine congrArg some ?_; refine Tile.ext (fun idx => ?_)
    obtain ⟨ir, id, ⟨⟩⟩ := idx
    have hbr := aft3_acc_reg_eqG s0 Q K V base BM ND NC sqm sqk skn skk svk svn sc BN c hBN hNC hc1 ir id
      qtileF (⟨fun idx : TileIndex [ND, BN] => some ((s.setReg "start_n" .nat [] (Tile.scalar i)).readMem K (base + idx.1.val * skk + (i + idx.2.1.val) * skn))⟩)
      (⟨fun idx : TileIndex [BN, ND] => some ((s.setReg "start_n" .nat [] (Tile.scalar i)).readMem V (base + (i + idx.1.val) * svk + idx.2.1.val * svn))⟩)
      qkT pT
      (⟨fun idx : TileIndex [BM, ND] => ((aft3StateBot1G qT kT vT ks kp i idx.1 idx.2.1).2.2 : ℝ)⟩)
      acc1T
      (⟨fun r : TileIndex [BM] => aft3RunningMaxG qT kT vT ks kp i r.1 ⟨0, hND⟩⟩)
      mijT alphaT hqtileF hrmemK hrmemV (by rw [hqkData]) (by simp only [hi]; rfl)
      (by simp only [hi, hqT, hkT, hvT, hks]
          exact aft3RunningMaxG_eq (qTile3G s0 Q base BM ND sqm sqk) (kTile3G s0 K base NC ND skn skk)
            (vTile3G s0 V base NC ND svk svn) (keyScale3G sc NC) kp (c * BN) ir ⟨0, hND⟩ id)
      (by rw [hmijcell ir]; exact aft3RunningMaxG_eq qT kT vT ks kp ((c + 1) * BN) ir ⟨0, hND⟩ id)
      halphad hacc1d hpTd
    have hne : aft3RunningMaxG qT kT vT ks kp ((c + 1) * BN) ir id ≠ ⊥ :=
      aft3RunningMaxG_noWindow_ne_bot qT kT vT ks ((c + 1) * BN) (by rw [hcBN_succ]; omega) hNC ir id
    show (Tile.bop NumericDType.real.add _ _ _).data _ = _
    rw [hbr]
    show _ = ((aft3StateBot1G qT kT vT ks kp (i + BN) ir id).2.2 : WithBot ℝ)
    rw [hcBN_succ.symm,
      aft3StateBot1G_eq_aft3StateBotG qT kT vT ks kp ((c + 1) * BN) ir id hne]
    rfl
  · rw [hqF]
  · rw [hqsF]
  · rw [hsmF]
  · rw [hoffF]
  · rw [hKpF]
  · rw [hVpF]
  · rw [hMptrF]
  · rw [hLptrF]
  · rw [hOpF]
  · exact hundefF
  · rw [hmemF]; funext rg o; rw [BlockState.setReg_mem]; exact congrFun (congrFun hmem rg) o

/-! ## General full kernel execution (cases 1/2/3) -/

set_option maxHeartbeats 4000000 in
set_option maxRecDepth 8000 in
/-- **General full kernel execution (case 1, sliding window).** -/
theorem aft3_attn_exec1G
    (Q K V M Out L : RegionName) (sm_scale : ℝ)
    (sqz sqh sqm sqk skz skh skn skk svz svh svk svn soz soh som son
      Z H H_KV N_CTX ROUND_CTX NKV_CTX off size BM ND BN : Nat) (s : BlockState)
    (hND : 0 < ND) (hBM : 0 < BM) (hBN : 0 < BN) (hNC : 0 < NKV_CTX) (hBNdvd : BN ∣ NKV_CTX)
    (hH : 0 < H) (hHKV : H_KV = H)
    (hskz : skz = sqz) (hskh : skh = sqh) (hsvz : svz = sqz) (hsvh : svh = sqh)
    (hsoz : soz = sqz) (hsoh : soh = sqh)
    (hMO : M ≠ Out) (hundef : ∀ rg o, s.undef rg o = 0)
    (hinjO : Function.Injective
      (fun idx : TileIndex [BM, ND] => (s.pids 1 / H * sqz + s.pids 1 % H * sqh) + (s.pids 0 * BM + idx.1.val) * som + idx.2.1.val * son))
    (hinjM : Function.Injective
      (fun r : TileIndex [BM] => s.pids 1 * ROUND_CTX + (s.pids 0 * BM + r.1.val))) :
    ∃ sF, stepStmts (attention_fwd_triton3_surface Q K V M Out L sm_scale
        sqz sqh sqm sqk skz skh skn skk svz svh svk svn soz soh som son
        Z H H_KV N_CTX ROUND_CTX NKV_CTX off size 1 1 BM ND BN 1 1 1 0).toAlgKernel.body s = some sF
      ∧ (∀ idx : TileIndex [BM, ND],
          sF.readMem Out ((s.pids 1 / H * sqz + s.pids 1 % H * sqh) + (s.pids 0 * BM + idx.1.val) * som + idx.2.1.val * son)
            = attentionFwdTriton3Case1OutSpecG s Q K V (s.pids 1 / H * sqz + s.pids 1 % H * sqh) BM ND NKV_CTX sqm sqk skn skk svk svn (sm_scale * 1.4426950408889634) BN off size idx)
      ∧ (∀ i : Fin BM,
          sF.readMem M (s.pids 1 * ROUND_CTX + (s.pids 0 * BM + i.val))
            = (WithBot.realAdd
                (aft3RunningMaxG (qTile3G s Q (s.pids 1 / H * sqz + s.pids 1 % H * sqh) BM ND sqm sqk) (kTile3G s K (s.pids 1 / H * sqz + s.pids 1 % H * sqh) NKV_CTX ND skn skk) (vTile3G s V (s.pids 1 / H * sqz + s.pids 1 % H * sqh) NKV_CTX ND svk svn) (keyScale3G (sm_scale * 1.4426950408889634) NKV_CTX) (fun i j => natSlidingWindowKeepG (s.pids 0) BM BN off size i j) NKV_CTX i ⟨0, hND⟩)
                (WithBot.realLog2 (((aft3StateBotKG (qTile3G s Q (s.pids 1 / H * sqz + s.pids 1 % H * sqh) BM ND sqm sqk) (kTile3G s K (s.pids 1 / H * sqz + s.pids 1 % H * sqh) NKV_CTX ND skn skk) (vTile3G s V (s.pids 1 / H * sqz + s.pids 1 % H * sqh) NKV_CTX ND svk svn) (keyScale3G (sm_scale * 1.4426950408889634) NKV_CTX) (fun i j => natSlidingWindowKeepG (s.pids 0) BM BN off size i j) NKV_CTX i ⟨0, hND⟩).2.1 : ℝ) : WithBot ℝ))).unbotD 0) := by
  set base := s.pids 1 / H * sqz + s.pids 1 % H * sqh with hbase
  set sc := sm_scale * 1.4426950408889634 with hsc
  set kp : Fin BM → Fin NKV_CTX → Prop := fun i j => natSlidingWindowKeepG (s.pids 0) BM BN off size i j with hkp
  rw [aft3_body_splitG]
  obtain ⟨sp, hpre, hinv0⟩ :=
    aft3PreLoop_evalG Q K V M Out L sm_scale sqz sqh sqm sqk skz skh skn skk svz svh svk svn soz soh som son H H_KV N_CTX ROUND_CTX NKV_CTX off size BM ND BN s hND hH hHKV hskz hskh hsvz hsvh hsoz hsoh kp hundef
  rw [stepStmts.append_some hpre]
  obtain ⟨final, sL, hloop, hfin, hinvL⟩ :=
    forRange_inv (idx := "start_n") (start := 0) (stop := NKV_CTX) (step := BN)
      (body := aft3LoopBodyG sm_scale off size BM ND BN)
      (P := fun i st => attnInvariantKG Q K V M Out L s base BM ND NKV_CTX BN sqm sqk skn skk svk svn som son ROUND_CTX hND sc kp i st)
      (s_init := sp)
      hBN.ne'
      (attnInvariant_zero_to_KG Q K V M Out L s base BM ND NKV_CTX BN sqm sqk skn skk svk svn som son ROUND_CTX hND sc kp sp hinv0)
      (fun i st hi hP => aft3_attn_step1G Q K V M Out L s base BM ND NKV_CTX BN sqm sqk skn skk svk svn som son ROUND_CTX off size hND hBM hBN hBNdvd sc i st hi
        (by obtain ⟨_, hmod, _, _⟩ := hP; exact hmod) hP)
  rw [stepStmts.cons_some hloop]
  have hfinal : final = NKV_CTX := by
    obtain ⟨_, hmod, hle, _⟩ := hinvL
    rcases Nat.lt_or_ge final NKV_CTX with h | h
    · exact absurd h (by simpa using hfin)
    · exact Nat.le_antisymm hle h
  subst final
  obtain ⟨sF, hpost, hO, hM⟩ :=
    aft3PostLoop_eval_KG Q K V M Out L s sL base BM ND NKV_CTX BN sqm sqk skn skk svk svn som son ROUND_CTX hND sc hMO kp hinjO hinjM hinvL
  refine ⟨sF, hpost, ?_, hM⟩
  intro idx
  obtain ⟨ir, id, ⟨⟩⟩ := idx
  rw [hO (ir, id, PUnit.unit)]
  rw [aft3StateBotKG_full_eq_streaming (qTile3G s Q base BM ND sqm sqk) (kTile3G s K base NKV_CTX ND skn skk)
    (vTile3G s V base NKV_CTX ND svk svn) (keyScale3G sc NKV_CTX) kp hNC ir id ⟨0, hND⟩]
  rw [attentionFwdTriton3Case1OutSpecG_eq_streaming s Q K V base BM ND NKV_CTX sqm sqk skn skk svk svn sc BN off size ir id]
  rw [aft3KeysUptoG_full (qTile3G s Q base BM ND sqm sqk) (kTile3G s K base NKV_CTX ND skn skk)
    (vTile3G s V base NKV_CTX ND svk svn) (keyScale3G sc NKV_CTX) kp ir id]

set_option maxHeartbeats 4000000 in
set_option maxRecDepth 8000 in
/-- **General full kernel execution (case 4, INIT=False resume + sliding window).**
The genuine, non-self-referential output: every `Out` lane holds the normalized
resume-seeded sliding-window online softmax `attentionFwdTriton3Case4OutSpecG`. -/
theorem aft3_attn_exec4G
    (Q K V M Out L : RegionName) (sm_scale : ℝ)
    (sqz sqh sqm sqk skz skh skn skk svz svh svk svn soz soh som son
      Z H H_KV N_CTX ROUND_CTX NKV_CTX off size BM ND BN : Nat) (s : BlockState)
    (hND : 0 < ND) (hBM : 0 < BM) (hBN : 0 < BN) (hNC : 0 < NKV_CTX) (hBNdvd : BN ∣ NKV_CTX)
    (hH : 0 < H) (hHKV : H_KV = H)
    (hskz : skz = sqz) (hskh : skh = sqh) (hsvz : svz = sqz) (hsvh : svh = sqh)
    (hsoz : soz = sqz) (hsoh : soh = sqh)
    (hMO : M ≠ Out) (hundef : ∀ rg o, s.undef rg o = 0)
    (hinjO : Function.Injective
      (fun idx : TileIndex [BM, ND] => (s.pids 1 / H * sqz + s.pids 1 % H * sqh) + (s.pids 0 * BM + idx.1.val) * som + idx.2.1.val * son))
    (hinjM : Function.Injective
      (fun r : TileIndex [BM] => s.pids 1 * ROUND_CTX + (s.pids 0 * BM + r.1.val))) :
    ∃ sF, stepStmts (attention_fwd_triton3_surface Q K V M Out L sm_scale
        sqz sqh sqm sqk skz skh skn skk svz svh svk svn soz soh som son
        Z H H_KV N_CTX ROUND_CTX NKV_CTX off size 1 1 BM ND BN 1 0 1 0).toAlgKernel.body s = some sF
      ∧ (∀ idx : TileIndex [BM, ND],
          sF.readMem Out ((s.pids 1 / H * sqz + s.pids 1 % H * sqh) + (s.pids 0 * BM + idx.1.val) * som + idx.2.1.val * son)
            = attentionFwdTriton3Case4OutSpecG s Q K V M Out L (s.pids 1 / H * sqz + s.pids 1 % H * sqh) BM ND NKV_CTX sqm sqk skn skk svk svn som son ROUND_CTX (sm_scale * 1.4426950408889634) BN off size hND idx)
      ∧ (∀ i : Fin BM,
          sF.readMem M (s.pids 1 * ROUND_CTX + (s.pids 0 * BM + i.val))
            = (WithBot.realAdd
                (aft3StateSeededG (qTile3G s Q (s.pids 1 / H * sqz + s.pids 1 % H * sqh) BM ND sqm sqk) (kTile3G s K (s.pids 1 / H * sqz + s.pids 1 % H * sqh) NKV_CTX ND skn skk) (vTile3G s V (s.pids 1 / H * sqz + s.pids 1 % H * sqh) NKV_CTX ND svk svn) (keyScale3G (sm_scale * 1.4426950408889634) NKV_CTX) (fun i j => natSlidingWindowKeepG (s.pids 0) BM BN off size i j) (aft3Case4Seed s M Out L (s.pids 1 / H * sqz + s.pids 1 % H * sqh) BM ND som son ROUND_CTX) NKV_CTX i ⟨0, hND⟩).1
                (WithBot.realLog2 (((aft3StateSeededG (qTile3G s Q (s.pids 1 / H * sqz + s.pids 1 % H * sqh) BM ND sqm sqk) (kTile3G s K (s.pids 1 / H * sqz + s.pids 1 % H * sqh) NKV_CTX ND skn skk) (vTile3G s V (s.pids 1 / H * sqz + s.pids 1 % H * sqh) NKV_CTX ND svk svn) (keyScale3G (sm_scale * 1.4426950408889634) NKV_CTX) (fun i j => natSlidingWindowKeepG (s.pids 0) BM BN off size i j) (aft3Case4Seed s M Out L (s.pids 1 / H * sqz + s.pids 1 % H * sqh) BM ND som son ROUND_CTX) NKV_CTX i ⟨0, hND⟩).2.1 : ℝ) : WithBot ℝ))).unbotD 0) := by
  set base := s.pids 1 / H * sqz + s.pids 1 % H * sqh with hbase
  set sc := sm_scale * 1.4426950408889634 with hsc
  set kp : Fin BM → Fin NKV_CTX → Prop := fun i j => natSlidingWindowKeepG (s.pids 0) BM BN off size i j with hkp
  set seed := aft3Case4Seed s M Out L base BM ND som son ROUND_CTX with hseed
  have hseednebot : ∀ i d, (seed i d).1 ≠ ⊥ := fun i d => WithBot.coe_ne_bot
  have hseedfst : ∀ (r : Fin BM) (d d' : Fin ND), (seed r d).1 = (seed r d').1 := fun r d d' => rfl
  rw [aft3_body_splitG4]
  obtain ⟨sp, hpre, hinv0⟩ :=
    aft3PreLoop_evalG_init0 Q K V M Out L sm_scale sqz sqh sqm sqk skz skh skn skk svz svh svk svn soz soh som son H H_KV N_CTX ROUND_CTX NKV_CTX off size BM ND BN s hND hH hHKV hskz hskh hsvz hsvh hsoz hsoh kp hundef
  rw [stepStmts.append_some hpre]
  obtain ⟨final, sL, hloop, hfin, hinvL⟩ :=
    forRange_inv (idx := "start_n") (start := 0) (stop := NKV_CTX) (step := BN)
      (body := aft3LoopBodyG sm_scale off size BM ND BN)
      (P := fun i st => attnInvariantSeededG Q K V M Out L s base BM ND NKV_CTX BN sqm sqk skn skk svk svn som son ROUND_CTX hND sc kp seed i st)
      (s_init := sp)
      hBN.ne'
      hinv0
      (fun i st hi hP => aft3_attn_step1_seededG Q K V M Out L s base BM ND NKV_CTX BN sqm sqk skn skk svk svn som son ROUND_CTX off size hND hBM hBN hBNdvd sc seed hseednebot hseedfst i st hi
        (by obtain ⟨_, hmod, _, _⟩ := hP; exact hmod) hP)
  rw [stepStmts.cons_some hloop]
  have hfinal : final = NKV_CTX := by
    obtain ⟨_, hmod, hle, _⟩ := hinvL
    rcases Nat.lt_or_ge final NKV_CTX with h | h
    · exact absurd h (by simpa using hfin)
    · exact Nat.le_antisymm hle h
  subst final
  obtain ⟨sF, hpost, hO, hM⟩ :=
    aft3PostLoop_eval_seededG Q K V M Out L s sL base BM ND NKV_CTX BN sqm sqk skn skk svk svn som son ROUND_CTX hND sc hMO kp seed hinjO hinjM hinvL
  refine ⟨sF, hpost, ?_, hM⟩
  intro idx
  rw [hO idx]
  simp only [attentionFwdTriton3Case4OutSpecG, hseed, hkp]

set_option maxHeartbeats 4000000 in
set_option maxRecDepth 8000 in
/-- **General full kernel execution (case 2, complement sliding window).** -/
theorem aft3_attn_exec2G
    (Q K V M Out L : RegionName) (sm_scale : ℝ)
    (sqz sqh sqm sqk skz skh skn skk svz svh svk svn soz soh som son
      Z H H_KV N_CTX ROUND_CTX NKV_CTX off size BM ND BN : Nat) (s : BlockState)
    (hND : 0 < ND) (hBM : 0 < BM) (hBN : 0 < BN) (hNC : 0 < NKV_CTX) (hBNdvd : BN ∣ NKV_CTX)
    (hH : 0 < H) (hHKV : H_KV = H)
    (hskz : skz = sqz) (hskh : skh = sqh) (hsvz : svz = sqz) (hsvh : svh = sqh)
    (hsoz : soz = sqz) (hsoh : soh = sqh)
    (hMO : M ≠ Out) (hundef : ∀ rg o, s.undef rg o = 0)
    (hinjO : Function.Injective
      (fun idx : TileIndex [BM, ND] => (s.pids 1 / H * sqz + s.pids 1 % H * sqh) + (s.pids 0 * BM + idx.1.val) * som + idx.2.1.val * son))
    (hinjM : Function.Injective
      (fun r : TileIndex [BM] => s.pids 1 * ROUND_CTX + (s.pids 0 * BM + r.1.val))) :
    ∃ sF, stepStmts (attention_fwd_triton3_surface Q K V M Out L sm_scale
        sqz sqh sqm sqk skz skh skn skk svz svh svk svn soz soh som son
        Z H H_KV N_CTX ROUND_CTX NKV_CTX off size 1 1 BM ND BN 1 1 1 1).toAlgKernel.body s = some sF
      ∧ (∀ idx : TileIndex [BM, ND],
          sF.readMem Out ((s.pids 1 / H * sqz + s.pids 1 % H * sqh) + (s.pids 0 * BM + idx.1.val) * som + idx.2.1.val * son)
            = attentionFwdTriton3Case2OutSpecG s Q K V (s.pids 1 / H * sqz + s.pids 1 % H * sqh) BM ND NKV_CTX sqm sqk skn skk svk svn (sm_scale * 1.4426950408889634) BN off size idx)
      ∧ (∀ i : Fin BM,
          sF.readMem M (s.pids 1 * ROUND_CTX + (s.pids 0 * BM + i.val))
            = (WithBot.realAdd
                (aft3RunningMaxG (qTile3G s Q (s.pids 1 / H * sqz + s.pids 1 % H * sqh) BM ND sqm sqk) (kTile3G s K (s.pids 1 / H * sqz + s.pids 1 % H * sqh) NKV_CTX ND skn skk) (vTile3G s V (s.pids 1 / H * sqz + s.pids 1 % H * sqh) NKV_CTX ND svk svn) (keyScale3G (sm_scale * 1.4426950408889634) NKV_CTX) (fun i j => natComplementSlidingWindowKeepG (s.pids 0) BM BN off size i j) NKV_CTX i ⟨0, hND⟩)
                (WithBot.realLog2 (((aft3StateBotKG (qTile3G s Q (s.pids 1 / H * sqz + s.pids 1 % H * sqh) BM ND sqm sqk) (kTile3G s K (s.pids 1 / H * sqz + s.pids 1 % H * sqh) NKV_CTX ND skn skk) (vTile3G s V (s.pids 1 / H * sqz + s.pids 1 % H * sqh) NKV_CTX ND svk svn) (keyScale3G (sm_scale * 1.4426950408889634) NKV_CTX) (fun i j => natComplementSlidingWindowKeepG (s.pids 0) BM BN off size i j) NKV_CTX i ⟨0, hND⟩).2.1 : ℝ) : WithBot ℝ))).unbotD 0) := by
  set base := s.pids 1 / H * sqz + s.pids 1 % H * sqh with hbase
  set sc := sm_scale * 1.4426950408889634 with hsc
  set kp : Fin BM → Fin NKV_CTX → Prop := fun i j => natComplementSlidingWindowKeepG (s.pids 0) BM BN off size i j with hkp
  rw [aft3_body_splitG2]
  obtain ⟨sp, hpre, hinv0⟩ :=
    aft3PreLoop_evalG Q K V M Out L sm_scale sqz sqh sqm sqk skz skh skn skk svz svh svk svn soz soh som son H H_KV N_CTX ROUND_CTX NKV_CTX off size BM ND BN s hND hH hHKV hskz hskh hsvz hsvh hsoz hsoh kp hundef
  rw [stepStmts.append_some hpre]
  obtain ⟨final, sL, hloop, hfin, hinvL⟩ :=
    forRange_inv (idx := "start_n") (start := 0) (stop := NKV_CTX) (step := BN)
      (body := aft3LoopBodyG2 sm_scale off size BM ND BN)
      (P := fun i st => attnInvariantKG Q K V M Out L s base BM ND NKV_CTX BN sqm sqk skn skk svk svn som son ROUND_CTX hND sc kp i st)
      (s_init := sp)
      hBN.ne'
      (attnInvariant_zero_to_KG Q K V M Out L s base BM ND NKV_CTX BN sqm sqk skn skk svk svn som son ROUND_CTX hND sc kp sp hinv0)
      (fun i st hi hP => aft3_attn_step2G Q K V M Out L s base BM ND NKV_CTX BN sqm sqk skn skk svk svn som son ROUND_CTX off size hND hBM hBN hBNdvd sc i st hi
        (by obtain ⟨_, hmod, _, _⟩ := hP; exact hmod) hP)
  rw [stepStmts.cons_some hloop]
  have hfinal : final = NKV_CTX := by
    obtain ⟨_, hmod, hle, _⟩ := hinvL
    rcases Nat.lt_or_ge final NKV_CTX with h | h
    · exact absurd h (by simpa using hfin)
    · exact Nat.le_antisymm hle h
  subst final
  obtain ⟨sF, hpost, hO, hM⟩ :=
    aft3PostLoop_eval_KG Q K V M Out L s sL base BM ND NKV_CTX BN sqm sqk skn skk svk svn som son ROUND_CTX hND sc hMO kp hinjO hinjM hinvL
  refine ⟨sF, hpost, ?_, hM⟩
  intro idx
  obtain ⟨ir, id, ⟨⟩⟩ := idx
  rw [hO (ir, id, PUnit.unit)]
  rw [aft3StateBotKG_full_eq_streaming (qTile3G s Q base BM ND sqm sqk) (kTile3G s K base NKV_CTX ND skn skk)
    (vTile3G s V base NKV_CTX ND svk svn) (keyScale3G sc NKV_CTX) kp hNC ir id ⟨0, hND⟩]
  rw [attentionFwdTriton3Case2OutSpecG_eq_streaming s Q K V base BM ND NKV_CTX sqm sqk skn skk svk svn sc BN off size ir id]
  rw [aft3KeysUptoG_full (qTile3G s Q base BM ND sqm sqk) (kTile3G s K base NKV_CTX ND skn skk)
    (vTile3G s V base NKV_CTX ND svk svn) (keyScale3G sc NKV_CTX) kp ir id]


set_option maxHeartbeats 4000000 in
set_option maxRecDepth 8000 in
/-- **General full kernel execution (case 3, no window).** -/
theorem aft3_attn_execG
    (Q K V M Out L : RegionName) (sm_scale : ℝ)
    (sqz sqh sqm sqk skz skh skn skk svz svh svk svn soz soh som son
      Z H H_KV N_CTX ROUND_CTX NKV_CTX off BM ND BN : Nat) (s : BlockState)
    (hND : 0 < ND) (hBM : 0 < BM) (hBN : 0 < BN) (hNC : 0 < NKV_CTX) (hBNdvd : BN ∣ NKV_CTX)
    (hH : 0 < H) (hHKV : H_KV = H)
    (hskz : skz = sqz) (hskh : skh = sqh) (hsvz : svz = sqz) (hsvh : svh = sqh)
    (hsoz : soz = sqz) (hsoh : soh = sqh)
    (hMO : M ≠ Out) (hundef : ∀ rg o, s.undef rg o = 0)
    (hinjO : Function.Injective
      (fun idx : TileIndex [BM, ND] => (s.pids 1 / H * sqz + s.pids 1 % H * sqh) + (s.pids 0 * BM + idx.1.val) * som + idx.2.1.val * son))
    (hinjM : Function.Injective
      (fun r : TileIndex [BM] => s.pids 1 * ROUND_CTX + (s.pids 0 * BM + r.1.val))) :
    ∃ sF, stepStmts (attention_fwd_triton3_surface Q K V M Out L sm_scale
        sqz sqh sqm sqk skz skh skn skk svz svh svk svn soz soh som son
        Z H H_KV N_CTX ROUND_CTX NKV_CTX off 0 1 1 BM ND BN 1 1 0 0).toAlgKernel.body s = some sF
      ∧ (∀ idx : TileIndex [BM, ND],
          sF.readMem Out ((s.pids 1 / H * sqz + s.pids 1 % H * sqh) + (s.pids 0 * BM + idx.1.val) * som + idx.2.1.val * son)
            = attentionFwdTriton3Case3OutSpecG s Q K V (s.pids 1 / H * sqz + s.pids 1 % H * sqh) BM ND NKV_CTX sqm sqk skn skk svk svn (sm_scale * 1.4426950408889634) idx)
      ∧ (∀ i : Fin BM,
          sF.readMem M (s.pids 1 * ROUND_CTX + (s.pids 0 * BM + i.val))
            = (aft3RunningMaxG (qTile3G s Q (s.pids 1 / H * sqz + s.pids 1 % H * sqh) BM ND sqm sqk) (kTile3G s K (s.pids 1 / H * sqz + s.pids 1 % H * sqh) NKV_CTX ND skn skk) (vTile3G s V (s.pids 1 / H * sqz + s.pids 1 % H * sqh) NKV_CTX ND svk svn) (keyScale3G (sm_scale * 1.4426950408889634) NKV_CTX) (fun i j => noWindowKeep i j) NKV_CTX i ⟨0, hND⟩).unbotD 0
              + Real.log
                ((aft3StateBot1G (qTile3G s Q (s.pids 1 / H * sqz + s.pids 1 % H * sqh) BM ND sqm sqk) (kTile3G s K (s.pids 1 / H * sqz + s.pids 1 % H * sqh) NKV_CTX ND skn skk) (vTile3G s V (s.pids 1 / H * sqz + s.pids 1 % H * sqh) NKV_CTX ND svk svn) (keyScale3G (sm_scale * 1.4426950408889634) NKV_CTX) (fun i j => noWindowKeep i j) NKV_CTX i ⟨0, hND⟩).2.1) / Real.log 2) := by
  set base := s.pids 1 / H * sqz + s.pids 1 % H * sqh with hbase
  set sc := sm_scale * 1.4426950408889634 with hsc
  set kp : Fin BM → Fin NKV_CTX → Prop := fun i j => noWindowKeep i j with hkp
  rw [aft3_body_splitG3]
  obtain ⟨sp, hpre, hinv0⟩ :=
    aft3PreLoop_evalG Q K V M Out L sm_scale sqz sqh sqm sqk skz skh skn skk svz svh svk svn soz soh som son H H_KV N_CTX ROUND_CTX NKV_CTX off 0 BM ND BN s hND hH hHKV hskz hskh hsvz hsvh hsoz hsoh kp hundef
  rw [stepStmts.append_some hpre]
  obtain ⟨final, sL, hloop, hfin, hinvL⟩ :=
    forRange_inv (idx := "start_n") (start := 0) (stop := NKV_CTX) (step := BN)
      (body := aft3LoopBodyG3 sm_scale off BM ND BN)
      (P := fun i st => attnInvariantG Q K V M Out L s base BM ND NKV_CTX BN sqm sqk skn skk svk svn som son ROUND_CTX hND sc kp i st)
      (s_init := sp)
      hBN.ne'
      hinv0
      (fun i st hi hP => aft3_attn_step3G Q K V M Out L s base BM ND NKV_CTX BN sqm sqk skn skk svk svn som son ROUND_CTX off 0 hND hBM hBN hNC hBNdvd sc i st hi
        (by obtain ⟨_, hmod, _, _⟩ := hP; exact hmod) hP)
  rw [stepStmts.cons_some hloop]
  have hfinal : final = NKV_CTX := by
    obtain ⟨_, hmod, hle, _⟩ := hinvL
    rcases Nat.lt_or_ge final NKV_CTX with h | h
    · exact absurd h (by simpa using hfin)
    · exact Nat.le_antisymm hle h
  subst final
  obtain ⟨sF, hpost, hO, hM⟩ :=
    aft3PostLoop_evalG Q K V M Out L s sL base BM ND NKV_CTX BN sqm sqk skn skk svk svn som son ROUND_CTX hND hNC sc hMO hinjO hinjM hinvL
  exact ⟨sF, hpost, hO, hM⟩


/-! ## General genuine output summaries (cases 1/2/3) -/

/-- General genuine `M`-row spec (cases 1/2): raw `(M ⊔ … + log2 l).unbotD`. -/
noncomputable def attentionFwdTriton3KMSpecG
    (s : BlockState) (Q K V : RegionName)
    (base BM ND NC sqm sqk skn skk svk svn : Nat) (sc : ℝ)
    (keep : Fin BM → Fin NC → Prop) [∀ i j, Decidable (keep i j)] (i : Fin BM) (hND : 0 < ND) : ℝ :=
  (WithBot.realAdd
      (aft3RunningMaxG (qTile3G s Q base BM ND sqm sqk) (kTile3G s K base NC ND skn skk)
        (vTile3G s V base NC ND svk svn) (keyScale3G sc NC) keep NC i ⟨0, hND⟩)
      (WithBot.realLog2 (((aft3StateBotKG (qTile3G s Q base BM ND sqm sqk) (kTile3G s K base NC ND skn skk)
        (vTile3G s V base NC ND svk svn) (keyScale3G sc NC) keep NC i ⟨0, hND⟩).2.1 : ℝ) : WithBot ℝ))).unbotD 0

/-- General genuine `M`-row spec (case 3): `m_i + log2 l_i` finalize. -/
noncomputable def attentionFwdTriton3Case3MSpecG
    (s : BlockState) (Q K V : RegionName)
    (base BM ND NC sqm sqk skn skk svk svn : Nat) (sc : ℝ) (i : Fin BM) (hND : 0 < ND) : ℝ :=
  (aft3RunningMaxG (qTile3G s Q base BM ND sqm sqk) (kTile3G s K base NC ND skn skk)
      (vTile3G s V base NC ND svk svn) (keyScale3G sc NC) (fun i j => noWindowKeep i j) NC i ⟨0, hND⟩).unbotD 0
    + Real.log
      ((aft3StateBot1G (qTile3G s Q base BM ND sqm sqk) (kTile3G s K base NC ND skn skk)
          (vTile3G s V base NC ND svk svn) (keyScale3G sc NC) (fun i j => noWindowKeep i j) NC i ⟨0, hND⟩).2.1) / Real.log 2

/-- **Case-4 finalize M closed form (general).** The `m + log2 l` finalize of the
resume-seeded sliding-window online-softmax fold (`aft3StateSeededG` over the seed
`aft3Case4Seed`, read off at column `0`), as written to `M[row]`. Named wrapper so
the `output_summary_general` statement stays a one-liner (mirrors
`attentionFwdTriton3Case3MSpecG`). -/
noncomputable def attentionFwdTriton3Case4MSpecG
    (s : BlockState) (Q K V M Out L : RegionName)
    (base BM ND NC sqm sqk skn skk svk svn som son ROUND_CTX : Nat) (sc : ℝ)
    (BN off size : Nat) (i : Fin BM) (hND : 0 < ND) : ℝ :=
  let seed := aft3Case4Seed s M Out L base BM ND som son ROUND_CTX
  let kp := fun i j => natSlidingWindowKeepG (s.pids 0) BM BN off size i j
  (WithBot.realAdd
    (aft3StateSeededG (qTile3G s Q base BM ND sqm sqk) (kTile3G s K base NC ND skn skk) (vTile3G s V base NC ND svk svn) (keyScale3G sc NC) kp seed NC i ⟨0, hND⟩).1
    (WithBot.realLog2 (((aft3StateSeededG (qTile3G s Q base BM ND sqm sqk) (kTile3G s K base NC ND skn skk) (vTile3G s V base NC ND svk svn) (keyScale3G sc NC) kp seed NC i ⟨0, hND⟩).2.1 : ℝ) : WithBot ℝ))).unbotD 0


/-! ### ════════ ★ MAIN THEOREM ★ ════════ -/
set_option maxHeartbeats 4000000 in
set_option maxRecDepth 8000 in
/-- **Case 1 general genuine output summary.** -/
specification attention_fwd_triton3_python_case1_output_summary_general
    (Q K V M Out L : RegionName) (sm_scale : ℝ)
    (sqz sqh sqm sqk skz skh skn skk svz svh svk svn soz soh som son
      Z H H_KV N_CTX ROUND_CTX NKV_CTX off size BM ND BN : Nat) (s : BlockState)
    (hND : 0 < ND) (hBM : 0 < BM) (hBN : 0 < BN) (hNC : 0 < NKV_CTX) (hBNdvd : BN ∣ NKV_CTX)
    (hH : 0 < H) (hHKV : H_KV = H)
    (hskz : skz = sqz) (hskh : skh = sqh) (hsvz : svz = sqz) (hsvh : svh = sqh)
    (hsoz : soz = sqz) (hsoh : soh = sqh)
    (hMO : M ≠ Out) (hundef : ∀ rg o, s.undef rg o = 0)
    (hinjO : Function.Injective
      (fun idx : TileIndex [BM, ND] => (s.pids 1 / H * sqz + s.pids 1 % H * sqh) + (s.pids 0 * BM + idx.1.val) * som + idx.2.1.val * son))
    (hinjM : Function.Injective
      (fun r : TileIndex [BM] => s.pids 1 * ROUND_CTX + (s.pids 0 * BM + r.1.val))) :
    (∃ alg, (attention_fwd_triton3_surface Q K V M Out L sm_scale
      sqz sqh sqm sqk skz skh skn skk svz svh svk svn soz soh som son
      Z H H_KV N_CTX ROUND_CTX NKV_CTX off size 1 1 BM ND BN 1 1 1 0).toAlgorithm? = Except.ok alg) ∧
    ComputeCorrect.Realizes_without_Rounding
      (kernel := attention_fwd_triton3_surface Q K V M Out L sm_scale
        sqz sqh sqm sqk skz skh skn skk svz svh svk svn soz soh som son
        Z H H_KV N_CTX ROUND_CTX NKV_CTX off size 1 1 BM ND BN 1 1 1 0)
      (initialState := s)
      (write := ComputeCorrect.WriteMap.writeIf
        (fun idx : TileIndex [BM, ND] => active s N_CTX ND BM idx)
        (fun idx : TileIndex [BM, ND] => (Out, outOffset s H sqz sqh som son BM idx)))
      (expected := fun idx : TileIndex [BM, ND] =>
        attentionFwdTriton3Case1OutSpecG s Q K V (s.pids 1 / H * sqz + s.pids 1 % H * sqh) BM ND NKV_CTX sqm sqk skn skk svk svn (sm_scale * 1.4426950408889634) BN off size idx) ∧
    ComputeCorrect.Realizes_without_Rounding
      (kernel := attention_fwd_triton3_surface Q K V M Out L sm_scale
        sqz sqh sqm sqk skz skh skn skk svz svh svk svn soz soh som son
        Z H H_KV N_CTX ROUND_CTX NKV_CTX off size 1 1 BM ND BN 1 1 1 0)
      (initialState := s)
      (write := fun i : Fin BM => some (M, lRowOffset s (s.pids 1) ROUND_CTX BM i))
      (expected := fun i : Fin BM =>
        attentionFwdTriton3KMSpecG s Q K V (s.pids 1 / H * sqz + s.pids 1 % H * sqh) BM ND NKV_CTX sqm sqk skn skk svk svn (sm_scale * 1.4426950408889634) (fun i j => natSlidingWindowKeepG (s.pids 0) BM BN off size i j) i hND) := by
  have houtOff : ∀ idx : TileIndex [BM, ND],
      outOffset s H sqz sqh som son BM idx
        = (s.pids 1 / H * sqz + s.pids 1 % H * sqh) + (s.pids 0 * BM + idx.1.val) * som + idx.2.1.val * son := by
    intro idx; simp only [outOffset, offZ, offH, mIndex, kIndex]
  have hlRow : ∀ i : Fin BM,
      lRowOffset s (s.pids 1) ROUND_CTX BM i = s.pids 1 * ROUND_CTX + (s.pids 0 * BM + i.val) := by
    intro i; simp only [lRowOffset]
  refine ⟨by apply attention_fwd_triton3_surface_toAlgorithm_supported, ?_, ?_⟩
  · rw [ComputeCorrect.realizes_writeIf_iff]
    apply ComputeKernel.computeCorrect_of_toAlgKernel
    · simp [attention_fwd_triton3_surface, ComputeExpr.toAlgorithm?, ComputeOp.toAlgorithm?]
    intro s0 s' hExec hs0
    subst s0
    intro idx _hActive
    obtain ⟨sF, hstep, hO, _⟩ := aft3_attn_exec1G Q K V M Out L sm_scale
      sqz sqh sqm sqk skz skh skn skk svz svh svk svn soz soh som son
      Z H H_KV N_CTX ROUND_CTX NKV_CTX off size BM ND BN s hND hBM hBN hNC hBNdvd hH hHKV
      hskz hskh hsvz hsvh hsoz hsoh hMO hundef hinjO hinjM
    rw [exec] at hExec
    rw [hstep] at hExec
    obtain rfl : sF = s' := Option.some.inj hExec
    rw [houtOff idx]; exact hO idx
  · unfold ComputeCorrect.Realizes_without_Rounding
    apply ComputeKernel.computeCorrect_of_toAlgKernel
    · simp [attention_fwd_triton3_surface, ComputeExpr.toAlgorithm?, ComputeOp.toAlgorithm?]
    intro s0 s' hExec hs0
    subst s0
    intro i
    obtain ⟨sF, hstep, _, hM⟩ := aft3_attn_exec1G Q K V M Out L sm_scale
      sqz sqh sqm sqk skz skh skn skk svz svh svk svn soz soh som son
      Z H H_KV N_CTX ROUND_CTX NKV_CTX off size BM ND BN s hND hBM hBN hNC hBNdvd hH hHKV
      hskz hskh hsvz hsvh hsoz hsoh hMO hundef hinjO hinjM
    rw [exec] at hExec
    rw [hstep] at hExec
    obtain rfl : sF = s' := Option.some.inj hExec
    simp only [hlRow i]
    show sF.readMem M _ = _
    rw [hM i, attentionFwdTriton3KMSpecG]


/-! ### ════════ ★ MAIN THEOREM ★ ════════ -/
set_option maxHeartbeats 4000000 in
set_option maxRecDepth 8000 in
/-- **Case 2 general genuine output summary.** -/
specification attention_fwd_triton3_python_case2_output_summary_general
    (Q K V M Out L : RegionName) (sm_scale : ℝ)
    (sqz sqh sqm sqk skz skh skn skk svz svh svk svn soz soh som son
      Z H H_KV N_CTX ROUND_CTX NKV_CTX off size BM ND BN : Nat) (s : BlockState)
    (hND : 0 < ND) (hBM : 0 < BM) (hBN : 0 < BN) (hNC : 0 < NKV_CTX) (hBNdvd : BN ∣ NKV_CTX)
    (hH : 0 < H) (hHKV : H_KV = H)
    (hskz : skz = sqz) (hskh : skh = sqh) (hsvz : svz = sqz) (hsvh : svh = sqh)
    (hsoz : soz = sqz) (hsoh : soh = sqh)
    (hMO : M ≠ Out) (hundef : ∀ rg o, s.undef rg o = 0)
    (hinjO : Function.Injective
      (fun idx : TileIndex [BM, ND] => (s.pids 1 / H * sqz + s.pids 1 % H * sqh) + (s.pids 0 * BM + idx.1.val) * som + idx.2.1.val * son))
    (hinjM : Function.Injective
      (fun r : TileIndex [BM] => s.pids 1 * ROUND_CTX + (s.pids 0 * BM + r.1.val))) :
    (∃ alg, (attention_fwd_triton3_surface Q K V M Out L sm_scale
      sqz sqh sqm sqk skz skh skn skk svz svh svk svn soz soh som son
      Z H H_KV N_CTX ROUND_CTX NKV_CTX off size 1 1 BM ND BN 1 1 1 1).toAlgorithm? = Except.ok alg) ∧
    ComputeCorrect.Realizes_without_Rounding
      (kernel := attention_fwd_triton3_surface Q K V M Out L sm_scale
        sqz sqh sqm sqk skz skh skn skk svz svh svk svn soz soh som son
        Z H H_KV N_CTX ROUND_CTX NKV_CTX off size 1 1 BM ND BN 1 1 1 1)
      (initialState := s)
      (write := ComputeCorrect.WriteMap.writeIf
        (fun idx : TileIndex [BM, ND] => active s N_CTX ND BM idx)
        (fun idx : TileIndex [BM, ND] => (Out, outOffset s H sqz sqh som son BM idx)))
      (expected := fun idx : TileIndex [BM, ND] =>
        attentionFwdTriton3Case2OutSpecG s Q K V (s.pids 1 / H * sqz + s.pids 1 % H * sqh) BM ND NKV_CTX sqm sqk skn skk svk svn (sm_scale * 1.4426950408889634) BN off size idx) ∧
    ComputeCorrect.Realizes_without_Rounding
      (kernel := attention_fwd_triton3_surface Q K V M Out L sm_scale
        sqz sqh sqm sqk skz skh skn skk svz svh svk svn soz soh som son
        Z H H_KV N_CTX ROUND_CTX NKV_CTX off size 1 1 BM ND BN 1 1 1 1)
      (initialState := s)
      (write := fun i : Fin BM => some (M, lRowOffset s (s.pids 1) ROUND_CTX BM i))
      (expected := fun i : Fin BM =>
        attentionFwdTriton3KMSpecG s Q K V (s.pids 1 / H * sqz + s.pids 1 % H * sqh) BM ND NKV_CTX sqm sqk skn skk svk svn (sm_scale * 1.4426950408889634) (fun i j => natComplementSlidingWindowKeepG (s.pids 0) BM BN off size i j) i hND) := by
  have houtOff : ∀ idx : TileIndex [BM, ND],
      outOffset s H sqz sqh som son BM idx
        = (s.pids 1 / H * sqz + s.pids 1 % H * sqh) + (s.pids 0 * BM + idx.1.val) * som + idx.2.1.val * son := by
    intro idx; simp only [outOffset, offZ, offH, mIndex, kIndex]
  have hlRow : ∀ i : Fin BM,
      lRowOffset s (s.pids 1) ROUND_CTX BM i = s.pids 1 * ROUND_CTX + (s.pids 0 * BM + i.val) := by
    intro i; simp only [lRowOffset]
  refine ⟨by apply attention_fwd_triton3_surface_toAlgorithm_supported, ?_, ?_⟩
  · rw [ComputeCorrect.realizes_writeIf_iff]
    apply ComputeKernel.computeCorrect_of_toAlgKernel
    · simp [attention_fwd_triton3_surface, ComputeExpr.toAlgorithm?, ComputeOp.toAlgorithm?]
    intro s0 s' hExec hs0
    subst s0
    intro idx _hActive
    obtain ⟨sF, hstep, hO, _⟩ := aft3_attn_exec2G Q K V M Out L sm_scale
      sqz sqh sqm sqk skz skh skn skk svz svh svk svn soz soh som son
      Z H H_KV N_CTX ROUND_CTX NKV_CTX off size BM ND BN s hND hBM hBN hNC hBNdvd hH hHKV
      hskz hskh hsvz hsvh hsoz hsoh hMO hundef hinjO hinjM
    rw [exec] at hExec
    rw [hstep] at hExec
    obtain rfl : sF = s' := Option.some.inj hExec
    rw [houtOff idx]; exact hO idx
  · unfold ComputeCorrect.Realizes_without_Rounding
    apply ComputeKernel.computeCorrect_of_toAlgKernel
    · simp [attention_fwd_triton3_surface, ComputeExpr.toAlgorithm?, ComputeOp.toAlgorithm?]
    intro s0 s' hExec hs0
    subst s0
    intro i
    obtain ⟨sF, hstep, _, hM⟩ := aft3_attn_exec2G Q K V M Out L sm_scale
      sqz sqh sqm sqk skz skh skn skk svz svh svk svn soz soh som son
      Z H H_KV N_CTX ROUND_CTX NKV_CTX off size BM ND BN s hND hBM hBN hNC hBNdvd hH hHKV
      hskz hskh hsvz hsvh hsoz hsoh hMO hundef hinjO hinjM
    rw [exec] at hExec
    rw [hstep] at hExec
    obtain rfl : sF = s' := Option.some.inj hExec
    simp only [hlRow i]
    show sF.readMem M _ = _
    rw [hM i, attentionFwdTriton3KMSpecG]



/-! ### ════════ ★ MAIN THEOREM ★ ════════ -/
set_option maxHeartbeats 4000000 in
set_option maxRecDepth 8000 in
/-- **Case 3 general genuine output summary.** -/
specification attention_fwd_triton3_python_case3_output_summary_general
    (Q K V M Out L : RegionName) (sm_scale : ℝ)
    (sqz sqh sqm sqk skz skh skn skk svz svh svk svn soz soh som son
      Z H H_KV N_CTX ROUND_CTX NKV_CTX off BM ND BN : Nat) (s : BlockState)
    (hND : 0 < ND) (hBM : 0 < BM) (hBN : 0 < BN) (hNC : 0 < NKV_CTX) (hBNdvd : BN ∣ NKV_CTX)
    (hH : 0 < H) (hHKV : H_KV = H)
    (hskz : skz = sqz) (hskh : skh = sqh) (hsvz : svz = sqz) (hsvh : svh = sqh)
    (hsoz : soz = sqz) (hsoh : soh = sqh)
    (hMO : M ≠ Out) (hundef : ∀ rg o, s.undef rg o = 0)
    (hinjO : Function.Injective
      (fun idx : TileIndex [BM, ND] => (s.pids 1 / H * sqz + s.pids 1 % H * sqh) + (s.pids 0 * BM + idx.1.val) * som + idx.2.1.val * son))
    (hinjM : Function.Injective
      (fun r : TileIndex [BM] => s.pids 1 * ROUND_CTX + (s.pids 0 * BM + r.1.val))) :
    (∃ alg, (attention_fwd_triton3_surface Q K V M Out L sm_scale
      sqz sqh sqm sqk skz skh skn skk svz svh svk svn soz soh som son
      Z H H_KV N_CTX ROUND_CTX NKV_CTX off 0 1 1 BM ND BN 1 1 0 0).toAlgorithm? = Except.ok alg) ∧
    ComputeCorrect.Realizes_without_Rounding
      (kernel := attention_fwd_triton3_surface Q K V M Out L sm_scale
        sqz sqh sqm sqk skz skh skn skk svz svh svk svn soz soh som son
        Z H H_KV N_CTX ROUND_CTX NKV_CTX off 0 1 1 BM ND BN 1 1 0 0)
      (initialState := s)
      (write := ComputeCorrect.WriteMap.writeIf
        (fun idx : TileIndex [BM, ND] => active s N_CTX ND BM idx)
        (fun idx : TileIndex [BM, ND] => (Out, outOffset s H sqz sqh som son BM idx)))
      (expected := fun idx : TileIndex [BM, ND] =>
        attentionFwdTriton3Case3OutSpecG s Q K V (s.pids 1 / H * sqz + s.pids 1 % H * sqh) BM ND NKV_CTX sqm sqk skn skk svk svn (sm_scale * 1.4426950408889634) idx) ∧
    ComputeCorrect.Realizes_without_Rounding
      (kernel := attention_fwd_triton3_surface Q K V M Out L sm_scale
        sqz sqh sqm sqk skz skh skn skk svz svh svk svn soz soh som son
        Z H H_KV N_CTX ROUND_CTX NKV_CTX off 0 1 1 BM ND BN 1 1 0 0)
      (initialState := s)
      (write := fun i : Fin BM => some (M, lRowOffset s (s.pids 1) ROUND_CTX BM i))
      (expected := fun i : Fin BM =>
        attentionFwdTriton3Case3MSpecG s Q K V (s.pids 1 / H * sqz + s.pids 1 % H * sqh) BM ND NKV_CTX sqm sqk skn skk svk svn (sm_scale * 1.4426950408889634) i hND) := by
  have houtOff : ∀ idx : TileIndex [BM, ND],
      outOffset s H sqz sqh som son BM idx
        = (s.pids 1 / H * sqz + s.pids 1 % H * sqh) + (s.pids 0 * BM + idx.1.val) * som + idx.2.1.val * son := by
    intro idx; simp only [outOffset, offZ, offH, mIndex, kIndex]
  have hlRow : ∀ i : Fin BM,
      lRowOffset s (s.pids 1) ROUND_CTX BM i = s.pids 1 * ROUND_CTX + (s.pids 0 * BM + i.val) := by
    intro i; simp only [lRowOffset]
  refine ⟨by apply attention_fwd_triton3_surface_toAlgorithm_supported, ?_, ?_⟩
  · rw [ComputeCorrect.realizes_writeIf_iff]
    apply ComputeKernel.computeCorrect_of_toAlgKernel
    · simp [attention_fwd_triton3_surface, ComputeExpr.toAlgorithm?, ComputeOp.toAlgorithm?]
    intro s0 s' hExec hs0
    subst s0
    intro idx _hActive
    obtain ⟨sF, hstep, hO, _⟩ := aft3_attn_execG Q K V M Out L sm_scale
      sqz sqh sqm sqk skz skh skn skk svz svh svk svn soz soh som son
      Z H H_KV N_CTX ROUND_CTX NKV_CTX off BM ND BN s hND hBM hBN hNC hBNdvd hH hHKV
      hskz hskh hsvz hsvh hsoz hsoh hMO hundef hinjO hinjM
    rw [exec] at hExec
    rw [hstep] at hExec
    obtain rfl : sF = s' := Option.some.inj hExec
    rw [houtOff idx]; exact hO idx
  · unfold ComputeCorrect.Realizes_without_Rounding
    apply ComputeKernel.computeCorrect_of_toAlgKernel
    · simp [attention_fwd_triton3_surface, ComputeExpr.toAlgorithm?, ComputeOp.toAlgorithm?]
    intro s0 s' hExec hs0
    subst s0
    intro i
    obtain ⟨sF, hstep, _, hM⟩ := aft3_attn_execG Q K V M Out L sm_scale
      sqz sqh sqm sqk skz skh skn skk svz svh svk svn soz soh som son
      Z H H_KV N_CTX ROUND_CTX NKV_CTX off BM ND BN s hND hBM hBN hNC hBNdvd hH hHKV
      hskz hskh hsvz hsvh hsoz hsoh hMO hundef hinjO hinjM
    rw [exec] at hExec
    rw [hstep] at hExec
    obtain rfl : sF = s' := Option.some.inj hExec
    simp only [hlRow i]
    show sF.readMem M _ = _
    rw [hM i, attentionFwdTriton3Case3MSpecG]

set_option maxHeartbeats 4000000 in
set_option maxRecDepth 8000 in
/-- **Dimension-general genuine `output_summary`, case 4** (`INIT=False` cross-launch
resume + sliding window). The executed surface writes the GENUINE
`attentionFwdTriton3Case4OutSpecG` (normalized resume-seeded sliding-window online
softmax, read over INPUT `Q`/`K`/`V` and the resume buffers `M`/`L`/`Out` — **no
self-reference** to this program's own executed output) into `O`, and the `m+log2 l`
finalize into `M`. The resume seed is read from `M`/`L`/`Out` at the initial state. -/
specification attention_fwd_triton3_python_case4_output_summary_general
    (Q K V M Out L : RegionName) (sm_scale : ℝ)
    (sqz sqh sqm sqk skz skh skn skk svz svh svk svn soz soh som son
      Z H H_KV N_CTX ROUND_CTX NKV_CTX off size BM ND BN : Nat) (s : BlockState)
    (hND : 0 < ND) (hBM : 0 < BM) (hBN : 0 < BN) (hNC : 0 < NKV_CTX) (hBNdvd : BN ∣ NKV_CTX)
    (hH : 0 < H) (hHKV : H_KV = H)
    (hskz : skz = sqz) (hskh : skh = sqh) (hsvz : svz = sqz) (hsvh : svh = sqh)
    (hsoz : soz = sqz) (hsoh : soh = sqh)
    (hMO : M ≠ Out) (hundef : ∀ rg o, s.undef rg o = 0)
    (hinjO : Function.Injective
      (fun idx : TileIndex [BM, ND] => (s.pids 1 / H * sqz + s.pids 1 % H * sqh) + (s.pids 0 * BM + idx.1.val) * som + idx.2.1.val * son))
    (hinjM : Function.Injective
      (fun r : TileIndex [BM] => s.pids 1 * ROUND_CTX + (s.pids 0 * BM + r.1.val))) :
    (∃ alg, (attention_fwd_triton3_surface Q K V M Out L sm_scale
      sqz sqh sqm sqk skz skh skn skk svz svh svk svn soz soh som son
      Z H H_KV N_CTX ROUND_CTX NKV_CTX off size 1 1 BM ND BN 1 0 1 0).toAlgorithm? = Except.ok alg) ∧
    ComputeCorrect.Realizes_without_Rounding
      (kernel := attention_fwd_triton3_surface Q K V M Out L sm_scale
        sqz sqh sqm sqk skz skh skn skk svz svh svk svn soz soh som son
        Z H H_KV N_CTX ROUND_CTX NKV_CTX off size 1 1 BM ND BN 1 0 1 0)
      (initialState := s)
      (write := ComputeCorrect.WriteMap.writeIf
        (fun idx : TileIndex [BM, ND] => active s N_CTX ND BM idx)
        (fun idx : TileIndex [BM, ND] => (Out, outOffset s H sqz sqh som son BM idx)))
      (expected := fun idx : TileIndex [BM, ND] =>
        attentionFwdTriton3Case4OutSpecG s Q K V M Out L (s.pids 1 / H * sqz + s.pids 1 % H * sqh) BM ND NKV_CTX sqm sqk skn skk svk svn som son ROUND_CTX (sm_scale * 1.4426950408889634) BN off size hND idx) ∧
    ComputeCorrect.Realizes_without_Rounding
      (kernel := attention_fwd_triton3_surface Q K V M Out L sm_scale
        sqz sqh sqm sqk skz skh skn skk svz svh svk svn soz soh som son
        Z H H_KV N_CTX ROUND_CTX NKV_CTX off size 1 1 BM ND BN 1 0 1 0)
      (initialState := s)
      (write := fun i : Fin BM => some (M, lRowOffset s (s.pids 1) ROUND_CTX BM i))
      (expected := fun i : Fin BM =>
        attentionFwdTriton3Case4MSpecG s Q K V M Out L (s.pids 1 / H * sqz + s.pids 1 % H * sqh) BM ND NKV_CTX sqm sqk skn skk svk svn som son ROUND_CTX (sm_scale * 1.4426950408889634) BN off size i hND) := by
  have houtOff : ∀ idx : TileIndex [BM, ND],
      outOffset s H sqz sqh som son BM idx
        = (s.pids 1 / H * sqz + s.pids 1 % H * sqh) + (s.pids 0 * BM + idx.1.val) * som + idx.2.1.val * son := by
    intro idx; simp only [outOffset, offZ, offH, mIndex, kIndex]
  have hlRow : ∀ i : Fin BM,
      lRowOffset s (s.pids 1) ROUND_CTX BM i = s.pids 1 * ROUND_CTX + (s.pids 0 * BM + i.val) := by
    intro i; simp only [lRowOffset]
  refine ⟨by apply attention_fwd_triton3_surface_toAlgorithm_supported, ?_, ?_⟩
  · rw [ComputeCorrect.realizes_writeIf_iff]
    apply ComputeKernel.computeCorrect_of_toAlgKernel
    · simp [attention_fwd_triton3_surface, ComputeExpr.toAlgorithm?, ComputeOp.toAlgorithm?]
    intro s0 s' hExec hs0
    subst s0
    intro idx _hActive
    obtain ⟨sF, hstep, hO, _⟩ := aft3_attn_exec4G Q K V M Out L sm_scale
      sqz sqh sqm sqk skz skh skn skk svz svh svk svn soz soh som son
      Z H H_KV N_CTX ROUND_CTX NKV_CTX off size BM ND BN s hND hBM hBN hNC hBNdvd hH hHKV
      hskz hskh hsvz hsvh hsoz hsoh hMO hundef hinjO hinjM
    rw [exec] at hExec
    rw [hstep] at hExec
    obtain rfl : sF = s' := Option.some.inj hExec
    rw [houtOff idx]; exact hO idx
  · unfold ComputeCorrect.Realizes_without_Rounding
    apply ComputeKernel.computeCorrect_of_toAlgKernel
    · simp [attention_fwd_triton3_surface, ComputeExpr.toAlgorithm?, ComputeOp.toAlgorithm?]
    intro s0 s' hExec hs0
    subst s0
    intro i
    obtain ⟨sF, hstep, _, hM⟩ := aft3_attn_exec4G Q K V M Out L sm_scale
      sqz sqh sqm sqk skz skh skn skk svz svh svk svn soz soh som son
      Z H H_KV N_CTX ROUND_CTX NKV_CTX off size BM ND BN s hND hBM hBN hNC hBNdvd hH hHKV
      hskz hskh hsvz hsvh hsoz hsoh hMO hundef hinjO hinjM
    rw [exec] at hExec
    rw [hstep] at hExec
    obtain rfl : sF = s' := Option.some.inj hExec
    simp only [hlRow i]
    show sF.readMem M _ = _
    exact hM i


end Correct_without_Rounding

/-! # ══════════ The `⊨[R]` io headline — case 3 (round-7 exemplar) ══════════

The `StreamMasked3DKernelIO₃ₓ₂` face of the **case-3** (no-window, `INIT=1`,
`END=1`) kernel — the bench's first io headline on a `make_block_ptr` kernel.
Everything below is purely additive; the exact surfaces above are untouched. -/

section IOFace

open scoped VeriTile.Triton.StreamMasked3DKernelIO₃ₓ₂

/-! ## `R`-side constexpr mirrors and cast-free collapses

The whole case-3 surface is cast-free post-erasure (`.to(tl.int64)` /
`.to(Out.type.element_ty)` collapse to the identity at translation, all loads
and both terminal stores are `.real`-typed), so `stepStmtsR R` collapses
verbatim onto the exact stepper on all three body segments and the exact
`aft3PreLoop_evalG` / `aft3_attn_step3G` / `aft3PostLoop_evalG` stack is
reused unchanged under `execR R`. -/

/-- `evalOpR` mirror of the constexpr `Op.ne c₁ c₂` conditions (cast-free). -/
private theorem aft3_evalOpR_ne_const (R : RoundingModel) (a b : Nat) (s : BlockState) :
    evalOpR R (Op.ne ComparableDType.nat Broadcast.nil (Op.constNat a) (Op.constNat b)) s
      = evalOp (Op.ne ComparableDType.nat Broadcast.nil (Op.constNat a) (Op.constNat b)) s := by
  simp only [evalOpR, evalOp]

/-- `stepStmtR` mirror of `aft3_ifThen_false`. -/
private theorem aft3_ifThen_falseR (R : RoundingModel) {cond : Op .bool []}
    {body : List Stmt} {s : BlockState}
    (hc : evalOpR R cond s = some (Tile.scalar Bool.false)) :
    stepStmtR R (.ifThen cond body) s = some s := by
  simp only [stepStmtR, hc, Option.bind, Tile.scalar]
  rfl

/-- `stepStmtR` mirror of `aft3_ifThenElse_true`. -/
private theorem aft3_ifThenElse_trueR (R : RoundingModel) {cond : Op .bool []}
    {t e : List Stmt} {s : BlockState}
    (hc : evalOpR R cond s = some (Tile.scalar Bool.true)) :
    stepStmtR R (.ifThenElse cond t e) s = stepStmtsR R t s := by
  simp only [stepStmtR, hc, Option.bind, Tile.scalar]
  rfl

/-- `mapM` congruence for cast-free dynamic block-pointer offset lists. -/
private theorem aft3_evalOpR_castFree_offsets (R : RoundingModel) :
    ∀ (offsets : List (Op .nat [])) (s : BlockState),
      (∀ o ∈ offsets, evalOpR R o s = evalOp o s) →
      offsets.mapM (fun off => do
          let v ← evalOpR R off s
          some (v.data PUnit.unit))
        = offsets.mapM (fun off => do
            let v ← evalOp off s
            some (v.data PUnit.unit))
  | [], _, _ => rfl
  | off :: rest, s, h => by
      simp only [List.mapM_cons, h off List.mem_cons_self,
        aft3_evalOpR_castFree_offsets R rest s
          (fun o ho => h o (List.mem_cons_of_mem _ ho))]

/-- `evalOpR` mirror of `Op.makeBlockPtrDynOffsets` for cast-free base/offset
ops (the `.nat` channels never round). -/
private theorem aft3_evalOpR_mbpdo_castFree (R : RoundingModel) (region : RegionName)
    (base : Op .nat []) (ps : List Nat) (bs : TileShape) (strides : List Nat)
    (offs : List (Op .nat [])) (s : BlockState)
    (hb : evalOpR R base s = evalOp base s)
    (ho : ∀ o ∈ offs, evalOpR R o s = evalOp o s) :
    evalOpR R (.makeBlockPtrDynOffsets region base ps bs strides offs) s
      = evalOp (.makeBlockPtrDynOffsets region base ps bs strides offs) s := by
  simp only [evalOpR, evalOp, hb, aft3_evalOpR_castFree_offsets R offs s ho]

/-- Per-statement cast-free collapse lifts to statement lists (walks the
actual successor chain; a failing step collapses on both sides). -/
private theorem aft3_stepStmtsR_castFree_of_stmts (R : RoundingModel) :
    ∀ (l : List Stmt), (∀ st ∈ l, ∀ u, stepStmtR R st u = stepStmt st u) →
      ∀ s, stepStmtsR R l s = stepStmts l s
  | [], _, s => by simp only [stepStmtsR, stepStmts]
  | st :: rest, h, s => by
      simp only [stepStmtsR, stepStmts, h st List.mem_cons_self s]
      cases stepStmt st s with
      | none => rfl
      | some s' =>
          exact aft3_stepStmtsR_castFree_of_stmts R rest
            (fun st' h' u => h st' (List.mem_cons_of_mem _ h') u) s'

set_option maxHeartbeats 4000000 in
/-- Every case-3 preLoop statement is cast-free, statement-by-statement (the
blanket list unfolding diverges on the dead `INIT=0` / boundary-checked load
branches of the two constexpr `ifThenElse`s, which are reduced to their live
branches first; the two `makeBlockPtrDynOffsets` assigns go through the
dedicated `mapM` mirror). -/
private theorem aft3PreLoopG_stmt_castFree (R : RoundingModel)
    (Q K V M Out L : RegionName) (sm_scale : ℝ)
    (sqz sqh sqm sqk skz skh skn skk svz svh svk svn soz soh som son
      H H_KV N_CTX ROUND_CTX NKV_CTX off size BM ND BN : Nat) :
    ∀ st ∈ aft3PreLoopG Q K V M Out L sm_scale sqz sqh sqm sqk skz skh skn skk svz svh svk svn soz soh som son H H_KV N_CTX ROUND_CTX NKV_CTX off size BM ND BN,
      ∀ u, stepStmtR R st u = stepStmt st u := by
  intro st hst u
  simp only [aft3PreLoopG, List.mem_cons, List.not_mem_nil, or_false] at hst
  rcases hst with rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl |
    rfl | rfl | rfl | rfl | rfl | rfl | rfl
  · simp only [stepStmtR, stepStmt, evalOpR.eq_def, evalOp.eq_def]
  · simp only [stepStmtR, stepStmt, evalOpR.eq_def, evalOp.eq_def]
  · simp only [stepStmtR, stepStmt, evalOpR.eq_def, evalOp.eq_def]
  · simp only [stepStmtR, stepStmt, evalOpR.eq_def, evalOp.eq_def]
  · simp only [stepStmtR, stepStmt, evalOpR.eq_def, evalOp.eq_def]
  · simp only [stepStmtR, stepStmt, evalOpR.eq_def, evalOp.eq_def]
  · simp only [stepStmtR, stepStmt, evalOpR.eq_def, evalOp.eq_def]
  · simp only [stepStmtR, stepStmt, evalOpR.eq_def, evalOp.eq_def]
  · simp only [stepStmtR, stepStmt, evalOpR.eq_def, evalOp.eq_def]
  · -- Q_block_ptr (`makeBlockPtrDynOffsets`): dedicated `mapM` mirror
    simp only [stepStmtR, stepStmt,
      aft3_evalOpR_mbpdo_castFree R Q (Op.ref TileDType.nat [] "q_offset") [N_CTX, ND] [BM, ND] [sqm, sqk]
        [Op.mul NumericDType.nat Broadcast.nil (Op.ref TileDType.nat [] "start_m") (Op.constNat BM), Op.constNat 0] u
        (by simp only [evalOpR, evalOp])
        (by
          intro o ho
          simp only [List.mem_cons, List.not_mem_nil, or_false] at ho
          rcases ho with rfl | rfl <;> simp only [evalOpR.eq_def, evalOp.eq_def])]
  · simp only [stepStmtR, stepStmt, evalOpR.eq_def, evalOp.eq_def]
  · simp only [stepStmtR, stepStmt, evalOpR.eq_def, evalOp.eq_def]
  · -- O_block_ptr (`makeBlockPtrDynOffsets`): dedicated `mapM` mirror
    simp only [stepStmtR, stepStmt,
      aft3_evalOpR_mbpdo_castFree R Out (Op.ref TileDType.nat [] "o_offset") [ROUND_CTX, ND] [BM, ND] [som, son]
        [Op.mul NumericDType.nat Broadcast.nil (Op.ref TileDType.nat [] "start_m") (Op.constNat BM), Op.constNat 0] u
        (by simp only [evalOpR, evalOp])
        (by
          intro o ho
          simp only [List.mem_cons, List.not_mem_nil, or_false] at ho
          rcases ho with rfl | rfl <;> simp only [evalOpR.eq_def, evalOp.eq_def])]
  · simp only [stepStmtR, stepStmt, evalOpR.eq_def, evalOp.eq_def]
  · simp only [stepStmtR, stepStmt, evalOpR.eq_def, evalOp.eq_def]
  · simp only [stepStmtR, stepStmt, evalOpR.eq_def, evalOp.eq_def]
  · -- INIT `ifThenElse` (constexpr-true): collapse on the live init branch only
    rw [aft3_ifThenElse_trueR R (by rw [aft3_evalOpR_ne_const]; exact aft3_ne_one_zero_true u),
      aft3_ifThenElse_true (aft3_ne_one_zero_true u)]
    simp only [stepStmtsR, stepStmts, stepStmtR, stepStmt, evalOpR.eq_def, evalOp.eq_def]
    rfl
  · simp only [stepStmtR, stepStmt, evalOpR.eq_def, evalOp.eq_def]
  · simp only [stepStmtR, stepStmt, evalOpR.eq_def, evalOp.eq_def]
  · -- IS_EVEN_M `ifThenElse` (constexpr-true): collapse on the live q-load only
    rw [aft3_ifThenElse_trueR R (by rw [aft3_evalOpR_ne_const]; exact aft3_ne_one_zero_true u),
      aft3_ifThenElse_true (aft3_ne_one_zero_true u)]
    simp only [stepStmtsR, stepStmts, stepStmtR, stepStmt, evalOpR.eq_def, evalOp.eq_def]
    rfl

/-- The case-3 preLoop is cast-free: it steps identically under `stepStmtsR R`. -/
private theorem aft3PreLoopG_castFree (R : RoundingModel)
    (Q K V M Out L : RegionName) (sm_scale : ℝ)
    (sqz sqh sqm sqk skz skh skn skk svz svh svk svn soz soh som son
      H H_KV N_CTX ROUND_CTX NKV_CTX off size BM ND BN : Nat) (t : BlockState) :
    stepStmtsR R (aft3PreLoopG Q K V M Out L sm_scale sqz sqh sqm sqk skz skh skn skk svz svh svk svn soz soh som son H H_KV N_CTX ROUND_CTX NKV_CTX off size BM ND BN) t
      = stepStmts (aft3PreLoopG Q K V M Out L sm_scale sqz sqh sqm sqk skz skh skn skk svz svh svk svn soz soh som son H H_KV N_CTX ROUND_CTX NKV_CTX off size BM ND BN) t :=
  aft3_stepStmtsR_castFree_of_stmts R _
    (aft3PreLoopG_stmt_castFree R Q K V M Out L sm_scale sqz sqh sqm sqk skz skh skn skk svz svh svk svn soz soh som son H H_KV N_CTX ROUND_CTX NKV_CTX off size BM ND BN) t

/-- The scalar/pointer/index prefix (statements 0–15) is cast-free. -/
private theorem aft3PreLoopScalarsG_castFree (R : RoundingModel)
    (Q K V M Out L : RegionName) (sm_scale : ℝ)
    (sqz sqh sqm sqk skz skh skn skk svz svh svk svn soz soh som son
      H H_KV N_CTX ROUND_CTX NKV_CTX off size BM ND BN : Nat) (t : BlockState) :
    stepStmtsR R (aft3PreLoopScalarsG Q K V M Out L sm_scale sqz sqh sqm sqk skz skh skn skk svz svh svk svn soz soh som son H H_KV N_CTX ROUND_CTX NKV_CTX off size BM ND BN) t
      = stepStmts (aft3PreLoopScalarsG Q K V M Out L sm_scale sqz sqh sqm sqk skz skh skn skk svz svh svk svn soz soh som son H H_KV N_CTX ROUND_CTX NKV_CTX off size BM ND BN) t :=
  aft3_stepStmtsR_castFree_of_stmts R _
    (fun st hst =>
      aft3PreLoopG_stmt_castFree R Q K V M Out L sm_scale sqz sqh sqm sqk skz skh skn skk svz svh svk svn soz soh som son H H_KV N_CTX ROUND_CTX NKV_CTX off size BM ND BN st
        (List.mem_of_mem_take (by simpa [aft3PreLoopScalarsG] using hst))) t

set_option maxHeartbeats 2000000 in
/-- The case-3 loop body is cast-free. -/
private theorem aft3LoopBodyG3_castFree (R : RoundingModel) (sc : ℝ)
    (off BM ND BN : Nat) (t : BlockState) :
    stepStmtsR R (aft3LoopBodyG3 sc off BM ND BN) t
      = stepStmts (aft3LoopBodyG3 sc off BM ND BN) t := by
  simp only [aft3LoopBodyG3, stepStmtsR, stepStmts, stepStmtR, stepStmt,
    evalOpR.eq_def, evalOp.eq_def]
  rfl

set_option maxHeartbeats 2000000 in
/-- The case-3 postLoop (finalize + the two `.real` terminal stores) is
cast-free: `writeMemTypedR R .real` *is* `writeMemTyped .real`. -/
private theorem aft3PostLoopG_castFree (R : RoundingModel)
    (M Out L : RegionName) (BM ND : Nat) (t : BlockState) :
    stepStmtsR R (aft3PostLoopG M Out L BM ND) t
      = stepStmts (aft3PostLoopG M Out L BM ND) t := by
  simp only [aft3PostLoopG, stepStmtsR, stepStmts, stepStmtR, stepStmt,
    evalOpR.eq_def, evalOp.eq_def]
  rfl

set_option maxHeartbeats 4000000 in
/-- The case-3 surface sits inside the flat-memory bridge's covered fragment
(no `ptrSub`; the block-pointer ops are structurally covered). -/
theorem aft3_flattenOkG3 (Q K V M Out L : RegionName) (sm_scale : ℝ)
    (sqz sqh sqm sqk skz skh skn skk svz svh svk svn soz soh som son
      Z H H_KV N_CTX ROUND_CTX NKV_CTX off BM ND BN : Nat) :
    ((attention_fwd_triton3_surface Q K V M Out L sm_scale
      sqz sqh sqm sqk skz skh skn skk svz svh svk svn soz soh som son
      Z H H_KV N_CTX ROUND_CTX NKV_CTX off 0 1 1 BM ND BN 1 1 0 0).toAlgKernel).FlattenOk := by
  unfold Kernel.FlattenOk
  rw [aft3_body_splitG3]
  simp [aft3PreLoopG, aft3LoopBodyG3, aft3PostLoopG, StmtList.FlattenOk,
    Stmt.FlattenOk, Op.FlattenOk]
  simp [Op.FlattenOk.eq_def]

/-! ## IO signature, stream-indexed tiles, and the spec `f`

Window transcription (all bases coincide at the invariant's
`base = pid₁/H·sqz + pid₁%H·sqh` — the `skz=sqz`-family equalities are
headline hypotheses, exactly as on the exact stack):

* `read1` (`Q`, the **static** stream — the window ignores `t`): lane
  `j = (i, e)` row-major over `[BM, ND]` reads
  `base + (pid₀·BM + i)·sqm + e·sqk` (the `Q_block_ptr` cell).
* `read2` (`K`, advanced by `BN` **columns** per step): lane `j = (e, jL)`
  over `[ND, BN]` reads `base + e·skk + (t·BN + jL)·skn`.
* `read3` (`V`, advanced by `BN` **rows** per step): lane `j = (r, d)` over
  `[BN, ND]` reads `base + (t·BN + r)·svk + d·svn`.
* `write1` (`Out` tile via `O_block_ptr`): lane `j = (i, d)` writes
  `base + (pid₀·BM + i)·som + d·son`.
* `write2` (`M` row via the plain `m_ptrs`): lane `i` writes
  `pid₁·ROUND_CTX + pid₀·BM + i`.

The surface is unmasked (`IS_EVEN_N=1` is hardwired in the port, inherited
as-is): all masks are `True`. `pid₂` is unused (2-D grid). Both `outDType`s
are the `.real` default — the store-side `.to(Out.type.element_ty)` cast is
erased to the identity at translation (see the file's Modeling boundary). -/

/-- **Streaming IO signature** of the case-3 (`(END,INIT,SW,CSW) = (1,1,0,0)`)
`_attn_fwd` surface on the three-stream two-output attention fold skin. -/
def attentionFwdTriton3Case3IO (Q K V M Out L : RegionName) (sm_scale : ℝ)
    (sqz sqh sqm sqk skz skh skn skk svz svh svk svn soz soh som son
      Z H H_KV N_CTX ROUND_CTX NKV_CTX off BM ND BN : Nat) :
    StreamMasked3DKernelIO₃ₓ₂ where
  kernel := attention_fwd_triton3_surface Q K V M Out L sm_scale
    sqz sqh sqm sqk skz skh skn skk svz svh svk svn soz soh som son
    Z H H_KV N_CTX ROUND_CTX NKV_CTX off 0 1 1 BM ND BN 1 1 0 0
  inp1 := Q
  inp2 := K
  inp3 := V
  out1 := Out
  out2 := M
  T := NKV_CTX / BN
  B1 := BM * ND
  B2 := ND * BN
  B3 := BN * ND
  C1 := BM * ND
  C2 := BM
  read1 := fun p₀ p₁ _ _ j =>
    (p₁ / H * sqz + p₁ % H * sqh) + (p₀ * BM + j.val / ND) * sqm + (j.val % ND) * sqk
  read2 := fun _ p₁ _ t j =>
    (p₁ / H * sqz + p₁ % H * sqh) + (j.val / BN) * skk + (t.val * BN + j.val % BN) * skn
  read3 := fun _ p₁ _ t j =>
    (p₁ / H * sqz + p₁ % H * sqh) + (t.val * BN + j.val / ND) * svk + (j.val % ND) * svn
  write1 := fun p₀ p₁ _ j =>
    (p₁ / H * sqz + p₁ % H * sqh) + (p₀ * BM + j.val / ND) * som + (j.val % ND) * son
  write2 := fun p₀ p₁ _ j => p₁ * ROUND_CTX + (p₀ * BM + j.val)
  mask1 := fun _ _ _ _ _ => True
  mask2 := fun _ _ _ _ _ => True
  mask3 := fun _ _ _ _ _ => True
  writeMask1 := fun _ _ _ _ => True
  writeMask2 := fun _ _ _ _ => True

/-- The `Q` tile read off the (static) first stream: the window ignores `t`,
so the step-`0` slice carries the whole tile. -/
noncomputable def aft3IOqT (BM ND T : Nat) (hT : 0 < T)
    (xs : Fin T → Fin (BM * ND) → ℝ) : TileIndex [BM, ND] → ℝ :=
  fun idx => xs ⟨0, hT⟩ (Lane2D.encode idx)

/-- The global `K` tile read off the second stream: global key `j` lives in
step `j / BN`, block-local column `j % BN`, at stream lane `(e, j % BN)`. -/
noncomputable def aft3IOkT (ND BN NC T : Nat) (hTB : T * BN = NC) (hBN : 0 < BN)
    (ys : Fin T → Fin (ND * BN) → ℝ) : TileIndex [NC, ND] → ℝ :=
  fun idx =>
    ys ⟨idx.1.val / BN, (Nat.div_lt_iff_lt_mul hBN).mpr (by rw [hTB]; exact idx.1.isLt)⟩
      (Lane2D.encode (idx.2.1, ⟨idx.1.val % BN, Nat.mod_lt _ hBN⟩, PUnit.unit))

/-- The global `V` tile read off the third stream: global key `j` lives in
step `j / BN`, block-local row `j % BN`, at stream lane `(j % BN, d)`. -/
noncomputable def aft3IOvT (ND BN NC T : Nat) (hTB : T * BN = NC) (hBN : 0 < BN)
    (zs : Fin T → Fin (BN * ND) → ℝ) : TileIndex [NC, ND] → ℝ :=
  fun idx =>
    zs ⟨idx.1.val / BN, (Nat.div_lt_iff_lt_mul hBN).mpr (by rw [hTB]; exact idx.1.isLt)⟩
      (Lane2D.encode (⟨idx.1.val % BN, Nat.mod_lt _ hBN⟩, idx.2.1, PUnit.unit))

/-- **Case-3 `Out` closed form on the streams**: the plain base-2
per-key-scale softmax (`attentionRealBase2PerKeyScalePred`, exactly the
existing `attentionFwdTriton3Case3OutSpecG`) restated over the three streamed
tiles, at output lane `j = (i, d)` row-major over `[BM, ND]`. -/
noncomputable def attentionFwdTriton3Case3IOOutSpec (BM ND BN NC T : Nat)
    (hT : 0 < T) (hTB : T * BN = NC) (hBN : 0 < BN) (sc : ℝ)
    (xs : Fin T → Fin (BM * ND) → ℝ) (ys : Fin T → Fin (ND * BN) → ℝ)
    (zs : Fin T → Fin (BN * ND) → ℝ) (j : Fin (BM * ND)) : ℝ :=
  attentionRealBase2PerKeyScalePred (aft3IOqT BM ND T hT xs)
    (aft3IOkT ND BN NC T hTB hBN ys) (aft3IOvT ND BN NC T hTB hBN zs)
    (keyScale3G sc NC) (fun (i : Fin BM) (j : Fin NC) => noWindowKeep i j)
    (Lane2D.decode j)

/-- **Case-3 `M` closed form on the streams**: the `m_i + log2 l_i` finalize
(exactly the existing `attentionFwdTriton3Case3MSpecG`) restated over the
three streamed tiles, at output row `i`. -/
noncomputable def attentionFwdTriton3Case3IOMSpec (BM ND BN NC T : Nat)
    (hND : 0 < ND) (hT : 0 < T) (hTB : T * BN = NC) (hBN : 0 < BN) (sc : ℝ)
    (xs : Fin T → Fin (BM * ND) → ℝ) (ys : Fin T → Fin (ND * BN) → ℝ)
    (zs : Fin T → Fin (BN * ND) → ℝ) (i : Fin BM) : ℝ :=
  (aft3RunningMaxG (aft3IOqT BM ND T hT xs) (aft3IOkT ND BN NC T hTB hBN ys)
      (aft3IOvT ND BN NC T hTB hBN zs) (keyScale3G sc NC)
      (fun i j => noWindowKeep i j) NC i ⟨0, hND⟩).unbotD 0
    + Real.log
      ((aft3StateBot1G (aft3IOqT BM ND T hT xs) (aft3IOkT ND BN NC T hTB hBN ys)
          (aft3IOvT ND BN NC T hTB hBN zs) (keyScale3G sc NC)
          (fun i j => noWindowKeep i j) NC i ⟨0, hND⟩).2.1) / Real.log 2

/-! ### Stream-pin tile bridges: under the skin's input pins the kernel-side
memory tiles ARE the stream-indexed tiles, pointwise. -/

/-- `qTile3G` = the static-stream tile, under the `read1` pins. -/
private theorem aft3IOqT_eq (s₀ : BlockState) (Q : RegionName)
    (base sqm sqk BM ND T : Nat) (hT : 0 < T)
    (xs : Fin T → Fin (BM * ND) → ℝ)
    (hx : ∀ (t : Fin T) (j : Fin (BM * ND)),
      s₀.readMem Q (base + (s₀.pids 0 * BM + j.val / ND) * sqm + (j.val % ND) * sqk)
        = xs t j) :
    qTile3G s₀ Q base BM ND sqm sqk = aft3IOqT BM ND T hT xs := by
  funext idx
  obtain ⟨i, e, ⟨⟩⟩ := idx
  show s₀.readMem Q (base + (s₀.pids 0 * BM + i.val) * sqm + e.val * sqk)
    = xs ⟨0, hT⟩ (Lane2D.encode (i, e, PUnit.unit))
  rw [← hx ⟨0, hT⟩ (Lane2D.encode (i, e, PUnit.unit))]
  simp only [Lane2D.encode_div, Lane2D.encode_mod]

/-- `kTile3G` = the `K`-stream tile, under the `read2` pins. -/
private theorem aft3IOkT_eq (s₀ : BlockState) (K : RegionName)
    (base skn skk ND BN NC T : Nat) (hTB : T * BN = NC) (hBN : 0 < BN)
    (ys : Fin T → Fin (ND * BN) → ℝ)
    (hy : ∀ (t : Fin T) (j : Fin (ND * BN)),
      s₀.readMem K (base + (j.val / BN) * skk + (t.val * BN + j.val % BN) * skn)
        = ys t j) :
    kTile3G s₀ K base NC ND skn skk = aft3IOkT ND BN NC T hTB hBN ys := by
  funext idx
  obtain ⟨j, e, ⟨⟩⟩ := idx
  show s₀.readMem K (base + j.val * skn + e.val * skk) = _
  rw [aft3IOkT]
  rw [← hy ⟨j.val / BN, (Nat.div_lt_iff_lt_mul hBN).mpr (by rw [hTB]; exact j.isLt)⟩
      (Lane2D.encode (e, ⟨j.val % BN, Nat.mod_lt _ hBN⟩, PUnit.unit))]
  simp only [Lane2D.encode_div, Lane2D.encode_mod]
  refine congrArg (s₀.readMem K) ?_
  have hdm : j.val / BN * BN + j.val % BN = j.val := Nat.div_add_mod' j.val BN
  rw [hdm]
  ring

/-- `vTile3G` = the `V`-stream tile, under the `read3` pins. -/
private theorem aft3IOvT_eq (s₀ : BlockState) (V : RegionName)
    (base svk svn ND BN NC T : Nat) (hTB : T * BN = NC) (hBN : 0 < BN)
    (zs : Fin T → Fin (BN * ND) → ℝ)
    (hz : ∀ (t : Fin T) (j : Fin (BN * ND)),
      s₀.readMem V (base + (t.val * BN + j.val / ND) * svk + (j.val % ND) * svn)
        = zs t j) :
    vTile3G s₀ V base NC ND svk svn = aft3IOvT ND BN NC T hTB hBN zs := by
  funext idx
  obtain ⟨j, d, ⟨⟩⟩ := idx
  show s₀.readMem V (base + j.val * svk + d.val * svn) = _
  rw [aft3IOvT]
  rw [← hz ⟨j.val / BN, (Nat.div_lt_iff_lt_mul hBN).mpr (by rw [hTB]; exact j.isLt)⟩
      (Lane2D.encode (⟨j.val % BN, Nat.mod_lt _ hBN⟩, d, PUnit.unit))]
  simp only [Lane2D.encode_div, Lane2D.encode_mod]
  refine congrArg (s₀.readMem V) ?_
  have hdm : j.val / BN * BN + j.val % BN = j.val := Nat.div_add_mod' j.val BN
  rw [hdm]

/-! ## The safety walk (weak invariant)

The skin's `hts` obligation quantifies over **arbitrary** launch states, so
the clean-`undef` full invariant `attnInvariantG` is unavailable there. The
safety walk instead runs on the *shape* half: exact pins for the four
loop-carried pointers (whose addresses are the bound obligations) plus bare
existence for the value registers, mirroring `matmul_kernel`'s `matmulSafeInv`
precedent. -/

/-- Safety-walk loop invariant: counter bounds, `start_m`/`off_hz` pins, the
exact `K`/`V` block-pointer shapes at counter `c`, the exact `m_ptrs`/`l_ptrs`
/`O_block_ptr` shapes, and existence of the value registers. -/
private def aft3SafeInv (K V M Out L : RegionName) (s0 : BlockState)
    (base BM ND NC BN skk skn svk svn som son ROUND_CTX : Nat)
    (c : Nat) (s : BlockState) : Prop :=
  c % BN = 0 ∧ c ≤ NC ∧
  s.regs .nat [] "start_m" = some (Tile.scalar (s0.pids 0)) ∧
  s.regs .nat [] "off_hz" = some (Tile.scalar (s0.pids 1)) ∧
  (∃ qT : Tile .real [BM, ND], s.regs .real [BM, ND] "q" = some qT) ∧
  (∃ sc : ℝ, s.regs .real [] "qk_scale" = some (Tile.scalar (some sc))) ∧
  (∃ mT : Tile .real [BM], s.regs .real [BM] "m_i" = some mT) ∧
  (∃ lT : Tile .real [BM], s.regs .real [BM] "l_i" = some lT) ∧
  (∃ aT : Tile .real [BM, ND], s.regs .real [BM, ND] "acc" = some aT) ∧
  s.regs .blockPtr [ND, BN] "K_block_ptr" = some
    (⟨fun _ : TileIndex [ND, BN] =>
      { region := K, baseOffset := base, parentShape := [ND, NC], blockShape := [ND, BN],
        strides := [skk, skn], offsets := [0, c] }⟩) ∧
  s.regs .blockPtr [BN, ND] "V_block_ptr" = some
    (⟨fun _ : TileIndex [BN, ND] =>
      { region := V, baseOffset := base, parentShape := [NC, ND], blockShape := [BN, ND],
        strides := [svk, svn], offsets := [c, 0] }⟩) ∧
  s.regs .ptr [BM] "m_ptrs" = some
    (Tile.ptrAdd Broadcast.scalarL (Tile.scalar (M.cast, (0 : Nat)))
      (Tile.bop NumericDType.nat.add Broadcast.scalarL (Tile.scalar (s0.pids 1 * ROUND_CTX))
        (Tile.vec (fun r : Fin BM => s0.pids 0 * BM + r.val)))) ∧
  s.regs .ptr [BM] "l_ptrs" = some
    (Tile.ptrAdd Broadcast.scalarL (Tile.scalar (L.cast, (0 : Nat)))
      (Tile.bop NumericDType.nat.add Broadcast.scalarL (Tile.scalar (s0.pids 1 * ROUND_CTX))
        (Tile.vec (fun r : Fin BM => s0.pids 0 * BM + r.val)))) ∧
  s.regs .blockPtr [BM, ND] "O_block_ptr" = some
    (⟨fun _ : TileIndex [BM, ND] =>
      { region := Out, baseOffset := base, parentShape := [ROUND_CTX, ND], blockShape := [BM, ND],
        strides := [som, son], offsets := [s0.pids 0 * BM, 0] }⟩)

set_option maxHeartbeats 4000000 in
set_option maxRecDepth 8000 in
/-- **Weak preLoop**: from an **arbitrary** launch state (no clean-`undef`
hypothesis) the case-3 preLoop steps to a state satisfying `aft3SafeInv … 0`.
Value conclusions of `aft3PreLoop_evalG` are dropped; only the shape half is
kept. -/
private theorem aft3PreLoop_evalW
    (Q K V M Out L : RegionName) (sm_scale : ℝ)
    (sqz sqh sqm sqk skz skh skn skk svz svh svk svn soz soh som son
      H H_KV N_CTX ROUND_CTX NKV_CTX off size BM ND BN : Nat) (s : BlockState)
    (hH : 0 < H) (hHKV : H_KV = H)
    (hskz : skz = sqz) (hskh : skh = sqh) (hsvz : svz = sqz) (hsvh : svh = sqh)
    (hsoz : soz = sqz) (hsoh : soh = sqh) :
    ∃ s', stepStmts (aft3PreLoopG Q K V M Out L sm_scale sqz sqh sqm sqk skz skh skn skk svz svh svk svn soz soh som son H H_KV N_CTX ROUND_CTX NKV_CTX off size BM ND BN) s = some s'
      ∧ aft3SafeInv K V M Out L s (s.pids 1 / H * sqz + s.pids 1 % H * sqh) BM ND NKV_CTX BN skk skn svk svn som son ROUND_CTX 0 s' := by
  obtain ⟨s11, h11, hpids, hmem, huf, hstart, hoffhz, hQp, hKp, hVp, hOp, hMptr, hLptr⟩ :=
    aft3PreLoopScalarsG_eval Q K V M Out L sm_scale sqz sqh sqm sqk skz skh skn skk svz svh svk svn soz soh som son H H_KV N_CTX ROUND_CTX NKV_CTX off size BM ND BN s hH hHKV hskz hskh hsvz hsvh hsoz hsoh
  rw [show aft3PreLoopG Q K V M Out L sm_scale sqz sqh sqm sqk skz skh skn skk svz svh svk svn soz soh som son H H_KV N_CTX ROUND_CTX NKV_CTX off size BM ND BN
      = aft3PreLoopScalarsG Q K V M Out L sm_scale sqz sqh sqm sqk skz skh skn skk svz svh svk svn soz soh som son H H_KV N_CTX ROUND_CTX NKV_CTX off size BM ND BN ++ (aft3PreLoopG Q K V M Out L sm_scale sqz sqh sqm sqk skz skh skn skk svz svh svk svn soz soh som son H H_KV N_CTX ROUND_CTX NKV_CTX off size BM ND BN).drop 16 from by
    rw [aft3PreLoopScalarsG]; rw [List.take_append_drop]]
  rw [stepStmts.append_some h11]
  rw [show (aft3PreLoopG Q K V M Out L sm_scale sqz sqh sqm sqk skz skh skn skk svz svh svk svn soz soh som son H H_KV N_CTX ROUND_CTX NKV_CTX off size BM ND BN).drop 16
      = [ Stmt.ifThenElse (Op.ne ComparableDType.nat Broadcast.nil (Op.constNat 1) (Op.constNat 0)) [Stmt.assign TileDType.real [BM] "m_i" ((Op.add NumericDType.real Broadcast.scalarR (Op.full [BM] (Op.const 0)) Op.negInf)), Stmt.assign TileDType.real [BM] "l_i" ((Op.add NumericDType.real Broadcast.scalarR (Op.full [BM] (Op.const 0)) (Op.const 1.0))), Stmt.assign TileDType.real [BM, ND] "acc" (Op.full [BM, ND] (Op.const 0))] [Stmt.assign TileDType.real [BM] "m_i" (Op.load TileDType.real (MemAccess.ptr (Op.ref TileDType.ptr [BM] "m_ptrs")) MaskOpt.none), Stmt.assign TileDType.real [BM] "l_i" (Op.load TileDType.real (MemAccess.ptr (Op.ref TileDType.ptr [BM] "l_ptrs")) MaskOpt.none), Stmt.assign TileDType.real [BM, ND] "acc" (Op.load TileDType.real (MemAccess.blockPtr (Op.ref TileDType.blockPtr [BM, ND] "O_block_ptr") []) MaskOpt.none .unspecified)],
          Stmt.assign TileDType.real [] "qk_scale" (Op.mul NumericDType.real Broadcast.nil (Op.const sm_scale) (Op.const 1.0)),
          Stmt.assign TileDType.real [] "qk_scale" (Op.mul NumericDType.real Broadcast.nil (Op.ref TileDType.real [] "qk_scale") (Op.const 1.4426950408889634)),
          Stmt.ifThenElse (Op.ne ComparableDType.nat Broadcast.nil (Op.constNat 1) (Op.constNat 0)) [Stmt.assign TileDType.real [BM, ND] "q" (Op.load TileDType.real (MemAccess.blockPtr (Op.ref TileDType.blockPtr [BM, ND] "Q_block_ptr") []) MaskOpt.none .unspecified)] [Stmt.assign TileDType.real [BM, ND] "q" (Op.load TileDType.real (MemAccess.blockPtr (Op.ref TileDType.blockPtr [BM, ND] "Q_block_ptr") [0, 1]) MaskOpt.none)] ] from by rfl]
  rw [stepStmts.cons_some
    (show stepStmt _ s11 = some _ from by
      rw [aft3_ifThenElse_true (aft3_ne_one_zero_true s11), aft3_init_stepsG s11 BM ND])]
  rw [stepStmts.cons_some (stepStmt_assign_eq_some
    (show evalOp (Op.mul NumericDType.real Broadcast.nil (Op.const sm_scale) (Op.const 1.0)) _
        = some (Tile.scalar (some (sm_scale * 1.0))) from by
      rw [evalOp_mul]
      simp only [evalOp_const, Option.bind_eq_bind, Option.bind_some]
      refine congrArg some (congrArg Tile.scalar ?_)
      simp only [NumericDType.mul, WithBot.realMul, Option.map₂, Option.bind, Option.map]))]
  rw [stepStmts.cons_some (stepStmt_assign_eq_some
    (show evalOp (Op.mul NumericDType.real Broadcast.nil (Op.ref TileDType.real [] "qk_scale") (Op.const 1.4426950408889634)) _
        = some (Tile.scalar (some (sm_scale * 1.4426950408889634))) from by
      rw [evalOp_mul]
      simp only [evalOp_ref, evalOp_const, BlockState.setReg_same, Option.bind_eq_bind,
        Option.bind_some]
      refine congrArg some (congrArg Tile.scalar ?_)
      simp only [NumericDType.mul, WithBot.realMul, Option.map₂, Option.bind, Option.map]
      refine congrArg some ?_; norm_num))]
  rw [stepStmts.cons_some
    (show stepStmt _ _ = some _ from by
      rw [aft3_ifThenElse_true (aft3_ne_one_zero_true _)]
      rw [stepStmts.cons_some (stepStmt_assign_eq_some
        (aft3_load_v_eval Q (s.pids 1 / H * sqz + s.pids 1 % H * sqh) N_CTX ND BM ND sqm sqk (s.pids 0 * BM)
          (Op.ref TileDType.blockPtr [BM, ND] "Q_block_ptr") _
          (by rw [evalOp_ref]
              simp only [BlockState.setReg_ne_name, ne_eq, String.reduceEq, not_false_eq_true,
                BlockState.setReg_same]
              exact hQp)))]
      rw [stepStmts.nil])]
  rw [stepStmts.nil]
  refine ⟨_, rfl, ?_⟩
  refine ⟨by simp, Nat.zero_le _, ?_, ?_,
    ⟨⟨fun idx : TileIndex [BM, ND] => some (s11.readMem Q
        (s.pids 1 / H * sqz + s.pids 1 % H * sqh + (s.pids 0 * BM + idx.1.val) * sqm + idx.2.1.val * sqk))⟩, ?_⟩,
    ⟨sm_scale * 1.4426950408889634, ?_⟩,
    ⟨⟨fun _ : TileIndex [BM] => (⊥ : WithBot ℝ)⟩, ?_⟩,
    ⟨⟨fun _ : TileIndex [BM] => some (1 : ℝ)⟩, ?_⟩,
    ⟨⟨fun _ : TileIndex [BM, ND] => some (0 : ℝ)⟩, ?_⟩, ?_, ?_, ?_, ?_, ?_⟩
  · simp only [BlockState.setReg_ne_name, ne_eq, String.reduceEq, not_false_eq_true,
      BlockState.setReg_same]
    rw [hstart]
  · simp only [BlockState.setReg_ne_name, ne_eq, String.reduceEq, not_false_eq_true,
      BlockState.setReg_same]
    rw [hoffhz]
  · simp only [BlockState.setReg_same]
    refine congrArg some (Tile.ext fun idx => ?_)
    simp only [BlockState.setReg_readMem]
  · simp only [BlockState.setReg_ne_name, ne_eq, String.reduceEq, not_false_eq_true,
      BlockState.setReg_same]
  · simp only [BlockState.setReg_ne_name, ne_eq, String.reduceEq, not_false_eq_true,
      BlockState.setReg_same]
  · simp only [BlockState.setReg_ne_name, ne_eq, String.reduceEq, not_false_eq_true,
      BlockState.setReg_same]
  · simp only [BlockState.setReg_ne_name, ne_eq, String.reduceEq, not_false_eq_true,
      BlockState.setReg_same]
  · simp only [BlockState.setReg_ne_name, ne_eq, String.reduceEq, not_false_eq_true,
      BlockState.setReg_same]
    rw [hKp]
  · simp only [BlockState.setReg_ne_name, ne_eq, String.reduceEq, not_false_eq_true,
      BlockState.setReg_same]
    rw [hVp]
  · simp only [BlockState.setReg_ne_name, ne_eq, String.reduceEq, not_false_eq_true,
      BlockState.setReg_same]
    rw [hMptr]
  · simp only [BlockState.setReg_ne_name, ne_eq, String.reduceEq, not_false_eq_true,
      BlockState.setReg_same]
    rw [hLptr]
  · simp only [BlockState.setReg_ne_name, ne_eq, String.reduceEq, not_false_eq_true,
      BlockState.setReg_same]
    rw [hOp]

set_option maxHeartbeats 4000000 in
set_option maxRecDepth 8000 in
/-- **Weak loop-body step** (`aft3LoopBodyG3_steps` minus the clean-`undef`
hypothesis, shape conclusions only): the case-3 body steps successfully from
register pins alone, advancing the `K`/`V` block pointers and preserving the
other pins. The `smsc` body argument is phantom (the lowered body reads
`qk_scale` from the register file), so it is decoupled from the pinned
register value `sc`. -/
private theorem aft3LoopBodyG3_stepsW (sin : BlockState) (SM ohz smsc_off : Nat) (smsc : ℝ)
    (Kreg Vreg : RegionName) (kbase vbase kcol vrow : Nat)
    (skk skn svk svn ND NKV_CTX BM BN : Nat) (hBN : 0 < BN)
    (qtile : Tile .real [BM, ND]) (mtile ltile : Tile .real [BM]) (acctile : Tile .real [BM, ND])
    (ktile : Tile .real [ND, BN]) (vtile : Tile .real [BN, ND]) (sc : ℝ)
    (mptrs lptrs : Tile .ptr [BM]) (oblk : Tile .blockPtr [BM, ND])
    (hmptrs : sin.regs .ptr [BM] "m_ptrs" = some mptrs)
    (hlptrs : sin.regs .ptr [BM] "l_ptrs" = some lptrs)
    (hoblk : sin.regs .blockPtr [BM, ND] "O_block_ptr" = some oblk)
    (hsm : sin.regs .nat [] "start_m" = some (Tile.scalar SM))
    (hoff : sin.regs .nat [] "off_hz" = some (Tile.scalar ohz))
    (hq : sin.regs .real [BM, ND] "q" = some qtile)
    (hqs : sin.regs .real [] "qk_scale" = some (Tile.scalar (some sc)))
    (hmi : sin.regs .real [BM] "m_i" = some mtile)
    (hli : sin.regs .real [BM] "l_i" = some ltile)
    (hacc : sin.regs .real [BM, ND] "acc" = some acctile)
    (hKp : sin.regs .blockPtr [ND, BN] "K_block_ptr" = some
      (⟨fun _ : TileIndex [ND, BN] =>
        { region := Kreg, baseOffset := kbase, parentShape := [ND, NKV_CTX],
          blockShape := [ND, BN], strides := [skk, skn], offsets := [0, kcol] }⟩))
    (hVp : sin.regs .blockPtr [BN, ND] "V_block_ptr" = some
      (⟨fun _ : TileIndex [BN, ND] =>
        { region := Vreg, baseOffset := vbase, parentShape := [NKV_CTX, ND],
          blockShape := [BN, ND], strides := [svk, svn], offsets := [vrow, 0] }⟩))
    (hkload : ∀ idx : TileIndex [ND, BN],
      ktile.data idx = some (sin.readMem Kreg (kbase + idx.1.val * skk + (kcol + idx.2.1.val) * skn)))
    (hvload : ∀ idx : TileIndex [BN, ND],
      vtile.data idx = some (sin.readMem Vreg (vbase + (vrow + idx.1.val) * svk + idx.2.1.val * svn))) :
    ∃ sF, stepStmts (aft3LoopBodyG3 smsc smsc_off BM ND BN) sin = some sF
      ∧ sF.regs .nat [] "start_m" = some (Tile.scalar SM)
      ∧ sF.regs .nat [] "off_hz" = some (Tile.scalar ohz)
      ∧ sF.regs .real [BM, ND] "q" = some qtile
      ∧ sF.regs .real [] "qk_scale" = some (Tile.scalar (some sc))
      ∧ (∃ mT : Tile .real [BM], sF.regs .real [BM] "m_i" = some mT)
      ∧ (∃ lT : Tile .real [BM], sF.regs .real [BM] "l_i" = some lT)
      ∧ (∃ aT : Tile .real [BM, ND], sF.regs .real [BM, ND] "acc" = some aT)
      ∧ sF.regs .blockPtr [ND, BN] "K_block_ptr" = some
          (⟨fun _ : TileIndex [ND, BN] =>
            { region := Kreg, baseOffset := kbase, parentShape := [ND, NKV_CTX],
              blockShape := [ND, BN], strides := [skk, skn], offsets := [0, kcol + BN] }⟩)
      ∧ sF.regs .blockPtr [BN, ND] "V_block_ptr" = some
          (⟨fun _ : TileIndex [BN, ND] =>
            { region := Vreg, baseOffset := vbase, parentShape := [NKV_CTX, ND],
              blockShape := [BN, ND], strides := [svk, svn], offsets := [vrow + BN, 0] }⟩)
      ∧ sF.regs .ptr [BM] "m_ptrs" = some mptrs
      ∧ sF.regs .ptr [BM] "l_ptrs" = some lptrs
      ∧ sF.regs .blockPtr [BM, ND] "O_block_ptr" = some oblk := by
  set qkT : Tile .real [BM, BN] :=
    Tile.bop NumericDType.real.mul Broadcast.scalarR
      (Tile.bop NumericDType.real.add (Broadcast.consSame (Broadcast.consSame Broadcast.nil))
        (⟨fun _ => some (0 : ℝ)⟩ : Tile .real [BM, BN]) (Tile.dot [] qtile ktile))
      (Tile.scalar (some sc)) with hqkT
  obtain ⟨rmaxT, hrm⟩ : ∃ t, Tile.reduceMaxDrop (⟨1, by simp⟩ : Fin [BM, BN].length) qkT = some t :=
    ⟨_, by unfold Tile.reduceMaxDrop; rw [dif_pos (show 0 < TileShape.axisDim [BM, BN] (⟨1, by simp⟩ : Fin [BM, BN].length) from by simpa [TileShape.axisDim] using hBN)]⟩
  set mijT : Tile .real [BM] := Tile.select (Tile.cop ComparableDType.real.gt (Broadcast.consSame Broadcast.nil) mtile rmaxT) mtile rmaxT with hmij
  set alphaT : Tile .real [BM] := Tile.uop WithBot.realExp2 (Tile.bop NumericDType.real.sub (Broadcast.consSame Broadcast.nil) mtile mijT) with halpha
  set pT : Tile .real [BM, BN] := Tile.uop WithBot.realExp2 (Tile.bop NumericDType.real.sub (Broadcast.consSame (Broadcast.consR Broadcast.nil)) qkT (Tile.expandDim ⟨1, by simp⟩ mijT)) with hpT
  set lijT : Tile .real [BM] := Tile.reduceSumDrop (⟨1, by simp⟩ : Fin [BM, BN].length) pT with hlij
  set acc1T : Tile .real [BM, ND] := Tile.bop NumericDType.real.mul (Broadcast.consSame (Broadcast.consR Broadcast.nil)) acctile (Tile.expandDim ⟨1, by simp⟩ alphaT) with hacc1
  unfold aft3LoopBodyG3
  -- L1: k = load K_block_ptr
  rw [stepStmts.cons_some (stepStmt_assign_eq_some
    (show evalOp (Op.load TileDType.real (MemAccess.blockPtr (Op.ref TileDType.blockPtr [ND, BN] "K_block_ptr") []) MaskOpt.none .unspecified) sin
        = some ktile from by
      rw [aft3_load_k_eval Kreg kbase ND NKV_CTX ND BN skk skn kcol (Op.ref TileDType.blockPtr [ND, BN] "K_block_ptr") sin
        (by rw [evalOp_ref]; exact hKp)]
      refine congrArg some ?_; refine Tile.ext (fun idx => ?_); rw [hkload idx]))]
  -- L2: qk = zeros
  rw [stepStmts.cons_some (stepStmt_assign_eq_some (aft3_qkzeros_eval _ BM BN))]
  -- L3: qk += dot q k
  rw [stepStmts.cons_some (stepStmt_assign_eq_some
    (aft3_qk_dot_eval _ BM BN ND (⟨fun _ => some (0 : ℝ)⟩ : Tile .real [BM, BN]) qtile ktile
      (by rw [BlockState.setReg_same])
      (by simp only [BlockState.setReg_ne_name, ne_eq, String.reduceEq, not_false_eq_true,
            BlockState.setReg_same]; exact hq)
      (by simp only [BlockState.setReg_ne_name, ne_eq, String.reduceEq, not_false_eq_true,
            BlockState.setReg_same] <;> try rfl)))]
  -- L4: qk *= qk_scale
  rw [stepStmts.cons_some (stepStmt_assign_eq_some
    (aft3_qk_scale_ref_eval _ BM BN sc
      (Tile.bop NumericDType.real.add (Broadcast.consSame (Broadcast.consSame Broadcast.nil))
        (⟨fun _ => some (0 : ℝ)⟩ : Tile .real [BM, BN]) (Tile.dot [] qtile ktile))
      (by rw [BlockState.setReg_same])
      (by simp only [BlockState.setReg_ne_name, ne_eq, String.reduceEq, not_false_eq_true]; exact hqs)))]
  -- L5: window ifThen (SLIDING_WINDOW false) → skipped
  rw [stepStmts.cons_some (aft3_ifThen_false (aft3_ne_zero_zero_false _))]
  -- L6: m_ij = maximum(m_i, max(qk,1))
  rw [stepStmts.cons_some (stepStmt_assign_eq_some
    (aft3_mij_evalG _ BM BN mtile qkT rmaxT (by simp)
      (by simp only [BlockState.setReg_ne_name, ne_eq, String.reduceEq, not_false_eq_true]; exact hmi)
      (by rw [BlockState.setReg_same] <;> try rfl)
      hrm))]
  -- L7: qk -= m_ij[:, None]
  rw [stepStmts.cons_some (stepStmt_assign_eq_some
    (aft3_qk_sub_evalG _ BM BN (by simp) qkT mijT
      (by simp only [BlockState.setReg_ne_name, ne_eq, String.reduceEq, not_false_eq_true,
            BlockState.setReg_same] <;> try rfl)
      (by rw [BlockState.setReg_same])))]
  -- L8: p = exp2 qk
  rw [stepStmts.cons_some (stepStmt_assign_eq_some
    (aft3_p_evalG _ BM BN (Tile.bop NumericDType.real.sub (Broadcast.consSame (Broadcast.consR Broadcast.nil)) qkT (Tile.expandDim ⟨1, by simp⟩ mijT))
      (by rw [BlockState.setReg_same])))]
  -- L9: pmask ifThen (SLIDING_WINDOW false) → skipped
  rw [stepStmts.cons_some (aft3_ifThen_false (aft3_ne_zero_zero_false _))]
  -- L10: l_ij = sum p 1
  rw [stepStmts.cons_some (@stepStmt_assign_eq_some .real [BM] "l_ij"
    (Op.reduceSum (⟨1, by simp⟩ : Fin [BM, BN].length) Bool.false (Op.ref .real [BM, BN] "p")) _ lijT
    (aft3_lij_evalG _ BM BN pT (by simp) (by rw [BlockState.setReg_same])))]
  -- L11: tmp = m_i - m_ij
  rw [stepStmts.cons_some (stepStmt_assign_eq_some
    (aft3_tmp_evalG _ BM mtile mijT
      (by simp only [BlockState.setReg_ne_name, ne_eq, String.reduceEq, not_false_eq_true]; exact hmi)
      (by simp only [BlockState.setReg_ne_name, ne_eq, String.reduceEq, not_false_eq_true,
            BlockState.setReg_same] <;> try rfl)))]
  -- L12: alpha = exp2 tmp
  rw [stepStmts.cons_some (stepStmt_assign_eq_some
    (aft3_alpha_evalG _ BM (Tile.bop NumericDType.real.sub (Broadcast.consSame Broadcast.nil) mtile mijT)
      (by rw [BlockState.setReg_same])))]
  -- L13: l_i = l_i * alpha + l_ij
  rw [stepStmts.cons_some (stepStmt_assign_eq_some
    (aft3_li_evalG _ BM ltile alphaT lijT
      (by simp only [BlockState.setReg_ne_name, ne_eq, String.reduceEq, not_false_eq_true]; exact hli)
      (by simp only [BlockState.setReg_ne_name, ne_eq, String.reduceEq, not_false_eq_true,
            BlockState.setReg_same] <;> try rfl)
      (by simp only [BlockState.setReg_ne_name, ne_eq, String.reduceEq, not_false_eq_true,
            BlockState.setReg_same] <;> try rfl)))]
  -- L14: acc = acc * alpha[:, None]
  rw [stepStmts.cons_some (stepStmt_assign_eq_some
    (aft3_acc_rescale_evalG _ BM ND (by simp) acctile alphaT
      (by simp only [BlockState.setReg_ne_name, ne_eq, String.reduceEq, not_false_eq_true]; exact hacc)
      (by simp only [BlockState.setReg_ne_name, ne_eq, String.reduceEq, not_false_eq_true,
            BlockState.setReg_same] <;> try rfl)))]
  -- L15: v = load V_block_ptr
  rw [stepStmts.cons_some (stepStmt_assign_eq_some
    (show evalOp (Op.load TileDType.real (MemAccess.blockPtr (Op.ref TileDType.blockPtr [BN, ND] "V_block_ptr") []) MaskOpt.none .unspecified) _
        = some vtile from by
      rw [aft3_load_v_eval Vreg vbase NKV_CTX ND BN ND svk svn vrow (Op.ref TileDType.blockPtr [BN, ND] "V_block_ptr") _
        (by rw [evalOp_ref]
            simp only [BlockState.setReg_ne_name, ne_eq, String.reduceEq, not_false_eq_true]
            exact hVp)]
      refine congrArg some ?_; refine Tile.ext (fun idx => ?_)
      simp only [BlockState.setReg_readMem]; rw [hvload idx]))]
  -- L16: acc += dot p v
  rw [stepStmts.cons_some (stepStmt_assign_eq_some
    (aft3_acc_eval _ BM BN ND acc1T pT vtile
      (by simp only [BlockState.setReg_ne_name, ne_eq, String.reduceEq, not_false_eq_true,
            BlockState.setReg_same] <;> try rfl)
      (by simp only [BlockState.setReg_ne_name, ne_eq, String.reduceEq, not_false_eq_true,
            BlockState.setReg_same] <;> try rfl)
      (by rw [BlockState.setReg_same])))]
  -- L17: m_i = m_ij
  rw [stepStmts.cons_some (stepStmt_assign_eq_some
    (aft3_mi_carry_evalG _ BM mijT
      (by simp only [BlockState.setReg_ne_name, ne_eq, String.reduceEq, not_false_eq_true,
            BlockState.setReg_same] <;> try rfl)))]
  -- L18: V_block_ptr = advance [BN, 0]
  rw [stepStmts.cons_some (stepStmt_assign_eq_some
    (aft3_advance_v_eval _ Vreg vbase NKV_CTX ND BN ND svk svn vrow BN "V_block_ptr"
      (by simp only [BlockState.setReg_ne_name, ne_eq, String.reduceEq, not_false_eq_true]; exact hVp)))]
  -- L19: K_block_ptr = advance [0, BN]
  rw [stepStmts.cons_some (stepStmt_assign_eq_some
    (aft3_advance_k_eval _ Kreg kbase ND NKV_CTX ND BN skk skn kcol BN "K_block_ptr"
      (by simp only [BlockState.setReg_ne_name, ne_eq, String.reduceEq, not_false_eq_true]; exact hKp)))]
  rw [stepStmts.nil]
  refine ⟨_, rfl, ?_, ?_, ?_, ?_, ⟨mijT, ?_⟩,
    ⟨Tile.bop NumericDType.real.add (Broadcast.consSame Broadcast.nil)
      (Tile.bop NumericDType.real.mul (Broadcast.consSame Broadcast.nil) ltile alphaT) lijT, ?_⟩,
    ⟨Tile.bop NumericDType.real.add (Broadcast.consSame (Broadcast.consSame Broadcast.nil))
      acc1T (Tile.dot [] pT vtile), ?_⟩, ?_, ?_, ?_, ?_, ?_⟩
  · simp only [BlockState.setReg_ne_name, ne_eq, String.reduceEq, not_false_eq_true,
      BlockState.setReg_same]; exact hsm
  · simp only [BlockState.setReg_ne_name, ne_eq, String.reduceEq, not_false_eq_true,
      BlockState.setReg_same]; exact hoff
  · simp only [BlockState.setReg_ne_name, ne_eq, String.reduceEq, not_false_eq_true,
      BlockState.setReg_same]; exact hq
  · simp only [BlockState.setReg_ne_name, ne_eq, String.reduceEq, not_false_eq_true,
      BlockState.setReg_same]; exact hqs
  · simp only [BlockState.setReg_ne_name, ne_eq, String.reduceEq, not_false_eq_true,
      BlockState.setReg_same]
  · simp only [BlockState.setReg_ne_name, ne_eq, String.reduceEq, not_false_eq_true,
      BlockState.setReg_same]
  · simp only [BlockState.setReg_ne_name, ne_eq, String.reduceEq, not_false_eq_true,
      BlockState.setReg_same]
  · simp only [BlockState.setReg_same]
  · simp only [BlockState.setReg_ne_name, ne_eq, String.reduceEq, not_false_eq_true,
      BlockState.setReg_same]
  · simp only [BlockState.setReg_ne_name, ne_eq, String.reduceEq, not_false_eq_true,
      BlockState.setReg_same]; exact hmptrs
  · simp only [BlockState.setReg_ne_name, ne_eq, String.reduceEq, not_false_eq_true,
      BlockState.setReg_same]; exact hlptrs
  · simp only [BlockState.setReg_ne_name, ne_eq, String.reduceEq, not_false_eq_true,
      BlockState.setReg_same]; exact hoblk

set_option maxHeartbeats 2000000 in
/-- **Weak invariant step**: one case-3 body iteration from `aft3SafeInv c`
steps successfully (exact stepper) and re-establishes `aft3SafeInv (c + BN)`. -/
private theorem aft3_attn_stepW (K V M Out L : RegionName) (s0 : BlockState) (smsc : ℝ)
    (base BM ND NC BN skk skn svk svn som son ROUND_CTX smsc_off : Nat)
    (hBN : 0 < BN) (hBNdvd : BN ∣ NC)
    (c : Nat) (s : BlockState) (hlt : c < NC)
    (hP : aft3SafeInv K V M Out L s0 base BM ND NC BN skk skn svk svn som son ROUND_CTX c s) :
    ∃ s', stepStmts (aft3LoopBodyG3 smsc smsc_off BM ND BN)
        (s.setReg "start_n" .nat [] (Tile.scalar c)) = some s'
      ∧ aft3SafeInv K V M Out L s0 base BM ND NC BN skk skn svk svn som son ROUND_CTX (c + BN) s' := by
  obtain ⟨hmod, hle, hsm, hoff, ⟨qT, hq⟩, ⟨sc, hqs⟩, ⟨mT, hmi⟩, ⟨lT, hli⟩, ⟨aT, hacc⟩,
    hKp, hVp, hMptr, hLptr, hOp⟩ := hP
  set sin := s.setReg "start_n" .nat [] (Tile.scalar c) with hsin
  obtain ⟨sF, hstep, hsm', hoff', hq', hqs', hmiE, hliE, haccE, hKp', hVp', hMptr', hLptr', hOp'⟩ :=
    aft3LoopBodyG3_stepsW sin (s0.pids 0) (s0.pids 1) smsc_off smsc K V base base c c
      skk skn svk svn ND NC BM BN hBN qT mT lT aT
      (⟨fun idx : TileIndex [ND, BN] =>
        some (sin.readMem K (base + idx.1.val * skk + (c + idx.2.1.val) * skn))⟩)
      (⟨fun idx : TileIndex [BN, ND] =>
        some (sin.readMem V (base + (c + idx.1.val) * svk + idx.2.1.val * svn))⟩)
      sc _ _ _
      (by rw [hsin]
          simp only [BlockState.setReg_ne_name, ne_eq, String.reduceEq, not_false_eq_true]
          exact hMptr)
      (by rw [hsin]
          simp only [BlockState.setReg_ne_name, ne_eq, String.reduceEq, not_false_eq_true]
          exact hLptr)
      (by rw [hsin]
          simp only [BlockState.setReg_ne_name, ne_eq, String.reduceEq, not_false_eq_true]
          exact hOp)
      (by rw [hsin]
          simp only [BlockState.setReg_ne_name, ne_eq, String.reduceEq, not_false_eq_true]
          exact hsm)
      (by rw [hsin]
          simp only [BlockState.setReg_ne_name, ne_eq, String.reduceEq, not_false_eq_true]
          exact hoff)
      (by rw [hsin]
          simp only [BlockState.setReg_ne_name, ne_eq, String.reduceEq, not_false_eq_true]
          exact hq)
      (by rw [hsin]
          simp only [BlockState.setReg_ne_name, ne_eq, String.reduceEq, not_false_eq_true]
          exact hqs)
      (by rw [hsin]
          simp only [BlockState.setReg_ne_name, ne_eq, String.reduceEq, not_false_eq_true]
          exact hmi)
      (by rw [hsin]
          simp only [BlockState.setReg_ne_name, ne_eq, String.reduceEq, not_false_eq_true]
          exact hli)
      (by rw [hsin]
          simp only [BlockState.setReg_ne_name, ne_eq, String.reduceEq, not_false_eq_true]
          exact hacc)
      (by rw [hsin]
          simp only [BlockState.setReg_ne_name, ne_eq, String.reduceEq, not_false_eq_true]
          exact hKp)
      (by rw [hsin]
          simp only [BlockState.setReg_ne_name, ne_eq, String.reduceEq, not_false_eq_true]
          exact hVp)
      (fun idx => rfl) (fun idx => rfl)
  have hmod' : (c + BN) % BN = 0 := by rw [Nat.add_mod_right]; exact hmod
  have hle' : c + BN ≤ NC := by
    obtain ⟨k, hk⟩ := hBNdvd
    obtain ⟨m, hm⟩ := Nat.dvd_of_mod_eq_zero hmod
    subst hk hm
    have hmk : m < k := by
      by_contra hmk
      exact Nat.not_le_of_lt hlt (Nat.mul_le_mul_left BN (Nat.le_of_not_lt hmk))
    calc BN * m + BN = BN * (m + 1) := by ring
      _ ≤ BN * k := Nat.mul_le_mul_left BN hmk
  exact ⟨sF, hstep, hmod', hle', hsm', hoff', ⟨qT, hq'⟩, ⟨sc, hqs'⟩, hmiE, hliE, haccE,
    hKp', hVp', hMptr', hLptr', hOp'⟩

set_option maxHeartbeats 4000000 in
set_option maxRecDepth 8000 in
/-- **Per-iteration `TraceSafeListR` for the case-3 body**: the two block-ptr
loads' per-lane addresses are the invariant's pinned pointer shapes, in
bounds by the skin's `read2`/`read3` windows instantiated at step `c / BN`;
everything else is register-only (the two sliding-window `ifThen`s are
constexpr-false, so their dead bodies impose nothing). -/
private theorem aft3_bodySafeW (R : RoundingModel) (bounds : RegionBounds)
    (K V M Out L : RegionName) (s0 : BlockState) (smsc : ℝ)
    (base BM ND NC BN skk skn svk svn som son ROUND_CTX smsc_off : Nat)
    (hBN : 0 < BN) (hBNdvd : BN ∣ NC)
    (c : Nat) (s : BlockState) (hc : c < NC)
    (hP : aft3SafeInv K V M Out L s0 base BM ND NC BN skk skn svk svn som son ROUND_CTX c s)
    (hbK : ∀ (t : Fin (NC / BN)) (j : Fin (ND * BN)),
      base + (j.val / BN) * skk + (t.val * BN + j.val % BN) * skn < bounds K)
    (hbV : ∀ (t : Fin (NC / BN)) (j : Fin (BN * ND)),
      base + (t.val * BN + j.val / ND) * svk + (j.val % ND) * svn < bounds V) :
    Stmt.TraceSafeListR R bounds (aft3LoopBodyG3 smsc smsc_off BM ND BN)
      (s.setReg "start_n" .nat [] (Tile.scalar c)) := by
  obtain ⟨hmod, hle, hsm, hoff, ⟨qT, hq⟩, ⟨sc, hqs⟩, ⟨mT, hmi⟩, ⟨lT, hli⟩, ⟨aT, hacc⟩,
    hKp, hVp, hMptr, hLptr, hOp⟩ := hP
  have hcBN : c / BN * BN = c := Nat.div_mul_cancel (Nat.dvd_of_mod_eq_zero hmod)
  have hcdivlt : c / BN < NC / BN := by
    have h1 : c / BN * BN < NC / BN * BN := by
      rw [hcBN, Nat.div_mul_cancel hBNdvd]
      exact hc
    exact lt_of_mul_lt_mul_right h1 (Nat.zero_le BN)
  set t0 := s.setReg "start_n" .nat [] (Tile.scalar c) with ht0
  have hKp0 : t0.regs .blockPtr [ND, BN] "K_block_ptr" = some
      (⟨fun _ : TileIndex [ND, BN] =>
        { region := K, baseOffset := base, parentShape := [ND, NC], blockShape := [ND, BN],
          strides := [skk, skn], offsets := [0, c] }⟩) := by
    rw [ht0]
    simp only [BlockState.setReg_ne_name, ne_eq, String.reduceEq, not_false_eq_true]
    exact hKp
  have hVp0 : t0.regs .blockPtr [BN, ND] "V_block_ptr" = some
      (⟨fun _ : TileIndex [BN, ND] =>
        { region := V, baseOffset := base, parentShape := [NC, ND], blockShape := [BN, ND],
          strides := [svk, svn], offsets := [c, 0] }⟩) := by
    rw [ht0]
    simp only [BlockState.setReg_ne_name, ne_eq, String.reduceEq, not_false_eq_true]
    exact hVp
  unfold aft3LoopBodyG3
  -- (1) k = load K_block_ptr: the per-lane K bound
  refine Stmt.TraceSafeListR.cons_intro ?_ (fun s1 h1 => ?_)
  · simp only [Stmt.TraceSafeR, Op.SafeAtR.eq_def, MaskOpt.ActiveR,
      MemAccess.ActiveAddressSafeR, memAccessActiveAddressSafeR]
    refine ⟨trivial, trivial, ?_⟩
    intro ptrs hptrs idx _
    rw [evalOpR_ref, hKp0] at hptrs
    obtain rfl := Option.some.inj hptrs
    intro _
    have hbound := hbK ⟨c / BN, hcdivlt⟩ (Lane2D.encode (idx.1, idx.2.1, PUnit.unit))
    simp only [Lane2D.encode_div, Lane2D.encode_mod] at hbound
    rw [hcBN] at hbound
    simpa using hbound
  obtain ⟨v1, -, rfl⟩ := stepStmtR_assign_inv h1
  -- (2) qk = zeros
  refine Stmt.TraceSafeListR.cons_intro
    (by simp [Stmt.TraceSafeR, Op.SafeAtR.eq_def]) (fun s2 h2 => ?_)
  obtain ⟨v2, -, rfl⟩ := stepStmtR_assign_inv h2
  -- (3) qk += dot q k
  refine Stmt.TraceSafeListR.cons_intro
    (by simp [Stmt.TraceSafeR, Op.SafeAtR.eq_def]) (fun s3 h3 => ?_)
  obtain ⟨v3, -, rfl⟩ := stepStmtR_assign_inv h3
  -- (4) qk *= qk_scale
  refine Stmt.TraceSafeListR.cons_intro
    (by simp [Stmt.TraceSafeR, Op.SafeAtR.eq_def]) (fun s4 h4 => ?_)
  obtain ⟨v4, -, rfl⟩ := stepStmtR_assign_inv h4
  -- (5) dead sliding-window ifThen
  refine Stmt.TraceSafeListR.cons_intro ?_ (fun s5 h5 => ?_)
  · simp only [Stmt.TraceSafeR]
    refine ⟨by simp [Op.SafeAtR.eq_def], ?_⟩
    rw [aft3_evalOpR_ne_const, aft3_ne_zero_zero_false]
    exact trivial
  rw [aft3_ifThen_falseR R (by rw [aft3_evalOpR_ne_const]; exact aft3_ne_zero_zero_false _)] at h5
  obtain rfl := Option.some.inj h5
  -- (6) m_ij
  refine Stmt.TraceSafeListR.cons_intro
    (by simp [Stmt.TraceSafeR, Op.SafeAtR.eq_def]) (fun s6 h6 => ?_)
  obtain ⟨v6, -, rfl⟩ := stepStmtR_assign_inv h6
  -- (7) qk -= m_ij[:, None]
  refine Stmt.TraceSafeListR.cons_intro
    (by simp [Stmt.TraceSafeR, Op.SafeAtR.eq_def]) (fun s7 h7 => ?_)
  obtain ⟨v7, -, rfl⟩ := stepStmtR_assign_inv h7
  -- (8) p = exp2 qk
  refine Stmt.TraceSafeListR.cons_intro
    (by simp [Stmt.TraceSafeR, Op.SafeAtR.eq_def]) (fun s8 h8 => ?_)
  obtain ⟨v8, -, rfl⟩ := stepStmtR_assign_inv h8
  -- (9) dead sliding-window ifThen
  refine Stmt.TraceSafeListR.cons_intro ?_ (fun s9 h9 => ?_)
  · simp only [Stmt.TraceSafeR]
    refine ⟨by simp [Op.SafeAtR.eq_def], ?_⟩
    rw [aft3_evalOpR_ne_const, aft3_ne_zero_zero_false]
    exact trivial
  rw [aft3_ifThen_falseR R (by rw [aft3_evalOpR_ne_const]; exact aft3_ne_zero_zero_false _)] at h9
  obtain rfl := Option.some.inj h9
  -- (10) l_ij
  refine Stmt.TraceSafeListR.cons_intro
    (by simp [Stmt.TraceSafeR, Op.SafeAtR.eq_def]) (fun s10 h10 => ?_)
  obtain ⟨v10, -, rfl⟩ := stepStmtR_assign_inv h10
  -- (11) tmp
  refine Stmt.TraceSafeListR.cons_intro
    (by simp [Stmt.TraceSafeR, Op.SafeAtR.eq_def]) (fun s11 h11 => ?_)
  obtain ⟨v11, -, rfl⟩ := stepStmtR_assign_inv h11
  -- (12) alpha
  refine Stmt.TraceSafeListR.cons_intro
    (by simp [Stmt.TraceSafeR, Op.SafeAtR.eq_def]) (fun s12 h12 => ?_)
  obtain ⟨v12, -, rfl⟩ := stepStmtR_assign_inv h12
  -- (13) l_i
  refine Stmt.TraceSafeListR.cons_intro
    (by simp [Stmt.TraceSafeR, Op.SafeAtR.eq_def]) (fun s13 h13 => ?_)
  obtain ⟨v13, -, rfl⟩ := stepStmtR_assign_inv h13
  -- (14) acc = acc * alpha[:, None]
  refine Stmt.TraceSafeListR.cons_intro
    (by simp [Stmt.TraceSafeR, Op.SafeAtR.eq_def]) (fun s14 h14 => ?_)
  obtain ⟨v14, -, rfl⟩ := stepStmtR_assign_inv h14
  -- (15) v = load V_block_ptr: the per-lane V bound
  refine Stmt.TraceSafeListR.cons_intro ?_ (fun s15 h15 => ?_)
  · simp only [Stmt.TraceSafeR, Op.SafeAtR.eq_def, MaskOpt.ActiveR,
      MemAccess.ActiveAddressSafeR, memAccessActiveAddressSafeR]
    refine ⟨trivial, trivial, ?_⟩
    intro ptrs hptrs idx _
    rw [evalOpR_ref] at hptrs
    simp only [BlockState.setReg_ne_name, ne_eq, String.reduceEq, not_false_eq_true] at hptrs
    rw [hVp0] at hptrs
    obtain rfl := Option.some.inj hptrs
    intro _
    have hbound := hbV ⟨c / BN, hcdivlt⟩ (Lane2D.encode (idx.1, idx.2.1, PUnit.unit))
    simp only [Lane2D.encode_div, Lane2D.encode_mod] at hbound
    rw [hcBN] at hbound
    simpa using hbound
  obtain ⟨v15, -, rfl⟩ := stepStmtR_assign_inv h15
  -- (16) acc += dot p v
  refine Stmt.TraceSafeListR.cons_intro
    (by simp [Stmt.TraceSafeR, Op.SafeAtR.eq_def]) (fun s16 h16 => ?_)
  obtain ⟨v16, -, rfl⟩ := stepStmtR_assign_inv h16
  -- (17) m_i = m_ij
  refine Stmt.TraceSafeListR.cons_intro
    (by simp [Stmt.TraceSafeR, Op.SafeAtR.eq_def]) (fun s17 h17 => ?_)
  obtain ⟨v17, -, rfl⟩ := stepStmtR_assign_inv h17
  -- (18) V_block_ptr advance (register-only)
  refine Stmt.TraceSafeListR.cons_intro
    (by simp [Stmt.TraceSafeR, Op.SafeAtR.eq_def]) (fun s18 h18 => ?_)
  obtain ⟨v18, -, rfl⟩ := stepStmtR_assign_inv h18
  -- (19) K_block_ptr advance (register-only)
  exact Stmt.TraceSafeListR.cons_intro
    (by simp [Stmt.TraceSafeR, Op.SafeAtR.eq_def])
    (fun _ _ => Stmt.TraceSafeListR.nil_intro)

/-- Cons-level inversion for `stepStmtsR` (walks a successful list run one
statement at a time). -/
private theorem aft3_stepStmtsR_cons_inv {R : RoundingModel} {st : Stmt}
    {rest : List Stmt} {s s' : BlockState}
    (h : stepStmtsR R (st :: rest) s = some s') :
    ∃ u, stepStmtR R st s = some u ∧ stepStmtsR R rest u = some s' := by
  rw [stepStmtsR] at h
  cases hu : stepStmtR R st s with
  | none => rw [hu] at h; exact absurd h (by simp)
  | some u => rw [hu] at h; exact ⟨u, rfl, h⟩

/-- `writeMemTypedR` at the `.real` channel is the exact typed write. -/
private theorem aft3_writeMemTypedR_real (R : RoundingModel) (s : BlockState)
    (region : RegionName) (offset : Nat) (v : TileCarrier .real) :
    s.writeMemTypedR R .real region offset v = s.writeMemTyped .real region offset v := rfl

set_option maxHeartbeats 4000000 in
set_option maxRecDepth 8000 in
/-- **`TraceSafeListR` for the case-3 postLoop**: the `END=1` finalize branch
is register-only; the two terminal stores' per-lane addresses are the pinned
`m_ptrs` row (`write2` window, bounds on `M`) and the pinned `O_block_ptr`
tile (`write1` window, bounds on `Out`). -/
private theorem aft3_postSafeW (R : RoundingModel) (bounds : RegionBounds)
    (K V M Out L : RegionName) (s0 : BlockState)
    (base BM ND NC BN skk skn svk svn som son ROUND_CTX c : Nat)
    (s : BlockState)
    (hP : aft3SafeInv K V M Out L s0 base BM ND NC BN skk skn svk svn som son ROUND_CTX c s)
    (hbO : ∀ j : Fin (BM * ND),
      base + (s0.pids 0 * BM + j.val / ND) * som + (j.val % ND) * son < bounds Out)
    (hbM : ∀ j : Fin BM,
      s0.pids 1 * ROUND_CTX + (s0.pids 0 * BM + j.val) < bounds M) :
    Stmt.TraceSafeListR R bounds (aft3PostLoopG M Out L BM ND) s := by
  obtain ⟨hmod, hle, hsm, hoff, ⟨qT, hq⟩, ⟨sc, hqs⟩, ⟨mT, hmi⟩, ⟨lT, hli⟩, ⟨aT, hacc⟩,
    hKp, hVp, hMptr, hLptr, hOp⟩ := hP
  unfold aft3PostLoopG
  -- (1) the END=1 ifThenElse: constexpr-true, register-only live branch
  refine Stmt.TraceSafeListR.cons_intro ?_ (fun s1 h1 => ?_)
  · simp only [Stmt.TraceSafeR]
    refine ⟨by simp [Op.SafeAtR.eq_def], ?_⟩
    rw [aft3_evalOpR_ne_const, aft3_ne_one_zero_true]
    show Stmt.TraceSafeListR R bounds
      [Stmt.assign TileDType.real [BM] "m_i" ((Op.add NumericDType.real Broadcast.nil.consSame (Op.ref TileDType.real [BM] "m_i") (Op.ref TileDType.real [BM] "l_i").log2)),
       Stmt.assign TileDType.real [BM, ND] "acc" ((Op.div NumericDType.real Broadcast.nil.consR.consSame (Op.ref TileDType.real [BM, ND] "acc") (Op.expandDim ⟨1, by simp⟩ (Op.ref TileDType.real [BM] "l_i"))))] s
    refine Stmt.TraceSafeListR.of_forall _ _ ?_
    intro st hst u
    simp only [List.mem_cons, List.not_mem_nil, or_false] at hst
    rcases hst with rfl | rfl <;> simp [Stmt.TraceSafeR, Op.SafeAtR.eq_def]
  rw [aft3_ifThenElse_trueR R (by rw [aft3_evalOpR_ne_const]; exact aft3_ne_one_zero_true _)] at h1
  obtain ⟨u1, ha1, h1⟩ := aft3_stepStmtsR_cons_inv h1
  obtain ⟨va, -, rfl⟩ := stepStmtR_assign_inv ha1
  obtain ⟨u2, ha2, h1⟩ := aft3_stepStmtsR_cons_inv h1
  obtain ⟨vb, -, rfl⟩ := stepStmtR_assign_inv ha2
  rw [stepStmtsR_nil] at h1
  obtain rfl := Option.some.inj h1
  -- the state after the finalize branch
  set s2 := (s.setReg "m_i" .real [BM] va).setReg "acc" .real [BM, ND] vb with hs2
  have hmi2 : s2.regs .real [BM] "m_i" = some va := by
    rw [hs2]
    simp only [BlockState.setReg_ne_name, ne_eq, String.reduceEq, not_false_eq_true,
      BlockState.setReg_same]
  have hacc2 : s2.regs .real [BM, ND] "acc" = some vb := by
    rw [hs2, BlockState.setReg_same]
  have hMptr2 : s2.regs .ptr [BM] "m_ptrs" = some
      (Tile.ptrAdd Broadcast.scalarL (Tile.scalar (M.cast, (0 : Nat)))
        (Tile.bop NumericDType.nat.add Broadcast.scalarL (Tile.scalar (s0.pids 1 * ROUND_CTX))
          (Tile.vec (fun r : Fin BM => s0.pids 0 * BM + r.val)))) := by
    rw [hs2]
    simp only [BlockState.setReg_ne_name, ne_eq, String.reduceEq, not_false_eq_true]
    exact hMptr
  set mOffFn : TileIndex [BM] → Nat :=
    fun r => s0.pids 1 * ROUND_CTX + (s0.pids 0 * BM + r.1.val) with hmOffFn
  have hmptrEval : evalOp (Op.ref TileDType.ptr [BM] "m_ptrs") s2
      = some (⟨fun r : TileIndex [BM] => (M.cast, mOffFn r)⟩ : Tile .ptr [BM]) := by
    rw [evalOp_ref, hMptr2]
    refine congrArg some ?_; ext r
    · rfl
    · simp only [Tile.ptrAdd_data, Tile.scalar_data, Tile.bop_data, Tile.vec_data,
        Broadcast.leftIndex_scalarL, Broadcast.rightIndex_scalarL, Broadcast.leftIndex_nil,
        Broadcast.rightIndex_nil, NumericDType.add, Nat.zero_add, hmOffFn]
  -- (2) the m store: `write2` bounds on `M`
  refine Stmt.TraceSafeListR.cons_intro ?_ (fun s3 h3 => ?_)
  · simp only [Stmt.TraceSafeR, MemAccess.SafeAtR, MaskOpt.SafeAtR, Op.SafeAtR.eq_def,
      MaskOpt.ActiveR, MemAccess.ActiveAddressSafeR, memAccessActiveAddressSafeR]
    refine ⟨trivial, trivial, trivial, ?_⟩
    intro ptrs hptrs i _
    rw [evalOpR_ref, hMptr2] at hptrs
    obtain rfl := Option.some.inj hptrs
    have hbound := hbM i.1
    simpa [Tile.ptrAdd_data, Tile.scalar_data, Tile.bop_data, Tile.vec_data,
      Broadcast.leftIndex_scalarL, Broadcast.rightIndex_scalarL, Broadcast.leftIndex_nil,
      Broadcast.rightIndex_nil, NumericDType.add, Nat.zero_add] using hbound
  -- identify the m-store successor (cast-free statement + forward eval)
  rw [show stepStmtR R (Stmt.store TileDType.real [BM] (MemAccess.ptr (Op.ref TileDType.ptr [BM] "m_ptrs")) ((Op.ref TileDType.real [BM] "m_i")) MaskOpt.none) s2
      = stepStmt (Stmt.store TileDType.real [BM] (MemAccess.ptr (Op.ref TileDType.ptr [BM] "m_ptrs")) ((Op.ref TileDType.real [BM] "m_i")) MaskOpt.none) s2 from by
    simp only [stepStmtR, stepStmt, evalOpR.eq_def, evalOp.eq_def]
    rfl] at h3
  rw [show stepStmt (Stmt.store TileDType.real [BM] (MemAccess.ptr (Op.ref TileDType.ptr [BM] "m_ptrs")) ((Op.ref TileDType.real [BM] "m_i")) MaskOpt.none) s2
      = some ((TileShape.allIndices [BM]).foldl
          (fun acc r => acc.writeMemTyped .real M (mOffFn r) (va.data r)) s2) from by
    simp only [stepStmt, evalOp_ref, hmi2, hmptrEval, Option.bind_eq_bind, Option.bind_some,
      Option.map_some, if_true, Region.cast_id]] at h3
  obtain rfl := Option.some.inj h3
  -- (3) the O store: `write1` bounds on `Out`
  refine Stmt.TraceSafeListR.cons_intro ?_ (fun _ _ => Stmt.TraceSafeListR.nil_intro)
  simp only [Stmt.TraceSafeR, MemAccess.SafeAtR, MaskOpt.SafeAtR, Op.SafeAtR.eq_def,
    MaskOpt.ActiveR, MemAccess.ActiveAddressSafeR, memAccessActiveAddressSafeR]
  refine ⟨trivial, trivial, trivial, ?_⟩
  intro ptrs hptrs idx _
  rw [evalOpR_ref] at hptrs
  rw [show ((TileShape.allIndices [BM]).foldl
        (fun acc r => acc.writeMemTyped .real M (mOffFn r) (va.data r)) s2).regs
          .blockPtr [BM, ND] "O_block_ptr"
      = s2.regs .blockPtr [BM, ND] "O_block_ptr" from by
    simp only [BlockState.foldl_writeMemTyped_regs]] at hptrs
  rw [show s2.regs .blockPtr [BM, ND] "O_block_ptr" = some
      (⟨fun _ : TileIndex [BM, ND] =>
        { region := Out, baseOffset := base, parentShape := [ROUND_CTX, ND], blockShape := [BM, ND],
          strides := [som, son], offsets := [s0.pids 0 * BM, 0] }⟩) from by
    rw [hs2]
    simp only [BlockState.setReg_ne_name, ne_eq, String.reduceEq, not_false_eq_true]
    exact hOp] at hptrs
  obtain rfl := Option.some.inj hptrs
  intro _
  have hbound := hbO (Lane2D.encode (idx.1, idx.2.1, PUnit.unit))
  simp only [Lane2D.encode_div, Lane2D.encode_mod] at hbound
  simpa using hbound

set_option maxHeartbeats 8000000 in
set_option maxRecDepth 8000 in
/-- **The `TraceSafeR` walk for the whole case-3 kernel** — the bench's first
block-pointer safety walk: the prologue's 16 scalar/pointer assigns are safe
at every state, the constexpr `INIT`/`IS_EVEN_M` branches are register-only
except the `Q_block_ptr` load (bounded by the skin's `read1` window at step
`0`), the KV loop runs `Stmt.forRangeTraceSafeR_inv` over `aft3SafeInv`, and
the postLoop stores are bounded by the `write1`/`write2` windows. -/
private theorem aft3_traceSafeR_case3 (R : RoundingModel) (bounds : RegionBounds)
    (Q K V M Out L : RegionName) (sm_scale : ℝ)
    (sqz sqh sqm sqk skz skh skn skk svz svh svk svn soz soh som son
      Z H H_KV N_CTX ROUND_CTX NKV_CTX off BM ND BN : Nat) (s : BlockState)
    (hH : 0 < H) (hHKV : H_KV = H)
    (hskz : skz = sqz) (hskh : skh = sqh) (hsvz : svz = sqz) (hsvh : svh = sqh)
    (hsoz : soz = sqz) (hsoh : soh = sqh)
    (hBN : 0 < BN) (hNC : 0 < NKV_CTX) (hBNdvd : BN ∣ NKV_CTX)
    (hbQ : ∀ (t : Fin (NKV_CTX / BN)) (j : Fin (BM * ND)),
      (s.pids 1 / H * sqz + s.pids 1 % H * sqh) + (s.pids 0 * BM + j.val / ND) * sqm + (j.val % ND) * sqk < bounds Q)
    (hbK : ∀ (t : Fin (NKV_CTX / BN)) (j : Fin (ND * BN)),
      (s.pids 1 / H * sqz + s.pids 1 % H * sqh) + (j.val / BN) * skk + (t.val * BN + j.val % BN) * skn < bounds K)
    (hbV : ∀ (t : Fin (NKV_CTX / BN)) (j : Fin (BN * ND)),
      (s.pids 1 / H * sqz + s.pids 1 % H * sqh) + (t.val * BN + j.val / ND) * svk + (j.val % ND) * svn < bounds V)
    (hbO : ∀ j : Fin (BM * ND),
      (s.pids 1 / H * sqz + s.pids 1 % H * sqh) + (s.pids 0 * BM + j.val / ND) * som + (j.val % ND) * son < bounds Out)
    (hbM : ∀ j : Fin BM, s.pids 1 * ROUND_CTX + (s.pids 0 * BM + j.val) < bounds M) :
    ((attention_fwd_triton3_surface Q K V M Out L sm_scale
      sqz sqh sqm sqk skz skh skn skk svz svh svk svn soz soh som son
      Z H H_KV N_CTX ROUND_CTX NKV_CTX off 0 1 1 BM ND BN 1 1 0 0).toAlgKernel).TraceSafeR R bounds s := by
  have hT : 0 < NKV_CTX / BN := Nat.div_pos (Nat.le_of_dvd hNC hBNdvd) hBN
  unfold Kernel.TraceSafeR
  rw [aft3_body_splitG3]
  refine Stmt.TraceSafeListR.append_intro _ _ ?_ ?_
  · -- the preLoop
    obtain ⟨s11, h11, hpids, hmem, huf, hstart, hoffhz, hQp, hKp, hVp, hOp, hMptr, hLptr⟩ :=
      aft3PreLoopScalarsG_eval Q K V M Out L sm_scale sqz sqh sqm sqk skz skh skn skk svz svh svk svn soz soh som son H H_KV N_CTX ROUND_CTX NKV_CTX off 0 BM ND BN s hH hHKV hskz hskh hsvz hsvh hsoz hsoh
    rw [show aft3PreLoopG Q K V M Out L sm_scale sqz sqh sqm sqk skz skh skn skk svz svh svk svn soz soh som son H H_KV N_CTX ROUND_CTX NKV_CTX off 0 BM ND BN
        = aft3PreLoopScalarsG Q K V M Out L sm_scale sqz sqh sqm sqk skz skh skn skk svz svh svk svn soz soh som son H H_KV N_CTX ROUND_CTX NKV_CTX off 0 BM ND BN ++ (aft3PreLoopG Q K V M Out L sm_scale sqz sqh sqm sqk skz skh skn skk svz svh svk svn soz soh som son H H_KV N_CTX ROUND_CTX NKV_CTX off 0 BM ND BN).drop 16 from by
      rw [aft3PreLoopScalarsG]; rw [List.take_append_drop]]
    refine Stmt.TraceSafeListR.append_intro _ _ ?_ ?_
    · -- statements 0–15: register-only assigns, safe at every state
      refine Stmt.TraceSafeListR.of_forall _ _ ?_
      intro st hst u
      simp only [aft3PreLoopScalarsG, aft3PreLoopG, List.take_succ_cons, List.take_zero,
        List.mem_cons, List.not_mem_nil, or_false] at hst
      rcases hst with rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl |
        rfl | rfl | rfl | rfl <;>
        simp [Stmt.TraceSafeR, Op.SafeAtR]
    · intro s1 hs1
      rw [aft3PreLoopScalarsG_castFree R Q K V M Out L sm_scale sqz sqh sqm sqk skz skh skn skk svz svh svk svn soz soh som son H H_KV N_CTX ROUND_CTX NKV_CTX off 0 BM ND BN s, h11] at hs1
      obtain rfl := Option.some.inj hs1
      rw [show (aft3PreLoopG Q K V M Out L sm_scale sqz sqh sqm sqk skz skh skn skk svz svh svk svn soz soh som son H H_KV N_CTX ROUND_CTX NKV_CTX off 0 BM ND BN).drop 16
          = [ Stmt.ifThenElse (Op.ne ComparableDType.nat Broadcast.nil (Op.constNat 1) (Op.constNat 0)) [Stmt.assign TileDType.real [BM] "m_i" ((Op.add NumericDType.real Broadcast.scalarR (Op.full [BM] (Op.const 0)) Op.negInf)), Stmt.assign TileDType.real [BM] "l_i" ((Op.add NumericDType.real Broadcast.scalarR (Op.full [BM] (Op.const 0)) (Op.const 1.0))), Stmt.assign TileDType.real [BM, ND] "acc" (Op.full [BM, ND] (Op.const 0))] [Stmt.assign TileDType.real [BM] "m_i" (Op.load TileDType.real (MemAccess.ptr (Op.ref TileDType.ptr [BM] "m_ptrs")) MaskOpt.none), Stmt.assign TileDType.real [BM] "l_i" (Op.load TileDType.real (MemAccess.ptr (Op.ref TileDType.ptr [BM] "l_ptrs")) MaskOpt.none), Stmt.assign TileDType.real [BM, ND] "acc" (Op.load TileDType.real (MemAccess.blockPtr (Op.ref TileDType.blockPtr [BM, ND] "O_block_ptr") []) MaskOpt.none .unspecified)],
              Stmt.assign TileDType.real [] "qk_scale" (Op.mul NumericDType.real Broadcast.nil (Op.const sm_scale) (Op.const 1.0)),
              Stmt.assign TileDType.real [] "qk_scale" (Op.mul NumericDType.real Broadcast.nil (Op.ref TileDType.real [] "qk_scale") (Op.const 1.4426950408889634)),
              Stmt.ifThenElse (Op.ne ComparableDType.nat Broadcast.nil (Op.constNat 1) (Op.constNat 0)) [Stmt.assign TileDType.real [BM, ND] "q" (Op.load TileDType.real (MemAccess.blockPtr (Op.ref TileDType.blockPtr [BM, ND] "Q_block_ptr") []) MaskOpt.none .unspecified)] [Stmt.assign TileDType.real [BM, ND] "q" (Op.load TileDType.real (MemAccess.blockPtr (Op.ref TileDType.blockPtr [BM, ND] "Q_block_ptr") [0, 1]) MaskOpt.none)] ] from by rfl]
      -- the INIT ifThenElse: register-only live branch
      refine Stmt.TraceSafeListR.cons_intro ?_ (fun u1 hu1 => ?_)
      · simp only [Stmt.TraceSafeR]
        refine ⟨by simp [Op.SafeAtR.eq_def], ?_⟩
        rw [aft3_evalOpR_ne_const, aft3_ne_one_zero_true]
        show Stmt.TraceSafeListR R bounds
          [Stmt.assign TileDType.real [BM] "m_i" ((Op.add NumericDType.real Broadcast.scalarR (Op.full [BM] (Op.const 0)) Op.negInf)),
           Stmt.assign TileDType.real [BM] "l_i" ((Op.add NumericDType.real Broadcast.scalarR (Op.full [BM] (Op.const 0)) (Op.const 1.0))),
           Stmt.assign TileDType.real [BM, ND] "acc" (Op.full [BM, ND] (Op.const 0))] s11
        refine Stmt.TraceSafeListR.of_forall _ _ ?_
        intro st hst u
        simp only [List.mem_cons, List.not_mem_nil, or_false] at hst
        rcases hst with rfl | rfl | rfl <;> simp [Stmt.TraceSafeR, Op.SafeAtR.eq_def]
      rw [aft3_ifThenElse_trueR R (by rw [aft3_evalOpR_ne_const]; exact aft3_ne_one_zero_true _)] at hu1
      obtain ⟨w1, hw1, hu1⟩ := aft3_stepStmtsR_cons_inv hu1
      obtain ⟨va, -, rfl⟩ := stepStmtR_assign_inv hw1
      obtain ⟨w2, hw2, hu1⟩ := aft3_stepStmtsR_cons_inv hu1
      obtain ⟨vb, -, rfl⟩ := stepStmtR_assign_inv hw2
      obtain ⟨w3, hw3, hu1⟩ := aft3_stepStmtsR_cons_inv hu1
      obtain ⟨vc, -, rfl⟩ := stepStmtR_assign_inv hw3
      rw [stepStmtsR_nil] at hu1
      obtain rfl := Option.some.inj hu1
      -- qk_scale ×2 (register-only)
      refine Stmt.TraceSafeListR.cons_intro
        (by simp [Stmt.TraceSafeR, Op.SafeAtR.eq_def]) (fun u2 hu2 => ?_)
      obtain ⟨vd, -, rfl⟩ := stepStmtR_assign_inv hu2
      refine Stmt.TraceSafeListR.cons_intro
        (by simp [Stmt.TraceSafeR, Op.SafeAtR.eq_def]) (fun u3 hu3 => ?_)
      obtain ⟨ve, -, rfl⟩ := stepStmtR_assign_inv hu3
      -- the IS_EVEN_M ifThenElse: the live `Q_block_ptr` load (`read1` bound)
      refine Stmt.TraceSafeListR.cons_intro ?_ (fun _ _ => Stmt.TraceSafeListR.nil_intro)
      simp only [Stmt.TraceSafeR]
      refine ⟨by simp [Op.SafeAtR.eq_def], ?_⟩
      rw [aft3_evalOpR_ne_const, aft3_ne_one_zero_true]
      show Stmt.TraceSafeListR R bounds
        [Stmt.assign TileDType.real [BM, ND] "q" (Op.load TileDType.real (MemAccess.blockPtr (Op.ref TileDType.blockPtr [BM, ND] "Q_block_ptr") []) MaskOpt.none .unspecified)] _
      refine Stmt.TraceSafeListR.cons_intro ?_ (fun _ _ => Stmt.TraceSafeListR.nil_intro)
      simp only [Stmt.TraceSafeR, Op.SafeAtR.eq_def, MaskOpt.ActiveR,
        MemAccess.ActiveAddressSafeR, memAccessActiveAddressSafeR]
      refine ⟨trivial, trivial, ?_⟩
      intro ptrs hptrs idx _
      rw [evalOpR_ref] at hptrs
      simp only [BlockState.setReg_ne_name, ne_eq, String.reduceEq, not_false_eq_true] at hptrs
      rw [hQp] at hptrs
      obtain rfl := Option.some.inj hptrs
      intro _
      have hbound := hbQ ⟨0, hT⟩ (Lane2D.encode (idx.1, idx.2.1, PUnit.unit))
      simp only [Lane2D.encode_div, Lane2D.encode_mod] at hbound
      simpa using hbound

  · -- after the preLoop: the KV loop, then the postLoop
    intro s2 hs2
    obtain ⟨spW, hpreW, hinv0⟩ :=
      aft3PreLoop_evalW Q K V M Out L sm_scale sqz sqh sqm sqk skz skh skn skk svz svh svk svn soz soh som son H H_KV N_CTX ROUND_CTX NKV_CTX off 0 BM ND BN s hH hHKV hskz hskh hsvz hsvh hsoz hsoh
    rw [aft3PreLoopG_castFree R Q K V M Out L sm_scale sqz sqh sqm sqk skz skh skn skk svz svh svk svn soz soh som son H H_KV N_CTX ROUND_CTX NKV_CTX off 0 BM ND BN s, hpreW] at hs2
    obtain rfl := Option.some.inj hs2
    refine Stmt.TraceSafeListR.cons_intro ?_ (fun s3 hs3 => ?_)
    · -- the KV loop is trace-safe (invariant principle over `aft3SafeInv`)
      simp only [Stmt.TraceSafeR]
      refine Stmt.forRangeTraceSafeR_inv R bounds "start_n" NKV_CTX BN
        (aft3LoopBodyG3 sm_scale off BM ND BN)
        (aft3SafeInv K V M Out L s (s.pids 1 / H * sqz + s.pids 1 % H * sqh) BM ND NKV_CTX BN skk skn svk svn som son ROUND_CTX) ?_ 0 spW hinv0
      intro c st hc hP
      refine ⟨aft3_bodySafeW R bounds K V M Out L s sm_scale (s.pids 1 / H * sqz + s.pids 1 % H * sqh) BM ND NKV_CTX BN skk skn svk svn som son ROUND_CTX off hBN hBNdvd c st hc hP hbK hbV, ?_⟩
      obtain ⟨st', hstep, hP'⟩ :=
        aft3_attn_stepW K V M Out L s sm_scale (s.pids 1 / H * sqz + s.pids 1 % H * sqh) BM ND NKV_CTX BN skk skn svk svn som son ROUND_CTX off hBN hBNdvd c st hc hP
      exact ⟨st', by rw [aft3LoopBodyG3_castFree]; exact hstep, hP'⟩
    · -- identify the post-loop state and finish on the postLoop stores
      obtain ⟨final, sfin, hLoop, hfinal, hPfin⟩ :=
        forRange_inv (idx := "start_n") (start := 0) (stop := NKV_CTX) (step := BN)
          (body := aft3LoopBodyG3 sm_scale off BM ND BN)
          (P := aft3SafeInv K V M Out L s (s.pids 1 / H * sqz + s.pids 1 % H * sqh) BM ND NKV_CTX BN skk skn svk svn som son ROUND_CTX)
          (s_init := spW) hBN.ne' hinv0
          (fun c st hc hP =>
            aft3_attn_stepW K V M Out L s sm_scale (s.pids 1 / H * sqz + s.pids 1 % H * sqh) BM ND NKV_CTX BN skk skn svk svn som son ROUND_CTX off hBN hBNdvd c st hc hP)
      rw [show stepStmtR R (Stmt.forRange "start_n" 0 NKV_CTX BN (aft3LoopBodyG3 sm_scale off BM ND BN)) spW = some sfin from by
        rw [stepStmtR_forRange,
          stepForRangeAuxR_castFree R _ (aft3LoopBodyG3_castFree R sm_scale off BM ND BN) "start_n",
          ← stepForRangeAux.forRange_unfold]
        exact hLoop] at hs3
      obtain rfl := Option.some.inj hs3
      exact aft3_postSafeW R bounds K V M Out L s (s.pids 1 / H * sqz + s.pids 1 % H * sqh) BM ND NKV_CTX BN skk skn svk svn som son ROUND_CTX final sfin hPfin hbO hbM

/-! ## The postLoop frame

`aft3PostLoop_evalG` delivers the two readback values; the skin additionally
needs the per-cell frame (every cell outside the two write windows is
untouched). Derived from the pins + the deterministic exact walk. -/

/-- Cons-level inversion for exact `stepStmts`. -/
private theorem aft3_stepStmts_cons_inv {st : Stmt} {rest : List Stmt} {s s' : BlockState}
    (h : stepStmts (st :: rest) s = some s') :
    ∃ u, stepStmt st s = some u ∧ stepStmts rest u = some s' := by
  rw [stepStmts] at h
  cases hu : stepStmt st s with
  | none => rw [hu] at h; exact absurd h (by simp)
  | some u => rw [hu] at h; exact ⟨u, rfl, h⟩

/-- Assign-step inversion for exact `stepStmt`. -/
private theorem aft3_stepStmt_assign_inv {dtype : TileDType} {shape : TileShape}
    {name : RegName} {e : Op dtype shape} {s s' : BlockState}
    (h : stepStmt (.assign dtype shape name e) s = some s') :
    ∃ v, evalOp e s = some v ∧ s' = s.setReg name dtype shape v := by
  cases hv : evalOp e s with
  | none => simp [stepStmt, hv] at h
  | some v =>
      simp [stepStmt, hv] at h
      exact ⟨v, rfl, h.symm⟩

/-- An unmasked single-region `writeMem` scatter preserves every cell it does
not hit. -/
private theorem aft3_foldl_writeMem_frame {α : Type} (region : RegionName)
    (offFn : α → Nat) (valFn : α → ℝ) :
    ∀ (l : List α) (s : BlockState) (r : RegionName) (o : Nat),
      (r = region → ∀ k ∈ l, offFn k ≠ o) →
      ((l.foldl (fun acc k => acc.writeMem region (offFn k) (valFn k)) s).mem r o
        = s.mem r o)
  | [], _, _, _, _ => rfl
  | k :: rest, s, r, o, h => by
      rw [List.foldl_cons,
        aft3_foldl_writeMem_frame region offFn valFn rest _ r o
          (fun hr k' hk' => h hr k' (List.mem_cons_of_mem _ hk')),
        BlockState.writeMem_mem]
      rw [if_neg (fun hro => h hro.1 k List.mem_cons_self hro.2.symm)]

set_option maxHeartbeats 4000000 in
set_option maxRecDepth 8000 in
/-- **PostLoop frame**: whatever the case-3 postLoop writes, every flat cell
outside the `M`-row window (`write2`) and the `Out`-tile window (`write1`) is
untouched. -/
private theorem aft3PostLoop_frameW (M Out L : RegionName) (s0 : BlockState)
    (base BM ND som son ROUND_CTX : Nat) (s sP : BlockState)
    (hMptr : s.regs .ptr [BM] "m_ptrs" = some
      (Tile.ptrAdd Broadcast.scalarL (Tile.scalar (M.cast, (0 : Nat)))
        (Tile.bop NumericDType.nat.add Broadcast.scalarL (Tile.scalar (s0.pids 1 * ROUND_CTX))
          (Tile.vec (fun r : Fin BM => s0.pids 0 * BM + r.val)))))
    (hOp : s.regs .blockPtr [BM, ND] "O_block_ptr" = some
      (⟨fun _ : TileIndex [BM, ND] =>
        { region := Out, baseOffset := base, parentShape := [ROUND_CTX, ND], blockShape := [BM, ND],
          strides := [som, son], offsets := [s0.pids 0 * BM, 0] }⟩))
    (h : stepStmts (aft3PostLoopG M Out L BM ND) s = some sP) :
    ∀ r o,
      (r = M → ∀ i : Fin BM, o ≠ s0.pids 1 * ROUND_CTX + (s0.pids 0 * BM + i.val)) →
      (r = Out → ∀ idx : TileIndex [BM, ND],
        o ≠ base + (s0.pids 0 * BM + idx.1.val) * som + idx.2.1.val * son) →
      sP.mem r o = s.mem r o := by
  unfold aft3PostLoopG at h
  -- (1) the END=1 finalize branch: two register assigns
  obtain ⟨u1, hif, h⟩ := aft3_stepStmts_cons_inv h
  rw [aft3_ifThenElse_true (aft3_ne_one_zero_true s)] at hif
  obtain ⟨u1a, ha, hif⟩ := aft3_stepStmts_cons_inv hif
  obtain ⟨va, -, rfl⟩ := aft3_stepStmt_assign_inv ha
  obtain ⟨u1b, hb, hif⟩ := aft3_stepStmts_cons_inv hif
  obtain ⟨vb, -, rfl⟩ := aft3_stepStmt_assign_inv hb
  rw [stepStmts.nil] at hif
  obtain rfl := Option.some.inj hif
  set s2 := (s.setReg "m_i" .real [BM] va).setReg "acc" .real [BM, ND] vb with hs2
  have hmi2 : s2.regs .real [BM] "m_i" = some va := by
    rw [hs2]
    simp only [BlockState.setReg_ne_name, ne_eq, String.reduceEq, not_false_eq_true,
      BlockState.setReg_same]
  have hMptr2 : s2.regs .ptr [BM] "m_ptrs" = some
      (Tile.ptrAdd Broadcast.scalarL (Tile.scalar (M.cast, (0 : Nat)))
        (Tile.bop NumericDType.nat.add Broadcast.scalarL (Tile.scalar (s0.pids 1 * ROUND_CTX))
          (Tile.vec (fun r : Fin BM => s0.pids 0 * BM + r.val)))) := by
    rw [hs2]
    simp only [BlockState.setReg_ne_name, ne_eq, String.reduceEq, not_false_eq_true]
    exact hMptr
  set mOffFn : TileIndex [BM] → Nat :=
    fun r => s0.pids 1 * ROUND_CTX + (s0.pids 0 * BM + r.1.val) with hmOffFn
  have hmptrEval : evalOp (Op.ref TileDType.ptr [BM] "m_ptrs") s2
      = some (⟨fun r : TileIndex [BM] => (M.cast, mOffFn r)⟩ : Tile .ptr [BM]) := by
    rw [evalOp_ref, hMptr2]
    refine congrArg some ?_; ext r
    · rfl
    · simp only [Tile.ptrAdd_data, Tile.scalar_data, Tile.bop_data, Tile.vec_data,
        Broadcast.leftIndex_scalarL, Broadcast.rightIndex_scalarL, Broadcast.leftIndex_nil,
        Broadcast.rightIndex_nil, NumericDType.add, Nat.zero_add, hmOffFn]
  -- (2) the m store
  obtain ⟨u2, hst1, h⟩ := aft3_stepStmts_cons_inv h
  rw [show stepStmt (Stmt.store TileDType.real [BM] (MemAccess.ptr (Op.ref TileDType.ptr [BM] "m_ptrs")) ((Op.ref TileDType.real [BM] "m_i")) MaskOpt.none) s2
      = some ((TileShape.allIndices [BM]).foldl
          (fun acc r => acc.writeMemTyped .real M (mOffFn r) (va.data r)) s2) from by
    simp only [stepStmt, evalOp_ref, hmi2, hmptrEval, Option.bind_eq_bind, Option.bind_some,
      Option.map_some, if_true, Region.cast_id]] at hst1
  obtain rfl := Option.some.inj hst1
  set s3 := (TileShape.allIndices [BM]).foldl
      (fun acc r => acc.writeMemTyped .real M (mOffFn r) (va.data r)) s2 with hs3
  have hacc3 : s3.regs .real [BM, ND] "acc" = some vb := by
    rw [hs3]
    simp only [BlockState.foldl_writeMemTyped_regs]
    rw [hs2, BlockState.setReg_same]
  have hOp3 : s3.regs .blockPtr [BM, ND] "O_block_ptr" = some
      (⟨fun _ : TileIndex [BM, ND] =>
        { region := Out, baseOffset := base, parentShape := [ROUND_CTX, ND], blockShape := [BM, ND],
          strides := [som, son], offsets := [s0.pids 0 * BM, 0] }⟩) := by
    rw [hs3]
    simp only [BlockState.foldl_writeMemTyped_regs]
    rw [hs2]
    simp only [BlockState.setReg_ne_name, ne_eq, String.reduceEq, not_false_eq_true]
    exact hOp
  set oOffFn : TileIndex [BM, ND] → Nat :=
    fun idx => base + (s0.pids 0 * BM + idx.1.val) * som + idx.2.1.val * son with hoOffFn
  -- (3) the O store
  obtain ⟨u3, hst2, h⟩ := aft3_stepStmts_cons_inv h
  rw [show stepStmt (Stmt.store TileDType.real [BM, ND]
      (MemAccess.blockPtr (Op.ref TileDType.blockPtr [BM, ND] "O_block_ptr") [])
      ((Op.ref TileDType.real [BM, ND] "acc")) MaskOpt.none) s3
      = some ((TileShape.allIndices [BM, ND]).foldl
          (fun acc idx => acc.writeMemTyped .real Out (oOffFn idx) (vb.data idx)) s3) from by
    simp only [stepStmt, evalOp_ref, hacc3, hOp3, Option.bind_eq_bind, Option.bind_some,
      Option.map_some]
    refine congrArg some ?_
    refine List.foldl_ext _ _ s3 ?_
    intro acc idx _
    simp only [TileShape.indexToList, BlockPtr.inBounds, List.all_nil, Bool.and_true,
      Bool.true_and, if_true]
    have haddr : BlockPtr.address
        { region := Out, baseOffset := base, parentShape := [ROUND_CTX, ND], blockShape := [BM, ND],
          strides := [som, son], offsets := [s0.pids 0 * BM, 0] }
        [idx.1.val, idx.2.1.val]
        = oOffFn idx := by
      show base + ((s0.pids 0 * BM + idx.1.val) * som + (0 + idx.2.1.val) * son) = _
      rw [Nat.zero_add, hoOffFn]; ring
    rw [haddr]] at hst2
  obtain rfl := Option.some.inj hst2
  rw [stepStmts.nil] at h
  obtain rfl := Option.some.inj h
  -- the frame
  intro r o hM hO
  rw [show ((TileShape.allIndices [BM, ND]).foldl
        (fun acc idx => acc.writeMemTyped .real Out (oOffFn idx) (vb.data idx)) s3).mem r o
      = s3.mem r o from by
    simp only [BlockState.writeMemTyped_real]
    exact aft3_foldl_writeMem_frame Out oOffFn
      (fun idx => FloatDType.real.storeValue (vb.data idx)) (TileShape.allIndices [BM, ND])
      s3 r o (fun hr idx _ => (hO hr idx).symm)]
  rw [hs3]
  rw [show ((TileShape.allIndices [BM]).foldl
        (fun acc r' => acc.writeMemTyped .real M (mOffFn r') (va.data r')) s2).mem r o
      = s2.mem r o from by
    simp only [BlockState.writeMemTyped_real]
    exact aft3_foldl_writeMem_frame M mOffFn
      (fun r' => FloatDType.real.storeValue (va.data r')) (TileShape.allIndices [BM])
      s2 r o (fun hr k _ => (hM hr k.1).symm)]
  rw [hs2]
  simp only [BlockState.setReg_mem]

/-! ### ════════ ★ MAIN THEOREM ★ ════════ -/
set_option maxHeartbeats 8000000 in
set_option maxRecDepth 8000 in
/-- **The case-3 `⊨[R]` io headline (round-7 exemplar; the bench's first io
headline on a `make_block_ptr` kernel).** For every rounding model `R`, the
case-3 (`(END,INIT,SLIDING_WINDOW,CSW) = (1,1,0,0)`) `_attn_fwd` surface
implements, on its `StreamMasked3DKernelIO₃ₓ₂` signature, the **ideal-ℝ
online-softmax attention fold** over the three streamed tiles: output lane
`j = (i, d)` of `Out` holds the plain base-2 per-key-scale softmax
(`attentionFwdTriton3Case3IOOutSpec` = the existing
`attentionFwdTriton3Case3OutSpecG` closed form restated on the streams), and
row `i` of `M` holds the `m_i + log2 l_i` finalize
(`attentionFwdTriton3Case3IOMSpec` = `attentionFwdTriton3Case3MSpecG` on the
streams). Both output grids are the `.real` default (the store-side
`.to(Out.type.element_ty)` cast erases to the identity at translation), so at
every `R` the terminal cells carry the exact fold values.

**Hypothesis provenance** (inherited verbatim from the exact case-3 headline
`attention_fwd_triton3_python_case3_output_summary_general`, all
truth-forced): `0 < ND/BM/BN/NKV_CTX` and `BN ∣ NKV_CTX` shape the KV walk
(`T = NKV_CTX / BN` full blocks); `0 < H`, `H_KV = H` and the six stride
equalities collapse the four `q/k/v/o` plane offsets onto the shared base
`pid₁/H·sqz + pid₁%H·sqh` (the kernel's GQA-free regime); `M ≠ Out` keeps the
`O` store from clobbering the `M` row; `hinjO`/`hinjM` (∀-pids forms of the
exact stack's per-program injectivity) make the per-lane readback of the two
scatter stores well-defined. The exact headline's `hundef` is **not** a
hypothesis here — the skin's Hoare triple carries the `undef` pin itself.

**Scope disclosed**: this round showcases the io face on **case 3 only**; the
sliding-window cases 1/2 and the `INIT=0` resume case 4 stay on their
existing exact headlines (follow-ups on the same io pattern). The port's
known fidelity gaps (`IS_EVEN_N = 1` hardwired, casts erased to identity,
`@triton.heuristics` not modeled) are inherited as-is from the surface. -/
specification attention_fwd_triton3_case3_io_correctness (R : RoundingModel)
    (Q K V M Out L : RegionName) (sm_scale : ℝ)
    (sqz sqh sqm sqk skz skh skn skk svz svh svk svn soz soh som son
      Z H H_KV N_CTX ROUND_CTX NKV_CTX off BM ND BN : Nat)
    (hND : 0 < ND) (hBM : 0 < BM) (hBN : 0 < BN) (hNC : 0 < NKV_CTX) (hBNdvd : BN ∣ NKV_CTX)
    (hH : 0 < H) (hHKV : H_KV = H)
    (hskz : skz = sqz) (hskh : skh = sqh) (hsvz : svz = sqz) (hsvh : svh = sqh)
    (hsoz : soz = sqz) (hsoh : soh = sqh)
    (hMO : M ≠ Out)
    (hinjO : ∀ p₀ p₁ : Nat, Function.Injective
      (fun idx : TileIndex [BM, ND] =>
        (p₁ / H * sqz + p₁ % H * sqh) + (p₀ * BM + idx.1.val) * som + idx.2.1.val * son))
    (hinjM : ∀ p₀ p₁ : Nat, Function.Injective
      (fun r : TileIndex [BM] => p₁ * ROUND_CTX + (p₀ * BM + r.1.val))) :
    attentionFwdTriton3Case3IO Q K V M Out L sm_scale sqz sqh sqm sqk skz skh skn skk svz svh svk svn soz soh som son Z H H_KV N_CTX ROUND_CTX NKV_CTX off BM ND BN ⊨[R]
      fun _ _ _ xs ys zs =>
        (fun j => attentionFwdTriton3Case3IOOutSpec BM ND BN NKV_CTX (NKV_CTX / BN)
            (Nat.div_pos (Nat.le_of_dvd hNC hBNdvd) hBN) (Nat.div_mul_cancel hBNdvd) hBN
            (sm_scale * 1.4426950408889634) xs ys zs j,
         fun i => attentionFwdTriton3Case3IOMSpec BM ND BN NKV_CTX (NKV_CTX / BN) hND
            (Nat.div_pos (Nat.le_of_dvd hNC hBNdvd) hBN) (Nat.div_mul_cancel hBNdvd) hBN
            (sm_scale * 1.4426950408889634) xs ys zs i) := by
  have hT : 0 < NKV_CTX / BN := Nat.div_pos (Nat.le_of_dvd hNC hBNdvd) hBN
  have hTB : NKV_CTX / BN * BN = NKV_CTX := Nat.div_mul_cancel hBNdvd
  refine StreamMasked3DKernelIO₃ₓ₂.ImplementsR.intro _ ?_ ?_ ?_
  · exact aft3_flattenOkG3 Q K V M Out L sm_scale sqz sqh sqm sqk skz skh skn skk svz svh svk svn soz soh som son Z H H_KV N_CTX ROUND_CTX NKV_CTX off BM ND BN
  · -- the safety walk
    intro bounds s xs ys zs _hlaunch _hx _hy _hz hbr1 hbr2 hbr3 hbw1 hbw2
    simp only [attentionFwdTriton3Case3IO] at hbr1 hbr2 hbr3 hbw1 hbw2 ⊢
    exact aft3_traceSafeR_case3 R bounds Q K V M Out L sm_scale
      sqz sqh sqm sqk skz skh skn skk svz svh svk svn soz soh som son
      Z H H_KV N_CTX ROUND_CTX NKV_CTX off BM ND BN s hH hHKV hskz hskh hsvz hsvh hsoz hsoh
      hBN hNC hBNdvd
      (fun t j => hbr1 t j trivial) (fun t j => hbr2 t j trivial)
      (fun t j => hbr3 t j trivial) (fun j => hbw1 j trivial) (fun j => hbw2 j trivial)
  · -- the rounded Hoare triple: exact invariant stack + cast-free collapses
    intro s₀ xs ys zs _hlaunch hu hx hy hz
    simp only [attentionFwdTriton3Case3IO] at hx hy hz ⊢
    have hundef' : ∀ rg o, s₀.undef rg o = 0 := fun rg o => by rw [hu]
    set base := s₀.pids 1 / H * sqz + s₀.pids 1 % H * sqh with hbase
    set sc := sm_scale * 1.4426950408889634 with hsc
    obtain ⟨sp, hpre, hinv0⟩ :=
      aft3PreLoop_evalG Q K V M Out L sm_scale sqz sqh sqm sqk skz skh skn skk svz svh svk svn soz soh som son H H_KV N_CTX ROUND_CTX NKV_CTX off 0 BM ND BN s₀ hND hH hHKV hskz hskh hsvz hsvh hsoz hsoh (fun i j => noWindowKeep i j) hundef'
    obtain ⟨final, sL, hloop, hfin, hinvL⟩ :=
      forRange_inv (idx := "start_n") (start := 0) (stop := NKV_CTX) (step := BN)
        (body := aft3LoopBodyG3 sm_scale off BM ND BN)
        (P := fun i st => attnInvariantG Q K V M Out L s₀ base BM ND NKV_CTX BN sqm sqk skn skk svk svn som son ROUND_CTX hND sc (fun i j => noWindowKeep i j) i st)
        (s_init := sp)
        hBN.ne'
        hinv0
        (fun i st hi hP => aft3_attn_step3G Q K V M Out L s₀ base BM ND NKV_CTX BN sqm sqk skn skk svk svn som son ROUND_CTX off 0 hND hBM hBN hNC hBNdvd sc i st hi
          (by obtain ⟨_, hmod, _, _⟩ := hP; exact hmod) hP)
    have hfinal : final = NKV_CTX := by
      obtain ⟨_, hmod, hle, _⟩ := hinvL
      rcases Nat.lt_or_ge final NKV_CTX with h | h
      · exact absurd h (by simpa using hfin)
      · exact Nat.le_antisymm hle h
    subst final
    obtain ⟨sF, hpost, hO, hM⟩ :=
      aft3PostLoop_evalG Q K V M Out L s₀ sL base BM ND NKV_CTX BN sqm sqk skn skk svk svn som son ROUND_CTX hND hNC sc hMO
        (hinjO (s₀.pids 0) (s₀.pids 1)) (hinjM (s₀.pids 0) (s₀.pids 1)) hinvL
    obtain ⟨hpidsL, _, _, _, _, _, _, _, _, _, _, _, hMptrL, _, hOpL, _, hmemL⟩ := hinvL
    have hframe := aft3PostLoop_frameW M Out L s₀ base BM ND som son ROUND_CTX sL sF hMptrL hOpL hpost
    refine ⟨sF, ?_, ?_, ?_, ?_⟩
    · -- termination under `execR R` (everything cast-free)
      show execR R (attention_fwd_triton3_surface Q K V M Out L sm_scale
        sqz sqh sqm sqk skz skh skn skk svz svh svk svn soz soh som son
        Z H H_KV N_CTX ROUND_CTX NKV_CTX off 0 1 1 BM ND BN 1 1 0 0).toAlgKernel s₀ = some sF
      unfold execR
      rw [aft3_body_splitG3, stepStmtsR_append,
        aft3PreLoopG_castFree R Q K V M Out L sm_scale sqz sqh sqm sqk skz skh skn skk svz svh svk svn soz soh som son H H_KV N_CTX ROUND_CTX NKV_CTX off 0 BM ND BN s₀,
        hpre, Option.bind_some,
        stepStmtsR_cons_some (show stepStmtR R (Stmt.forRange "start_n" 0 NKV_CTX BN (aft3LoopBodyG3 sm_scale off BM ND BN)) sp = some sL from by
          rw [stepStmtR_forRange,
            stepForRangeAuxR_castFree R _ (aft3LoopBodyG3_castFree R sm_scale off BM ND BN) "start_n",
            ← stepForRangeAux.forRange_unfold]
          exact hloop),
        aft3PostLoopG_castFree R M Out L BM ND sL]
      exact hpost
    · -- Out readback = the streamed closed form
      intro j _
      have hOj := hO (Lane2D.decode j)
      rw [show base + (s₀.pids 0 * BM + (Lane2D.decode j).1.val) * som + (Lane2D.decode j).2.1.val * son
          = base + (s₀.pids 0 * BM + j.val / ND) * som + (j.val % ND) * son from by
        simp only [Lane2D.decode_row, Lane2D.decode_col]] at hOj
      rw [BlockState.readMemAs_real, hOj]
      unfold attentionFwdTriton3Case3OutSpecG
      unfold attentionFwdTriton3Case3IOOutSpec
      rw [aft3IOqT_eq s₀ Q base sqm sqk BM ND (NKV_CTX / BN) hT xs (fun t j' => hx t j' trivial),
        aft3IOkT_eq s₀ K base skn skk ND BN NKV_CTX (NKV_CTX / BN) hTB hBN ys (fun t j' => hy t j' trivial),
        aft3IOvT_eq s₀ V base svk svn ND BN NKV_CTX (NKV_CTX / BN) hTB hBN zs (fun t j' => hz t j' trivial)]
      simp [FloatDType.ofReal]
    · -- M readback = the streamed finalize
      intro i _
      rw [BlockState.readMemAs_real, hM i]
      unfold attentionFwdTriton3Case3IOMSpec
      rw [aft3IOqT_eq s₀ Q base sqm sqk BM ND (NKV_CTX / BN) hT xs (fun t j' => hx t j' trivial),
        aft3IOkT_eq s₀ K base skn skk ND BN NKV_CTX (NKV_CTX / BN) hTB hBN ys (fun t j' => hy t j' trivial),
        aft3IOvT_eq s₀ V base svk svn ND BN NKV_CTX (NKV_CTX / BN) hTB hBN zs (fun t j' => hz t j' trivial)]
      simp [FloatDType.ofReal]
    · -- the frame: cells outside the two write windows are untouched
      intro r oo hcond
      obtain ⟨h1, h2⟩ := hcond
      rw [hframe r oo ?_ ?_, hmemL]
      · intro hr i
        exact fun hoo => h2 i trivial hr hoo
      · intro hr idx
        have h := h1 (Lane2D.encode (idx.1, idx.2.1, PUnit.unit)) trivial hr
        simpa [Lane2D.encode_div, Lane2D.encode_mod] using h

/-! # ══════════ The `⊨[R]` io headlines — cases 1 and 2 (sliding window) ══════════

The `StreamMasked3DKernelIO₃ₓ₂` faces of the **case-1**
(`(END,INIT,SLIDING_WINDOW,COMPLEMENT) = (1,1,1,0)`, keep `dist < size`) and
**case-2** (`(1,1,1,1)`, complement keep `size ≤ dist`) surfaces. The io
skeleton (reads/writes/masks/streams) is *identical* to the case-3 face
above — the window is data, not addressing: it enters the SPEC `f` as the
key filter (verbatim the exact headlines' `natSlidingWindowKeepG` /
`natComplementSlidingWindowKeepG`), while the kernel field is the
sliding-window constexpr instantiation. All state-shaped case-3 machinery
(`aft3SafeInv`, `aft3PreLoop_evalW`, `aft3_postSafeW`, `aft3PostLoop_frameW`,
the stream tiles `aft3IOqT/kT/vT` and their pin bridges, the preLoop/postLoop
cast-free collapses) is reused as-is; only the loop-body-shaped pieces
(cast-free walk, weak step, body safety) are re-instantiated on
`aft3LoopBodyG`/`aft3LoopBodyG2`, whose two sliding-window `ifThen`s are
constexpr-live here. -/

/-- `stepStmtR` mirror of `aft3_ifThen_true`. -/
private theorem aft3_ifThen_trueR (R : RoundingModel) {cond : Op .bool []}
    {body : List Stmt} {s : BlockState}
    (hc : evalOpR R cond s = some (Tile.scalar Bool.true)) :
    stepStmtR R (.ifThen cond body) s = stepStmtsR R body s := by
  simp only [stepStmtR, hc, Option.bind, Tile.scalar]
  rfl

/-- `stepStmtR` mirror of `aft3_ifThenElse_false`. -/
private theorem aft3_ifThenElse_falseR (R : RoundingModel) {cond : Op .bool []}
    {t e : List Stmt} {s : BlockState}
    (hc : evalOpR R cond s = some (Tile.scalar Bool.false)) :
    stepStmtR R (.ifThenElse cond t e) s = stepStmtsR R e s := by
  simp only [stepStmtR, hc, Option.bind, Tile.scalar]
  rfl

set_option maxHeartbeats 4000000 in
/-- Every case-1 loop-body statement is cast-free, statement-by-statement: the
two live sliding-window `ifThen`s are collapsed onto their branches through
the constexpr mirrors (the inner `COMPLEMENT` `ifThenElse` onto its live
`boolAnd` else-branch); every leaf op is `.real`/`.nat`/`.bool` arithmetic
with no `.to(...)` casts. -/
private theorem aft3LoopBodyG_stmt_castFree (R : RoundingModel) (sc : ℝ)
    (off size BM ND BN : Nat) :
    ∀ st ∈ aft3LoopBodyG sc off size BM ND BN, ∀ u, stepStmtR R st u = stepStmt st u := by
  intro st hst u
  simp only [aft3LoopBodyG, List.mem_cons, List.not_mem_nil, or_false] at hst
  rcases hst with rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl |
    rfl | rfl | rfl | rfl | rfl | rfl
  · simp only [stepStmtR, stepStmt, evalOpR.eq_def, evalOp.eq_def]
  · simp only [stepStmtR, stepStmt, evalOpR.eq_def, evalOp.eq_def]
  · simp only [stepStmtR, stepStmt, evalOpR.eq_def, evalOp.eq_def]
  · simp only [stepStmtR, stepStmt, evalOpR.eq_def, evalOp.eq_def]
  · -- the sliding-window `ifThen` (constexpr-true): collapse onto the live block
    rw [aft3_ifThen_trueR R (by rw [aft3_evalOpR_ne_const]; exact aft3_ne_one_zero_true u),
      aft3_ifThen_true (aft3_ne_one_zero_true u)]
    refine aft3_stepStmtsR_castFree_of_stmts R _ ?_ u
    intro st' hst' u'
    simp only [List.mem_cons, List.not_mem_nil, or_false] at hst'
    rcases hst' with rfl | rfl | rfl
    · simp only [stepStmtR, stepStmt, evalOpR.eq_def, evalOp.eq_def]
    · -- the inner `COMPLEMENT` `ifThenElse` (constexpr-false): live boolAnd branch
      rw [aft3_ifThenElse_falseR R (by rw [aft3_evalOpR_ne_const]; exact aft3_ne_zero_zero_false u'),
        aft3_ifThenElse_false (aft3_ne_zero_zero_false u')]
      refine aft3_stepStmtsR_castFree_of_stmts R _ ?_ u'
      intro st'' hst'' u''
      simp only [List.mem_cons, List.not_mem_nil, or_false] at hst''
      rcases hst'' with rfl
      simp only [stepStmtR, stepStmt, evalOpR.eq_def, evalOp.eq_def]
    · simp only [stepStmtR, stepStmt, evalOpR.eq_def, evalOp.eq_def]
  · simp only [stepStmtR, stepStmt, evalOpR.eq_def, evalOp.eq_def]
  · simp only [stepStmtR, stepStmt, evalOpR.eq_def, evalOp.eq_def]
  · simp only [stepStmtR, stepStmt, evalOpR.eq_def, evalOp.eq_def]
  · -- the p-mask `ifThen` (constexpr-true): single live `where` assign
    rw [aft3_ifThen_trueR R (by rw [aft3_evalOpR_ne_const]; exact aft3_ne_one_zero_true u),
      aft3_ifThen_true (aft3_ne_one_zero_true u)]
    refine aft3_stepStmtsR_castFree_of_stmts R _ ?_ u
    intro st' hst' u'
    simp only [List.mem_cons, List.not_mem_nil, or_false] at hst'
    rcases hst' with rfl
    simp only [stepStmtR, stepStmt, evalOpR.eq_def, evalOp.eq_def]
  · simp only [stepStmtR, stepStmt, evalOpR.eq_def, evalOp.eq_def]
  · simp only [stepStmtR, stepStmt, evalOpR.eq_def, evalOp.eq_def]
  · simp only [stepStmtR, stepStmt, evalOpR.eq_def, evalOp.eq_def]
  · simp only [stepStmtR, stepStmt, evalOpR.eq_def, evalOp.eq_def]
  · simp only [stepStmtR, stepStmt, evalOpR.eq_def, evalOp.eq_def]
  · simp only [stepStmtR, stepStmt, evalOpR.eq_def, evalOp.eq_def]
  · simp only [stepStmtR, stepStmt, evalOpR.eq_def, evalOp.eq_def]
  · simp only [stepStmtR, stepStmt, evalOpR.eq_def, evalOp.eq_def]
  · simp only [stepStmtR, stepStmt, evalOpR.eq_def, evalOp.eq_def]
  · simp only [stepStmtR, stepStmt, evalOpR.eq_def, evalOp.eq_def]

/-- The case-1 loop body is cast-free. -/
private theorem aft3LoopBodyG_castFree (R : RoundingModel) (sc : ℝ)
    (off size BM ND BN : Nat) (t : BlockState) :
    stepStmtsR R (aft3LoopBodyG sc off size BM ND BN) t
      = stepStmts (aft3LoopBodyG sc off size BM ND BN) t :=
  aft3_stepStmtsR_castFree_of_stmts R _
    (aft3LoopBodyG_stmt_castFree R sc off size BM ND BN) t

set_option maxHeartbeats 4000000 in
/-- Every case-2 loop-body statement is cast-free (as `aft3LoopBodyG_stmt_castFree`;
the inner `COMPLEMENT` `ifThenElse` is constexpr-true here, collapsing onto the
live `≥ size` then-branch). -/
private theorem aft3LoopBodyG2_stmt_castFree (R : RoundingModel) (sc : ℝ)
    (off size BM ND BN : Nat) :
    ∀ st ∈ aft3LoopBodyG2 sc off size BM ND BN, ∀ u, stepStmtR R st u = stepStmt st u := by
  intro st hst u
  simp only [aft3LoopBodyG2, List.mem_cons, List.not_mem_nil, or_false] at hst
  rcases hst with rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl |
    rfl | rfl | rfl | rfl | rfl | rfl
  · simp only [stepStmtR, stepStmt, evalOpR.eq_def, evalOp.eq_def]
  · simp only [stepStmtR, stepStmt, evalOpR.eq_def, evalOp.eq_def]
  · simp only [stepStmtR, stepStmt, evalOpR.eq_def, evalOp.eq_def]
  · simp only [stepStmtR, stepStmt, evalOpR.eq_def, evalOp.eq_def]
  · -- the sliding-window `ifThen` (constexpr-true)
    rw [aft3_ifThen_trueR R (by rw [aft3_evalOpR_ne_const]; exact aft3_ne_one_zero_true u),
      aft3_ifThen_true (aft3_ne_one_zero_true u)]
    refine aft3_stepStmtsR_castFree_of_stmts R _ ?_ u
    intro st' hst' u'
    simp only [List.mem_cons, List.not_mem_nil, or_false] at hst'
    rcases hst' with rfl | rfl | rfl
    · simp only [stepStmtR, stepStmt, evalOpR.eq_def, evalOp.eq_def]
    · -- the inner `COMPLEMENT` `ifThenElse` (constexpr-true): live `≥ size` branch
      rw [aft3_ifThenElse_trueR R (by rw [aft3_evalOpR_ne_const]; exact aft3_ne_one_zero_true u'),
        aft3_ifThenElse_true (aft3_ne_one_zero_true u')]
      refine aft3_stepStmtsR_castFree_of_stmts R _ ?_ u'
      intro st'' hst'' u''
      simp only [List.mem_cons, List.not_mem_nil, or_false] at hst''
      rcases hst'' with rfl
      simp only [stepStmtR, stepStmt, evalOpR.eq_def, evalOp.eq_def]
    · simp only [stepStmtR, stepStmt, evalOpR.eq_def, evalOp.eq_def]
  · simp only [stepStmtR, stepStmt, evalOpR.eq_def, evalOp.eq_def]
  · simp only [stepStmtR, stepStmt, evalOpR.eq_def, evalOp.eq_def]
  · simp only [stepStmtR, stepStmt, evalOpR.eq_def, evalOp.eq_def]
  · -- the p-mask `ifThen` (constexpr-true)
    rw [aft3_ifThen_trueR R (by rw [aft3_evalOpR_ne_const]; exact aft3_ne_one_zero_true u),
      aft3_ifThen_true (aft3_ne_one_zero_true u)]
    refine aft3_stepStmtsR_castFree_of_stmts R _ ?_ u
    intro st' hst' u'
    simp only [List.mem_cons, List.not_mem_nil, or_false] at hst'
    rcases hst' with rfl
    simp only [stepStmtR, stepStmt, evalOpR.eq_def, evalOp.eq_def]
  · simp only [stepStmtR, stepStmt, evalOpR.eq_def, evalOp.eq_def]
  · simp only [stepStmtR, stepStmt, evalOpR.eq_def, evalOp.eq_def]
  · simp only [stepStmtR, stepStmt, evalOpR.eq_def, evalOp.eq_def]
  · simp only [stepStmtR, stepStmt, evalOpR.eq_def, evalOp.eq_def]
  · simp only [stepStmtR, stepStmt, evalOpR.eq_def, evalOp.eq_def]
  · simp only [stepStmtR, stepStmt, evalOpR.eq_def, evalOp.eq_def]
  · simp only [stepStmtR, stepStmt, evalOpR.eq_def, evalOp.eq_def]
  · simp only [stepStmtR, stepStmt, evalOpR.eq_def, evalOp.eq_def]
  · simp only [stepStmtR, stepStmt, evalOpR.eq_def, evalOp.eq_def]
  · simp only [stepStmtR, stepStmt, evalOpR.eq_def, evalOp.eq_def]

/-- The case-2 loop body is cast-free. -/
private theorem aft3LoopBodyG2_castFree (R : RoundingModel) (sc : ℝ)
    (off size BM ND BN : Nat) (t : BlockState) :
    stepStmtsR R (aft3LoopBodyG2 sc off size BM ND BN) t
      = stepStmts (aft3LoopBodyG2 sc off size BM ND BN) t :=
  aft3_stepStmtsR_castFree_of_stmts R _
    (aft3LoopBodyG2_stmt_castFree R sc off size BM ND BN) t

set_option maxHeartbeats 4000000 in
/-- The case-1 surface sits inside the flat-memory bridge's covered fragment
(no `ptrSub`; the block-pointer ops are structurally covered). -/
theorem aft3_flattenOkG1 (Q K V M Out L : RegionName) (sm_scale : ℝ)
    (sqz sqh sqm sqk skz skh skn skk svz svh svk svn soz soh som son
      Z H H_KV N_CTX ROUND_CTX NKV_CTX off size BM ND BN : Nat) :
    ((attention_fwd_triton3_surface Q K V M Out L sm_scale
      sqz sqh sqm sqk skz skh skn skk svz svh svk svn soz soh som son
      Z H H_KV N_CTX ROUND_CTX NKV_CTX off size 1 1 BM ND BN 1 1 1 0).toAlgKernel).FlattenOk := by
  unfold Kernel.FlattenOk
  rw [aft3_body_splitG]
  simp [aft3PreLoopG, aft3LoopBodyG, aft3PostLoopG, StmtList.FlattenOk,
    Stmt.FlattenOk, Op.FlattenOk]
  simp [Op.FlattenOk.eq_def]

set_option maxHeartbeats 4000000 in
/-- The case-2 surface sits inside the flat-memory bridge's covered fragment. -/
theorem aft3_flattenOkG2 (Q K V M Out L : RegionName) (sm_scale : ℝ)
    (sqz sqh sqm sqk skz skh skn skk svz svh svk svn soz soh som son
      Z H H_KV N_CTX ROUND_CTX NKV_CTX off size BM ND BN : Nat) :
    ((attention_fwd_triton3_surface Q K V M Out L sm_scale
      sqz sqh sqm sqk skz skh skn skk svz svh svk svn soz soh som son
      Z H H_KV N_CTX ROUND_CTX NKV_CTX off size 1 1 BM ND BN 1 1 1 1).toAlgKernel).FlattenOk := by
  unfold Kernel.FlattenOk
  rw [aft3_body_splitG2]
  simp [aft3PreLoopG, aft3LoopBodyG2, aft3PostLoopG, StmtList.FlattenOk,
    Stmt.FlattenOk, Op.FlattenOk]
  simp [Op.FlattenOk.eq_def]

/-- **Streaming IO signature** of the case-1
(`(END,INIT,SLIDING_WINDOW,COMPLEMENT) = (1,1,1,0)`) `_attn_fwd` surface —
identical reads/writes/masks to the case-3 face (the window is a spec-side
key filter, not an addressing change). -/
def attentionFwdTriton3Case1IO (Q K V M Out L : RegionName) (sm_scale : ℝ)
    (sqz sqh sqm sqk skz skh skn skk svz svh svk svn soz soh som son
      Z H H_KV N_CTX ROUND_CTX NKV_CTX off size BM ND BN : Nat) :
    StreamMasked3DKernelIO₃ₓ₂ where
  kernel := attention_fwd_triton3_surface Q K V M Out L sm_scale
    sqz sqh sqm sqk skz skh skn skk svz svh svk svn soz soh som son
    Z H H_KV N_CTX ROUND_CTX NKV_CTX off size 1 1 BM ND BN 1 1 1 0
  inp1 := Q
  inp2 := K
  inp3 := V
  out1 := Out
  out2 := M
  T := NKV_CTX / BN
  B1 := BM * ND
  B2 := ND * BN
  B3 := BN * ND
  C1 := BM * ND
  C2 := BM
  read1 := fun p₀ p₁ _ _ j =>
    (p₁ / H * sqz + p₁ % H * sqh) + (p₀ * BM + j.val / ND) * sqm + (j.val % ND) * sqk
  read2 := fun _ p₁ _ t j =>
    (p₁ / H * sqz + p₁ % H * sqh) + (j.val / BN) * skk + (t.val * BN + j.val % BN) * skn
  read3 := fun _ p₁ _ t j =>
    (p₁ / H * sqz + p₁ % H * sqh) + (t.val * BN + j.val / ND) * svk + (j.val % ND) * svn
  write1 := fun p₀ p₁ _ j =>
    (p₁ / H * sqz + p₁ % H * sqh) + (p₀ * BM + j.val / ND) * som + (j.val % ND) * son
  write2 := fun p₀ p₁ _ j => p₁ * ROUND_CTX + (p₀ * BM + j.val)
  mask1 := fun _ _ _ _ _ => True
  mask2 := fun _ _ _ _ _ => True
  mask3 := fun _ _ _ _ _ => True
  writeMask1 := fun _ _ _ _ => True
  writeMask2 := fun _ _ _ _ => True

/-- **Streaming IO signature** of the case-2 (`(1,1,1,1)`, complement window)
surface — same io skeleton, complement constexpr instantiation. -/
def attentionFwdTriton3Case2IO (Q K V M Out L : RegionName) (sm_scale : ℝ)
    (sqz sqh sqm sqk skz skh skn skk svz svh svk svn soz soh som son
      Z H H_KV N_CTX ROUND_CTX NKV_CTX off size BM ND BN : Nat) :
    StreamMasked3DKernelIO₃ₓ₂ where
  kernel := attention_fwd_triton3_surface Q K V M Out L sm_scale
    sqz sqh sqm sqk skz skh skn skk svz svh svk svn soz soh som son
    Z H H_KV N_CTX ROUND_CTX NKV_CTX off size 1 1 BM ND BN 1 1 1 1
  inp1 := Q
  inp2 := K
  inp3 := V
  out1 := Out
  out2 := M
  T := NKV_CTX / BN
  B1 := BM * ND
  B2 := ND * BN
  B3 := BN * ND
  C1 := BM * ND
  C2 := BM
  read1 := fun p₀ p₁ _ _ j =>
    (p₁ / H * sqz + p₁ % H * sqh) + (p₀ * BM + j.val / ND) * sqm + (j.val % ND) * sqk
  read2 := fun _ p₁ _ t j =>
    (p₁ / H * sqz + p₁ % H * sqh) + (j.val / BN) * skk + (t.val * BN + j.val % BN) * skn
  read3 := fun _ p₁ _ t j =>
    (p₁ / H * sqz + p₁ % H * sqh) + (t.val * BN + j.val / ND) * svk + (j.val % ND) * svn
  write1 := fun p₀ p₁ _ j =>
    (p₁ / H * sqz + p₁ % H * sqh) + (p₀ * BM + j.val / ND) * som + (j.val % ND) * son
  write2 := fun p₀ p₁ _ j => p₁ * ROUND_CTX + (p₀ * BM + j.val)
  mask1 := fun _ _ _ _ _ => True
  mask2 := fun _ _ _ _ _ => True
  mask3 := fun _ _ _ _ _ => True
  writeMask1 := fun _ _ _ _ => True
  writeMask2 := fun _ _ _ _ => True

/-- **Case-1 `Out` closed form on the streams**: the sliding-window base-2
per-key-scale softmax (exactly the exact headline's
`attentionFwdTriton3Case1OutSpecG`, keep `natSlidingWindowKeepG`) restated
over the three streamed tiles, at output lane `j = (i, d)` row-major over
`[BM, ND]`. The window filter eats `p₀` (the `start_m` program id). -/
noncomputable def attentionFwdTriton3Case1IOOutSpec (p₀ BM ND BN NC T : Nat)
    (hT : 0 < T) (hTB : T * BN = NC) (hBN : 0 < BN) (sc : ℝ) (off size : Nat)
    (xs : Fin T → Fin (BM * ND) → ℝ) (ys : Fin T → Fin (ND * BN) → ℝ)
    (zs : Fin T → Fin (BN * ND) → ℝ) (j : Fin (BM * ND)) : ℝ :=
  attentionRealBase2PerKeyScalePred (aft3IOqT BM ND T hT xs)
    (aft3IOkT ND BN NC T hTB hBN ys) (aft3IOvT ND BN NC T hTB hBN zs)
    (keyScale3G sc NC) (fun i j => natSlidingWindowKeepG p₀ BM BN off size i j)
    (Lane2D.decode j)

/-- **Case-1 `M` closed form on the streams**: the raw
`(m ⊔ … + log2 l).unbotD 0` finalize (exactly the exact headline's
`attentionFwdTriton3KMSpecG` at the sliding-window keep) restated over the
three streamed tiles, at output row `i`. -/
noncomputable def attentionFwdTriton3Case1IOMSpec (p₀ BM ND BN NC T : Nat)
    (hND : 0 < ND) (hT : 0 < T) (hTB : T * BN = NC) (hBN : 0 < BN) (sc : ℝ)
    (off size : Nat)
    (xs : Fin T → Fin (BM * ND) → ℝ) (ys : Fin T → Fin (ND * BN) → ℝ)
    (zs : Fin T → Fin (BN * ND) → ℝ) (i : Fin BM) : ℝ :=
  (WithBot.realAdd
      (aft3RunningMaxG (aft3IOqT BM ND T hT xs) (aft3IOkT ND BN NC T hTB hBN ys)
        (aft3IOvT ND BN NC T hTB hBN zs) (keyScale3G sc NC)
        (fun i j => natSlidingWindowKeepG p₀ BM BN off size i j) NC i ⟨0, hND⟩)
      (WithBot.realLog2
        (((aft3StateBotKG (aft3IOqT BM ND T hT xs) (aft3IOkT ND BN NC T hTB hBN ys)
            (aft3IOvT ND BN NC T hTB hBN zs) (keyScale3G sc NC)
            (fun i j => natSlidingWindowKeepG p₀ BM BN off size i j) NC i ⟨0, hND⟩).2.1 : ℝ)
          : WithBot ℝ))).unbotD 0

/-- **Case-2 `Out` closed form on the streams** (complement keep
`natComplementSlidingWindowKeepG`; otherwise as case 1). -/
noncomputable def attentionFwdTriton3Case2IOOutSpec (p₀ BM ND BN NC T : Nat)
    (hT : 0 < T) (hTB : T * BN = NC) (hBN : 0 < BN) (sc : ℝ) (off size : Nat)
    (xs : Fin T → Fin (BM * ND) → ℝ) (ys : Fin T → Fin (ND * BN) → ℝ)
    (zs : Fin T → Fin (BN * ND) → ℝ) (j : Fin (BM * ND)) : ℝ :=
  attentionRealBase2PerKeyScalePred (aft3IOqT BM ND T hT xs)
    (aft3IOkT ND BN NC T hTB hBN ys) (aft3IOvT ND BN NC T hTB hBN zs)
    (keyScale3G sc NC) (fun i j => natComplementSlidingWindowKeepG p₀ BM BN off size i j)
    (Lane2D.decode j)

/-- **Case-2 `M` closed form on the streams** (complement keep). -/
noncomputable def attentionFwdTriton3Case2IOMSpec (p₀ BM ND BN NC T : Nat)
    (hND : 0 < ND) (hT : 0 < T) (hTB : T * BN = NC) (hBN : 0 < BN) (sc : ℝ)
    (off size : Nat)
    (xs : Fin T → Fin (BM * ND) → ℝ) (ys : Fin T → Fin (ND * BN) → ℝ)
    (zs : Fin T → Fin (BN * ND) → ℝ) (i : Fin BM) : ℝ :=
  (WithBot.realAdd
      (aft3RunningMaxG (aft3IOqT BM ND T hT xs) (aft3IOkT ND BN NC T hTB hBN ys)
        (aft3IOvT ND BN NC T hTB hBN zs) (keyScale3G sc NC)
        (fun i j => natComplementSlidingWindowKeepG p₀ BM BN off size i j) NC i ⟨0, hND⟩)
      (WithBot.realLog2
        (((aft3StateBotKG (aft3IOqT BM ND T hT xs) (aft3IOkT ND BN NC T hTB hBN ys)
            (aft3IOvT ND BN NC T hTB hBN zs) (keyScale3G sc NC)
            (fun i j => natComplementSlidingWindowKeepG p₀ BM BN off size i j) NC i ⟨0, hND⟩).2.1 : ℝ)
          : WithBot ℝ))).unbotD 0

/-- The `aft3StateBotKG` writeback ratio at the full window IS the masked
closed form `attentionRealBase2PerKeyScalePred` — the per-lane composition of
the two `_eq_streaming` bridges with `aft3KeysUptoG_full`, packaged once for
the io headlines (works for any keep predicate over any tiles). -/
private theorem aft3_botKG_ratio_eq_pred {BM ND NC : Nat}
    (qT : TileIndex [BM, ND] → ℝ) (kT vT : TileIndex [NC, ND] → ℝ)
    (ks : Fin NC → ℝ) (kp : Fin BM → Fin NC → Prop) [∀ i j, Decidable (kp i j)]
    (hNC : 0 < NC) (hND : 0 < ND) (idx : TileIndex [BM, ND]) :
    ((aft3StateBotKG qT kT vT ks kp NC idx.1 idx.2.1).2.2)
        / ((aft3StateBotKG qT kT vT ks kp NC idx.1 ⟨0, hND⟩).2.1)
      = attentionRealBase2PerKeyScalePred qT kT vT ks kp idx := by
  obtain ⟨ir, dd, ⟨⟩⟩ := idx
  rw [aft3StateBotKG_full_eq_streaming qT kT vT ks kp hNC ir dd ⟨0, hND⟩]
  rw [VeriTile.Triton.attentionRealBase2PerKeyScalePred_eq_streaming qT kT vT ks kp ir dd]
  rw [aft3KeysUptoG_full qT kT vT ks kp ir dd]

set_option maxHeartbeats 4000000 in
set_option maxRecDepth 8000 in
/-- **Weak loop-body step (case 1)**: `aft3LoopBodyG_steps` minus the
clean-`undef` hypothesis (whose only use was the dropped `undef`-preservation
conclusion) — usable from arbitrary launch states in the safety walk. The
`smsc` body argument is phantom (the lowered body reads `qk_scale` from the
register file). -/
private theorem aft3LoopBodyG_stepsW1 (sin : BlockState) (SM SN off size : Nat) (smsc : ℝ)
    (Kreg Vreg : RegionName) (kbase vbase kcol vrow : Nat)
    (skk skn svk svn ND NKV_CTX BM BN : Nat) (hBN : 0 < BN)
    (qtile : Tile .real [BM, ND]) (mtile ltile : Tile .real [BM]) (acctile : Tile .real [BM, ND])
    (ktile : Tile .real [ND, BN]) (vtile : Tile .real [BN, ND]) (sc : ℝ)
    (hsm : sin.regs .nat [] "start_m" = some (Tile.scalar SM))
    (hsn : sin.regs .nat [] "start_n" = some (Tile.scalar SN))
    (hq : sin.regs .real [BM, ND] "q" = some qtile)
    (hqs : sin.regs .real [] "qk_scale" = some (Tile.scalar (some sc)))
    (hmi : sin.regs .real [BM] "m_i" = some mtile)
    (hli : sin.regs .real [BM] "l_i" = some ltile)
    (hacc : sin.regs .real [BM, ND] "acc" = some acctile)
    (hKp : sin.regs .blockPtr [ND, BN] "K_block_ptr" = some
      (⟨fun _ : TileIndex [ND, BN] =>
        { region := Kreg, baseOffset := kbase, parentShape := [ND, NKV_CTX],
          blockShape := [ND, BN], strides := [skk, skn], offsets := [0, kcol] }⟩))
    (hVp : sin.regs .blockPtr [BN, ND] "V_block_ptr" = some
      (⟨fun _ : TileIndex [BN, ND] =>
        { region := Vreg, baseOffset := vbase, parentShape := [NKV_CTX, ND],
          blockShape := [BN, ND], strides := [svk, svn], offsets := [vrow, 0] }⟩))
    (hkload : ∀ idx : TileIndex [ND, BN],
      ktile.data idx = some (sin.readMem Kreg (kbase + idx.1.val * skk + (kcol + idx.2.1.val) * skn)))
    (hvload : ∀ idx : TileIndex [BN, ND],
      vtile.data idx = some (sin.readMem Vreg (vbase + (vrow + idx.1.val) * svk + idx.2.1.val * svn))) :
    ∃ sF, stepStmts (aft3LoopBodyG smsc off size BM ND BN) sin = some sF
      ∧ sF.pids = sin.pids ∧ sF.mem = sin.mem
      ∧ sF.regs .real [BM, ND] "q" = some qtile
      ∧ sF.regs .real [] "qk_scale" = some (Tile.scalar (some sc))
      ∧ sF.regs .nat [] "start_m" = some (Tile.scalar SM)
      ∧ sF.regs .blockPtr [ND, BN] "K_block_ptr" = some
          (⟨fun _ : TileIndex [ND, BN] =>
            { region := Kreg, baseOffset := kbase, parentShape := [ND, NKV_CTX],
              blockShape := [ND, BN], strides := [skk, skn], offsets := [0, kcol + BN] }⟩)
      ∧ sF.regs .blockPtr [BN, ND] "V_block_ptr" = some
          (⟨fun _ : TileIndex [BN, ND] =>
            { region := Vreg, baseOffset := vbase, parentShape := [NKV_CTX, ND],
              blockShape := [BN, ND], strides := [svk, svn], offsets := [vrow + BN, 0] }⟩)
      ∧ sF.regs .nat [] "off_hz" = sin.regs .nat [] "off_hz"
      ∧ sF.regs .ptr [BM] "m_ptrs" = sin.regs .ptr [BM] "m_ptrs"
      ∧ sF.regs .ptr [BM] "l_ptrs" = sin.regs .ptr [BM] "l_ptrs"
      ∧ sF.regs .blockPtr [BM, ND] "O_block_ptr" = sin.regs .blockPtr [BM, ND] "O_block_ptr"
      ∧ ∃ (qkT : Tile .real [BM, BN]) (rmaxT mijT alphaT lijT : Tile .real [BM])
            (pT pmT : Tile .real [BM, BN]) (acc1T : Tile .real [BM, ND]),
          (qkT = ⟨fun idx : TileIndex [BM, BN] =>
            if aft3MaskCell1G SM SN off size BM BN idx
            then (Tile.bop NumericDType.real.mul Broadcast.scalarR
                    (Tile.bop NumericDType.real.add
                      (Broadcast.consSame (Broadcast.consSame Broadcast.nil))
                      (⟨fun _ => some (0 : ℝ)⟩ : Tile .real [BM, BN]) (Tile.dot [] qtile ktile))
                    (Tile.scalar (some sc))).data idx
            else (⊥ : WithBot ℝ)⟩)
          ∧ Tile.reduceMaxDrop (⟨1, by simp⟩ : Fin [BM, BN].length) qkT = some rmaxT
          ∧ mijT = Tile.select (Tile.cop ComparableDType.real.gt (Broadcast.consSame Broadcast.nil) mtile rmaxT) mtile rmaxT
          ∧ alphaT = Tile.uop WithBot.realExp2 (Tile.bop NumericDType.real.sub (Broadcast.consSame Broadcast.nil) mtile mijT)
          ∧ pT = Tile.uop WithBot.realExp2 (Tile.bop NumericDType.real.sub (Broadcast.consSame (Broadcast.consR Broadcast.nil)) qkT (Tile.expandDim ⟨1, by simp⟩ mijT))
          ∧ pmT = ⟨fun idx : TileIndex [BM, BN] =>
              if aft3MaskCell1G SM SN off size BM BN idx then pT.data idx else (some (0.0 : ℝ) : WithBot ℝ)⟩
          ∧ lijT = Tile.reduceSumDrop (⟨1, by simp⟩ : Fin [BM, BN].length) pmT
          ∧ acc1T = Tile.bop NumericDType.real.mul (Broadcast.consSame (Broadcast.consR Broadcast.nil)) acctile (Tile.expandDim ⟨1, by simp⟩ alphaT)
          ∧ sF.regs .real [BM] "m_i" = some mijT
          ∧ sF.regs .real [BM] "l_i" = some (Tile.bop NumericDType.real.add (Broadcast.consSame Broadcast.nil)
              (Tile.bop NumericDType.real.mul (Broadcast.consSame Broadcast.nil) ltile alphaT) lijT)
          ∧ sF.regs .real [BM, ND] "acc" = some (Tile.bop NumericDType.real.add
              (Broadcast.consSame (Broadcast.consSame Broadcast.nil)) acc1T (Tile.dot [] pmT vtile)) := by
  set qkSeedT : Tile .real [BM, BN] :=
    Tile.bop NumericDType.real.mul Broadcast.scalarR
      (Tile.bop NumericDType.real.add (Broadcast.consSame (Broadcast.consSame Broadcast.nil))
        (⟨fun _ => some (0 : ℝ)⟩ : Tile .real [BM, BN]) (Tile.dot [] qtile ktile))
      (Tile.scalar (some sc)) with hqkSeed
  set maskT : Tile .bool [BM, BN] := ⟨fun idx : TileIndex [BM, BN] => aft3MaskCell1G SM SN off size BM BN idx⟩ with hmaskT
  set qkT : Tile .real [BM, BN] :=
    ⟨fun idx : TileIndex [BM, BN] =>
      if maskT.data idx then qkSeedT.data idx else (⊥ : WithBot ℝ)⟩ with hqkT
  obtain ⟨rmaxT, hrm⟩ : ∃ t, Tile.reduceMaxDrop (⟨1, by simp⟩ : Fin [BM, BN].length) qkT = some t :=
    ⟨_, by unfold Tile.reduceMaxDrop; rw [dif_pos (show 0 < TileShape.axisDim [BM, BN] (⟨1, by simp⟩ : Fin [BM, BN].length) from by simpa [TileShape.axisDim] using hBN)]⟩
  set mijT : Tile .real [BM] := Tile.select (Tile.cop ComparableDType.real.gt (Broadcast.consSame Broadcast.nil) mtile rmaxT) mtile rmaxT with hmij
  set alphaT : Tile .real [BM] := Tile.uop WithBot.realExp2 (Tile.bop NumericDType.real.sub (Broadcast.consSame Broadcast.nil) mtile mijT) with halpha
  set pT : Tile .real [BM, BN] := Tile.uop WithBot.realExp2 (Tile.bop NumericDType.real.sub (Broadcast.consSame (Broadcast.consR Broadcast.nil)) qkT (Tile.expandDim ⟨1, by simp⟩ mijT)) with hpT
  set pmT : Tile .real [BM, BN] := ⟨fun idx : TileIndex [BM, BN] => if maskT.data idx then pT.data idx else (some (0.0 : ℝ) : WithBot ℝ)⟩ with hpmT
  set lijT : Tile .real [BM] := Tile.reduceSumDrop (⟨1, by simp⟩ : Fin [BM, BN].length) pmT with hlij
  set acc1T : Tile .real [BM, ND] := Tile.bop NumericDType.real.mul (Broadcast.consSame (Broadcast.consR Broadcast.nil)) acctile (Tile.expandDim ⟨1, by simp⟩ alphaT) with hacc1
  unfold aft3LoopBodyG
  -- L1: k = load K_block_ptr
  rw [stepStmts.cons_some (stepStmt_assign_eq_some
    (show evalOp (Op.load TileDType.real (MemAccess.blockPtr (Op.ref TileDType.blockPtr [ND, BN] "K_block_ptr") []) MaskOpt.none .unspecified) sin
        = some ktile from by
      rw [aft3_load_k_eval Kreg kbase ND NKV_CTX ND BN skk skn kcol (Op.ref TileDType.blockPtr [ND, BN] "K_block_ptr") sin
        (by rw [evalOp_ref]; exact hKp)]
      refine congrArg some ?_; refine Tile.ext (fun idx => ?_); rw [hkload idx]))]
  -- L2: qk = zeros
  rw [stepStmts.cons_some (stepStmt_assign_eq_some (aft3_qkzeros_eval _ BM BN))]
  -- L3: qk += dot q k
  rw [stepStmts.cons_some (stepStmt_assign_eq_some
    (aft3_qk_dot_eval _ BM BN ND (⟨fun _ => some (0 : ℝ)⟩ : Tile .real [BM, BN]) qtile ktile
      (by rw [BlockState.setReg_same])
      (by simp only [BlockState.setReg_ne_name, ne_eq, String.reduceEq, not_false_eq_true,
            BlockState.setReg_same]; exact hq)
      (by simp only [BlockState.setReg_ne_name, ne_eq, String.reduceEq, not_false_eq_true,
            BlockState.setReg_same])))]
  -- L4: qk *= qk_scale
  rw [stepStmts.cons_some (stepStmt_assign_eq_some
    (aft3_qk_scale_ref_eval _ BM BN sc
      (Tile.bop NumericDType.real.add (Broadcast.consSame (Broadcast.consSame Broadcast.nil))
        (⟨fun _ => some (0 : ℝ)⟩ : Tile .real [BM, BN]) (Tile.dot [] qtile ktile))
      (by rw [BlockState.setReg_same])
      (by simp only [BlockState.setReg_ne_name, ne_eq, String.reduceEq, not_false_eq_true]; exact hqs)))]
  -- L5: window ifThen (SLIDING_WINDOW true)
  rw [stepStmts.cons_some
    (show stepStmt _ _ = some _ from
      (aft3_ifThen_true (aft3_ne_one_zero_true _)).trans
        (aft3_window1_stepsG _ SM SN off size BM BN (by simp) (by simp) qkSeedT
          (by simp only [BlockState.setReg_ne_name, ne_eq, String.reduceEq, not_false_eq_true]; exact hsm)
          (by simp only [BlockState.setReg_ne_name, ne_eq, String.reduceEq, not_false_eq_true]; exact hsn)
          (by rw [BlockState.setReg_same])))]
  -- L6: m_ij = maximum(m_i, max(qk,1))
  rw [stepStmts.cons_some (stepStmt_assign_eq_some
    (aft3_mij_evalG _ BM BN mtile qkT rmaxT (by simp)
      (by simp only [BlockState.setReg_ne_name, ne_eq, String.reduceEq, not_false_eq_true]; exact hmi)
      (by rw [BlockState.setReg_same])
      hrm))]
  -- L7: qk -= m_ij[:, None]
  rw [stepStmts.cons_some (stepStmt_assign_eq_some
    (aft3_qk_sub_evalG _ BM BN (by simp) qkT mijT
      (by simp only [BlockState.setReg_ne_name, ne_eq, String.reduceEq, not_false_eq_true,
            BlockState.setReg_same] <;> try rfl)
      (by rw [BlockState.setReg_same])))]
  -- L8: p = exp2 qk
  rw [stepStmts.cons_some (stepStmt_assign_eq_some
    (aft3_p_evalG _ BM BN (Tile.bop NumericDType.real.sub (Broadcast.consSame (Broadcast.consR Broadcast.nil)) qkT (Tile.expandDim ⟨1, by simp⟩ mijT))
      (by rw [BlockState.setReg_same])))]
  -- L9: pmask ifThen (SLIDING_WINDOW true)
  rw [stepStmts.cons_some
    (show stepStmt _ _ = some _ from
      (aft3_ifThen_true (aft3_ne_one_zero_true _)).trans
        (aft3_pmask1_stepsG _ BM BN maskT pT
          (by simp only [BlockState.setReg_ne_name, ne_eq, String.reduceEq, not_false_eq_true,
                BlockState.setReg_same] <;> try rfl)
          (by rw [BlockState.setReg_same])))]
  -- L10: l_ij = sum p 1
  rw [stepStmts.cons_some (@stepStmt_assign_eq_some .real [BM] "l_ij"
    (Op.reduceSum (⟨1, by simp⟩ : Fin [BM, BN].length) Bool.false (Op.ref .real [BM, BN] "p")) _ lijT
    (aft3_lij_evalG _ BM BN pmT (by simp) (by rw [BlockState.setReg_same])))]
  -- L11: tmp = m_i - m_ij
  rw [stepStmts.cons_some (stepStmt_assign_eq_some
    (aft3_tmp_evalG _ BM mtile mijT
      (by simp only [BlockState.setReg_ne_name, ne_eq, String.reduceEq, not_false_eq_true]; exact hmi)
      (by simp only [BlockState.setReg_ne_name, ne_eq, String.reduceEq, not_false_eq_true,
            BlockState.setReg_same] <;> try rfl)))]
  -- L12: alpha = exp2 tmp
  rw [stepStmts.cons_some (stepStmt_assign_eq_some
    (aft3_alpha_evalG _ BM (Tile.bop NumericDType.real.sub (Broadcast.consSame Broadcast.nil) mtile mijT)
      (by rw [BlockState.setReg_same])))]
  -- L13: l_i = l_i * alpha + l_ij
  rw [stepStmts.cons_some (stepStmt_assign_eq_some
    (aft3_li_evalG _ BM ltile alphaT lijT
      (by simp only [BlockState.setReg_ne_name, ne_eq, String.reduceEq, not_false_eq_true]; exact hli)
      (by simp only [BlockState.setReg_ne_name, ne_eq, String.reduceEq, not_false_eq_true,
            BlockState.setReg_same] <;> try rfl)
      (by simp only [BlockState.setReg_ne_name, ne_eq, String.reduceEq, not_false_eq_true,
            BlockState.setReg_same] <;> try rfl)))]
  -- L14: acc = acc * alpha[:, None]
  rw [stepStmts.cons_some (stepStmt_assign_eq_some
    (aft3_acc_rescale_evalG _ BM ND (by simp) acctile alphaT
      (by simp only [BlockState.setReg_ne_name, ne_eq, String.reduceEq, not_false_eq_true]; exact hacc)
      (by simp only [BlockState.setReg_ne_name, ne_eq, String.reduceEq, not_false_eq_true,
            BlockState.setReg_same] <;> try rfl)))]
  -- L15: v = load V_block_ptr
  rw [stepStmts.cons_some (stepStmt_assign_eq_some
    (show evalOp (Op.load TileDType.real (MemAccess.blockPtr (Op.ref TileDType.blockPtr [BN, ND] "V_block_ptr") []) MaskOpt.none .unspecified) _
        = some vtile from by
      rw [aft3_load_v_eval Vreg vbase NKV_CTX ND BN ND svk svn vrow (Op.ref TileDType.blockPtr [BN, ND] "V_block_ptr") _
        (by rw [evalOp_ref]
            simp only [BlockState.setReg_ne_name, ne_eq, String.reduceEq, not_false_eq_true]
            exact hVp)]
      refine congrArg some ?_; refine Tile.ext (fun idx => ?_)
      simp only [BlockState.setReg_readMem]; rw [hvload idx]))]
  -- L16: acc += dot p v
  rw [stepStmts.cons_some (stepStmt_assign_eq_some
    (aft3_acc_eval _ BM BN ND acc1T pmT vtile
      (by simp only [BlockState.setReg_ne_name, ne_eq, String.reduceEq, not_false_eq_true,
            BlockState.setReg_same] <;> try rfl)
      (by simp only [BlockState.setReg_ne_name, ne_eq, String.reduceEq, not_false_eq_true,
            BlockState.setReg_same] <;> try rfl)
      (by rw [BlockState.setReg_same])))]
  -- L17: m_i = m_ij
  rw [stepStmts.cons_some (stepStmt_assign_eq_some
    (aft3_mi_carry_evalG _ BM mijT
      (by simp only [BlockState.setReg_ne_name, ne_eq, String.reduceEq, not_false_eq_true,
            BlockState.setReg_same] <;> try rfl)))]
  -- L18: V_block_ptr = advance [BN, 0]
  rw [stepStmts.cons_some (stepStmt_assign_eq_some
    (aft3_advance_v_eval _ Vreg vbase NKV_CTX ND BN ND svk svn vrow BN "V_block_ptr"
      (by simp only [BlockState.setReg_ne_name, ne_eq, String.reduceEq, not_false_eq_true]; exact hVp)))]
  -- L19: K_block_ptr = advance [0, BN]
  rw [stepStmts.cons_some (stepStmt_assign_eq_some
    (aft3_advance_k_eval _ Kreg kbase ND NKV_CTX ND BN skk skn kcol BN "K_block_ptr"
      (by simp only [BlockState.setReg_ne_name, ne_eq, String.reduceEq, not_false_eq_true]; exact hKp)))]
  rw [stepStmts.nil]
  refine ⟨_, rfl, ?_, ?_, ?_, ?_, ?_, ?_, ?_, ?_, ?_, ?_, ?_, qkT, rmaxT, mijT, alphaT, lijT, pT, pmT, acc1T,
    rfl, hrm, rfl, rfl, rfl, rfl, rfl, rfl, ?_, ?_, ?_⟩
  · simp only [BlockState.setReg_pids]
  · funext rg o; simp only [BlockState.setReg_mem]
  · simp only [BlockState.setReg_ne_name, ne_eq, String.reduceEq, not_false_eq_true,
      BlockState.setReg_same]; exact hq
  · simp only [BlockState.setReg_ne_name, ne_eq, String.reduceEq, not_false_eq_true,
      BlockState.setReg_same]; exact hqs
  · simp only [BlockState.setReg_ne_name, ne_eq, String.reduceEq, not_false_eq_true,
      BlockState.setReg_same]; exact hsm
  · simp only [BlockState.setReg_same]
  · simp only [BlockState.setReg_ne_name, ne_eq, String.reduceEq, not_false_eq_true,
      BlockState.setReg_same]
  · simp only [BlockState.setReg_ne_name, ne_eq, String.reduceEq, not_false_eq_true,
      BlockState.setReg_same]
  · simp only [BlockState.setReg_ne_name, ne_eq, String.reduceEq, not_false_eq_true,
      BlockState.setReg_same]
  · simp only [BlockState.setReg_ne_name, ne_eq, String.reduceEq, not_false_eq_true,
      BlockState.setReg_same]
  · simp only [BlockState.setReg_ne_name, ne_eq, String.reduceEq, not_false_eq_true,
      BlockState.setReg_same]
  · simp only [BlockState.setReg_ne_name, ne_eq, String.reduceEq, not_false_eq_true,
      BlockState.setReg_same]
  · simp only [BlockState.setReg_ne_name, ne_eq, String.reduceEq, not_false_eq_true,
      BlockState.setReg_same]
  · simp only [BlockState.setReg_ne_name, ne_eq, String.reduceEq, not_false_eq_true,
      BlockState.setReg_same]

set_option maxHeartbeats 4000000 in
set_option maxRecDepth 8000 in
/-- **Weak loop-body step (case 2, complement)** — `aft3LoopBodyG2_steps`
minus the clean-`undef` hypothesis. -/
private theorem aft3LoopBodyG2_stepsW2 (sin : BlockState) (SM SN off size : Nat) (smsc : ℝ)
    (Kreg Vreg : RegionName) (kbase vbase kcol vrow : Nat)
    (skk skn svk svn ND NKV_CTX BM BN : Nat) (hBN : 0 < BN)
    (qtile : Tile .real [BM, ND]) (mtile ltile : Tile .real [BM]) (acctile : Tile .real [BM, ND])
    (ktile : Tile .real [ND, BN]) (vtile : Tile .real [BN, ND]) (sc : ℝ)
    (hsm : sin.regs .nat [] "start_m" = some (Tile.scalar SM))
    (hsn : sin.regs .nat [] "start_n" = some (Tile.scalar SN))
    (hq : sin.regs .real [BM, ND] "q" = some qtile)
    (hqs : sin.regs .real [] "qk_scale" = some (Tile.scalar (some sc)))
    (hmi : sin.regs .real [BM] "m_i" = some mtile)
    (hli : sin.regs .real [BM] "l_i" = some ltile)
    (hacc : sin.regs .real [BM, ND] "acc" = some acctile)
    (hKp : sin.regs .blockPtr [ND, BN] "K_block_ptr" = some
      (⟨fun _ : TileIndex [ND, BN] =>
        { region := Kreg, baseOffset := kbase, parentShape := [ND, NKV_CTX],
          blockShape := [ND, BN], strides := [skk, skn], offsets := [0, kcol] }⟩))
    (hVp : sin.regs .blockPtr [BN, ND] "V_block_ptr" = some
      (⟨fun _ : TileIndex [BN, ND] =>
        { region := Vreg, baseOffset := vbase, parentShape := [NKV_CTX, ND],
          blockShape := [BN, ND], strides := [svk, svn], offsets := [vrow, 0] }⟩))
    (hkload : ∀ idx : TileIndex [ND, BN],
      ktile.data idx = some (sin.readMem Kreg (kbase + idx.1.val * skk + (kcol + idx.2.1.val) * skn)))
    (hvload : ∀ idx : TileIndex [BN, ND],
      vtile.data idx = some (sin.readMem Vreg (vbase + (vrow + idx.1.val) * svk + idx.2.1.val * svn))) :
    ∃ sF, stepStmts (aft3LoopBodyG2 smsc off size BM ND BN) sin = some sF
      ∧ sF.pids = sin.pids ∧ sF.mem = sin.mem
      ∧ sF.regs .real [BM, ND] "q" = some qtile
      ∧ sF.regs .real [] "qk_scale" = some (Tile.scalar (some sc))
      ∧ sF.regs .nat [] "start_m" = some (Tile.scalar SM)
      ∧ sF.regs .blockPtr [ND, BN] "K_block_ptr" = some
          (⟨fun _ : TileIndex [ND, BN] =>
            { region := Kreg, baseOffset := kbase, parentShape := [ND, NKV_CTX],
              blockShape := [ND, BN], strides := [skk, skn], offsets := [0, kcol + BN] }⟩)
      ∧ sF.regs .blockPtr [BN, ND] "V_block_ptr" = some
          (⟨fun _ : TileIndex [BN, ND] =>
            { region := Vreg, baseOffset := vbase, parentShape := [NKV_CTX, ND],
              blockShape := [BN, ND], strides := [svk, svn], offsets := [vrow + BN, 0] }⟩)
      ∧ sF.regs .nat [] "off_hz" = sin.regs .nat [] "off_hz"
      ∧ sF.regs .ptr [BM] "m_ptrs" = sin.regs .ptr [BM] "m_ptrs"
      ∧ sF.regs .ptr [BM] "l_ptrs" = sin.regs .ptr [BM] "l_ptrs"
      ∧ sF.regs .blockPtr [BM, ND] "O_block_ptr" = sin.regs .blockPtr [BM, ND] "O_block_ptr"
      ∧ ∃ (qkT : Tile .real [BM, BN]) (rmaxT mijT alphaT lijT : Tile .real [BM])
            (pT pmT : Tile .real [BM, BN]) (acc1T : Tile .real [BM, ND]),
          (qkT = ⟨fun idx : TileIndex [BM, BN] =>
            if aft3MaskCell2G SM SN off size BM BN idx
            then (Tile.bop NumericDType.real.mul Broadcast.scalarR
                    (Tile.bop NumericDType.real.add
                      (Broadcast.consSame (Broadcast.consSame Broadcast.nil))
                      (⟨fun _ => some (0 : ℝ)⟩ : Tile .real [BM, BN]) (Tile.dot [] qtile ktile))
                    (Tile.scalar (some sc))).data idx
            else (⊥ : WithBot ℝ)⟩)
          ∧ Tile.reduceMaxDrop (⟨1, by simp⟩ : Fin [BM, BN].length) qkT = some rmaxT
          ∧ mijT = Tile.select (Tile.cop ComparableDType.real.gt (Broadcast.consSame Broadcast.nil) mtile rmaxT) mtile rmaxT
          ∧ alphaT = Tile.uop WithBot.realExp2 (Tile.bop NumericDType.real.sub (Broadcast.consSame Broadcast.nil) mtile mijT)
          ∧ pT = Tile.uop WithBot.realExp2 (Tile.bop NumericDType.real.sub (Broadcast.consSame (Broadcast.consR Broadcast.nil)) qkT (Tile.expandDim ⟨1, by simp⟩ mijT))
          ∧ pmT = ⟨fun idx : TileIndex [BM, BN] =>
              if aft3MaskCell2G SM SN off size BM BN idx then pT.data idx else (some (0.0 : ℝ) : WithBot ℝ)⟩
          ∧ lijT = Tile.reduceSumDrop (⟨1, by simp⟩ : Fin [BM, BN].length) pmT
          ∧ acc1T = Tile.bop NumericDType.real.mul (Broadcast.consSame (Broadcast.consR Broadcast.nil)) acctile (Tile.expandDim ⟨1, by simp⟩ alphaT)
          ∧ sF.regs .real [BM] "m_i" = some mijT
          ∧ sF.regs .real [BM] "l_i" = some (Tile.bop NumericDType.real.add (Broadcast.consSame Broadcast.nil)
              (Tile.bop NumericDType.real.mul (Broadcast.consSame Broadcast.nil) ltile alphaT) lijT)
          ∧ sF.regs .real [BM, ND] "acc" = some (Tile.bop NumericDType.real.add
              (Broadcast.consSame (Broadcast.consSame Broadcast.nil)) acc1T (Tile.dot [] pmT vtile)) := by
  set qkSeedT : Tile .real [BM, BN] :=
    Tile.bop NumericDType.real.mul Broadcast.scalarR
      (Tile.bop NumericDType.real.add (Broadcast.consSame (Broadcast.consSame Broadcast.nil))
        (⟨fun _ => some (0 : ℝ)⟩ : Tile .real [BM, BN]) (Tile.dot [] qtile ktile))
      (Tile.scalar (some sc)) with hqkSeed
  set maskT : Tile .bool [BM, BN] := ⟨fun idx : TileIndex [BM, BN] => aft3MaskCell2G SM SN off size BM BN idx⟩ with hmaskT
  set qkT : Tile .real [BM, BN] :=
    ⟨fun idx : TileIndex [BM, BN] =>
      if maskT.data idx then qkSeedT.data idx else (⊥ : WithBot ℝ)⟩ with hqkT
  obtain ⟨rmaxT, hrm⟩ : ∃ t, Tile.reduceMaxDrop (⟨1, by simp⟩ : Fin [BM, BN].length) qkT = some t :=
    ⟨_, by unfold Tile.reduceMaxDrop; rw [dif_pos (show 0 < TileShape.axisDim [BM, BN] (⟨1, by simp⟩ : Fin [BM, BN].length) from by simpa [TileShape.axisDim] using hBN)]⟩
  set mijT : Tile .real [BM] := Tile.select (Tile.cop ComparableDType.real.gt (Broadcast.consSame Broadcast.nil) mtile rmaxT) mtile rmaxT with hmij
  set alphaT : Tile .real [BM] := Tile.uop WithBot.realExp2 (Tile.bop NumericDType.real.sub (Broadcast.consSame Broadcast.nil) mtile mijT) with halpha
  set pT : Tile .real [BM, BN] := Tile.uop WithBot.realExp2 (Tile.bop NumericDType.real.sub (Broadcast.consSame (Broadcast.consR Broadcast.nil)) qkT (Tile.expandDim ⟨1, by simp⟩ mijT)) with hpT
  set pmT : Tile .real [BM, BN] := ⟨fun idx : TileIndex [BM, BN] => if maskT.data idx then pT.data idx else (some (0.0 : ℝ) : WithBot ℝ)⟩ with hpmT
  set lijT : Tile .real [BM] := Tile.reduceSumDrop (⟨1, by simp⟩ : Fin [BM, BN].length) pmT with hlij
  set acc1T : Tile .real [BM, ND] := Tile.bop NumericDType.real.mul (Broadcast.consSame (Broadcast.consR Broadcast.nil)) acctile (Tile.expandDim ⟨1, by simp⟩ alphaT) with hacc1
  unfold aft3LoopBodyG2
  -- L1: k = load K_block_ptr
  rw [stepStmts.cons_some (stepStmt_assign_eq_some
    (show evalOp (Op.load TileDType.real (MemAccess.blockPtr (Op.ref TileDType.blockPtr [ND, BN] "K_block_ptr") []) MaskOpt.none .unspecified) sin
        = some ktile from by
      rw [aft3_load_k_eval Kreg kbase ND NKV_CTX ND BN skk skn kcol (Op.ref TileDType.blockPtr [ND, BN] "K_block_ptr") sin
        (by rw [evalOp_ref]; exact hKp)]
      refine congrArg some ?_; refine Tile.ext (fun idx => ?_); rw [hkload idx]))]
  -- L2: qk = zeros
  rw [stepStmts.cons_some (stepStmt_assign_eq_some (aft3_qkzeros_eval _ BM BN))]
  -- L3: qk += dot q k
  rw [stepStmts.cons_some (stepStmt_assign_eq_some
    (aft3_qk_dot_eval _ BM BN ND (⟨fun _ => some (0 : ℝ)⟩ : Tile .real [BM, BN]) qtile ktile
      (by rw [BlockState.setReg_same])
      (by simp only [BlockState.setReg_ne_name, ne_eq, String.reduceEq, not_false_eq_true,
            BlockState.setReg_same]; exact hq)
      (by simp only [BlockState.setReg_ne_name, ne_eq, String.reduceEq, not_false_eq_true,
            BlockState.setReg_same])))]
  -- L4: qk *= qk_scale
  rw [stepStmts.cons_some (stepStmt_assign_eq_some
    (aft3_qk_scale_ref_eval _ BM BN sc
      (Tile.bop NumericDType.real.add (Broadcast.consSame (Broadcast.consSame Broadcast.nil))
        (⟨fun _ => some (0 : ℝ)⟩ : Tile .real [BM, BN]) (Tile.dot [] qtile ktile))
      (by rw [BlockState.setReg_same])
      (by simp only [BlockState.setReg_ne_name, ne_eq, String.reduceEq, not_false_eq_true]; exact hqs)))]
  -- L5: window ifThen (SLIDING_WINDOW true)
  rw [stepStmts.cons_some
    (show stepStmt _ _ = some _ from
      (aft3_ifThen_true (aft3_ne_one_zero_true _)).trans
        (aft3_window2_stepsG _ SM SN off size BM BN (by simp) (by simp) qkSeedT
          (by simp only [BlockState.setReg_ne_name, ne_eq, String.reduceEq, not_false_eq_true]; exact hsm)
          (by simp only [BlockState.setReg_ne_name, ne_eq, String.reduceEq, not_false_eq_true]; exact hsn)
          (by rw [BlockState.setReg_same])))]
  -- L6: m_ij = maximum(m_i, max(qk,1))
  rw [stepStmts.cons_some (stepStmt_assign_eq_some
    (aft3_mij_evalG _ BM BN mtile qkT rmaxT (by simp)
      (by simp only [BlockState.setReg_ne_name, ne_eq, String.reduceEq, not_false_eq_true]; exact hmi)
      (by rw [BlockState.setReg_same])
      hrm))]
  -- L7: qk -= m_ij[:, None]
  rw [stepStmts.cons_some (stepStmt_assign_eq_some
    (aft3_qk_sub_evalG _ BM BN (by simp) qkT mijT
      (by simp only [BlockState.setReg_ne_name, ne_eq, String.reduceEq, not_false_eq_true,
            BlockState.setReg_same] <;> try rfl)
      (by rw [BlockState.setReg_same])))]
  -- L8: p = exp2 qk
  rw [stepStmts.cons_some (stepStmt_assign_eq_some
    (aft3_p_evalG _ BM BN (Tile.bop NumericDType.real.sub (Broadcast.consSame (Broadcast.consR Broadcast.nil)) qkT (Tile.expandDim ⟨1, by simp⟩ mijT))
      (by rw [BlockState.setReg_same])))]
  -- L9: pmask ifThen (SLIDING_WINDOW true)
  rw [stepStmts.cons_some
    (show stepStmt _ _ = some _ from
      (aft3_ifThen_true (aft3_ne_one_zero_true _)).trans
        (aft3_pmask1_stepsG _ BM BN maskT pT
          (by simp only [BlockState.setReg_ne_name, ne_eq, String.reduceEq, not_false_eq_true,
                BlockState.setReg_same] <;> try rfl)
          (by rw [BlockState.setReg_same])))]
  -- L10: l_ij = sum p 1
  rw [stepStmts.cons_some (@stepStmt_assign_eq_some .real [BM] "l_ij"
    (Op.reduceSum (⟨1, by simp⟩ : Fin [BM, BN].length) Bool.false (Op.ref .real [BM, BN] "p")) _ lijT
    (aft3_lij_evalG _ BM BN pmT (by simp) (by rw [BlockState.setReg_same])))]
  -- L11: tmp = m_i - m_ij
  rw [stepStmts.cons_some (stepStmt_assign_eq_some
    (aft3_tmp_evalG _ BM mtile mijT
      (by simp only [BlockState.setReg_ne_name, ne_eq, String.reduceEq, not_false_eq_true]; exact hmi)
      (by simp only [BlockState.setReg_ne_name, ne_eq, String.reduceEq, not_false_eq_true,
            BlockState.setReg_same] <;> try rfl)))]
  -- L12: alpha = exp2 tmp
  rw [stepStmts.cons_some (stepStmt_assign_eq_some
    (aft3_alpha_evalG _ BM (Tile.bop NumericDType.real.sub (Broadcast.consSame Broadcast.nil) mtile mijT)
      (by rw [BlockState.setReg_same])))]
  -- L13: l_i = l_i * alpha + l_ij
  rw [stepStmts.cons_some (stepStmt_assign_eq_some
    (aft3_li_evalG _ BM ltile alphaT lijT
      (by simp only [BlockState.setReg_ne_name, ne_eq, String.reduceEq, not_false_eq_true]; exact hli)
      (by simp only [BlockState.setReg_ne_name, ne_eq, String.reduceEq, not_false_eq_true,
            BlockState.setReg_same] <;> try rfl)
      (by simp only [BlockState.setReg_ne_name, ne_eq, String.reduceEq, not_false_eq_true,
            BlockState.setReg_same] <;> try rfl)))]
  -- L14: acc = acc * alpha[:, None]
  rw [stepStmts.cons_some (stepStmt_assign_eq_some
    (aft3_acc_rescale_evalG _ BM ND (by simp) acctile alphaT
      (by simp only [BlockState.setReg_ne_name, ne_eq, String.reduceEq, not_false_eq_true]; exact hacc)
      (by simp only [BlockState.setReg_ne_name, ne_eq, String.reduceEq, not_false_eq_true,
            BlockState.setReg_same] <;> try rfl)))]
  -- L15: v = load V_block_ptr
  rw [stepStmts.cons_some (stepStmt_assign_eq_some
    (show evalOp (Op.load TileDType.real (MemAccess.blockPtr (Op.ref TileDType.blockPtr [BN, ND] "V_block_ptr") []) MaskOpt.none .unspecified) _
        = some vtile from by
      rw [aft3_load_v_eval Vreg vbase NKV_CTX ND BN ND svk svn vrow (Op.ref TileDType.blockPtr [BN, ND] "V_block_ptr") _
        (by rw [evalOp_ref]
            simp only [BlockState.setReg_ne_name, ne_eq, String.reduceEq, not_false_eq_true]
            exact hVp)]
      refine congrArg some ?_; refine Tile.ext (fun idx => ?_)
      simp only [BlockState.setReg_readMem]; rw [hvload idx]))]
  -- L16: acc += dot p v
  rw [stepStmts.cons_some (stepStmt_assign_eq_some
    (aft3_acc_eval _ BM BN ND acc1T pmT vtile
      (by simp only [BlockState.setReg_ne_name, ne_eq, String.reduceEq, not_false_eq_true,
            BlockState.setReg_same] <;> try rfl)
      (by simp only [BlockState.setReg_ne_name, ne_eq, String.reduceEq, not_false_eq_true,
            BlockState.setReg_same] <;> try rfl)
      (by rw [BlockState.setReg_same])))]
  -- L17: m_i = m_ij
  rw [stepStmts.cons_some (stepStmt_assign_eq_some
    (aft3_mi_carry_evalG _ BM mijT
      (by simp only [BlockState.setReg_ne_name, ne_eq, String.reduceEq, not_false_eq_true,
            BlockState.setReg_same] <;> try rfl)))]
  -- L18: V_block_ptr = advance [BN, 0]
  rw [stepStmts.cons_some (stepStmt_assign_eq_some
    (aft3_advance_v_eval _ Vreg vbase NKV_CTX ND BN ND svk svn vrow BN "V_block_ptr"
      (by simp only [BlockState.setReg_ne_name, ne_eq, String.reduceEq, not_false_eq_true]; exact hVp)))]
  -- L19: K_block_ptr = advance [0, BN]
  rw [stepStmts.cons_some (stepStmt_assign_eq_some
    (aft3_advance_k_eval _ Kreg kbase ND NKV_CTX ND BN skk skn kcol BN "K_block_ptr"
      (by simp only [BlockState.setReg_ne_name, ne_eq, String.reduceEq, not_false_eq_true]; exact hKp)))]
  rw [stepStmts.nil]
  refine ⟨_, rfl, ?_, ?_, ?_, ?_, ?_, ?_, ?_, ?_, ?_, ?_, ?_, qkT, rmaxT, mijT, alphaT, lijT, pT, pmT, acc1T,
    rfl, hrm, rfl, rfl, rfl, rfl, rfl, rfl, ?_, ?_, ?_⟩
  · simp only [BlockState.setReg_pids]
  · funext rg o; simp only [BlockState.setReg_mem]
  · simp only [BlockState.setReg_ne_name, ne_eq, String.reduceEq, not_false_eq_true,
      BlockState.setReg_same]; exact hq
  · simp only [BlockState.setReg_ne_name, ne_eq, String.reduceEq, not_false_eq_true,
      BlockState.setReg_same]; exact hqs
  · simp only [BlockState.setReg_ne_name, ne_eq, String.reduceEq, not_false_eq_true,
      BlockState.setReg_same]; exact hsm
  · simp only [BlockState.setReg_same]
  · simp only [BlockState.setReg_ne_name, ne_eq, String.reduceEq, not_false_eq_true,
      BlockState.setReg_same]
  · simp only [BlockState.setReg_ne_name, ne_eq, String.reduceEq, not_false_eq_true,
      BlockState.setReg_same]
  · simp only [BlockState.setReg_ne_name, ne_eq, String.reduceEq, not_false_eq_true,
      BlockState.setReg_same]
  · simp only [BlockState.setReg_ne_name, ne_eq, String.reduceEq, not_false_eq_true,
      BlockState.setReg_same]
  · simp only [BlockState.setReg_ne_name, ne_eq, String.reduceEq, not_false_eq_true,
      BlockState.setReg_same]
  · simp only [BlockState.setReg_ne_name, ne_eq, String.reduceEq, not_false_eq_true,
      BlockState.setReg_same]
  · simp only [BlockState.setReg_ne_name, ne_eq, String.reduceEq, not_false_eq_true,
      BlockState.setReg_same]
  · simp only [BlockState.setReg_ne_name, ne_eq, String.reduceEq, not_false_eq_true,
      BlockState.setReg_same]

set_option maxHeartbeats 2000000 in
/-- **Weak invariant step (case 1)**: one case-1 body iteration from
`aft3SafeInv c` steps successfully (exact stepper) and re-establishes
`aft3SafeInv (c + BN)` — the window statements only touch the value
registers (`dist`/`mask`/`qk`/`p`), never the pinned pointer shapes. -/
private theorem aft3_attn_stepW1 (K V M Out L : RegionName) (s0 : BlockState) (smsc : ℝ)
    (base BM ND NC BN skk skn svk svn som son ROUND_CTX off size : Nat)
    (hBN : 0 < BN) (hBNdvd : BN ∣ NC)
    (c : Nat) (s : BlockState) (hlt : c < NC)
    (hP : aft3SafeInv K V M Out L s0 base BM ND NC BN skk skn svk svn som son ROUND_CTX c s) :
    ∃ s', stepStmts (aft3LoopBodyG smsc off size BM ND BN)
        (s.setReg "start_n" .nat [] (Tile.scalar c)) = some s'
      ∧ aft3SafeInv K V M Out L s0 base BM ND NC BN skk skn svk svn som son ROUND_CTX (c + BN) s' := by
  obtain ⟨hmod, hle, hsm, hoff, ⟨qT, hq⟩, ⟨sc, hqs⟩, ⟨mT, hmi⟩, ⟨lT, hli⟩, ⟨aT, hacc⟩,
    hKp, hVp, hMptr, hLptr, hOp⟩ := hP
  set sin := s.setReg "start_n" .nat [] (Tile.scalar c) with hsin
  obtain ⟨sF, hstep, -, -, hq', hqs', hsm', hKp', hVp', hoff', hMptr', hLptr', hOp',
    qkTx, rmaxTx, mijTx, alphaTx, lijTx, pTx, pmTx, acc1Tx,
    -, -, -, -, -, -, -, -, hmiF, hliF, haccF⟩ :=
    aft3LoopBodyG_stepsW1 sin (s0.pids 0) c off size smsc K V base base c c
      skk skn svk svn ND NC BM BN hBN qT mT lT aT
      (⟨fun idx : TileIndex [ND, BN] =>
        some (sin.readMem K (base + idx.1.val * skk + (c + idx.2.1.val) * skn))⟩)
      (⟨fun idx : TileIndex [BN, ND] =>
        some (sin.readMem V (base + (c + idx.1.val) * svk + idx.2.1.val * svn))⟩)
      sc
      (by rw [hsin]
          simp only [BlockState.setReg_ne_name, ne_eq, String.reduceEq, not_false_eq_true]
          exact hsm)
      (by rw [hsin, BlockState.setReg_same])
      (by rw [hsin]
          simp only [BlockState.setReg_ne_name, ne_eq, String.reduceEq, not_false_eq_true]
          exact hq)
      (by rw [hsin]
          simp only [BlockState.setReg_ne_name, ne_eq, String.reduceEq, not_false_eq_true]
          exact hqs)
      (by rw [hsin]
          simp only [BlockState.setReg_ne_name, ne_eq, String.reduceEq, not_false_eq_true]
          exact hmi)
      (by rw [hsin]
          simp only [BlockState.setReg_ne_name, ne_eq, String.reduceEq, not_false_eq_true]
          exact hli)
      (by rw [hsin]
          simp only [BlockState.setReg_ne_name, ne_eq, String.reduceEq, not_false_eq_true]
          exact hacc)
      (by rw [hsin]
          simp only [BlockState.setReg_ne_name, ne_eq, String.reduceEq, not_false_eq_true]
          exact hKp)
      (by rw [hsin]
          simp only [BlockState.setReg_ne_name, ne_eq, String.reduceEq, not_false_eq_true]
          exact hVp)
      (fun idx => rfl) (fun idx => rfl)
  have hmod' : (c + BN) % BN = 0 := by rw [Nat.add_mod_right]; exact hmod
  have hle' : c + BN ≤ NC := by
    obtain ⟨k, hk⟩ := hBNdvd
    obtain ⟨m, hm⟩ := Nat.dvd_of_mod_eq_zero hmod
    subst hk hm
    have hmk : m < k := by
      by_contra hmk
      exact Nat.not_le_of_lt hlt (Nat.mul_le_mul_left BN (Nat.le_of_not_lt hmk))
    calc BN * m + BN = BN * (m + 1) := by ring
      _ ≤ BN * k := Nat.mul_le_mul_left BN hmk
  refine ⟨sF, hstep, hmod', hle', hsm', ?_, ⟨qT, hq'⟩, ⟨sc, hqs'⟩,
    ⟨mijTx, hmiF⟩, ⟨_, hliF⟩, ⟨_, haccF⟩, hKp', hVp', ?_, ?_, ?_⟩
  · rw [hoff', hsin]
    simp only [BlockState.setReg_ne_name, ne_eq, String.reduceEq, not_false_eq_true]
    exact hoff
  · rw [hMptr', hsin]
    simp only [BlockState.setReg_ne_name, ne_eq, String.reduceEq, not_false_eq_true]
    exact hMptr
  · rw [hLptr', hsin]
    simp only [BlockState.setReg_ne_name, ne_eq, String.reduceEq, not_false_eq_true]
    exact hLptr
  · rw [hOp', hsin]
    simp only [BlockState.setReg_ne_name, ne_eq, String.reduceEq, not_false_eq_true]
    exact hOp

set_option maxHeartbeats 2000000 in
/-- **Weak invariant step (case 2, complement)** — as `aft3_attn_stepW1` on
`aft3LoopBodyG2`. -/
private theorem aft3_attn_stepW2 (K V M Out L : RegionName) (s0 : BlockState) (smsc : ℝ)
    (base BM ND NC BN skk skn svk svn som son ROUND_CTX off size : Nat)
    (hBN : 0 < BN) (hBNdvd : BN ∣ NC)
    (c : Nat) (s : BlockState) (hlt : c < NC)
    (hP : aft3SafeInv K V M Out L s0 base BM ND NC BN skk skn svk svn som son ROUND_CTX c s) :
    ∃ s', stepStmts (aft3LoopBodyG2 smsc off size BM ND BN)
        (s.setReg "start_n" .nat [] (Tile.scalar c)) = some s'
      ∧ aft3SafeInv K V M Out L s0 base BM ND NC BN skk skn svk svn som son ROUND_CTX (c + BN) s' := by
  obtain ⟨hmod, hle, hsm, hoff, ⟨qT, hq⟩, ⟨sc, hqs⟩, ⟨mT, hmi⟩, ⟨lT, hli⟩, ⟨aT, hacc⟩,
    hKp, hVp, hMptr, hLptr, hOp⟩ := hP
  set sin := s.setReg "start_n" .nat [] (Tile.scalar c) with hsin
  obtain ⟨sF, hstep, -, -, hq', hqs', hsm', hKp', hVp', hoff', hMptr', hLptr', hOp',
    qkTx, rmaxTx, mijTx, alphaTx, lijTx, pTx, pmTx, acc1Tx,
    -, -, -, -, -, -, -, -, hmiF, hliF, haccF⟩ :=
    aft3LoopBodyG2_stepsW2 sin (s0.pids 0) c off size smsc K V base base c c
      skk skn svk svn ND NC BM BN hBN qT mT lT aT
      (⟨fun idx : TileIndex [ND, BN] =>
        some (sin.readMem K (base + idx.1.val * skk + (c + idx.2.1.val) * skn))⟩)
      (⟨fun idx : TileIndex [BN, ND] =>
        some (sin.readMem V (base + (c + idx.1.val) * svk + idx.2.1.val * svn))⟩)
      sc
      (by rw [hsin]
          simp only [BlockState.setReg_ne_name, ne_eq, String.reduceEq, not_false_eq_true]
          exact hsm)
      (by rw [hsin, BlockState.setReg_same])
      (by rw [hsin]
          simp only [BlockState.setReg_ne_name, ne_eq, String.reduceEq, not_false_eq_true]
          exact hq)
      (by rw [hsin]
          simp only [BlockState.setReg_ne_name, ne_eq, String.reduceEq, not_false_eq_true]
          exact hqs)
      (by rw [hsin]
          simp only [BlockState.setReg_ne_name, ne_eq, String.reduceEq, not_false_eq_true]
          exact hmi)
      (by rw [hsin]
          simp only [BlockState.setReg_ne_name, ne_eq, String.reduceEq, not_false_eq_true]
          exact hli)
      (by rw [hsin]
          simp only [BlockState.setReg_ne_name, ne_eq, String.reduceEq, not_false_eq_true]
          exact hacc)
      (by rw [hsin]
          simp only [BlockState.setReg_ne_name, ne_eq, String.reduceEq, not_false_eq_true]
          exact hKp)
      (by rw [hsin]
          simp only [BlockState.setReg_ne_name, ne_eq, String.reduceEq, not_false_eq_true]
          exact hVp)
      (fun idx => rfl) (fun idx => rfl)
  have hmod' : (c + BN) % BN = 0 := by rw [Nat.add_mod_right]; exact hmod
  have hle' : c + BN ≤ NC := by
    obtain ⟨k, hk⟩ := hBNdvd
    obtain ⟨m, hm⟩ := Nat.dvd_of_mod_eq_zero hmod
    subst hk hm
    have hmk : m < k := by
      by_contra hmk
      exact Nat.not_le_of_lt hlt (Nat.mul_le_mul_left BN (Nat.le_of_not_lt hmk))
    calc BN * m + BN = BN * (m + 1) := by ring
      _ ≤ BN * k := Nat.mul_le_mul_left BN hmk
  refine ⟨sF, hstep, hmod', hle', hsm', ?_, ⟨qT, hq'⟩, ⟨sc, hqs'⟩,
    ⟨mijTx, hmiF⟩, ⟨_, hliF⟩, ⟨_, haccF⟩, hKp', hVp', ?_, ?_, ?_⟩
  · rw [hoff', hsin]
    simp only [BlockState.setReg_ne_name, ne_eq, String.reduceEq, not_false_eq_true]
    exact hoff
  · rw [hMptr', hsin]
    simp only [BlockState.setReg_ne_name, ne_eq, String.reduceEq, not_false_eq_true]
    exact hMptr
  · rw [hLptr', hsin]
    simp only [BlockState.setReg_ne_name, ne_eq, String.reduceEq, not_false_eq_true]
    exact hLptr
  · rw [hOp', hsin]
    simp only [BlockState.setReg_ne_name, ne_eq, String.reduceEq, not_false_eq_true]
    exact hOp

set_option maxHeartbeats 4000000 in
set_option maxRecDepth 8000 in
/-- **Per-iteration `TraceSafeListR` for the case-1 body**: as the case-3 walk
(`aft3_bodySafeW`), plus the two live sliding-window `ifThen`s — whose bodies
(`dist`/`mask`/`qk`-`where`, and the `p`-`where`) are register-only, so they
impose no bounds; their successors are inverted through the constexpr `R`
mirrors. -/
private theorem aft3_bodySafeW1 (R : RoundingModel) (bounds : RegionBounds)
    (K V M Out L : RegionName) (s0 : BlockState) (smsc : ℝ)
    (base BM ND NC BN skk skn svk svn som son ROUND_CTX off size : Nat)
    (hBN : 0 < BN) (hBNdvd : BN ∣ NC)
    (c : Nat) (s : BlockState) (hc : c < NC)
    (hP : aft3SafeInv K V M Out L s0 base BM ND NC BN skk skn svk svn som son ROUND_CTX c s)
    (hbK : ∀ (t : Fin (NC / BN)) (j : Fin (ND * BN)),
      base + (j.val / BN) * skk + (t.val * BN + j.val % BN) * skn < bounds K)
    (hbV : ∀ (t : Fin (NC / BN)) (j : Fin (BN * ND)),
      base + (t.val * BN + j.val / ND) * svk + (j.val % ND) * svn < bounds V) :
    Stmt.TraceSafeListR R bounds (aft3LoopBodyG smsc off size BM ND BN)
      (s.setReg "start_n" .nat [] (Tile.scalar c)) := by
  obtain ⟨hmod, hle, hsm, hoff, ⟨qT, hq⟩, ⟨sc, hqs⟩, ⟨mT, hmi⟩, ⟨lT, hli⟩, ⟨aT, hacc⟩,
    hKp, hVp, hMptr, hLptr, hOp⟩ := hP
  have hcBN : c / BN * BN = c := Nat.div_mul_cancel (Nat.dvd_of_mod_eq_zero hmod)
  have hcdivlt : c / BN < NC / BN := by
    have h1 : c / BN * BN < NC / BN * BN := by
      rw [hcBN, Nat.div_mul_cancel hBNdvd]
      exact hc
    exact lt_of_mul_lt_mul_right h1 (Nat.zero_le BN)
  set t0 := s.setReg "start_n" .nat [] (Tile.scalar c) with ht0
  have hKp0 : t0.regs .blockPtr [ND, BN] "K_block_ptr" = some
      (⟨fun _ : TileIndex [ND, BN] =>
        { region := K, baseOffset := base, parentShape := [ND, NC], blockShape := [ND, BN],
          strides := [skk, skn], offsets := [0, c] }⟩) := by
    rw [ht0]
    simp only [BlockState.setReg_ne_name, ne_eq, String.reduceEq, not_false_eq_true]
    exact hKp
  have hVp0 : t0.regs .blockPtr [BN, ND] "V_block_ptr" = some
      (⟨fun _ : TileIndex [BN, ND] =>
        { region := V, baseOffset := base, parentShape := [NC, ND], blockShape := [BN, ND],
          strides := [svk, svn], offsets := [c, 0] }⟩) := by
    rw [ht0]
    simp only [BlockState.setReg_ne_name, ne_eq, String.reduceEq, not_false_eq_true]
    exact hVp
  unfold aft3LoopBodyG
  -- (1) k = load K_block_ptr: the per-lane K bound
  refine Stmt.TraceSafeListR.cons_intro ?_ (fun s1 h1 => ?_)
  · simp only [Stmt.TraceSafeR, Op.SafeAtR.eq_def, MaskOpt.ActiveR,
      MemAccess.ActiveAddressSafeR, memAccessActiveAddressSafeR]
    refine ⟨trivial, trivial, ?_⟩
    intro ptrs hptrs idx _
    rw [evalOpR_ref, hKp0] at hptrs
    obtain rfl := Option.some.inj hptrs
    intro _
    have hbound := hbK ⟨c / BN, hcdivlt⟩ (Lane2D.encode (idx.1, idx.2.1, PUnit.unit))
    simp only [Lane2D.encode_div, Lane2D.encode_mod] at hbound
    rw [hcBN] at hbound
    simpa using hbound
  obtain ⟨v1, -, rfl⟩ := stepStmtR_assign_inv h1
  -- (2) qk = zeros
  refine Stmt.TraceSafeListR.cons_intro
    (by simp [Stmt.TraceSafeR, Op.SafeAtR.eq_def]) (fun s2 h2 => ?_)
  obtain ⟨v2, -, rfl⟩ := stepStmtR_assign_inv h2
  -- (3) qk += dot q k
  refine Stmt.TraceSafeListR.cons_intro
    (by simp [Stmt.TraceSafeR, Op.SafeAtR.eq_def]) (fun s3 h3 => ?_)
  obtain ⟨v3, -, rfl⟩ := stepStmtR_assign_inv h3
  -- (4) qk *= qk_scale
  refine Stmt.TraceSafeListR.cons_intro
    (by simp [Stmt.TraceSafeR, Op.SafeAtR.eq_def]) (fun s4 h4 => ?_)
  obtain ⟨v4, -, rfl⟩ := stepStmtR_assign_inv h4
  -- (5) live sliding-window ifThen: register-only dist/mask/where block
  refine Stmt.TraceSafeListR.cons_intro ?_ (fun s5 h5 => ?_)
  · simp only [Stmt.TraceSafeR]
    refine ⟨by simp [Op.SafeAtR.eq_def], ?_⟩
    rw [aft3_evalOpR_ne_const, aft3_ne_one_zero_true]
    show Stmt.TraceSafeListR R bounds
      [Stmt.assign TileDType.nat [BM, BN] "dist" (Op.add NumericDType.nat Broadcast.scalarR (Op.sub NumericDType.nat Broadcast.scalarR (Op.add NumericDType.nat Broadcast.scalarR (Op.sub NumericDType.nat Broadcast.nil.consL.consR (Op.expandDim ⟨1, by simp⟩ (Op.arange BM)) (Op.expandDim ⟨0, by simp⟩ (Op.arange BN))) (Op.mul NumericDType.nat Broadcast.nil (Op.ref TileDType.nat [] "start_m") (Op.constNat BM))) (Op.ref TileDType.nat [] "start_n")) (Op.constNat off)),
       Stmt.ifThenElse (Op.ne ComparableDType.nat Broadcast.nil (Op.constNat 0) (Op.constNat 0)) [Stmt.assign TileDType.bool [BM, BN] "mask" (Op.ge ComparableDType.nat Broadcast.scalarR (Op.ref TileDType.nat [BM, BN] "dist") (Op.constNat size))] [Stmt.assign TileDType.bool [BM, BN] "mask" (Op.boolAnd Broadcast.nil.consSame.consSame (Op.ge ComparableDType.nat Broadcast.scalarR (Op.ref TileDType.nat [BM, BN] "dist") (Op.constNat 0)) (Op.lt ComparableDType.nat Broadcast.scalarR (Op.ref TileDType.nat [BM, BN] "dist") (Op.constNat size)))],
       Stmt.assign TileDType.real [BM, BN] "qk" ((Op.ref TileDType.bool [BM, BN] "mask").where (Op.ref TileDType.real [BM, BN] "qk") (Op.negInf.broadcast [BM, BN]))] _
    refine Stmt.TraceSafeListR.of_forall _ _ ?_
    intro st hst u
    simp only [List.mem_cons, List.not_mem_nil, or_false] at hst
    rcases hst with rfl | rfl | rfl
    · simp [Stmt.TraceSafeR, Op.SafeAtR]
      exact ⟨by simp [Op.SafeAtR.eq_def], by simp [Op.SafeAtR.eq_def]⟩
    · simp only [Stmt.TraceSafeR]
      refine ⟨by simp [Op.SafeAtR.eq_def], ?_⟩
      rw [aft3_evalOpR_ne_const, aft3_ne_zero_zero_false]
      show Stmt.TraceSafeListR R bounds
        [Stmt.assign TileDType.bool [BM, BN] "mask" (Op.boolAnd Broadcast.nil.consSame.consSame (Op.ge ComparableDType.nat Broadcast.scalarR (Op.ref TileDType.nat [BM, BN] "dist") (Op.constNat 0)) (Op.lt ComparableDType.nat Broadcast.scalarR (Op.ref TileDType.nat [BM, BN] "dist") (Op.constNat size)))] u
      exact Stmt.TraceSafeListR.cons_intro
        (by simp [Stmt.TraceSafeR, Op.SafeAtR])
        (fun _ _ => Stmt.TraceSafeListR.nil_intro)
    · simp [Stmt.TraceSafeR, Op.SafeAtR]
  rw [aft3_ifThen_trueR R (by rw [aft3_evalOpR_ne_const]; exact aft3_ne_one_zero_true _)] at h5
  obtain ⟨w1, hw1, h5⟩ := aft3_stepStmtsR_cons_inv h5
  obtain ⟨vd, -, rfl⟩ := stepStmtR_assign_inv hw1
  obtain ⟨w2, hw2, h5⟩ := aft3_stepStmtsR_cons_inv h5
  rw [aft3_ifThenElse_falseR R (by rw [aft3_evalOpR_ne_const]; exact aft3_ne_zero_zero_false _)] at hw2
  obtain ⟨w2a, hw2a, hw2⟩ := aft3_stepStmtsR_cons_inv hw2
  obtain ⟨vm, -, rfl⟩ := stepStmtR_assign_inv hw2a
  rw [stepStmtsR_nil] at hw2
  obtain rfl := Option.some.inj hw2
  obtain ⟨w3, hw3, h5⟩ := aft3_stepStmtsR_cons_inv h5
  obtain ⟨vqk, -, rfl⟩ := stepStmtR_assign_inv hw3
  rw [stepStmtsR_nil] at h5
  obtain rfl := Option.some.inj h5
  -- (6) m_ij
  refine Stmt.TraceSafeListR.cons_intro
    (by simp [Stmt.TraceSafeR, Op.SafeAtR.eq_def]) (fun s6 h6 => ?_)
  obtain ⟨v6, -, rfl⟩ := stepStmtR_assign_inv h6
  -- (7) qk -= m_ij[:, None]
  refine Stmt.TraceSafeListR.cons_intro
    (by simp [Stmt.TraceSafeR, Op.SafeAtR.eq_def]) (fun s7 h7 => ?_)
  obtain ⟨v7, -, rfl⟩ := stepStmtR_assign_inv h7
  -- (8) p = exp2 qk
  refine Stmt.TraceSafeListR.cons_intro
    (by simp [Stmt.TraceSafeR, Op.SafeAtR.eq_def]) (fun s8 h8 => ?_)
  obtain ⟨v8, -, rfl⟩ := stepStmtR_assign_inv h8
  -- (9) live p-mask ifThen: single register-only where
  refine Stmt.TraceSafeListR.cons_intro ?_ (fun s9 h9 => ?_)
  · simp only [Stmt.TraceSafeR]
    refine ⟨by simp [Op.SafeAtR.eq_def], ?_⟩
    rw [aft3_evalOpR_ne_const, aft3_ne_one_zero_true]
    show Stmt.TraceSafeListR R bounds
      [Stmt.assign TileDType.real [BM, BN] "p" ((Op.ref TileDType.bool [BM, BN] "mask").where (Op.ref TileDType.real [BM, BN] "p") ((Op.const 0.0).broadcast [BM, BN]))] _
    exact Stmt.TraceSafeListR.cons_intro
      (by simp [Stmt.TraceSafeR, Op.SafeAtR])
      (fun _ _ => Stmt.TraceSafeListR.nil_intro)
  rw [aft3_ifThen_trueR R (by rw [aft3_evalOpR_ne_const]; exact aft3_ne_one_zero_true _)] at h9
  obtain ⟨w9, hw9, h9⟩ := aft3_stepStmtsR_cons_inv h9
  obtain ⟨vp, -, rfl⟩ := stepStmtR_assign_inv hw9
  rw [stepStmtsR_nil] at h9
  obtain rfl := Option.some.inj h9
  -- (10) l_ij
  refine Stmt.TraceSafeListR.cons_intro
    (by simp [Stmt.TraceSafeR, Op.SafeAtR.eq_def]) (fun s10 h10 => ?_)
  obtain ⟨v10, -, rfl⟩ := stepStmtR_assign_inv h10
  -- (11) tmp
  refine Stmt.TraceSafeListR.cons_intro
    (by simp [Stmt.TraceSafeR, Op.SafeAtR.eq_def]) (fun s11 h11 => ?_)
  obtain ⟨v11, -, rfl⟩ := stepStmtR_assign_inv h11
  -- (12) alpha
  refine Stmt.TraceSafeListR.cons_intro
    (by simp [Stmt.TraceSafeR, Op.SafeAtR.eq_def]) (fun s12 h12 => ?_)
  obtain ⟨v12, -, rfl⟩ := stepStmtR_assign_inv h12
  -- (13) l_i
  refine Stmt.TraceSafeListR.cons_intro
    (by simp [Stmt.TraceSafeR, Op.SafeAtR.eq_def]) (fun s13 h13 => ?_)
  obtain ⟨v13, -, rfl⟩ := stepStmtR_assign_inv h13
  -- (14) acc = acc * alpha[:, None]
  refine Stmt.TraceSafeListR.cons_intro
    (by simp [Stmt.TraceSafeR, Op.SafeAtR.eq_def]) (fun s14 h14 => ?_)
  obtain ⟨v14, -, rfl⟩ := stepStmtR_assign_inv h14
  -- (15) v = load V_block_ptr: the per-lane V bound
  refine Stmt.TraceSafeListR.cons_intro ?_ (fun s15 h15 => ?_)
  · simp only [Stmt.TraceSafeR, Op.SafeAtR.eq_def, MaskOpt.ActiveR,
      MemAccess.ActiveAddressSafeR, memAccessActiveAddressSafeR]
    refine ⟨trivial, trivial, ?_⟩
    intro ptrs hptrs idx _
    rw [evalOpR_ref] at hptrs
    simp only [BlockState.setReg_ne_name, ne_eq, String.reduceEq, not_false_eq_true] at hptrs
    rw [hVp0] at hptrs
    obtain rfl := Option.some.inj hptrs
    intro _
    have hbound := hbV ⟨c / BN, hcdivlt⟩ (Lane2D.encode (idx.1, idx.2.1, PUnit.unit))
    simp only [Lane2D.encode_div, Lane2D.encode_mod] at hbound
    rw [hcBN] at hbound
    simpa using hbound
  obtain ⟨v15, -, rfl⟩ := stepStmtR_assign_inv h15
  -- (16) acc += dot p v
  refine Stmt.TraceSafeListR.cons_intro
    (by simp [Stmt.TraceSafeR, Op.SafeAtR.eq_def]) (fun s16 h16 => ?_)
  obtain ⟨v16, -, rfl⟩ := stepStmtR_assign_inv h16
  -- (17) m_i = m_ij
  refine Stmt.TraceSafeListR.cons_intro
    (by simp [Stmt.TraceSafeR, Op.SafeAtR.eq_def]) (fun s17 h17 => ?_)
  obtain ⟨v17, -, rfl⟩ := stepStmtR_assign_inv h17
  -- (18) V_block_ptr advance (register-only)
  refine Stmt.TraceSafeListR.cons_intro
    (by simp [Stmt.TraceSafeR, Op.SafeAtR.eq_def]) (fun s18 h18 => ?_)
  obtain ⟨v18, -, rfl⟩ := stepStmtR_assign_inv h18
  -- (19) K_block_ptr advance (register-only)
  exact Stmt.TraceSafeListR.cons_intro
    (by simp [Stmt.TraceSafeR, Op.SafeAtR.eq_def])
    (fun _ _ => Stmt.TraceSafeListR.nil_intro)

set_option maxHeartbeats 4000000 in
set_option maxRecDepth 8000 in
/-- **Per-iteration `TraceSafeListR` for the case-2 body** — as
`aft3_bodySafeW1` with the inner `COMPLEMENT` `ifThenElse` constexpr-true
(live `≥ size` mask branch). -/
private theorem aft3_bodySafeW2 (R : RoundingModel) (bounds : RegionBounds)
    (K V M Out L : RegionName) (s0 : BlockState) (smsc : ℝ)
    (base BM ND NC BN skk skn svk svn som son ROUND_CTX off size : Nat)
    (hBN : 0 < BN) (hBNdvd : BN ∣ NC)
    (c : Nat) (s : BlockState) (hc : c < NC)
    (hP : aft3SafeInv K V M Out L s0 base BM ND NC BN skk skn svk svn som son ROUND_CTX c s)
    (hbK : ∀ (t : Fin (NC / BN)) (j : Fin (ND * BN)),
      base + (j.val / BN) * skk + (t.val * BN + j.val % BN) * skn < bounds K)
    (hbV : ∀ (t : Fin (NC / BN)) (j : Fin (BN * ND)),
      base + (t.val * BN + j.val / ND) * svk + (j.val % ND) * svn < bounds V) :
    Stmt.TraceSafeListR R bounds (aft3LoopBodyG2 smsc off size BM ND BN)
      (s.setReg "start_n" .nat [] (Tile.scalar c)) := by
  obtain ⟨hmod, hle, hsm, hoff, ⟨qT, hq⟩, ⟨sc, hqs⟩, ⟨mT, hmi⟩, ⟨lT, hli⟩, ⟨aT, hacc⟩,
    hKp, hVp, hMptr, hLptr, hOp⟩ := hP
  have hcBN : c / BN * BN = c := Nat.div_mul_cancel (Nat.dvd_of_mod_eq_zero hmod)
  have hcdivlt : c / BN < NC / BN := by
    have h1 : c / BN * BN < NC / BN * BN := by
      rw [hcBN, Nat.div_mul_cancel hBNdvd]
      exact hc
    exact lt_of_mul_lt_mul_right h1 (Nat.zero_le BN)
  set t0 := s.setReg "start_n" .nat [] (Tile.scalar c) with ht0
  have hKp0 : t0.regs .blockPtr [ND, BN] "K_block_ptr" = some
      (⟨fun _ : TileIndex [ND, BN] =>
        { region := K, baseOffset := base, parentShape := [ND, NC], blockShape := [ND, BN],
          strides := [skk, skn], offsets := [0, c] }⟩) := by
    rw [ht0]
    simp only [BlockState.setReg_ne_name, ne_eq, String.reduceEq, not_false_eq_true]
    exact hKp
  have hVp0 : t0.regs .blockPtr [BN, ND] "V_block_ptr" = some
      (⟨fun _ : TileIndex [BN, ND] =>
        { region := V, baseOffset := base, parentShape := [NC, ND], blockShape := [BN, ND],
          strides := [svk, svn], offsets := [c, 0] }⟩) := by
    rw [ht0]
    simp only [BlockState.setReg_ne_name, ne_eq, String.reduceEq, not_false_eq_true]
    exact hVp
  unfold aft3LoopBodyG2
  -- (1) k = load K_block_ptr: the per-lane K bound
  refine Stmt.TraceSafeListR.cons_intro ?_ (fun s1 h1 => ?_)
  · simp only [Stmt.TraceSafeR, Op.SafeAtR.eq_def, MaskOpt.ActiveR,
      MemAccess.ActiveAddressSafeR, memAccessActiveAddressSafeR]
    refine ⟨trivial, trivial, ?_⟩
    intro ptrs hptrs idx _
    rw [evalOpR_ref, hKp0] at hptrs
    obtain rfl := Option.some.inj hptrs
    intro _
    have hbound := hbK ⟨c / BN, hcdivlt⟩ (Lane2D.encode (idx.1, idx.2.1, PUnit.unit))
    simp only [Lane2D.encode_div, Lane2D.encode_mod] at hbound
    rw [hcBN] at hbound
    simpa using hbound
  obtain ⟨v1, -, rfl⟩ := stepStmtR_assign_inv h1
  -- (2) qk = zeros
  refine Stmt.TraceSafeListR.cons_intro
    (by simp [Stmt.TraceSafeR, Op.SafeAtR.eq_def]) (fun s2 h2 => ?_)
  obtain ⟨v2, -, rfl⟩ := stepStmtR_assign_inv h2
  -- (3) qk += dot q k
  refine Stmt.TraceSafeListR.cons_intro
    (by simp [Stmt.TraceSafeR, Op.SafeAtR.eq_def]) (fun s3 h3 => ?_)
  obtain ⟨v3, -, rfl⟩ := stepStmtR_assign_inv h3
  -- (4) qk *= qk_scale
  refine Stmt.TraceSafeListR.cons_intro
    (by simp [Stmt.TraceSafeR, Op.SafeAtR.eq_def]) (fun s4 h4 => ?_)
  obtain ⟨v4, -, rfl⟩ := stepStmtR_assign_inv h4
  -- (5) live sliding-window ifThen: register-only dist/mask/where block
  refine Stmt.TraceSafeListR.cons_intro ?_ (fun s5 h5 => ?_)
  · simp only [Stmt.TraceSafeR]
    refine ⟨by simp [Op.SafeAtR.eq_def], ?_⟩
    rw [aft3_evalOpR_ne_const, aft3_ne_one_zero_true]
    show Stmt.TraceSafeListR R bounds
      [Stmt.assign TileDType.nat [BM, BN] "dist" (Op.add NumericDType.nat Broadcast.scalarR (Op.sub NumericDType.nat Broadcast.scalarR (Op.add NumericDType.nat Broadcast.scalarR (Op.sub NumericDType.nat Broadcast.nil.consL.consR (Op.expandDim ⟨1, by simp⟩ (Op.arange BM)) (Op.expandDim ⟨0, by simp⟩ (Op.arange BN))) (Op.mul NumericDType.nat Broadcast.nil (Op.ref TileDType.nat [] "start_m") (Op.constNat BM))) (Op.ref TileDType.nat [] "start_n")) (Op.constNat off)),
       Stmt.ifThenElse (Op.ne ComparableDType.nat Broadcast.nil (Op.constNat 1) (Op.constNat 0)) [Stmt.assign TileDType.bool [BM, BN] "mask" (Op.ge ComparableDType.nat Broadcast.scalarR (Op.ref TileDType.nat [BM, BN] "dist") (Op.constNat size))] [Stmt.assign TileDType.bool [BM, BN] "mask" (Op.boolAnd Broadcast.nil.consSame.consSame (Op.ge ComparableDType.nat Broadcast.scalarR (Op.ref TileDType.nat [BM, BN] "dist") (Op.constNat 0)) (Op.lt ComparableDType.nat Broadcast.scalarR (Op.ref TileDType.nat [BM, BN] "dist") (Op.constNat size)))],
       Stmt.assign TileDType.real [BM, BN] "qk" ((Op.ref TileDType.bool [BM, BN] "mask").where (Op.ref TileDType.real [BM, BN] "qk") (Op.negInf.broadcast [BM, BN]))] _
    refine Stmt.TraceSafeListR.of_forall _ _ ?_
    intro st hst u
    simp only [List.mem_cons, List.not_mem_nil, or_false] at hst
    rcases hst with rfl | rfl | rfl
    · simp [Stmt.TraceSafeR, Op.SafeAtR]
      exact ⟨by simp [Op.SafeAtR.eq_def], by simp [Op.SafeAtR.eq_def]⟩
    · simp only [Stmt.TraceSafeR]
      refine ⟨by simp [Op.SafeAtR.eq_def], ?_⟩
      rw [aft3_evalOpR_ne_const, aft3_ne_one_zero_true]
      show Stmt.TraceSafeListR R bounds
        [Stmt.assign TileDType.bool [BM, BN] "mask" (Op.ge ComparableDType.nat Broadcast.scalarR (Op.ref TileDType.nat [BM, BN] "dist") (Op.constNat size))] u
      exact Stmt.TraceSafeListR.cons_intro
        (by simp [Stmt.TraceSafeR, Op.SafeAtR])
        (fun _ _ => Stmt.TraceSafeListR.nil_intro)
    · simp [Stmt.TraceSafeR, Op.SafeAtR]
  rw [aft3_ifThen_trueR R (by rw [aft3_evalOpR_ne_const]; exact aft3_ne_one_zero_true _)] at h5
  obtain ⟨w1, hw1, h5⟩ := aft3_stepStmtsR_cons_inv h5
  obtain ⟨vd, -, rfl⟩ := stepStmtR_assign_inv hw1
  obtain ⟨w2, hw2, h5⟩ := aft3_stepStmtsR_cons_inv h5
  rw [aft3_ifThenElse_trueR R (by rw [aft3_evalOpR_ne_const]; exact aft3_ne_one_zero_true _)] at hw2
  obtain ⟨w2a, hw2a, hw2⟩ := aft3_stepStmtsR_cons_inv hw2
  obtain ⟨vm, -, rfl⟩ := stepStmtR_assign_inv hw2a
  rw [stepStmtsR_nil] at hw2
  obtain rfl := Option.some.inj hw2
  obtain ⟨w3, hw3, h5⟩ := aft3_stepStmtsR_cons_inv h5
  obtain ⟨vqk, -, rfl⟩ := stepStmtR_assign_inv hw3
  rw [stepStmtsR_nil] at h5
  obtain rfl := Option.some.inj h5
  -- (6) m_ij
  refine Stmt.TraceSafeListR.cons_intro
    (by simp [Stmt.TraceSafeR, Op.SafeAtR.eq_def]) (fun s6 h6 => ?_)
  obtain ⟨v6, -, rfl⟩ := stepStmtR_assign_inv h6
  -- (7) qk -= m_ij[:, None]
  refine Stmt.TraceSafeListR.cons_intro
    (by simp [Stmt.TraceSafeR, Op.SafeAtR.eq_def]) (fun s7 h7 => ?_)
  obtain ⟨v7, -, rfl⟩ := stepStmtR_assign_inv h7
  -- (8) p = exp2 qk
  refine Stmt.TraceSafeListR.cons_intro
    (by simp [Stmt.TraceSafeR, Op.SafeAtR.eq_def]) (fun s8 h8 => ?_)
  obtain ⟨v8, -, rfl⟩ := stepStmtR_assign_inv h8
  -- (9) live p-mask ifThen: single register-only where
  refine Stmt.TraceSafeListR.cons_intro ?_ (fun s9 h9 => ?_)
  · simp only [Stmt.TraceSafeR]
    refine ⟨by simp [Op.SafeAtR.eq_def], ?_⟩
    rw [aft3_evalOpR_ne_const, aft3_ne_one_zero_true]
    show Stmt.TraceSafeListR R bounds
      [Stmt.assign TileDType.real [BM, BN] "p" ((Op.ref TileDType.bool [BM, BN] "mask").where (Op.ref TileDType.real [BM, BN] "p") ((Op.const 0.0).broadcast [BM, BN]))] _
    exact Stmt.TraceSafeListR.cons_intro
      (by simp [Stmt.TraceSafeR, Op.SafeAtR])
      (fun _ _ => Stmt.TraceSafeListR.nil_intro)
  rw [aft3_ifThen_trueR R (by rw [aft3_evalOpR_ne_const]; exact aft3_ne_one_zero_true _)] at h9
  obtain ⟨w9, hw9, h9⟩ := aft3_stepStmtsR_cons_inv h9
  obtain ⟨vp, -, rfl⟩ := stepStmtR_assign_inv hw9
  rw [stepStmtsR_nil] at h9
  obtain rfl := Option.some.inj h9
  -- (10) l_ij
  refine Stmt.TraceSafeListR.cons_intro
    (by simp [Stmt.TraceSafeR, Op.SafeAtR.eq_def]) (fun s10 h10 => ?_)
  obtain ⟨v10, -, rfl⟩ := stepStmtR_assign_inv h10
  -- (11) tmp
  refine Stmt.TraceSafeListR.cons_intro
    (by simp [Stmt.TraceSafeR, Op.SafeAtR.eq_def]) (fun s11 h11 => ?_)
  obtain ⟨v11, -, rfl⟩ := stepStmtR_assign_inv h11
  -- (12) alpha
  refine Stmt.TraceSafeListR.cons_intro
    (by simp [Stmt.TraceSafeR, Op.SafeAtR.eq_def]) (fun s12 h12 => ?_)
  obtain ⟨v12, -, rfl⟩ := stepStmtR_assign_inv h12
  -- (13) l_i
  refine Stmt.TraceSafeListR.cons_intro
    (by simp [Stmt.TraceSafeR, Op.SafeAtR.eq_def]) (fun s13 h13 => ?_)
  obtain ⟨v13, -, rfl⟩ := stepStmtR_assign_inv h13
  -- (14) acc = acc * alpha[:, None]
  refine Stmt.TraceSafeListR.cons_intro
    (by simp [Stmt.TraceSafeR, Op.SafeAtR.eq_def]) (fun s14 h14 => ?_)
  obtain ⟨v14, -, rfl⟩ := stepStmtR_assign_inv h14
  -- (15) v = load V_block_ptr: the per-lane V bound
  refine Stmt.TraceSafeListR.cons_intro ?_ (fun s15 h15 => ?_)
  · simp only [Stmt.TraceSafeR, Op.SafeAtR.eq_def, MaskOpt.ActiveR,
      MemAccess.ActiveAddressSafeR, memAccessActiveAddressSafeR]
    refine ⟨trivial, trivial, ?_⟩
    intro ptrs hptrs idx _
    rw [evalOpR_ref] at hptrs
    simp only [BlockState.setReg_ne_name, ne_eq, String.reduceEq, not_false_eq_true] at hptrs
    rw [hVp0] at hptrs
    obtain rfl := Option.some.inj hptrs
    intro _
    have hbound := hbV ⟨c / BN, hcdivlt⟩ (Lane2D.encode (idx.1, idx.2.1, PUnit.unit))
    simp only [Lane2D.encode_div, Lane2D.encode_mod] at hbound
    rw [hcBN] at hbound
    simpa using hbound
  obtain ⟨v15, -, rfl⟩ := stepStmtR_assign_inv h15
  -- (16) acc += dot p v
  refine Stmt.TraceSafeListR.cons_intro
    (by simp [Stmt.TraceSafeR, Op.SafeAtR.eq_def]) (fun s16 h16 => ?_)
  obtain ⟨v16, -, rfl⟩ := stepStmtR_assign_inv h16
  -- (17) m_i = m_ij
  refine Stmt.TraceSafeListR.cons_intro
    (by simp [Stmt.TraceSafeR, Op.SafeAtR.eq_def]) (fun s17 h17 => ?_)
  obtain ⟨v17, -, rfl⟩ := stepStmtR_assign_inv h17
  -- (18) V_block_ptr advance (register-only)
  refine Stmt.TraceSafeListR.cons_intro
    (by simp [Stmt.TraceSafeR, Op.SafeAtR.eq_def]) (fun s18 h18 => ?_)
  obtain ⟨v18, -, rfl⟩ := stepStmtR_assign_inv h18
  -- (19) K_block_ptr advance (register-only)
  exact Stmt.TraceSafeListR.cons_intro
    (by simp [Stmt.TraceSafeR, Op.SafeAtR.eq_def])
    (fun _ _ => Stmt.TraceSafeListR.nil_intro)

set_option maxHeartbeats 8000000 in
set_option maxRecDepth 8000 in
/-- **The `TraceSafeR` walk for the whole case-1 kernel** — the case-3 walk
(`aft3_traceSafeR_case3`) re-run over the sliding-window loop body
(`aft3_bodySafeW1` / `aft3_attn_stepW1`); the preLoop and postLoop segments
are shared verbatim. -/
private theorem aft3_traceSafeR_case1 (R : RoundingModel) (bounds : RegionBounds)
    (Q K V M Out L : RegionName) (sm_scale : ℝ)
    (sqz sqh sqm sqk skz skh skn skk svz svh svk svn soz soh som son
      Z H H_KV N_CTX ROUND_CTX NKV_CTX off size BM ND BN : Nat) (s : BlockState)
    (hH : 0 < H) (hHKV : H_KV = H)
    (hskz : skz = sqz) (hskh : skh = sqh) (hsvz : svz = sqz) (hsvh : svh = sqh)
    (hsoz : soz = sqz) (hsoh : soh = sqh)
    (hBN : 0 < BN) (hNC : 0 < NKV_CTX) (hBNdvd : BN ∣ NKV_CTX)
    (hbQ : ∀ (t : Fin (NKV_CTX / BN)) (j : Fin (BM * ND)),
      (s.pids 1 / H * sqz + s.pids 1 % H * sqh) + (s.pids 0 * BM + j.val / ND) * sqm + (j.val % ND) * sqk < bounds Q)
    (hbK : ∀ (t : Fin (NKV_CTX / BN)) (j : Fin (ND * BN)),
      (s.pids 1 / H * sqz + s.pids 1 % H * sqh) + (j.val / BN) * skk + (t.val * BN + j.val % BN) * skn < bounds K)
    (hbV : ∀ (t : Fin (NKV_CTX / BN)) (j : Fin (BN * ND)),
      (s.pids 1 / H * sqz + s.pids 1 % H * sqh) + (t.val * BN + j.val / ND) * svk + (j.val % ND) * svn < bounds V)
    (hbO : ∀ j : Fin (BM * ND),
      (s.pids 1 / H * sqz + s.pids 1 % H * sqh) + (s.pids 0 * BM + j.val / ND) * som + (j.val % ND) * son < bounds Out)
    (hbM : ∀ j : Fin BM, s.pids 1 * ROUND_CTX + (s.pids 0 * BM + j.val) < bounds M) :
    ((attention_fwd_triton3_surface Q K V M Out L sm_scale
      sqz sqh sqm sqk skz skh skn skk svz svh svk svn soz soh som son
      Z H H_KV N_CTX ROUND_CTX NKV_CTX off size 1 1 BM ND BN 1 1 1 0).toAlgKernel).TraceSafeR R bounds s := by
  have hT : 0 < NKV_CTX / BN := Nat.div_pos (Nat.le_of_dvd hNC hBNdvd) hBN
  unfold Kernel.TraceSafeR
  rw [aft3_body_splitG]
  refine Stmt.TraceSafeListR.append_intro _ _ ?_ ?_
  · -- the preLoop
    obtain ⟨s11, h11, hpids, hmem, huf, hstart, hoffhz, hQp, hKp, hVp, hOp, hMptr, hLptr⟩ :=
      aft3PreLoopScalarsG_eval Q K V M Out L sm_scale sqz sqh sqm sqk skz skh skn skk svz svh svk svn soz soh som son H H_KV N_CTX ROUND_CTX NKV_CTX off size BM ND BN s hH hHKV hskz hskh hsvz hsvh hsoz hsoh
    rw [show aft3PreLoopG Q K V M Out L sm_scale sqz sqh sqm sqk skz skh skn skk svz svh svk svn soz soh som son H H_KV N_CTX ROUND_CTX NKV_CTX off size BM ND BN
        = aft3PreLoopScalarsG Q K V M Out L sm_scale sqz sqh sqm sqk skz skh skn skk svz svh svk svn soz soh som son H H_KV N_CTX ROUND_CTX NKV_CTX off size BM ND BN ++ (aft3PreLoopG Q K V M Out L sm_scale sqz sqh sqm sqk skz skh skn skk svz svh svk svn soz soh som son H H_KV N_CTX ROUND_CTX NKV_CTX off size BM ND BN).drop 16 from by
      rw [aft3PreLoopScalarsG]; rw [List.take_append_drop]]
    refine Stmt.TraceSafeListR.append_intro _ _ ?_ ?_
    · -- statements 0–15: register-only assigns, safe at every state
      refine Stmt.TraceSafeListR.of_forall _ _ ?_
      intro st hst u
      simp only [aft3PreLoopScalarsG, aft3PreLoopG, List.take_succ_cons, List.take_zero,
        List.mem_cons, List.not_mem_nil, or_false] at hst
      rcases hst with rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl |
        rfl | rfl | rfl | rfl <;>
        simp [Stmt.TraceSafeR, Op.SafeAtR]
    · intro s1 hs1
      rw [aft3PreLoopScalarsG_castFree R Q K V M Out L sm_scale sqz sqh sqm sqk skz skh skn skk svz svh svk svn soz soh som son H H_KV N_CTX ROUND_CTX NKV_CTX off size BM ND BN s, h11] at hs1
      obtain rfl := Option.some.inj hs1
      rw [show (aft3PreLoopG Q K V M Out L sm_scale sqz sqh sqm sqk skz skh skn skk svz svh svk svn soz soh som son H H_KV N_CTX ROUND_CTX NKV_CTX off size BM ND BN).drop 16
          = [ Stmt.ifThenElse (Op.ne ComparableDType.nat Broadcast.nil (Op.constNat 1) (Op.constNat 0)) [Stmt.assign TileDType.real [BM] "m_i" ((Op.add NumericDType.real Broadcast.scalarR (Op.full [BM] (Op.const 0)) Op.negInf)), Stmt.assign TileDType.real [BM] "l_i" ((Op.add NumericDType.real Broadcast.scalarR (Op.full [BM] (Op.const 0)) (Op.const 1.0))), Stmt.assign TileDType.real [BM, ND] "acc" (Op.full [BM, ND] (Op.const 0))] [Stmt.assign TileDType.real [BM] "m_i" (Op.load TileDType.real (MemAccess.ptr (Op.ref TileDType.ptr [BM] "m_ptrs")) MaskOpt.none), Stmt.assign TileDType.real [BM] "l_i" (Op.load TileDType.real (MemAccess.ptr (Op.ref TileDType.ptr [BM] "l_ptrs")) MaskOpt.none), Stmt.assign TileDType.real [BM, ND] "acc" (Op.load TileDType.real (MemAccess.blockPtr (Op.ref TileDType.blockPtr [BM, ND] "O_block_ptr") []) MaskOpt.none .unspecified)],
              Stmt.assign TileDType.real [] "qk_scale" (Op.mul NumericDType.real Broadcast.nil (Op.const sm_scale) (Op.const 1.0)),
              Stmt.assign TileDType.real [] "qk_scale" (Op.mul NumericDType.real Broadcast.nil (Op.ref TileDType.real [] "qk_scale") (Op.const 1.4426950408889634)),
              Stmt.ifThenElse (Op.ne ComparableDType.nat Broadcast.nil (Op.constNat 1) (Op.constNat 0)) [Stmt.assign TileDType.real [BM, ND] "q" (Op.load TileDType.real (MemAccess.blockPtr (Op.ref TileDType.blockPtr [BM, ND] "Q_block_ptr") []) MaskOpt.none .unspecified)] [Stmt.assign TileDType.real [BM, ND] "q" (Op.load TileDType.real (MemAccess.blockPtr (Op.ref TileDType.blockPtr [BM, ND] "Q_block_ptr") [0, 1]) MaskOpt.none)] ] from by rfl]
      -- the INIT ifThenElse: register-only live branch
      refine Stmt.TraceSafeListR.cons_intro ?_ (fun u1 hu1 => ?_)
      · simp only [Stmt.TraceSafeR]
        refine ⟨by simp [Op.SafeAtR.eq_def], ?_⟩
        rw [aft3_evalOpR_ne_const, aft3_ne_one_zero_true]
        show Stmt.TraceSafeListR R bounds
          [Stmt.assign TileDType.real [BM] "m_i" ((Op.add NumericDType.real Broadcast.scalarR (Op.full [BM] (Op.const 0)) Op.negInf)),
           Stmt.assign TileDType.real [BM] "l_i" ((Op.add NumericDType.real Broadcast.scalarR (Op.full [BM] (Op.const 0)) (Op.const 1.0))),
           Stmt.assign TileDType.real [BM, ND] "acc" (Op.full [BM, ND] (Op.const 0))] s11
        refine Stmt.TraceSafeListR.of_forall _ _ ?_
        intro st hst u
        simp only [List.mem_cons, List.not_mem_nil, or_false] at hst
        rcases hst with rfl | rfl | rfl <;> simp [Stmt.TraceSafeR, Op.SafeAtR.eq_def]
      rw [aft3_ifThenElse_trueR R (by rw [aft3_evalOpR_ne_const]; exact aft3_ne_one_zero_true _)] at hu1
      obtain ⟨w1, hw1, hu1⟩ := aft3_stepStmtsR_cons_inv hu1
      obtain ⟨va, -, rfl⟩ := stepStmtR_assign_inv hw1
      obtain ⟨w2, hw2, hu1⟩ := aft3_stepStmtsR_cons_inv hu1
      obtain ⟨vb, -, rfl⟩ := stepStmtR_assign_inv hw2
      obtain ⟨w3, hw3, hu1⟩ := aft3_stepStmtsR_cons_inv hu1
      obtain ⟨vc, -, rfl⟩ := stepStmtR_assign_inv hw3
      rw [stepStmtsR_nil] at hu1
      obtain rfl := Option.some.inj hu1
      -- qk_scale ×2 (register-only)
      refine Stmt.TraceSafeListR.cons_intro
        (by simp [Stmt.TraceSafeR, Op.SafeAtR.eq_def]) (fun u2 hu2 => ?_)
      obtain ⟨vd, -, rfl⟩ := stepStmtR_assign_inv hu2
      refine Stmt.TraceSafeListR.cons_intro
        (by simp [Stmt.TraceSafeR, Op.SafeAtR.eq_def]) (fun u3 hu3 => ?_)
      obtain ⟨ve, -, rfl⟩ := stepStmtR_assign_inv hu3
      -- the IS_EVEN_M ifThenElse: the live `Q_block_ptr` load (`read1` bound)
      refine Stmt.TraceSafeListR.cons_intro ?_ (fun _ _ => Stmt.TraceSafeListR.nil_intro)
      simp only [Stmt.TraceSafeR]
      refine ⟨by simp [Op.SafeAtR.eq_def], ?_⟩
      rw [aft3_evalOpR_ne_const, aft3_ne_one_zero_true]
      show Stmt.TraceSafeListR R bounds
        [Stmt.assign TileDType.real [BM, ND] "q" (Op.load TileDType.real (MemAccess.blockPtr (Op.ref TileDType.blockPtr [BM, ND] "Q_block_ptr") []) MaskOpt.none .unspecified)] _
      refine Stmt.TraceSafeListR.cons_intro ?_ (fun _ _ => Stmt.TraceSafeListR.nil_intro)
      simp only [Stmt.TraceSafeR, Op.SafeAtR.eq_def, MaskOpt.ActiveR,
        MemAccess.ActiveAddressSafeR, memAccessActiveAddressSafeR]
      refine ⟨trivial, trivial, ?_⟩
      intro ptrs hptrs idx _
      rw [evalOpR_ref] at hptrs
      simp only [BlockState.setReg_ne_name, ne_eq, String.reduceEq, not_false_eq_true] at hptrs
      rw [hQp] at hptrs
      obtain rfl := Option.some.inj hptrs
      intro _
      have hbound := hbQ ⟨0, hT⟩ (Lane2D.encode (idx.1, idx.2.1, PUnit.unit))
      simp only [Lane2D.encode_div, Lane2D.encode_mod] at hbound
      simpa using hbound

  · -- after the preLoop: the KV loop, then the postLoop
    intro s2 hs2
    obtain ⟨spW, hpreW, hinv0⟩ :=
      aft3PreLoop_evalW Q K V M Out L sm_scale sqz sqh sqm sqk skz skh skn skk svz svh svk svn soz soh som son H H_KV N_CTX ROUND_CTX NKV_CTX off size BM ND BN s hH hHKV hskz hskh hsvz hsvh hsoz hsoh
    rw [aft3PreLoopG_castFree R Q K V M Out L sm_scale sqz sqh sqm sqk skz skh skn skk svz svh svk svn soz soh som son H H_KV N_CTX ROUND_CTX NKV_CTX off size BM ND BN s, hpreW] at hs2
    obtain rfl := Option.some.inj hs2
    refine Stmt.TraceSafeListR.cons_intro ?_ (fun s3 hs3 => ?_)
    · -- the KV loop is trace-safe (invariant principle over `aft3SafeInv`)
      simp only [Stmt.TraceSafeR]
      refine Stmt.forRangeTraceSafeR_inv R bounds "start_n" NKV_CTX BN
        (aft3LoopBodyG sm_scale off size BM ND BN)
        (aft3SafeInv K V M Out L s (s.pids 1 / H * sqz + s.pids 1 % H * sqh) BM ND NKV_CTX BN skk skn svk svn som son ROUND_CTX) ?_ 0 spW hinv0
      intro c st hc hP
      refine ⟨aft3_bodySafeW1 R bounds K V M Out L s sm_scale (s.pids 1 / H * sqz + s.pids 1 % H * sqh) BM ND NKV_CTX BN skk skn svk svn som son ROUND_CTX off size hBN hBNdvd c st hc hP hbK hbV, ?_⟩
      obtain ⟨st', hstep, hP'⟩ :=
        aft3_attn_stepW1 K V M Out L s sm_scale (s.pids 1 / H * sqz + s.pids 1 % H * sqh) BM ND NKV_CTX BN skk skn svk svn som son ROUND_CTX off size hBN hBNdvd c st hc hP
      exact ⟨st', by rw [aft3LoopBodyG_castFree]; exact hstep, hP'⟩
    · -- identify the post-loop state and finish on the postLoop stores
      obtain ⟨final, sfin, hLoop, hfinal, hPfin⟩ :=
        forRange_inv (idx := "start_n") (start := 0) (stop := NKV_CTX) (step := BN)
          (body := aft3LoopBodyG sm_scale off size BM ND BN)
          (P := aft3SafeInv K V M Out L s (s.pids 1 / H * sqz + s.pids 1 % H * sqh) BM ND NKV_CTX BN skk skn svk svn som son ROUND_CTX)
          (s_init := spW) hBN.ne' hinv0
          (fun c st hc hP =>
            aft3_attn_stepW1 K V M Out L s sm_scale (s.pids 1 / H * sqz + s.pids 1 % H * sqh) BM ND NKV_CTX BN skk skn svk svn som son ROUND_CTX off size hBN hBNdvd c st hc hP)
      rw [show stepStmtR R (Stmt.forRange "start_n" 0 NKV_CTX BN (aft3LoopBodyG sm_scale off size BM ND BN)) spW = some sfin from by
        rw [stepStmtR_forRange,
          stepForRangeAuxR_castFree R _ (aft3LoopBodyG_castFree R sm_scale off size BM ND BN) "start_n",
          ← stepForRangeAux.forRange_unfold]
        exact hLoop] at hs3
      obtain rfl := Option.some.inj hs3
      exact aft3_postSafeW R bounds K V M Out L s (s.pids 1 / H * sqz + s.pids 1 % H * sqh) BM ND NKV_CTX BN skk skn svk svn som son ROUND_CTX final sfin hPfin hbO hbM

set_option maxHeartbeats 8000000 in
set_option maxRecDepth 8000 in
/-- **The `TraceSafeR` walk for the whole case-2 kernel** (complement window;
`aft3_bodySafeW2` / `aft3_attn_stepW2`). -/
private theorem aft3_traceSafeR_case2 (R : RoundingModel) (bounds : RegionBounds)
    (Q K V M Out L : RegionName) (sm_scale : ℝ)
    (sqz sqh sqm sqk skz skh skn skk svz svh svk svn soz soh som son
      Z H H_KV N_CTX ROUND_CTX NKV_CTX off size BM ND BN : Nat) (s : BlockState)
    (hH : 0 < H) (hHKV : H_KV = H)
    (hskz : skz = sqz) (hskh : skh = sqh) (hsvz : svz = sqz) (hsvh : svh = sqh)
    (hsoz : soz = sqz) (hsoh : soh = sqh)
    (hBN : 0 < BN) (hNC : 0 < NKV_CTX) (hBNdvd : BN ∣ NKV_CTX)
    (hbQ : ∀ (t : Fin (NKV_CTX / BN)) (j : Fin (BM * ND)),
      (s.pids 1 / H * sqz + s.pids 1 % H * sqh) + (s.pids 0 * BM + j.val / ND) * sqm + (j.val % ND) * sqk < bounds Q)
    (hbK : ∀ (t : Fin (NKV_CTX / BN)) (j : Fin (ND * BN)),
      (s.pids 1 / H * sqz + s.pids 1 % H * sqh) + (j.val / BN) * skk + (t.val * BN + j.val % BN) * skn < bounds K)
    (hbV : ∀ (t : Fin (NKV_CTX / BN)) (j : Fin (BN * ND)),
      (s.pids 1 / H * sqz + s.pids 1 % H * sqh) + (t.val * BN + j.val / ND) * svk + (j.val % ND) * svn < bounds V)
    (hbO : ∀ j : Fin (BM * ND),
      (s.pids 1 / H * sqz + s.pids 1 % H * sqh) + (s.pids 0 * BM + j.val / ND) * som + (j.val % ND) * son < bounds Out)
    (hbM : ∀ j : Fin BM, s.pids 1 * ROUND_CTX + (s.pids 0 * BM + j.val) < bounds M) :
    ((attention_fwd_triton3_surface Q K V M Out L sm_scale
      sqz sqh sqm sqk skz skh skn skk svz svh svk svn soz soh som son
      Z H H_KV N_CTX ROUND_CTX NKV_CTX off size 1 1 BM ND BN 1 1 1 1).toAlgKernel).TraceSafeR R bounds s := by
  have hT : 0 < NKV_CTX / BN := Nat.div_pos (Nat.le_of_dvd hNC hBNdvd) hBN
  unfold Kernel.TraceSafeR
  rw [aft3_body_splitG2]
  refine Stmt.TraceSafeListR.append_intro _ _ ?_ ?_
  · -- the preLoop
    obtain ⟨s11, h11, hpids, hmem, huf, hstart, hoffhz, hQp, hKp, hVp, hOp, hMptr, hLptr⟩ :=
      aft3PreLoopScalarsG_eval Q K V M Out L sm_scale sqz sqh sqm sqk skz skh skn skk svz svh svk svn soz soh som son H H_KV N_CTX ROUND_CTX NKV_CTX off size BM ND BN s hH hHKV hskz hskh hsvz hsvh hsoz hsoh
    rw [show aft3PreLoopG Q K V M Out L sm_scale sqz sqh sqm sqk skz skh skn skk svz svh svk svn soz soh som son H H_KV N_CTX ROUND_CTX NKV_CTX off size BM ND BN
        = aft3PreLoopScalarsG Q K V M Out L sm_scale sqz sqh sqm sqk skz skh skn skk svz svh svk svn soz soh som son H H_KV N_CTX ROUND_CTX NKV_CTX off size BM ND BN ++ (aft3PreLoopG Q K V M Out L sm_scale sqz sqh sqm sqk skz skh skn skk svz svh svk svn soz soh som son H H_KV N_CTX ROUND_CTX NKV_CTX off size BM ND BN).drop 16 from by
      rw [aft3PreLoopScalarsG]; rw [List.take_append_drop]]
    refine Stmt.TraceSafeListR.append_intro _ _ ?_ ?_
    · -- statements 0–15: register-only assigns, safe at every state
      refine Stmt.TraceSafeListR.of_forall _ _ ?_
      intro st hst u
      simp only [aft3PreLoopScalarsG, aft3PreLoopG, List.take_succ_cons, List.take_zero,
        List.mem_cons, List.not_mem_nil, or_false] at hst
      rcases hst with rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl |
        rfl | rfl | rfl | rfl <;>
        simp [Stmt.TraceSafeR, Op.SafeAtR]
    · intro s1 hs1
      rw [aft3PreLoopScalarsG_castFree R Q K V M Out L sm_scale sqz sqh sqm sqk skz skh skn skk svz svh svk svn soz soh som son H H_KV N_CTX ROUND_CTX NKV_CTX off size BM ND BN s, h11] at hs1
      obtain rfl := Option.some.inj hs1
      rw [show (aft3PreLoopG Q K V M Out L sm_scale sqz sqh sqm sqk skz skh skn skk svz svh svk svn soz soh som son H H_KV N_CTX ROUND_CTX NKV_CTX off size BM ND BN).drop 16
          = [ Stmt.ifThenElse (Op.ne ComparableDType.nat Broadcast.nil (Op.constNat 1) (Op.constNat 0)) [Stmt.assign TileDType.real [BM] "m_i" ((Op.add NumericDType.real Broadcast.scalarR (Op.full [BM] (Op.const 0)) Op.negInf)), Stmt.assign TileDType.real [BM] "l_i" ((Op.add NumericDType.real Broadcast.scalarR (Op.full [BM] (Op.const 0)) (Op.const 1.0))), Stmt.assign TileDType.real [BM, ND] "acc" (Op.full [BM, ND] (Op.const 0))] [Stmt.assign TileDType.real [BM] "m_i" (Op.load TileDType.real (MemAccess.ptr (Op.ref TileDType.ptr [BM] "m_ptrs")) MaskOpt.none), Stmt.assign TileDType.real [BM] "l_i" (Op.load TileDType.real (MemAccess.ptr (Op.ref TileDType.ptr [BM] "l_ptrs")) MaskOpt.none), Stmt.assign TileDType.real [BM, ND] "acc" (Op.load TileDType.real (MemAccess.blockPtr (Op.ref TileDType.blockPtr [BM, ND] "O_block_ptr") []) MaskOpt.none .unspecified)],
              Stmt.assign TileDType.real [] "qk_scale" (Op.mul NumericDType.real Broadcast.nil (Op.const sm_scale) (Op.const 1.0)),
              Stmt.assign TileDType.real [] "qk_scale" (Op.mul NumericDType.real Broadcast.nil (Op.ref TileDType.real [] "qk_scale") (Op.const 1.4426950408889634)),
              Stmt.ifThenElse (Op.ne ComparableDType.nat Broadcast.nil (Op.constNat 1) (Op.constNat 0)) [Stmt.assign TileDType.real [BM, ND] "q" (Op.load TileDType.real (MemAccess.blockPtr (Op.ref TileDType.blockPtr [BM, ND] "Q_block_ptr") []) MaskOpt.none .unspecified)] [Stmt.assign TileDType.real [BM, ND] "q" (Op.load TileDType.real (MemAccess.blockPtr (Op.ref TileDType.blockPtr [BM, ND] "Q_block_ptr") [0, 1]) MaskOpt.none)] ] from by rfl]
      -- the INIT ifThenElse: register-only live branch
      refine Stmt.TraceSafeListR.cons_intro ?_ (fun u1 hu1 => ?_)
      · simp only [Stmt.TraceSafeR]
        refine ⟨by simp [Op.SafeAtR.eq_def], ?_⟩
        rw [aft3_evalOpR_ne_const, aft3_ne_one_zero_true]
        show Stmt.TraceSafeListR R bounds
          [Stmt.assign TileDType.real [BM] "m_i" ((Op.add NumericDType.real Broadcast.scalarR (Op.full [BM] (Op.const 0)) Op.negInf)),
           Stmt.assign TileDType.real [BM] "l_i" ((Op.add NumericDType.real Broadcast.scalarR (Op.full [BM] (Op.const 0)) (Op.const 1.0))),
           Stmt.assign TileDType.real [BM, ND] "acc" (Op.full [BM, ND] (Op.const 0))] s11
        refine Stmt.TraceSafeListR.of_forall _ _ ?_
        intro st hst u
        simp only [List.mem_cons, List.not_mem_nil, or_false] at hst
        rcases hst with rfl | rfl | rfl <;> simp [Stmt.TraceSafeR, Op.SafeAtR.eq_def]
      rw [aft3_ifThenElse_trueR R (by rw [aft3_evalOpR_ne_const]; exact aft3_ne_one_zero_true _)] at hu1
      obtain ⟨w1, hw1, hu1⟩ := aft3_stepStmtsR_cons_inv hu1
      obtain ⟨va, -, rfl⟩ := stepStmtR_assign_inv hw1
      obtain ⟨w2, hw2, hu1⟩ := aft3_stepStmtsR_cons_inv hu1
      obtain ⟨vb, -, rfl⟩ := stepStmtR_assign_inv hw2
      obtain ⟨w3, hw3, hu1⟩ := aft3_stepStmtsR_cons_inv hu1
      obtain ⟨vc, -, rfl⟩ := stepStmtR_assign_inv hw3
      rw [stepStmtsR_nil] at hu1
      obtain rfl := Option.some.inj hu1
      -- qk_scale ×2 (register-only)
      refine Stmt.TraceSafeListR.cons_intro
        (by simp [Stmt.TraceSafeR, Op.SafeAtR.eq_def]) (fun u2 hu2 => ?_)
      obtain ⟨vd, -, rfl⟩ := stepStmtR_assign_inv hu2
      refine Stmt.TraceSafeListR.cons_intro
        (by simp [Stmt.TraceSafeR, Op.SafeAtR.eq_def]) (fun u3 hu3 => ?_)
      obtain ⟨ve, -, rfl⟩ := stepStmtR_assign_inv hu3
      -- the IS_EVEN_M ifThenElse: the live `Q_block_ptr` load (`read1` bound)
      refine Stmt.TraceSafeListR.cons_intro ?_ (fun _ _ => Stmt.TraceSafeListR.nil_intro)
      simp only [Stmt.TraceSafeR]
      refine ⟨by simp [Op.SafeAtR.eq_def], ?_⟩
      rw [aft3_evalOpR_ne_const, aft3_ne_one_zero_true]
      show Stmt.TraceSafeListR R bounds
        [Stmt.assign TileDType.real [BM, ND] "q" (Op.load TileDType.real (MemAccess.blockPtr (Op.ref TileDType.blockPtr [BM, ND] "Q_block_ptr") []) MaskOpt.none .unspecified)] _
      refine Stmt.TraceSafeListR.cons_intro ?_ (fun _ _ => Stmt.TraceSafeListR.nil_intro)
      simp only [Stmt.TraceSafeR, Op.SafeAtR.eq_def, MaskOpt.ActiveR,
        MemAccess.ActiveAddressSafeR, memAccessActiveAddressSafeR]
      refine ⟨trivial, trivial, ?_⟩
      intro ptrs hptrs idx _
      rw [evalOpR_ref] at hptrs
      simp only [BlockState.setReg_ne_name, ne_eq, String.reduceEq, not_false_eq_true] at hptrs
      rw [hQp] at hptrs
      obtain rfl := Option.some.inj hptrs
      intro _
      have hbound := hbQ ⟨0, hT⟩ (Lane2D.encode (idx.1, idx.2.1, PUnit.unit))
      simp only [Lane2D.encode_div, Lane2D.encode_mod] at hbound
      simpa using hbound

  · -- after the preLoop: the KV loop, then the postLoop
    intro s2 hs2
    obtain ⟨spW, hpreW, hinv0⟩ :=
      aft3PreLoop_evalW Q K V M Out L sm_scale sqz sqh sqm sqk skz skh skn skk svz svh svk svn soz soh som son H H_KV N_CTX ROUND_CTX NKV_CTX off size BM ND BN s hH hHKV hskz hskh hsvz hsvh hsoz hsoh
    rw [aft3PreLoopG_castFree R Q K V M Out L sm_scale sqz sqh sqm sqk skz skh skn skk svz svh svk svn soz soh som son H H_KV N_CTX ROUND_CTX NKV_CTX off size BM ND BN s, hpreW] at hs2
    obtain rfl := Option.some.inj hs2
    refine Stmt.TraceSafeListR.cons_intro ?_ (fun s3 hs3 => ?_)
    · -- the KV loop is trace-safe (invariant principle over `aft3SafeInv`)
      simp only [Stmt.TraceSafeR]
      refine Stmt.forRangeTraceSafeR_inv R bounds "start_n" NKV_CTX BN
        (aft3LoopBodyG2 sm_scale off size BM ND BN)
        (aft3SafeInv K V M Out L s (s.pids 1 / H * sqz + s.pids 1 % H * sqh) BM ND NKV_CTX BN skk skn svk svn som son ROUND_CTX) ?_ 0 spW hinv0
      intro c st hc hP
      refine ⟨aft3_bodySafeW2 R bounds K V M Out L s sm_scale (s.pids 1 / H * sqz + s.pids 1 % H * sqh) BM ND NKV_CTX BN skk skn svk svn som son ROUND_CTX off size hBN hBNdvd c st hc hP hbK hbV, ?_⟩
      obtain ⟨st', hstep, hP'⟩ :=
        aft3_attn_stepW2 K V M Out L s sm_scale (s.pids 1 / H * sqz + s.pids 1 % H * sqh) BM ND NKV_CTX BN skk skn svk svn som son ROUND_CTX off size hBN hBNdvd c st hc hP
      exact ⟨st', by rw [aft3LoopBodyG2_castFree]; exact hstep, hP'⟩
    · -- identify the post-loop state and finish on the postLoop stores
      obtain ⟨final, sfin, hLoop, hfinal, hPfin⟩ :=
        forRange_inv (idx := "start_n") (start := 0) (stop := NKV_CTX) (step := BN)
          (body := aft3LoopBodyG2 sm_scale off size BM ND BN)
          (P := aft3SafeInv K V M Out L s (s.pids 1 / H * sqz + s.pids 1 % H * sqh) BM ND NKV_CTX BN skk skn svk svn som son ROUND_CTX)
          (s_init := spW) hBN.ne' hinv0
          (fun c st hc hP =>
            aft3_attn_stepW2 K V M Out L s sm_scale (s.pids 1 / H * sqz + s.pids 1 % H * sqh) BM ND NKV_CTX BN skk skn svk svn som son ROUND_CTX off size hBN hBNdvd c st hc hP)
      rw [show stepStmtR R (Stmt.forRange "start_n" 0 NKV_CTX BN (aft3LoopBodyG2 sm_scale off size BM ND BN)) spW = some sfin from by
        rw [stepStmtR_forRange,
          stepForRangeAuxR_castFree R _ (aft3LoopBodyG2_castFree R sm_scale off size BM ND BN) "start_n",
          ← stepForRangeAux.forRange_unfold]
        exact hLoop] at hs3
      obtain rfl := Option.some.inj hs3
      exact aft3_postSafeW R bounds K V M Out L s (s.pids 1 / H * sqz + s.pids 1 % H * sqh) BM ND NKV_CTX BN skk skn svk svn som son ROUND_CTX final sfin hPfin hbO hbM

/-! ### ════════ ★ MAIN THEOREM ★ ════════ -/
set_option maxHeartbeats 8000000 in
set_option maxRecDepth 8000 in
/-- **The case-1 `⊨[R]` io headline (sliding window).** For every rounding
model `R`, the case-1 (`(END,INIT,SLIDING_WINDOW,COMPLEMENT) = (1,1,1,0)`)
`_attn_fwd` surface implements, on its `StreamMasked3DKernelIO₃ₓ₂` signature,
the **ideal-ℝ sliding-window online-softmax attention fold** over the three
streamed tiles: output lane `j = (i, d)` of `Out` holds the window-filtered
base-2 per-key-scale softmax (`attentionFwdTriton3Case1IOOutSpec` = the
existing `attentionFwdTriton3Case1OutSpecG` closed form restated on the
streams — the `tl.where` window mask `0 ≤ dist ∧ dist < size` enters as the
`natSlidingWindowKeepG p₀` key filter), and row `i` of `M` holds the raw
`(m ⊔ … + log2 l).unbotD 0` finalize (`attentionFwdTriton3Case1IOMSpec` =
`attentionFwdTriton3KMSpecG` on the streams). Both output grids are the
`.real` default, so at every `R` the terminal cells carry the exact fold
values.

**Hypothesis provenance** (inherited verbatim from the exact case-1 headline
`attention_fwd_triton3_python_case1_output_summary_general`, all
truth-forced): `0 < ND/BM/BN/NKV_CTX` and `BN ∣ NKV_CTX` shape the KV walk;
`0 < H`, `H_KV = H` and the six stride equalities collapse the four plane
offsets onto the shared base `pid₁/H·sqz + pid₁%H·sqh`; `M ≠ Out` keeps the
`O` store off the `M` row; `hinjO`/`hinjM` (∀-pids forms of the exact
stack's per-program injectivity) make the scatter readbacks well-defined.
The exact headline's `hundef` is not a hypothesis — the skin's Hoare triple
carries the `undef` pin itself.

**Scope disclosed**: with this and the case-2 headline below, three of the
four constexpr cases carry io faces. Case 4 (`INIT=0` seeded resume) is
**not** converted: its surface reads six input regions (`Q`/`K`/`V` plus the
`M`/`L`/`Out` resume rows, `M` and `Out` simultaneously input and output) of
non-uniform per-step widths (`BM·ND`/`ND·BN`/`BN·ND`/`BM`/`BM`/`BM·ND`) —
neither the 3-input `StreamMasked3DKernelIO₃ₓ₂` skin nor the uniform-`B`
`StreamGroupedEmitMasked3DKernelIO` vector skin can state that honestly; it
needs a named-field `₆ₓ₂` (or per-channel-`B` grouped) variant and stays on
its exact headline `attention_fwd_triton3_python_case4_output_summary_general`
(deferred). The port's known fidelity gaps (`IS_EVEN_N = 1` hardwired, casts
erased to identity, `@triton.heuristics` not modeled) are inherited as-is. -/
specification attention_fwd_triton3_case1_io_correctness (R : RoundingModel)
    (Q K V M Out L : RegionName) (sm_scale : ℝ)
    (sqz sqh sqm sqk skz skh skn skk svz svh svk svn soz soh som son
      Z H H_KV N_CTX ROUND_CTX NKV_CTX off size BM ND BN : Nat)
    (hND : 0 < ND) (hBM : 0 < BM) (hBN : 0 < BN) (hNC : 0 < NKV_CTX) (hBNdvd : BN ∣ NKV_CTX)
    (hH : 0 < H) (hHKV : H_KV = H)
    (hskz : skz = sqz) (hskh : skh = sqh) (hsvz : svz = sqz) (hsvh : svh = sqh)
    (hsoz : soz = sqz) (hsoh : soh = sqh)
    (hMO : M ≠ Out)
    (hinjO : ∀ p₀ p₁ : Nat, Function.Injective
      (fun idx : TileIndex [BM, ND] =>
        (p₁ / H * sqz + p₁ % H * sqh) + (p₀ * BM + idx.1.val) * som + idx.2.1.val * son))
    (hinjM : ∀ p₀ p₁ : Nat, Function.Injective
      (fun r : TileIndex [BM] => p₁ * ROUND_CTX + (p₀ * BM + r.1.val))) :
    attentionFwdTriton3Case1IO Q K V M Out L sm_scale sqz sqh sqm sqk skz skh skn skk svz svh svk svn soz soh som son Z H H_KV N_CTX ROUND_CTX NKV_CTX off size BM ND BN ⊨[R]
      fun p₀ _ _ xs ys zs =>
        (fun j => attentionFwdTriton3Case1IOOutSpec p₀ BM ND BN NKV_CTX (NKV_CTX / BN)
            (Nat.div_pos (Nat.le_of_dvd hNC hBNdvd) hBN) (Nat.div_mul_cancel hBNdvd) hBN
            (sm_scale * 1.4426950408889634) off size xs ys zs j,
         fun i => attentionFwdTriton3Case1IOMSpec p₀ BM ND BN NKV_CTX (NKV_CTX / BN) hND
            (Nat.div_pos (Nat.le_of_dvd hNC hBNdvd) hBN) (Nat.div_mul_cancel hBNdvd) hBN
            (sm_scale * 1.4426950408889634) off size xs ys zs i) := by
  have hT : 0 < NKV_CTX / BN := Nat.div_pos (Nat.le_of_dvd hNC hBNdvd) hBN
  have hTB : NKV_CTX / BN * BN = NKV_CTX := Nat.div_mul_cancel hBNdvd
  refine StreamMasked3DKernelIO₃ₓ₂.ImplementsR.intro _ ?_ ?_ ?_
  · exact aft3_flattenOkG1 Q K V M Out L sm_scale sqz sqh sqm sqk skz skh skn skk svz svh svk svn soz soh som son Z H H_KV N_CTX ROUND_CTX NKV_CTX off size BM ND BN
  · -- the safety walk
    intro bounds s xs ys zs _hlaunch _hx _hy _hz hbr1 hbr2 hbr3 hbw1 hbw2
    simp only [attentionFwdTriton3Case1IO] at hbr1 hbr2 hbr3 hbw1 hbw2 ⊢
    exact aft3_traceSafeR_case1 R bounds Q K V M Out L sm_scale
      sqz sqh sqm sqk skz skh skn skk svz svh svk svn soz soh som son
      Z H H_KV N_CTX ROUND_CTX NKV_CTX off size BM ND BN s hH hHKV hskz hskh hsvz hsvh hsoz hsoh
      hBN hNC hBNdvd
      (fun t j => hbr1 t j trivial) (fun t j => hbr2 t j trivial)
      (fun t j => hbr3 t j trivial) (fun j => hbw1 j trivial) (fun j => hbw2 j trivial)
  · -- the rounded Hoare triple: exact KG invariant stack + cast-free collapses
    intro s₀ xs ys zs _hlaunch hu hx hy hz
    simp only [attentionFwdTriton3Case1IO] at hx hy hz ⊢
    have hundef' : ∀ rg o, s₀.undef rg o = 0 := fun rg o => by rw [hu]
    set base := s₀.pids 1 / H * sqz + s₀.pids 1 % H * sqh with hbase
    set sc := sm_scale * 1.4426950408889634 with hsc
    obtain ⟨sp, hpre, hinv0⟩ :=
      aft3PreLoop_evalG Q K V M Out L sm_scale sqz sqh sqm sqk skz skh skn skk svz svh svk svn soz soh som son H H_KV N_CTX ROUND_CTX NKV_CTX off size BM ND BN s₀ hND hH hHKV hskz hskh hsvz hsvh hsoz hsoh (fun i j => natSlidingWindowKeepG (s₀.pids 0) BM BN off size i j) hundef'
    obtain ⟨final, sL, hloop, hfin, hinvL⟩ :=
      forRange_inv (idx := "start_n") (start := 0) (stop := NKV_CTX) (step := BN)
        (body := aft3LoopBodyG sm_scale off size BM ND BN)
        (P := fun i st => attnInvariantKG Q K V M Out L s₀ base BM ND NKV_CTX BN sqm sqk skn skk svk svn som son ROUND_CTX hND sc (fun i j => natSlidingWindowKeepG (s₀.pids 0) BM BN off size i j) i st)
        (s_init := sp)
        hBN.ne'
        (attnInvariant_zero_to_KG Q K V M Out L s₀ base BM ND NKV_CTX BN sqm sqk skn skk svk svn som son ROUND_CTX hND sc (fun i j => natSlidingWindowKeepG (s₀.pids 0) BM BN off size i j) sp hinv0)
        (fun i st hi hP => aft3_attn_step1G Q K V M Out L s₀ base BM ND NKV_CTX BN sqm sqk skn skk svk svn som son ROUND_CTX off size hND hBM hBN hBNdvd sc i st hi
          (by obtain ⟨_, hmod, _, _⟩ := hP; exact hmod) hP)
    have hfinal : final = NKV_CTX := by
      obtain ⟨_, hmod, hle, _⟩ := hinvL
      rcases Nat.lt_or_ge final NKV_CTX with h | h
      · exact absurd h (by simpa using hfin)
      · exact Nat.le_antisymm hle h
    subst final
    obtain ⟨sF, hpost, hO, hM⟩ :=
      aft3PostLoop_eval_KG Q K V M Out L s₀ sL base BM ND NKV_CTX BN sqm sqk skn skk svk svn som son ROUND_CTX hND sc hMO
        (fun i j => natSlidingWindowKeepG (s₀.pids 0) BM BN off size i j)
        (hinjO (s₀.pids 0) (s₀.pids 1)) (hinjM (s₀.pids 0) (s₀.pids 1)) hinvL
    obtain ⟨hpidsL, _, _, _, _, _, _, _, _, _, _, _, hMptrL, _, hOpL, _, hmemL⟩ := hinvL
    have hframe := aft3PostLoop_frameW M Out L s₀ base BM ND som son ROUND_CTX sL sF hMptrL hOpL hpost
    refine ⟨sF, ?_, ?_, ?_, ?_⟩
    · -- termination under `execR R` (everything cast-free)
      show execR R (attention_fwd_triton3_surface Q K V M Out L sm_scale
        sqz sqh sqm sqk skz skh skn skk svz svh svk svn soz soh som son
        Z H H_KV N_CTX ROUND_CTX NKV_CTX off size 1 1 BM ND BN 1 1 1 0).toAlgKernel s₀ = some sF
      unfold execR
      rw [aft3_body_splitG, stepStmtsR_append,
        aft3PreLoopG_castFree R Q K V M Out L sm_scale sqz sqh sqm sqk skz skh skn skk svz svh svk svn soz soh som son H H_KV N_CTX ROUND_CTX NKV_CTX off size BM ND BN s₀,
        hpre, Option.bind_some,
        stepStmtsR_cons_some (show stepStmtR R (Stmt.forRange "start_n" 0 NKV_CTX BN (aft3LoopBodyG sm_scale off size BM ND BN)) sp = some sL from by
          rw [stepStmtR_forRange,
            stepForRangeAuxR_castFree R _ (aft3LoopBodyG_castFree R sm_scale off size BM ND BN) "start_n",
            ← stepForRangeAux.forRange_unfold]
          exact hloop),
        aft3PostLoopG_castFree R M Out L BM ND sL]
      exact hpost
    · -- Out readback = the streamed sliding-window closed form
      intro j _
      have hOj := hO (Lane2D.decode j)
      rw [show base + (s₀.pids 0 * BM + (Lane2D.decode j).1.val) * som + (Lane2D.decode j).2.1.val * son
          = base + (s₀.pids 0 * BM + j.val / ND) * som + (j.val % ND) * son from by
        simp only [Lane2D.decode_row, Lane2D.decode_col]] at hOj
      rw [BlockState.readMemAs_real, hOj]
      rw [aft3IOqT_eq s₀ Q base sqm sqk BM ND (NKV_CTX / BN) hT xs (fun t j' => hx t j' trivial),
        aft3IOkT_eq s₀ K base skn skk ND BN NKV_CTX (NKV_CTX / BN) hTB hBN ys (fun t j' => hy t j' trivial),
        aft3IOvT_eq s₀ V base svk svn ND BN NKV_CTX (NKV_CTX / BN) hTB hBN zs (fun t j' => hz t j' trivial)]
      rw [aft3_botKG_ratio_eq_pred (aft3IOqT BM ND (NKV_CTX / BN) hT xs)
        (aft3IOkT ND BN NKV_CTX (NKV_CTX / BN) hTB hBN ys)
        (aft3IOvT ND BN NKV_CTX (NKV_CTX / BN) hTB hBN zs)
        (keyScale3G sc NKV_CTX) (fun i j => natSlidingWindowKeepG (s₀.pids 0) BM BN off size i j)
        hNC hND (Lane2D.decode j)]
      unfold attentionFwdTriton3Case1IOOutSpec
      simp [FloatDType.ofReal]
    · -- M readback = the streamed raw finalize
      intro i _
      rw [BlockState.readMemAs_real, hM i]
      unfold attentionFwdTriton3Case1IOMSpec
      rw [aft3IOqT_eq s₀ Q base sqm sqk BM ND (NKV_CTX / BN) hT xs (fun t j' => hx t j' trivial),
        aft3IOkT_eq s₀ K base skn skk ND BN NKV_CTX (NKV_CTX / BN) hTB hBN ys (fun t j' => hy t j' trivial),
        aft3IOvT_eq s₀ V base svk svn ND BN NKV_CTX (NKV_CTX / BN) hTB hBN zs (fun t j' => hz t j' trivial)]
      simp [FloatDType.ofReal]
    · -- the frame: cells outside the two write windows are untouched
      intro r oo hcond
      obtain ⟨h1, h2⟩ := hcond
      rw [hframe r oo ?_ ?_, hmemL]
      · intro hr i
        exact fun hoo => h2 i trivial hr hoo
      · intro hr idx
        have h := h1 (Lane2D.encode (idx.1, idx.2.1, PUnit.unit)) trivial hr
        simpa [Lane2D.encode_div, Lane2D.encode_mod] using h

/-! ### ════════ ★ MAIN THEOREM ★ ════════ -/
set_option maxHeartbeats 8000000 in
set_option maxRecDepth 8000 in
/-- **The case-2 `⊨[R]` io headline (complement sliding window).** As the
case-1 io headline with the complementary key filter: the constexpr
`COMPLEMENT=1` mask `dist ≥ size` enters the spec as
`natComplementSlidingWindowKeepG p₀`, so `Out` holds
`attentionFwdTriton3Case2IOOutSpec` (= `attentionFwdTriton3Case2OutSpecG` on
the streams) and `M` the matching raw finalize
`attentionFwdTriton3Case2IOMSpec`. Hypotheses inherited verbatim from
`attention_fwd_triton3_python_case2_output_summary_general` minus `hundef`
(carried by the skin's triple). See the case-1 headline's scope note for why
case 4 (`INIT=0` seeded resume, six non-uniform input channels) has no
honest io face on the existing skins and stays on its exact headline. -/
specification attention_fwd_triton3_case2_io_correctness (R : RoundingModel)
    (Q K V M Out L : RegionName) (sm_scale : ℝ)
    (sqz sqh sqm sqk skz skh skn skk svz svh svk svn soz soh som son
      Z H H_KV N_CTX ROUND_CTX NKV_CTX off size BM ND BN : Nat)
    (hND : 0 < ND) (hBM : 0 < BM) (hBN : 0 < BN) (hNC : 0 < NKV_CTX) (hBNdvd : BN ∣ NKV_CTX)
    (hH : 0 < H) (hHKV : H_KV = H)
    (hskz : skz = sqz) (hskh : skh = sqh) (hsvz : svz = sqz) (hsvh : svh = sqh)
    (hsoz : soz = sqz) (hsoh : soh = sqh)
    (hMO : M ≠ Out)
    (hinjO : ∀ p₀ p₁ : Nat, Function.Injective
      (fun idx : TileIndex [BM, ND] =>
        (p₁ / H * sqz + p₁ % H * sqh) + (p₀ * BM + idx.1.val) * som + idx.2.1.val * son))
    (hinjM : ∀ p₀ p₁ : Nat, Function.Injective
      (fun r : TileIndex [BM] => p₁ * ROUND_CTX + (p₀ * BM + r.1.val))) :
    attentionFwdTriton3Case2IO Q K V M Out L sm_scale sqz sqh sqm sqk skz skh skn skk svz svh svk svn soz soh som son Z H H_KV N_CTX ROUND_CTX NKV_CTX off size BM ND BN ⊨[R]
      fun p₀ _ _ xs ys zs =>
        (fun j => attentionFwdTriton3Case2IOOutSpec p₀ BM ND BN NKV_CTX (NKV_CTX / BN)
            (Nat.div_pos (Nat.le_of_dvd hNC hBNdvd) hBN) (Nat.div_mul_cancel hBNdvd) hBN
            (sm_scale * 1.4426950408889634) off size xs ys zs j,
         fun i => attentionFwdTriton3Case2IOMSpec p₀ BM ND BN NKV_CTX (NKV_CTX / BN) hND
            (Nat.div_pos (Nat.le_of_dvd hNC hBNdvd) hBN) (Nat.div_mul_cancel hBNdvd) hBN
            (sm_scale * 1.4426950408889634) off size xs ys zs i) := by
  have hT : 0 < NKV_CTX / BN := Nat.div_pos (Nat.le_of_dvd hNC hBNdvd) hBN
  have hTB : NKV_CTX / BN * BN = NKV_CTX := Nat.div_mul_cancel hBNdvd
  refine StreamMasked3DKernelIO₃ₓ₂.ImplementsR.intro _ ?_ ?_ ?_
  · exact aft3_flattenOkG2 Q K V M Out L sm_scale sqz sqh sqm sqk skz skh skn skk svz svh svk svn soz soh som son Z H H_KV N_CTX ROUND_CTX NKV_CTX off size BM ND BN
  · -- the safety walk
    intro bounds s xs ys zs _hlaunch _hx _hy _hz hbr1 hbr2 hbr3 hbw1 hbw2
    simp only [attentionFwdTriton3Case2IO] at hbr1 hbr2 hbr3 hbw1 hbw2 ⊢
    exact aft3_traceSafeR_case2 R bounds Q K V M Out L sm_scale
      sqz sqh sqm sqk skz skh skn skk svz svh svk svn soz soh som son
      Z H H_KV N_CTX ROUND_CTX NKV_CTX off size BM ND BN s hH hHKV hskz hskh hsvz hsvh hsoz hsoh
      hBN hNC hBNdvd
      (fun t j => hbr1 t j trivial) (fun t j => hbr2 t j trivial)
      (fun t j => hbr3 t j trivial) (fun j => hbw1 j trivial) (fun j => hbw2 j trivial)
  · -- the rounded Hoare triple: exact KG invariant stack + cast-free collapses
    intro s₀ xs ys zs _hlaunch hu hx hy hz
    simp only [attentionFwdTriton3Case2IO] at hx hy hz ⊢
    have hundef' : ∀ rg o, s₀.undef rg o = 0 := fun rg o => by rw [hu]
    set base := s₀.pids 1 / H * sqz + s₀.pids 1 % H * sqh with hbase
    set sc := sm_scale * 1.4426950408889634 with hsc
    obtain ⟨sp, hpre, hinv0⟩ :=
      aft3PreLoop_evalG Q K V M Out L sm_scale sqz sqh sqm sqk skz skh skn skk svz svh svk svn soz soh som son H H_KV N_CTX ROUND_CTX NKV_CTX off size BM ND BN s₀ hND hH hHKV hskz hskh hsvz hsvh hsoz hsoh (fun i j => natComplementSlidingWindowKeepG (s₀.pids 0) BM BN off size i j) hundef'
    obtain ⟨final, sL, hloop, hfin, hinvL⟩ :=
      forRange_inv (idx := "start_n") (start := 0) (stop := NKV_CTX) (step := BN)
        (body := aft3LoopBodyG2 sm_scale off size BM ND BN)
        (P := fun i st => attnInvariantKG Q K V M Out L s₀ base BM ND NKV_CTX BN sqm sqk skn skk svk svn som son ROUND_CTX hND sc (fun i j => natComplementSlidingWindowKeepG (s₀.pids 0) BM BN off size i j) i st)
        (s_init := sp)
        hBN.ne'
        (attnInvariant_zero_to_KG Q K V M Out L s₀ base BM ND NKV_CTX BN sqm sqk skn skk svk svn som son ROUND_CTX hND sc (fun i j => natComplementSlidingWindowKeepG (s₀.pids 0) BM BN off size i j) sp hinv0)
        (fun i st hi hP => aft3_attn_step2G Q K V M Out L s₀ base BM ND NKV_CTX BN sqm sqk skn skk svk svn som son ROUND_CTX off size hND hBM hBN hBNdvd sc i st hi
          (by obtain ⟨_, hmod, _, _⟩ := hP; exact hmod) hP)
    have hfinal : final = NKV_CTX := by
      obtain ⟨_, hmod, hle, _⟩ := hinvL
      rcases Nat.lt_or_ge final NKV_CTX with h | h
      · exact absurd h (by simpa using hfin)
      · exact Nat.le_antisymm hle h
    subst final
    obtain ⟨sF, hpost, hO, hM⟩ :=
      aft3PostLoop_eval_KG Q K V M Out L s₀ sL base BM ND NKV_CTX BN sqm sqk skn skk svk svn som son ROUND_CTX hND sc hMO
        (fun i j => natComplementSlidingWindowKeepG (s₀.pids 0) BM BN off size i j)
        (hinjO (s₀.pids 0) (s₀.pids 1)) (hinjM (s₀.pids 0) (s₀.pids 1)) hinvL
    obtain ⟨hpidsL, _, _, _, _, _, _, _, _, _, _, _, hMptrL, _, hOpL, _, hmemL⟩ := hinvL
    have hframe := aft3PostLoop_frameW M Out L s₀ base BM ND som son ROUND_CTX sL sF hMptrL hOpL hpost
    refine ⟨sF, ?_, ?_, ?_, ?_⟩
    · -- termination under `execR R` (everything cast-free)
      show execR R (attention_fwd_triton3_surface Q K V M Out L sm_scale
        sqz sqh sqm sqk skz skh skn skk svz svh svk svn soz soh som son
        Z H H_KV N_CTX ROUND_CTX NKV_CTX off size 1 1 BM ND BN 1 1 1 1).toAlgKernel s₀ = some sF
      unfold execR
      rw [aft3_body_splitG2, stepStmtsR_append,
        aft3PreLoopG_castFree R Q K V M Out L sm_scale sqz sqh sqm sqk skz skh skn skk svz svh svk svn soz soh som son H H_KV N_CTX ROUND_CTX NKV_CTX off size BM ND BN s₀,
        hpre, Option.bind_some,
        stepStmtsR_cons_some (show stepStmtR R (Stmt.forRange "start_n" 0 NKV_CTX BN (aft3LoopBodyG2 sm_scale off size BM ND BN)) sp = some sL from by
          rw [stepStmtR_forRange,
            stepForRangeAuxR_castFree R _ (aft3LoopBodyG2_castFree R sm_scale off size BM ND BN) "start_n",
            ← stepForRangeAux.forRange_unfold]
          exact hloop),
        aft3PostLoopG_castFree R M Out L BM ND sL]
      exact hpost
    · -- Out readback = the streamed complement-window closed form
      intro j _
      have hOj := hO (Lane2D.decode j)
      rw [show base + (s₀.pids 0 * BM + (Lane2D.decode j).1.val) * som + (Lane2D.decode j).2.1.val * son
          = base + (s₀.pids 0 * BM + j.val / ND) * som + (j.val % ND) * son from by
        simp only [Lane2D.decode_row, Lane2D.decode_col]] at hOj
      rw [BlockState.readMemAs_real, hOj]
      rw [aft3IOqT_eq s₀ Q base sqm sqk BM ND (NKV_CTX / BN) hT xs (fun t j' => hx t j' trivial),
        aft3IOkT_eq s₀ K base skn skk ND BN NKV_CTX (NKV_CTX / BN) hTB hBN ys (fun t j' => hy t j' trivial),
        aft3IOvT_eq s₀ V base svk svn ND BN NKV_CTX (NKV_CTX / BN) hTB hBN zs (fun t j' => hz t j' trivial)]
      rw [aft3_botKG_ratio_eq_pred (aft3IOqT BM ND (NKV_CTX / BN) hT xs)
        (aft3IOkT ND BN NKV_CTX (NKV_CTX / BN) hTB hBN ys)
        (aft3IOvT ND BN NKV_CTX (NKV_CTX / BN) hTB hBN zs)
        (keyScale3G sc NKV_CTX) (fun i j => natComplementSlidingWindowKeepG (s₀.pids 0) BM BN off size i j)
        hNC hND (Lane2D.decode j)]
      unfold attentionFwdTriton3Case2IOOutSpec
      simp [FloatDType.ofReal]
    · -- M readback = the streamed raw finalize
      intro i _
      rw [BlockState.readMemAs_real, hM i]
      unfold attentionFwdTriton3Case2IOMSpec
      rw [aft3IOqT_eq s₀ Q base sqm sqk BM ND (NKV_CTX / BN) hT xs (fun t j' => hx t j' trivial),
        aft3IOkT_eq s₀ K base skn skk ND BN NKV_CTX (NKV_CTX / BN) hTB hBN ys (fun t j' => hy t j' trivial),
        aft3IOvT_eq s₀ V base svk svn ND BN NKV_CTX (NKV_CTX / BN) hTB hBN zs (fun t j' => hz t j' trivial)]
      simp [FloatDType.ofReal]
    · -- the frame: cells outside the two write windows are untouched
      intro r oo hcond
      obtain ⟨h1, h2⟩ := hcond
      rw [hframe r oo ?_ ?_, hmemL]
      · intro hr i
        exact fun hoo => h2 i trivial hr hoo
      · intro hr idx
        have h := h1 (Lane2D.encode (idx.1, idx.2.1, PUnit.unit)) trivial hr
        simpa [Lane2D.encode_div, Lane2D.encode_mod] using h

/-! # ══════════ The `⊨[R]` io headline — case 4 (₆ₓ₂ exemplar) ══════════

The `StreamMasked3DKernelIO₆ₓ₂` face of the **case-4**
(`(END,INIT,SLIDING_WINDOW,COMPLEMENT) = (1,0,1,0)`, cross-launch resume)
kernel — the corpus's first io face whose **input channels alias its output
channels**. Everything below is purely additive; the exact surfaces and the
case-1/2/3 io faces above are untouched.

**Why six channels.** With `INIT=0` the prologue does not seed `m_i`/`l_i`/
`acc` with `(⊥, 1, 0)`; it *loads* them from the `M`, `L` and `Out` buffers
(the running state left behind by the previous chunk launch). So the program
reads six regions — `Q` (static tile), `K`/`V` (per-step tiles), and the
`M`/`L`/`Out` resume rows — of radically non-uniform per-step widths
(`BM·ND`, `ND·BN`, `BN·ND`, `BM`, `BM`, `BM·ND`), and writes two of them back.

**Aliasing is honest here.** `out1 = Out = inp6` and `out2 = M = inp4`, so
`A.regions` repeats two names. That is sound, exactly as the skin's docstring
argues: `FlatAlloc.base` is a function of the region *name* (not a prefix sum
over the `regions` list), so a repeated name denotes **one** segment rather
than two; `A.Disjoint` only constrains pairs `r ≠ r'`, so it imposes nothing
on a name against itself; and `A.decode` resolves an address by `find?`, i.e.
by the first matching name, which is the same segment either way. Nothing in
the obligation set confuses the two roles: the six input pins are stated on
the **launch** state `s₀` (the incoming running state), while the two
readbacks are stated on the **final** state `s'` (the outgoing running state).
The frame clause still says only the two write windows moved, and those
windows are literally the `inp4`/`inp6` read windows — which is precisely the
resume semantics.

`L` is **read-only** in case 4: its store sits in the dead `END=0` branch of
`aft3PostLoopG`, so it appears as `inp5` only.

Window transcription (all bases coincide at `base = pid₁/H·sqz + pid₁%H·sqh`,
collapsed by the headline's `hskz`/`hskh`/`hsvz`/`hsvh`/`hsoz`/`hsoh`):

* `read1` (`Q`, the **static** stream): lane `j = (i, e)` over `[BM, ND]`
  reads `base + (pid₀·BM + i)·sqm + e·sqk`.
* `read2` (`K`, advanced by `BN` columns per step): lane `j = (e, jL)` over
  `[ND, BN]` reads `base + e·skk + (t·BN + jL)·skn`.
* `read3` (`V`, advanced by `BN` rows per step): lane `j = (r, d)` over
  `[BN, ND]` reads `base + (t·BN + r)·svk + d·svn`.
* `read4` (`M` resume row, static): lane `i` reads `pid₁·ROUND_CTX + pid₀·BM + i`.
* `read5` (`L` resume row, static): the same offset in `L`.
* `read6` (`Out` resume tile, static): lane `j = (i, d)` over `[BM, ND]` reads
  `base + (pid₀·BM + i)·som + d·son`.
* `write1` (`Out`) = `read6`'s window; `write2` (`M`) = `read4`'s window.

All six loads are unmasked, so every `maskᵢ` is `True`; both stores are
unmasked too. `pid₂` is unused (2-D grid). `T = NKV_CTX / BN` is pid-free, so
the skin's `pre` stays at its unconstrained default. Both output grids are the
`.real` default (the store-side `.to(...)` cast is erased to the identity at
translation), so no `hfp16` boundary appears. -/

open scoped VeriTile.Triton.StreamMasked3DKernelIO₆ₓ₂

set_option maxHeartbeats 4000000 in
/-- Every case-4 preLoop statement is cast-free, statement-by-statement — the
verbatim `aft3PreLoopG_stmt_castFree` walk with the `INIT` constexpr flipped
`1 → 0`, so the collapse runs on the **load** branch (`m_i`/`l_i`/`acc` read
back from `M`/`L`/`Out`) instead of the fresh ⊥/1/0 init. Both branches were
already covered leaf-by-leaf; only which one is reduced changes. -/
private theorem aft3PreLoopG_init0_stmt_castFree (R : RoundingModel)
    (Q K V M Out L : RegionName) (sm_scale : ℝ)
    (sqz sqh sqm sqk skz skh skn skk svz svh svk svn soz soh som son
      H H_KV N_CTX ROUND_CTX NKV_CTX off size BM ND BN : Nat) :
    ∀ st ∈ aft3PreLoopG_init0 Q K V M Out L sm_scale sqz sqh sqm sqk skz skh skn skk svz svh svk svn soz soh som son H H_KV N_CTX ROUND_CTX NKV_CTX off size BM ND BN,
      ∀ u, stepStmtR R st u = stepStmt st u := by
  intro st hst u
  simp only [aft3PreLoopG_init0, List.mem_cons, List.not_mem_nil, or_false] at hst
  rcases hst with rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl |
    rfl | rfl | rfl | rfl | rfl | rfl | rfl
  · simp only [stepStmtR, stepStmt, evalOpR.eq_def, evalOp.eq_def]
  · simp only [stepStmtR, stepStmt, evalOpR.eq_def, evalOp.eq_def]
  · simp only [stepStmtR, stepStmt, evalOpR.eq_def, evalOp.eq_def]
  · simp only [stepStmtR, stepStmt, evalOpR.eq_def, evalOp.eq_def]
  · simp only [stepStmtR, stepStmt, evalOpR.eq_def, evalOp.eq_def]
  · simp only [stepStmtR, stepStmt, evalOpR.eq_def, evalOp.eq_def]
  · simp only [stepStmtR, stepStmt, evalOpR.eq_def, evalOp.eq_def]
  · simp only [stepStmtR, stepStmt, evalOpR.eq_def, evalOp.eq_def]
  · simp only [stepStmtR, stepStmt, evalOpR.eq_def, evalOp.eq_def]
  · -- Q_block_ptr (`makeBlockPtrDynOffsets`): dedicated `mapM` mirror
    simp only [stepStmtR, stepStmt,
      aft3_evalOpR_mbpdo_castFree R Q (Op.ref TileDType.nat [] "q_offset") [N_CTX, ND] [BM, ND] [sqm, sqk]
        [Op.mul NumericDType.nat Broadcast.nil (Op.ref TileDType.nat [] "start_m") (Op.constNat BM), Op.constNat 0] u
        (by simp only [evalOpR, evalOp])
        (by
          intro o ho
          simp only [List.mem_cons, List.not_mem_nil, or_false] at ho
          rcases ho with rfl | rfl <;> simp only [evalOpR.eq_def, evalOp.eq_def])]
  · simp only [stepStmtR, stepStmt, evalOpR.eq_def, evalOp.eq_def]
  · simp only [stepStmtR, stepStmt, evalOpR.eq_def, evalOp.eq_def]
  · -- O_block_ptr (`makeBlockPtrDynOffsets`): dedicated `mapM` mirror
    simp only [stepStmtR, stepStmt,
      aft3_evalOpR_mbpdo_castFree R Out (Op.ref TileDType.nat [] "o_offset") [ROUND_CTX, ND] [BM, ND] [som, son]
        [Op.mul NumericDType.nat Broadcast.nil (Op.ref TileDType.nat [] "start_m") (Op.constNat BM), Op.constNat 0] u
        (by simp only [evalOpR, evalOp])
        (by
          intro o ho
          simp only [List.mem_cons, List.not_mem_nil, or_false] at ho
          rcases ho with rfl | rfl <;> simp only [evalOpR.eq_def, evalOp.eq_def])]
  · simp only [stepStmtR, stepStmt, evalOpR.eq_def, evalOp.eq_def]
  · simp only [stepStmtR, stepStmt, evalOpR.eq_def, evalOp.eq_def]
  · simp only [stepStmtR, stepStmt, evalOpR.eq_def, evalOp.eq_def]
  · -- INIT `ifThenElse` (constexpr-false): collapse on the live resume-load branch
    rw [aft3_ifThenElse_falseR R (by rw [aft3_evalOpR_ne_const]; exact aft3_ne_zero_zero_false u),
      aft3_ifThenElse_false (aft3_ne_zero_zero_false u)]
    simp only [stepStmtsR, stepStmts, stepStmtR, stepStmt, evalOpR.eq_def, evalOp.eq_def]
    rfl
  · simp only [stepStmtR, stepStmt, evalOpR.eq_def, evalOp.eq_def]
  · simp only [stepStmtR, stepStmt, evalOpR.eq_def, evalOp.eq_def]
  · -- IS_EVEN_M `ifThenElse` (constexpr-true): collapse on the live q-load only
    rw [aft3_ifThenElse_trueR R (by rw [aft3_evalOpR_ne_const]; exact aft3_ne_one_zero_true u),
      aft3_ifThenElse_true (aft3_ne_one_zero_true u)]
    simp only [stepStmtsR, stepStmts, stepStmtR, stepStmt, evalOpR.eq_def, evalOp.eq_def]
    rfl

/-- The case-4 preLoop is cast-free: it steps identically under `stepStmtsR R`. -/
private theorem aft3PreLoopG_init0_castFree (R : RoundingModel)
    (Q K V M Out L : RegionName) (sm_scale : ℝ)
    (sqz sqh sqm sqk skz skh skn skk svz svh svk svn soz soh som son
      H H_KV N_CTX ROUND_CTX NKV_CTX off size BM ND BN : Nat) (t : BlockState) :
    stepStmtsR R (aft3PreLoopG_init0 Q K V M Out L sm_scale sqz sqh sqm sqk skz skh skn skk svz svh svk svn soz soh som son H H_KV N_CTX ROUND_CTX NKV_CTX off size BM ND BN) t
      = stepStmts (aft3PreLoopG_init0 Q K V M Out L sm_scale sqz sqh sqm sqk skz skh skn skk svz svh svk svn soz soh som son H H_KV N_CTX ROUND_CTX NKV_CTX off size BM ND BN) t :=
  aft3_stepStmtsR_castFree_of_stmts R _
    (aft3PreLoopG_init0_stmt_castFree R Q K V M Out L sm_scale sqz sqh sqm sqk skz skh skn skk svz svh svk svn soz soh som son H H_KV N_CTX ROUND_CTX NKV_CTX off size BM ND BN) t

set_option maxHeartbeats 4000000 in
/-- The case-4 surface sits inside the flat-memory bridge's covered fragment
(no `ptrSub`; the block-pointer ops are structurally covered). -/
theorem aft3_flattenOkG4 (Q K V M Out L : RegionName) (sm_scale : ℝ)
    (sqz sqh sqm sqk skz skh skn skk svz svh svk svn soz soh som son
      Z H H_KV N_CTX ROUND_CTX NKV_CTX off size BM ND BN : Nat) :
    ((attention_fwd_triton3_surface Q K V M Out L sm_scale
      sqz sqh sqm sqk skz skh skn skk svz svh svk svn soz soh som son
      Z H H_KV N_CTX ROUND_CTX NKV_CTX off size 1 1 BM ND BN 1 0 1 0).toAlgKernel).FlattenOk := by
  unfold Kernel.FlattenOk
  rw [aft3_body_splitG4]
  simp [aft3PreLoopG_init0, aft3LoopBodyG, aft3PostLoopG, StmtList.FlattenOk,
    Stmt.FlattenOk, Op.FlattenOk]
  simp [Op.FlattenOk.eq_def]

/-- **Streaming IO signature** of the case-4 (`(END,INIT,SW,CSW) = (1,0,1,0)`)
`_attn_fwd` surface on the six-stream two-output attention fold skin. Channels
4/5/6 are the `M`/`L`/`Out` resume rows; `out1 = Out = inp6` and
`out2 = M = inp4` (see the section note on aliasing). -/
def attentionFwdTriton3Case4IO (Q K V M Out L : RegionName) (sm_scale : ℝ)
    (sqz sqh sqm sqk skz skh skn skk svz svh svk svn soz soh som son
      Z H H_KV N_CTX ROUND_CTX NKV_CTX off size BM ND BN : Nat) :
    StreamMasked3DKernelIO₆ₓ₂ where
  kernel := attention_fwd_triton3_surface Q K V M Out L sm_scale
    sqz sqh sqm sqk skz skh skn skk svz svh svk svn soz soh som son
    Z H H_KV N_CTX ROUND_CTX NKV_CTX off size 1 1 BM ND BN 1 0 1 0
  inp1 := Q
  inp2 := K
  inp3 := V
  inp4 := M
  inp5 := L
  inp6 := Out
  out1 := Out
  out2 := M
  T := NKV_CTX / BN
  B1 := BM * ND
  B2 := ND * BN
  B3 := BN * ND
  B4 := BM
  B5 := BM
  B6 := BM * ND
  C1 := BM * ND
  C2 := BM
  read1 := fun p₀ p₁ _ _ j =>
    (p₁ / H * sqz + p₁ % H * sqh) + (p₀ * BM + j.val / ND) * sqm + (j.val % ND) * sqk
  read2 := fun _ p₁ _ t j =>
    (p₁ / H * sqz + p₁ % H * sqh) + (j.val / BN) * skk + (t.val * BN + j.val % BN) * skn
  read3 := fun _ p₁ _ t j =>
    (p₁ / H * sqz + p₁ % H * sqh) + (t.val * BN + j.val / ND) * svk + (j.val % ND) * svn
  read4 := fun p₀ p₁ _ _ j => p₁ * ROUND_CTX + (p₀ * BM + j.val)
  read5 := fun p₀ p₁ _ _ j => p₁ * ROUND_CTX + (p₀ * BM + j.val)
  read6 := fun p₀ p₁ _ _ j =>
    (p₁ / H * sqz + p₁ % H * sqh) + (p₀ * BM + j.val / ND) * som + (j.val % ND) * son
  write1 := fun p₀ p₁ _ j =>
    (p₁ / H * sqz + p₁ % H * sqh) + (p₀ * BM + j.val / ND) * som + (j.val % ND) * son
  write2 := fun p₀ p₁ _ j => p₁ * ROUND_CTX + (p₀ * BM + j.val)
  mask1 := fun _ _ _ _ _ => True
  mask2 := fun _ _ _ _ _ => True
  mask3 := fun _ _ _ _ _ => True
  mask4 := fun _ _ _ _ _ => True
  mask5 := fun _ _ _ _ _ => True
  mask6 := fun _ _ _ _ _ => True
  writeMask1 := fun _ _ _ _ => True
  writeMask2 := fun _ _ _ _ => True

/-- The resume seed read off the (static) streams 4/5/6: row `i` takes its
running max from the `M` stream, its running denominator from the `L` stream,
and lane `(i, d)` its running accumulator from the `Out` stream. All three
windows ignore `t`, so the step-`0` slice carries the whole seed. -/
noncomputable def aft3IOseedT (BM ND T : Nat) (hT : 0 < T)
    (x4s x5s : Fin T → Fin BM → ℝ) (x6s : Fin T → Fin (BM * ND) → ℝ) :
    Fin BM → Fin ND → WithBot ℝ × ℝ × ℝ :=
  fun i d =>
    (((x4s ⟨0, hT⟩ i : ℝ) : WithBot ℝ), x5s ⟨0, hT⟩ i,
      x6s ⟨0, hT⟩ (Lane2D.encode (i, d, PUnit.unit)))

/-- `aft3Case4Seed` = the stream-indexed seed, under the `read4`/`read5`/`read6`
pins. -/
private theorem aft3IOseedT_eq (s₀ : BlockState) (M Out L : RegionName)
    (base BM ND som son ROUND_CTX T : Nat) (hT : 0 < T)
    (x4s x5s : Fin T → Fin BM → ℝ) (x6s : Fin T → Fin (BM * ND) → ℝ)
    (h4 : ∀ (t : Fin T) (j : Fin BM),
      s₀.readMem M (s₀.pids 1 * ROUND_CTX + (s₀.pids 0 * BM + j.val)) = x4s t j)
    (h5 : ∀ (t : Fin T) (j : Fin BM),
      s₀.readMem L (s₀.pids 1 * ROUND_CTX + (s₀.pids 0 * BM + j.val)) = x5s t j)
    (h6 : ∀ (t : Fin T) (j : Fin (BM * ND)),
      s₀.readMem Out (base + (s₀.pids 0 * BM + j.val / ND) * som + (j.val % ND) * son)
        = x6s t j) :
    aft3Case4Seed s₀ M Out L base BM ND som son ROUND_CTX
      = aft3IOseedT BM ND T hT x4s x5s x6s := by
  funext i d
  simp only [aft3Case4Seed, aft3IOseedT, mlRow3G, outLane3G]
  rw [h4 ⟨0, hT⟩ i, h5 ⟨0, hT⟩ i, ← h6 ⟨0, hT⟩ (Lane2D.encode (i, d, PUnit.unit))]
  simp only [Lane2D.encode_div, Lane2D.encode_mod]

/-- **Case-4 `Out` closed form on the streams**: the resume-seeded
sliding-window online-softmax fold (exactly the exact headline's
`attentionFwdTriton3Case4OutSpecG`, keep `natSlidingWindowKeepG`) restated over
the six streamed tiles, at output lane `j = (i, d)` row-major over `[BM, ND]`.
The seed is `aft3IOseedT` — the prior running state read off streams 4/5/6. -/
noncomputable def attentionFwdTriton3Case4IOOutSpec (p₀ BM ND BN NC T : Nat)
    (hND : 0 < ND) (hT : 0 < T) (hTB : T * BN = NC) (hBN : 0 < BN) (sc : ℝ)
    (off size : Nat)
    (x1s : Fin T → Fin (BM * ND) → ℝ) (x2s : Fin T → Fin (ND * BN) → ℝ)
    (x3s : Fin T → Fin (BN * ND) → ℝ) (x4s x5s : Fin T → Fin BM → ℝ)
    (x6s : Fin T → Fin (BM * ND) → ℝ) (j : Fin (BM * ND)) : ℝ :=
  (aft3StateSeededG (aft3IOqT BM ND T hT x1s) (aft3IOkT ND BN NC T hTB hBN x2s)
      (aft3IOvT ND BN NC T hTB hBN x3s) (keyScale3G sc NC)
      (fun i j => natSlidingWindowKeepG p₀ BM BN off size i j)
      (aft3IOseedT BM ND T hT x4s x5s x6s) NC
      (Lane2D.decode j).1 (Lane2D.decode j).2.1).2.2
    / (aft3StateSeededG (aft3IOqT BM ND T hT x1s) (aft3IOkT ND BN NC T hTB hBN x2s)
      (aft3IOvT ND BN NC T hTB hBN x3s) (keyScale3G sc NC)
      (fun i j => natSlidingWindowKeepG p₀ BM BN off size i j)
      (aft3IOseedT BM ND T hT x4s x5s x6s) NC
      (Lane2D.decode j).1 ⟨0, hND⟩).2.1

/-- **Case-4 `M` closed form on the streams**: the raw
`(m + log2 l).unbotD 0` finalize of the resume-seeded fold (exactly the exact
headline's `attentionFwdTriton3Case4MSpecG`) restated over the six streamed
tiles, at output row `i`. -/
noncomputable def attentionFwdTriton3Case4IOMSpec (p₀ BM ND BN NC T : Nat)
    (hND : 0 < ND) (hT : 0 < T) (hTB : T * BN = NC) (hBN : 0 < BN) (sc : ℝ)
    (off size : Nat)
    (x1s : Fin T → Fin (BM * ND) → ℝ) (x2s : Fin T → Fin (ND * BN) → ℝ)
    (x3s : Fin T → Fin (BN * ND) → ℝ) (x4s x5s : Fin T → Fin BM → ℝ)
    (x6s : Fin T → Fin (BM * ND) → ℝ) (i : Fin BM) : ℝ :=
  (WithBot.realAdd
      (aft3StateSeededG (aft3IOqT BM ND T hT x1s) (aft3IOkT ND BN NC T hTB hBN x2s)
        (aft3IOvT ND BN NC T hTB hBN x3s) (keyScale3G sc NC)
        (fun i j => natSlidingWindowKeepG p₀ BM BN off size i j)
        (aft3IOseedT BM ND T hT x4s x5s x6s) NC i ⟨0, hND⟩).1
      (WithBot.realLog2
        (((aft3StateSeededG (aft3IOqT BM ND T hT x1s) (aft3IOkT ND BN NC T hTB hBN x2s)
            (aft3IOvT ND BN NC T hTB hBN x3s) (keyScale3G sc NC)
            (fun i j => natSlidingWindowKeepG p₀ BM BN off size i j)
            (aft3IOseedT BM ND T hT x4s x5s x6s) NC i ⟨0, hND⟩).2.1 : ℝ)
          : WithBot ℝ))).unbotD 0

set_option maxHeartbeats 4000000 in
set_option maxRecDepth 8000 in
/-- **Weak case-4 preLoop**: from an **arbitrary** launch state (no
clean-`undef` hypothesis) the case-4 preLoop steps to a state satisfying
`aft3SafeInv … 0`. The `aft3PreLoop_evalW` script with the `INIT` branch
swapped for `aft3_load_stepsG`; only the shape half is kept, so the loaded
resume values appear as bare register witnesses. -/
private theorem aft3PreLoop_evalW_init0
    (Q K V M Out L : RegionName) (sm_scale : ℝ)
    (sqz sqh sqm sqk skz skh skn skk svz svh svk svn soz soh som son
      H H_KV N_CTX ROUND_CTX NKV_CTX off size BM ND BN : Nat) (s : BlockState)
    (hH : 0 < H) (hHKV : H_KV = H)
    (hskz : skz = sqz) (hskh : skh = sqh) (hsvz : svz = sqz) (hsvh : svh = sqh)
    (hsoz : soz = sqz) (hsoh : soh = sqh) :
    ∃ s', stepStmts (aft3PreLoopG_init0 Q K V M Out L sm_scale sqz sqh sqm sqk skz skh skn skk svz svh svk svn soz soh som son H H_KV N_CTX ROUND_CTX NKV_CTX off size BM ND BN) s = some s'
      ∧ aft3SafeInv K V M Out L s (s.pids 1 / H * sqz + s.pids 1 % H * sqh) BM ND NKV_CTX BN skk skn svk svn som son ROUND_CTX 0 s' := by
  obtain ⟨s11, h11, hpids, hmem, huf, hstart, hoffhz, hQp, hKp, hVp, hOp, hMptr, hLptr⟩ :=
    aft3PreLoopScalarsG_eval Q K V M Out L sm_scale sqz sqh sqm sqk skz skh skn skk svz svh svk svn soz soh som son H H_KV N_CTX ROUND_CTX NKV_CTX off size BM ND BN s hH hHKV hskz hskh hsvz hsvh hsoz hsoh
  rw [show aft3PreLoopG_init0 Q K V M Out L sm_scale sqz sqh sqm sqk skz skh skn skk svz svh svk svn soz soh som son H H_KV N_CTX ROUND_CTX NKV_CTX off size BM ND BN
      = aft3PreLoopScalarsG Q K V M Out L sm_scale sqz sqh sqm sqk skz skh skn skk svz svh svk svn soz soh som son H H_KV N_CTX ROUND_CTX NKV_CTX off size BM ND BN ++ (aft3PreLoopG_init0 Q K V M Out L sm_scale sqz sqh sqm sqk skz skh skn skk svz svh svk svn soz soh som son H H_KV N_CTX ROUND_CTX NKV_CTX off size BM ND BN).drop 16 from by
    rw [show aft3PreLoopScalarsG Q K V M Out L sm_scale sqz sqh sqm sqk skz skh skn skk svz svh svk svn soz soh som son H H_KV N_CTX ROUND_CTX NKV_CTX off size BM ND BN
        = (aft3PreLoopG_init0 Q K V M Out L sm_scale sqz sqh sqm sqk skz skh skn skk svz svh svk svn soz soh som son H H_KV N_CTX ROUND_CTX NKV_CTX off size BM ND BN).take 16 from rfl]
    rw [List.take_append_drop]]
  rw [stepStmts.append_some h11]
  rw [show (aft3PreLoopG_init0 Q K V M Out L sm_scale sqz sqh sqm sqk skz skh skn skk svz svh svk svn soz soh som son H H_KV N_CTX ROUND_CTX NKV_CTX off size BM ND BN).drop 16
      = [ Stmt.ifThenElse (Op.ne ComparableDType.nat Broadcast.nil (Op.constNat 0) (Op.constNat 0)) [Stmt.assign TileDType.real [BM] "m_i" ((Op.add NumericDType.real Broadcast.scalarR (Op.full [BM] (Op.const 0)) Op.negInf)), Stmt.assign TileDType.real [BM] "l_i" ((Op.add NumericDType.real Broadcast.scalarR (Op.full [BM] (Op.const 0)) (Op.const 1.0))), Stmt.assign TileDType.real [BM, ND] "acc" (Op.full [BM, ND] (Op.const 0))] [Stmt.assign TileDType.real [BM] "m_i" (Op.load TileDType.real (MemAccess.ptr (Op.ref TileDType.ptr [BM] "m_ptrs")) MaskOpt.none), Stmt.assign TileDType.real [BM] "l_i" (Op.load TileDType.real (MemAccess.ptr (Op.ref TileDType.ptr [BM] "l_ptrs")) MaskOpt.none), Stmt.assign TileDType.real [BM, ND] "acc" (Op.load TileDType.real (MemAccess.blockPtr (Op.ref TileDType.blockPtr [BM, ND] "O_block_ptr") []) MaskOpt.none .unspecified)],
          Stmt.assign TileDType.real [] "qk_scale" (Op.mul NumericDType.real Broadcast.nil (Op.const sm_scale) (Op.const 1.0)),
          Stmt.assign TileDType.real [] "qk_scale" (Op.mul NumericDType.real Broadcast.nil (Op.ref TileDType.real [] "qk_scale") (Op.const 1.4426950408889634)),
          Stmt.ifThenElse (Op.ne ComparableDType.nat Broadcast.nil (Op.constNat 1) (Op.constNat 0)) [Stmt.assign TileDType.real [BM, ND] "q" (Op.load TileDType.real (MemAccess.blockPtr (Op.ref TileDType.blockPtr [BM, ND] "Q_block_ptr") []) MaskOpt.none .unspecified)] [Stmt.assign TileDType.real [BM, ND] "q" (Op.load TileDType.real (MemAccess.blockPtr (Op.ref TileDType.blockPtr [BM, ND] "Q_block_ptr") [0, 1]) MaskOpt.none)] ] from by rfl]
  rw [stepStmts.cons_some
    (show stepStmt _ s11 = some _ from by
      rw [aft3_ifThenElse_false (aft3_ne_zero_zero_false s11),
        aft3_load_stepsG s11 M Out L BM ND (s.pids 1 / H * sqz + s.pids 1 % H * sqh) som son ROUND_CTX
          (by rw [hpids]; exact hMptr) (by rw [hpids]; exact hLptr) (by rw [hpids]; exact hOp)])]
  rw [stepStmts.cons_some (stepStmt_assign_eq_some
    (show evalOp (Op.mul NumericDType.real Broadcast.nil (Op.const sm_scale) (Op.const 1.0)) _
        = some (Tile.scalar (some (sm_scale * 1.0))) from by
      rw [evalOp_mul]
      simp only [evalOp_const, Option.bind_eq_bind, Option.bind_some]
      refine congrArg some (congrArg Tile.scalar ?_)
      simp only [NumericDType.mul, WithBot.realMul, Option.map₂, Option.bind, Option.map]))]
  rw [stepStmts.cons_some (stepStmt_assign_eq_some
    (show evalOp (Op.mul NumericDType.real Broadcast.nil (Op.ref TileDType.real [] "qk_scale") (Op.const 1.4426950408889634)) _
        = some (Tile.scalar (some (sm_scale * 1.4426950408889634))) from by
      rw [evalOp_mul]
      simp only [evalOp_ref, evalOp_const, BlockState.setReg_same, Option.bind_eq_bind,
        Option.bind_some]
      refine congrArg some (congrArg Tile.scalar ?_)
      simp only [NumericDType.mul, WithBot.realMul, Option.map₂, Option.bind, Option.map]
      refine congrArg some ?_; norm_num))]
  rw [stepStmts.cons_some
    (show stepStmt _ _ = some _ from by
      rw [aft3_ifThenElse_true (aft3_ne_one_zero_true _)]
      rw [stepStmts.cons_some (stepStmt_assign_eq_some
        (aft3_load_v_eval Q (s.pids 1 / H * sqz + s.pids 1 % H * sqh) N_CTX ND BM ND sqm sqk (s.pids 0 * BM)
          (Op.ref TileDType.blockPtr [BM, ND] "Q_block_ptr") _
          (by rw [evalOp_ref]
              simp only [BlockState.setReg_ne_name, ne_eq, String.reduceEq, not_false_eq_true,
                BlockState.setReg_same]
              exact hQp)))]
      rw [stepStmts.nil])]
  rw [stepStmts.nil]
  refine ⟨_, rfl, ?_⟩
  refine ⟨by simp, Nat.zero_le _, ?_, ?_,
    ⟨⟨fun idx : TileIndex [BM, ND] => some (s11.readMem Q
        (s.pids 1 / H * sqz + s.pids 1 % H * sqh + (s.pids 0 * BM + idx.1.val) * sqm + idx.2.1.val * sqk))⟩, ?_⟩,
    ⟨sm_scale * 1.4426950408889634, ?_⟩,
    ⟨⟨fun r : TileIndex [BM] =>
        some (s11.readMem M (s11.pids 1 * ROUND_CTX + (s11.pids 0 * BM + r.1.val)))⟩, ?_⟩,
    ⟨⟨fun r : TileIndex [BM] =>
        some (s11.readMem L (s11.pids 1 * ROUND_CTX + (s11.pids 0 * BM + r.1.val)))⟩, ?_⟩,
    ⟨⟨fun idx : TileIndex [BM, ND] => some (s11.readMem Out
        ((s.pids 1 / H * sqz + s.pids 1 % H * sqh) + (s11.pids 0 * BM + idx.1.val) * som + idx.2.1.val * son))⟩, ?_⟩,
    ?_, ?_, ?_, ?_, ?_⟩
  · simp only [BlockState.setReg_ne_name, ne_eq, String.reduceEq, not_false_eq_true,
      BlockState.setReg_same]
    rw [hstart]
  · simp only [BlockState.setReg_ne_name, ne_eq, String.reduceEq, not_false_eq_true,
      BlockState.setReg_same]
    rw [hoffhz]
  · simp only [BlockState.setReg_same]
    refine congrArg some (Tile.ext fun idx => ?_)
    simp only [BlockState.setReg_readMem]
  · simp only [BlockState.setReg_ne_name, ne_eq, String.reduceEq, not_false_eq_true,
      BlockState.setReg_same]
  · simp only [BlockState.setReg_ne_name, ne_eq, String.reduceEq, not_false_eq_true,
      BlockState.setReg_same]
  · simp only [BlockState.setReg_ne_name, ne_eq, String.reduceEq, not_false_eq_true,
      BlockState.setReg_same]
  · simp only [BlockState.setReg_ne_name, ne_eq, String.reduceEq, not_false_eq_true,
      BlockState.setReg_same]
  · simp only [BlockState.setReg_ne_name, ne_eq, String.reduceEq, not_false_eq_true,
      BlockState.setReg_same]
    rw [hKp]
  · simp only [BlockState.setReg_ne_name, ne_eq, String.reduceEq, not_false_eq_true,
      BlockState.setReg_same]
    rw [hVp]
  · simp only [BlockState.setReg_ne_name, ne_eq, String.reduceEq, not_false_eq_true,
      BlockState.setReg_same]
    rw [hMptr]
  · simp only [BlockState.setReg_ne_name, ne_eq, String.reduceEq, not_false_eq_true,
      BlockState.setReg_same]
    rw [hLptr]
  · simp only [BlockState.setReg_ne_name, ne_eq, String.reduceEq, not_false_eq_true,
      BlockState.setReg_same]
    rw [hOp]

set_option maxHeartbeats 8000000 in
set_option maxRecDepth 8000 in
/-- **The `TraceSafeR` walk for the whole case-4 kernel.** The case-1 walk
(shared loop body `aft3LoopBodyG`, shared postLoop) with the prologue's `INIT`
branch flipped: instead of a register-only init, the live branch performs the
three resume **loads**, whose addresses are the `read4` (`M` row), `read5`
(`L` row) and `read6` (`Out` tile) windows — i.e. literally the two write
windows plus `L`'s row, so the discharge reuses the same bound groups. -/
private theorem aft3_traceSafeR_case4 (R : RoundingModel) (bounds : RegionBounds)
    (Q K V M Out L : RegionName) (sm_scale : ℝ)
    (sqz sqh sqm sqk skz skh skn skk svz svh svk svn soz soh som son
      Z H H_KV N_CTX ROUND_CTX NKV_CTX off size BM ND BN : Nat) (s : BlockState)
    (hH : 0 < H) (hHKV : H_KV = H)
    (hskz : skz = sqz) (hskh : skh = sqh) (hsvz : svz = sqz) (hsvh : svh = sqh)
    (hsoz : soz = sqz) (hsoh : soh = sqh)
    (hBN : 0 < BN) (hNC : 0 < NKV_CTX) (hBNdvd : BN ∣ NKV_CTX)
    (hbQ : ∀ (t : Fin (NKV_CTX / BN)) (j : Fin (BM * ND)),
      (s.pids 1 / H * sqz + s.pids 1 % H * sqh) + (s.pids 0 * BM + j.val / ND) * sqm + (j.val % ND) * sqk < bounds Q)
    (hbK : ∀ (t : Fin (NKV_CTX / BN)) (j : Fin (ND * BN)),
      (s.pids 1 / H * sqz + s.pids 1 % H * sqh) + (j.val / BN) * skk + (t.val * BN + j.val % BN) * skn < bounds K)
    (hbV : ∀ (t : Fin (NKV_CTX / BN)) (j : Fin (BN * ND)),
      (s.pids 1 / H * sqz + s.pids 1 % H * sqh) + (t.val * BN + j.val / ND) * svk + (j.val % ND) * svn < bounds V)
    (hbMin : ∀ j : Fin BM, s.pids 1 * ROUND_CTX + (s.pids 0 * BM + j.val) < bounds M)
    (hbLin : ∀ j : Fin BM, s.pids 1 * ROUND_CTX + (s.pids 0 * BM + j.val) < bounds L)
    (hbOin : ∀ j : Fin (BM * ND),
      (s.pids 1 / H * sqz + s.pids 1 % H * sqh) + (s.pids 0 * BM + j.val / ND) * som + (j.val % ND) * son < bounds Out)
    (hbO : ∀ j : Fin (BM * ND),
      (s.pids 1 / H * sqz + s.pids 1 % H * sqh) + (s.pids 0 * BM + j.val / ND) * som + (j.val % ND) * son < bounds Out)
    (hbM : ∀ j : Fin BM, s.pids 1 * ROUND_CTX + (s.pids 0 * BM + j.val) < bounds M) :
    ((attention_fwd_triton3_surface Q K V M Out L sm_scale
      sqz sqh sqm sqk skz skh skn skk svz svh svk svn soz soh som son
      Z H H_KV N_CTX ROUND_CTX NKV_CTX off size 1 1 BM ND BN 1 0 1 0).toAlgKernel).TraceSafeR R bounds s := by
  have hT : 0 < NKV_CTX / BN := Nat.div_pos (Nat.le_of_dvd hNC hBNdvd) hBN
  unfold Kernel.TraceSafeR
  rw [aft3_body_splitG4]
  refine Stmt.TraceSafeListR.append_intro _ _ ?_ ?_
  · -- the preLoop
    obtain ⟨s11, h11, hpids, hmem, huf, hstart, hoffhz, hQp, hKp, hVp, hOp, hMptr, hLptr⟩ :=
      aft3PreLoopScalarsG_eval Q K V M Out L sm_scale sqz sqh sqm sqk skz skh skn skk svz svh svk svn soz soh som son H H_KV N_CTX ROUND_CTX NKV_CTX off size BM ND BN s hH hHKV hskz hskh hsvz hsvh hsoz hsoh
    rw [show aft3PreLoopG_init0 Q K V M Out L sm_scale sqz sqh sqm sqk skz skh skn skk svz svh svk svn soz soh som son H H_KV N_CTX ROUND_CTX NKV_CTX off size BM ND BN
        = aft3PreLoopScalarsG Q K V M Out L sm_scale sqz sqh sqm sqk skz skh skn skk svz svh svk svn soz soh som son H H_KV N_CTX ROUND_CTX NKV_CTX off size BM ND BN ++ (aft3PreLoopG_init0 Q K V M Out L sm_scale sqz sqh sqm sqk skz skh skn skk svz svh svk svn soz soh som son H H_KV N_CTX ROUND_CTX NKV_CTX off size BM ND BN).drop 16 from by
      rw [show aft3PreLoopScalarsG Q K V M Out L sm_scale sqz sqh sqm sqk skz skh skn skk svz svh svk svn soz soh som son H H_KV N_CTX ROUND_CTX NKV_CTX off size BM ND BN
          = (aft3PreLoopG_init0 Q K V M Out L sm_scale sqz sqh sqm sqk skz skh skn skk svz svh svk svn soz soh som son H H_KV N_CTX ROUND_CTX NKV_CTX off size BM ND BN).take 16 from rfl]
      rw [List.take_append_drop]]
    refine Stmt.TraceSafeListR.append_intro _ _ ?_ ?_
    · -- statements 0–15: register-only assigns, safe at every state
      refine Stmt.TraceSafeListR.of_forall _ _ ?_
      intro st hst u
      simp only [aft3PreLoopScalarsG, aft3PreLoopG, List.take_succ_cons, List.take_zero,
        List.mem_cons, List.not_mem_nil, or_false] at hst
      rcases hst with rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl | rfl |
        rfl | rfl | rfl | rfl <;>
        simp [Stmt.TraceSafeR, Op.SafeAtR]
    · intro s1 hs1
      rw [aft3PreLoopScalarsG_castFree R Q K V M Out L sm_scale sqz sqh sqm sqk skz skh skn skk svz svh svk svn soz soh som son H H_KV N_CTX ROUND_CTX NKV_CTX off size BM ND BN s, h11] at hs1
      obtain rfl := Option.some.inj hs1
      rw [show (aft3PreLoopG_init0 Q K V M Out L sm_scale sqz sqh sqm sqk skz skh skn skk svz svh svk svn soz soh som son H H_KV N_CTX ROUND_CTX NKV_CTX off size BM ND BN).drop 16
          = [ Stmt.ifThenElse (Op.ne ComparableDType.nat Broadcast.nil (Op.constNat 0) (Op.constNat 0)) [Stmt.assign TileDType.real [BM] "m_i" ((Op.add NumericDType.real Broadcast.scalarR (Op.full [BM] (Op.const 0)) Op.negInf)), Stmt.assign TileDType.real [BM] "l_i" ((Op.add NumericDType.real Broadcast.scalarR (Op.full [BM] (Op.const 0)) (Op.const 1.0))), Stmt.assign TileDType.real [BM, ND] "acc" (Op.full [BM, ND] (Op.const 0))] [Stmt.assign TileDType.real [BM] "m_i" (Op.load TileDType.real (MemAccess.ptr (Op.ref TileDType.ptr [BM] "m_ptrs")) MaskOpt.none), Stmt.assign TileDType.real [BM] "l_i" (Op.load TileDType.real (MemAccess.ptr (Op.ref TileDType.ptr [BM] "l_ptrs")) MaskOpt.none), Stmt.assign TileDType.real [BM, ND] "acc" (Op.load TileDType.real (MemAccess.blockPtr (Op.ref TileDType.blockPtr [BM, ND] "O_block_ptr") []) MaskOpt.none .unspecified)],
              Stmt.assign TileDType.real [] "qk_scale" (Op.mul NumericDType.real Broadcast.nil (Op.const sm_scale) (Op.const 1.0)),
              Stmt.assign TileDType.real [] "qk_scale" (Op.mul NumericDType.real Broadcast.nil (Op.ref TileDType.real [] "qk_scale") (Op.const 1.4426950408889634)),
              Stmt.ifThenElse (Op.ne ComparableDType.nat Broadcast.nil (Op.constNat 1) (Op.constNat 0)) [Stmt.assign TileDType.real [BM, ND] "q" (Op.load TileDType.real (MemAccess.blockPtr (Op.ref TileDType.blockPtr [BM, ND] "Q_block_ptr") []) MaskOpt.none .unspecified)] [Stmt.assign TileDType.real [BM, ND] "q" (Op.load TileDType.real (MemAccess.blockPtr (Op.ref TileDType.blockPtr [BM, ND] "Q_block_ptr") [0, 1]) MaskOpt.none)] ] from by rfl]
      -- the INIT ifThenElse: the three resume loads (`read4`/`read5`/`read6`)
      refine Stmt.TraceSafeListR.cons_intro ?_ (fun u1 hu1 => ?_)
      · simp only [Stmt.TraceSafeR]
        refine ⟨by simp [Op.SafeAtR.eq_def], ?_⟩
        rw [aft3_evalOpR_ne_const, aft3_ne_zero_zero_false]
        show Stmt.TraceSafeListR R bounds
          [Stmt.assign TileDType.real [BM] "m_i" (Op.load TileDType.real (MemAccess.ptr (Op.ref TileDType.ptr [BM] "m_ptrs")) MaskOpt.none),
           Stmt.assign TileDType.real [BM] "l_i" (Op.load TileDType.real (MemAccess.ptr (Op.ref TileDType.ptr [BM] "l_ptrs")) MaskOpt.none),
           Stmt.assign TileDType.real [BM, ND] "acc" (Op.load TileDType.real (MemAccess.blockPtr (Op.ref TileDType.blockPtr [BM, ND] "O_block_ptr") []) MaskOpt.none .unspecified)] s11
        -- `m_i = tl.load(m_ptrs)`: the `read4` window on `M`
        refine Stmt.TraceSafeListR.cons_intro ?_ (fun v1 hv1 => ?_)
        · simp only [Stmt.TraceSafeR, Op.SafeAtR.eq_def, MaskOpt.ActiveR,
            MemAccess.ActiveAddressSafeR, memAccessActiveAddressSafeR]
          refine ⟨trivial, trivial, ?_⟩
          intro ptrs hptrs r _
          rw [evalOpR_ref, hMptr] at hptrs
          obtain rfl := Option.some.inj hptrs
          have hbound := hbMin r.1
          simpa [Tile.ptrAdd_data, Tile.scalar_data, Tile.bop_data, Tile.vec_data,
            Broadcast.leftIndex_scalarL, Broadcast.rightIndex_scalarL, Broadcast.leftIndex_nil,
            Broadcast.rightIndex_nil, NumericDType.add, Nat.zero_add] using hbound
        obtain ⟨v1t, -, rfl⟩ := stepStmtR_assign_inv hv1
        -- `l_i = tl.load(l_ptrs)`: the `read5` window on `L`
        refine Stmt.TraceSafeListR.cons_intro ?_ (fun v2 hv2 => ?_)
        · simp only [Stmt.TraceSafeR, Op.SafeAtR.eq_def, MaskOpt.ActiveR,
            MemAccess.ActiveAddressSafeR, memAccessActiveAddressSafeR]
          refine ⟨trivial, trivial, ?_⟩
          intro ptrs hptrs r _
          rw [evalOpR_ref] at hptrs
          simp only [BlockState.setReg_ne_name, ne_eq, String.reduceEq, not_false_eq_true] at hptrs
          rw [hLptr] at hptrs
          obtain rfl := Option.some.inj hptrs
          have hbound := hbLin r.1
          simpa [Tile.ptrAdd_data, Tile.scalar_data, Tile.bop_data, Tile.vec_data,
            Broadcast.leftIndex_scalarL, Broadcast.rightIndex_scalarL, Broadcast.leftIndex_nil,
            Broadcast.rightIndex_nil, NumericDType.add, Nat.zero_add] using hbound
        obtain ⟨v2t, -, rfl⟩ := stepStmtR_assign_inv hv2
        -- `acc = tl.load(O_block_ptr)`: the `read6` window on `Out`
        refine Stmt.TraceSafeListR.cons_intro ?_ (fun _ _ => Stmt.TraceSafeListR.nil_intro)
        simp only [Stmt.TraceSafeR, Op.SafeAtR.eq_def, MaskOpt.ActiveR,
          MemAccess.ActiveAddressSafeR, memAccessActiveAddressSafeR]
        refine ⟨trivial, trivial, ?_⟩
        intro ptrs hptrs idx _
        rw [evalOpR_ref] at hptrs
        simp only [BlockState.setReg_ne_name, ne_eq, String.reduceEq, not_false_eq_true] at hptrs
        rw [hOp] at hptrs
        obtain rfl := Option.some.inj hptrs
        intro _
        have hbound := hbOin (Lane2D.encode (idx.1, idx.2.1, PUnit.unit))
        simp only [Lane2D.encode_div, Lane2D.encode_mod] at hbound
        simpa using hbound
      rw [aft3_ifThenElse_falseR R (by rw [aft3_evalOpR_ne_const]; exact aft3_ne_zero_zero_false _)] at hu1
      obtain ⟨w1, hw1, hu1⟩ := aft3_stepStmtsR_cons_inv hu1
      obtain ⟨va, -, rfl⟩ := stepStmtR_assign_inv hw1
      obtain ⟨w2, hw2, hu1⟩ := aft3_stepStmtsR_cons_inv hu1
      obtain ⟨vb, -, rfl⟩ := stepStmtR_assign_inv hw2
      obtain ⟨w3, hw3, hu1⟩ := aft3_stepStmtsR_cons_inv hu1
      obtain ⟨vc, -, rfl⟩ := stepStmtR_assign_inv hw3
      rw [stepStmtsR_nil] at hu1
      obtain rfl := Option.some.inj hu1
      -- qk_scale ×2 (register-only)
      refine Stmt.TraceSafeListR.cons_intro
        (by simp [Stmt.TraceSafeR, Op.SafeAtR.eq_def]) (fun u2 hu2 => ?_)
      obtain ⟨vd, -, rfl⟩ := stepStmtR_assign_inv hu2
      refine Stmt.TraceSafeListR.cons_intro
        (by simp [Stmt.TraceSafeR, Op.SafeAtR.eq_def]) (fun u3 hu3 => ?_)
      obtain ⟨ve, -, rfl⟩ := stepStmtR_assign_inv hu3
      -- the IS_EVEN_M ifThenElse: the live `Q_block_ptr` load (`read1` bound)
      refine Stmt.TraceSafeListR.cons_intro ?_ (fun _ _ => Stmt.TraceSafeListR.nil_intro)
      simp only [Stmt.TraceSafeR]
      refine ⟨by simp [Op.SafeAtR.eq_def], ?_⟩
      rw [aft3_evalOpR_ne_const, aft3_ne_one_zero_true]
      show Stmt.TraceSafeListR R bounds
        [Stmt.assign TileDType.real [BM, ND] "q" (Op.load TileDType.real (MemAccess.blockPtr (Op.ref TileDType.blockPtr [BM, ND] "Q_block_ptr") []) MaskOpt.none .unspecified)] _
      refine Stmt.TraceSafeListR.cons_intro ?_ (fun _ _ => Stmt.TraceSafeListR.nil_intro)
      simp only [Stmt.TraceSafeR, Op.SafeAtR.eq_def, MaskOpt.ActiveR,
        MemAccess.ActiveAddressSafeR, memAccessActiveAddressSafeR]
      refine ⟨trivial, trivial, ?_⟩
      intro ptrs hptrs idx _
      rw [evalOpR_ref] at hptrs
      simp only [BlockState.setReg_ne_name, ne_eq, String.reduceEq, not_false_eq_true] at hptrs
      rw [hQp] at hptrs
      obtain rfl := Option.some.inj hptrs
      intro _
      have hbound := hbQ ⟨0, hT⟩ (Lane2D.encode (idx.1, idx.2.1, PUnit.unit))
      simp only [Lane2D.encode_div, Lane2D.encode_mod] at hbound
      simpa using hbound

  · -- after the preLoop: the KV loop, then the postLoop
    intro s2 hs2
    obtain ⟨spW, hpreW, hinv0⟩ :=
      aft3PreLoop_evalW_init0 Q K V M Out L sm_scale sqz sqh sqm sqk skz skh skn skk svz svh svk svn soz soh som son H H_KV N_CTX ROUND_CTX NKV_CTX off size BM ND BN s hH hHKV hskz hskh hsvz hsvh hsoz hsoh
    rw [aft3PreLoopG_init0_castFree R Q K V M Out L sm_scale sqz sqh sqm sqk skz skh skn skk svz svh svk svn soz soh som son H H_KV N_CTX ROUND_CTX NKV_CTX off size BM ND BN s, hpreW] at hs2
    obtain rfl := Option.some.inj hs2
    refine Stmt.TraceSafeListR.cons_intro ?_ (fun s3 hs3 => ?_)
    · -- the KV loop is trace-safe (invariant principle over `aft3SafeInv`)
      simp only [Stmt.TraceSafeR]
      refine Stmt.forRangeTraceSafeR_inv R bounds "start_n" NKV_CTX BN
        (aft3LoopBodyG sm_scale off size BM ND BN)
        (aft3SafeInv K V M Out L s (s.pids 1 / H * sqz + s.pids 1 % H * sqh) BM ND NKV_CTX BN skk skn svk svn som son ROUND_CTX) ?_ 0 spW hinv0
      intro c st hc hP
      refine ⟨aft3_bodySafeW1 R bounds K V M Out L s sm_scale (s.pids 1 / H * sqz + s.pids 1 % H * sqh) BM ND NKV_CTX BN skk skn svk svn som son ROUND_CTX off size hBN hBNdvd c st hc hP hbK hbV, ?_⟩
      obtain ⟨st', hstep, hP'⟩ :=
        aft3_attn_stepW1 K V M Out L s sm_scale (s.pids 1 / H * sqz + s.pids 1 % H * sqh) BM ND NKV_CTX BN skk skn svk svn som son ROUND_CTX off size hBN hBNdvd c st hc hP
      exact ⟨st', by rw [aft3LoopBodyG_castFree]; exact hstep, hP'⟩
    · -- identify the post-loop state and finish on the postLoop stores
      obtain ⟨final, sfin, hLoop, hfinal, hPfin⟩ :=
        forRange_inv (idx := "start_n") (start := 0) (stop := NKV_CTX) (step := BN)
          (body := aft3LoopBodyG sm_scale off size BM ND BN)
          (P := aft3SafeInv K V M Out L s (s.pids 1 / H * sqz + s.pids 1 % H * sqh) BM ND NKV_CTX BN skk skn svk svn som son ROUND_CTX)
          (s_init := spW) hBN.ne' hinv0
          (fun c st hc hP =>
            aft3_attn_stepW1 K V M Out L s sm_scale (s.pids 1 / H * sqz + s.pids 1 % H * sqh) BM ND NKV_CTX BN skk skn svk svn som son ROUND_CTX off size hBN hBNdvd c st hc hP)
      rw [show stepStmtR R (Stmt.forRange "start_n" 0 NKV_CTX BN (aft3LoopBodyG sm_scale off size BM ND BN)) spW = some sfin from by
        rw [stepStmtR_forRange,
          stepForRangeAuxR_castFree R _ (aft3LoopBodyG_castFree R sm_scale off size BM ND BN) "start_n",
          ← stepForRangeAux.forRange_unfold]
        exact hLoop] at hs3
      obtain rfl := Option.some.inj hs3
      exact aft3_postSafeW R bounds K V M Out L s (s.pids 1 / H * sqz + s.pids 1 % H * sqh) BM ND NKV_CTX BN skk skn svk svn som son ROUND_CTX final sfin hPfin hbO hbM

/-! ### ════════ ★ MAIN THEOREM ★ ════════ -/
set_option maxHeartbeats 8000000 in
set_option maxRecDepth 8000 in
/-- **The case-4 `⊨[R]` io headline (`INIT=0` cross-launch resume).** For every
rounding model `R`, the case-4
(`(END,INIT,SLIDING_WINDOW,COMPLEMENT) = (1,0,1,0)`) `_attn_fwd` surface
implements, on its `StreamMasked3DKernelIO₆ₓ₂` signature, the **ideal-ℝ
resume-seeded sliding-window online-softmax attention fold** over the six
streamed tiles: output lane `j = (i, d)` of `Out` holds the window-filtered
base-2 per-key-scale fold started from the loaded running state
(`attentionFwdTriton3Case4IOOutSpec` = the existing
`attentionFwdTriton3Case4OutSpecG` closed form restated on the streams, with
the seed `aft3IOseedT` read off streams 4/5/6), and row `i` of `M` holds the
raw `(m + log2 l).unbotD 0` finalize of that same fold
(`attentionFwdTriton3Case4IOMSpec` = `attentionFwdTriton3Case4MSpecG` on the
streams). Both output grids are the `.real` default, so at every `R` the
terminal cells carry the exact fold values.

**Aliasing** (the point of this exemplar): `inp6 = out1 = Out` and
`inp4 = out2 = M`, so the skin's region list repeats two names. See the
section note above for why that is sound — one name, one segment; the input
pins read `s₀` while the readbacks read `s'`; the frame still says only the
two write windows moved. `L` (`inp5`) is read-only in case 4, its store
living in the dead `END=0` branch.

**Hypothesis provenance** (inherited verbatim from the exact case-4 headline
`attention_fwd_triton3_python_case4_output_summary_general`, all
truth-forced): `0 < ND/BM/BN/NKV_CTX` and `BN ∣ NKV_CTX` shape the KV walk
(`T = NKV_CTX / BN` full blocks); `0 < H`, `H_KV = H` and the six stride
equalities collapse the four plane offsets onto the shared base
`pid₁/H·sqz + pid₁%H·sqh`; `M ≠ Out` keeps the `O` store off the `M` row;
`hinjO`/`hinjM` (∀-pids forms of the exact stack's per-program injectivity)
make the scatter readbacks well-defined. The exact headline's `hundef` is not
a hypothesis — the skin's Hoare triple carries the `undef` pin itself.

**Scope**: with this headline all **four** constexpr cases of the file carry
`⊨[R]` io faces. The port's known fidelity gaps (`IS_EVEN_N = 1` hardwired,
casts erased to identity, `@triton.heuristics` not modeled) are inherited
as-is from the surface. -/
specification attention_fwd_triton3_case4_io_correctness (R : RoundingModel)
    (Q K V M Out L : RegionName) (sm_scale : ℝ)
    (sqz sqh sqm sqk skz skh skn skk svz svh svk svn soz soh som son
      Z H H_KV N_CTX ROUND_CTX NKV_CTX off size BM ND BN : Nat)
    (hND : 0 < ND) (hBM : 0 < BM) (hBN : 0 < BN) (hNC : 0 < NKV_CTX) (hBNdvd : BN ∣ NKV_CTX)
    (hH : 0 < H) (hHKV : H_KV = H)
    (hskz : skz = sqz) (hskh : skh = sqh) (hsvz : svz = sqz) (hsvh : svh = sqh)
    (hsoz : soz = sqz) (hsoh : soh = sqh)
    (hMO : M ≠ Out)
    (hinjO : ∀ p₀ p₁ : Nat, Function.Injective
      (fun idx : TileIndex [BM, ND] =>
        (p₁ / H * sqz + p₁ % H * sqh) + (p₀ * BM + idx.1.val) * som + idx.2.1.val * son))
    (hinjM : ∀ p₀ p₁ : Nat, Function.Injective
      (fun r : TileIndex [BM] => p₁ * ROUND_CTX + (p₀ * BM + r.1.val))) :
    attentionFwdTriton3Case4IO Q K V M Out L sm_scale sqz sqh sqm sqk skz skh skn skk svz svh svk svn soz soh som son Z H H_KV N_CTX ROUND_CTX NKV_CTX off size BM ND BN ⊨[R]
      fun p₀ _ _ x1s x2s x3s x4s x5s x6s =>
        (fun j => attentionFwdTriton3Case4IOOutSpec p₀ BM ND BN NKV_CTX (NKV_CTX / BN) hND
            (Nat.div_pos (Nat.le_of_dvd hNC hBNdvd) hBN) (Nat.div_mul_cancel hBNdvd) hBN
            (sm_scale * 1.4426950408889634) off size x1s x2s x3s x4s x5s x6s j,
         fun i => attentionFwdTriton3Case4IOMSpec p₀ BM ND BN NKV_CTX (NKV_CTX / BN) hND
            (Nat.div_pos (Nat.le_of_dvd hNC hBNdvd) hBN) (Nat.div_mul_cancel hBNdvd) hBN
            (sm_scale * 1.4426950408889634) off size x1s x2s x3s x4s x5s x6s i) := by
  have hT : 0 < NKV_CTX / BN := Nat.div_pos (Nat.le_of_dvd hNC hBNdvd) hBN
  have hTB : NKV_CTX / BN * BN = NKV_CTX := Nat.div_mul_cancel hBNdvd
  refine StreamMasked3DKernelIO₆ₓ₂.ImplementsR.intro _ ?_ ?_ ?_
  · exact aft3_flattenOkG4 Q K V M Out L sm_scale sqz sqh sqm sqk skz skh skn skk svz svh svk svn soz soh som son Z H H_KV N_CTX ROUND_CTX NKV_CTX off size BM ND BN
  · -- the safety walk
    intro bounds s x1s x2s x3s x4s x5s x6s _hlaunch _hx1 _hx2 _hx3 _hx4 _hx5 _hx6
      hbr1 hbr2 hbr3 hbr4 hbr5 hbr6 hbw1 hbw2
    simp only [attentionFwdTriton3Case4IO] at hbr1 hbr2 hbr3 hbr4 hbr5 hbr6 hbw1 hbw2 ⊢
    exact aft3_traceSafeR_case4 R bounds Q K V M Out L sm_scale
      sqz sqh sqm sqk skz skh skn skk svz svh svk svn soz soh som son
      Z H H_KV N_CTX ROUND_CTX NKV_CTX off size BM ND BN s hH hHKV hskz hskh hsvz hsvh hsoz hsoh
      hBN hNC hBNdvd
      (fun t j => hbr1 t j trivial) (fun t j => hbr2 t j trivial)
      (fun t j => hbr3 t j trivial) (fun j => hbr4 ⟨0, hT⟩ j trivial)
      (fun j => hbr5 ⟨0, hT⟩ j trivial) (fun j => hbr6 ⟨0, hT⟩ j trivial)
      (fun j => hbw1 j trivial) (fun j => hbw2 j trivial)
  · -- the rounded Hoare triple: exact seeded invariant stack + cast-free collapses
    intro s₀ x1s x2s x3s x4s x5s x6s _hlaunch hu hx1 hx2 hx3 hx4 hx5 hx6
    simp only [attentionFwdTriton3Case4IO] at hx1 hx2 hx3 hx4 hx5 hx6 ⊢
    have hundef' : ∀ rg o, s₀.undef rg o = 0 := fun rg o => by rw [hu]
    set base := s₀.pids 1 / H * sqz + s₀.pids 1 % H * sqh with hbase
    set sc := sm_scale * 1.4426950408889634 with hsc
    set seed := aft3Case4Seed s₀ M Out L base BM ND som son ROUND_CTX with hseed
    have hseednebot : ∀ i d, (seed i d).1 ≠ ⊥ := fun i d => WithBot.coe_ne_bot
    have hseedfst : ∀ (r : Fin BM) (d d' : Fin ND), (seed r d).1 = (seed r d').1 :=
      fun r d d' => rfl
    obtain ⟨sp, hpre, hinv0⟩ :=
      aft3PreLoop_evalG_init0 Q K V M Out L sm_scale sqz sqh sqm sqk skz skh skn skk svz svh svk svn soz soh som son H H_KV N_CTX ROUND_CTX NKV_CTX off size BM ND BN s₀ hND hH hHKV hskz hskh hsvz hsvh hsoz hsoh (fun i j => natSlidingWindowKeepG (s₀.pids 0) BM BN off size i j) hundef'
    obtain ⟨final, sL, hloop, hfin, hinvL⟩ :=
      forRange_inv (idx := "start_n") (start := 0) (stop := NKV_CTX) (step := BN)
        (body := aft3LoopBodyG sm_scale off size BM ND BN)
        (P := fun i st => attnInvariantSeededG Q K V M Out L s₀ base BM ND NKV_CTX BN sqm sqk skn skk svk svn som son ROUND_CTX hND sc (fun i j => natSlidingWindowKeepG (s₀.pids 0) BM BN off size i j) seed i st)
        (s_init := sp)
        hBN.ne'
        hinv0
        (fun i st hi hP => aft3_attn_step1_seededG Q K V M Out L s₀ base BM ND NKV_CTX BN sqm sqk skn skk svk svn som son ROUND_CTX off size hND hBM hBN hBNdvd sc seed hseednebot hseedfst i st hi
          (by obtain ⟨_, hmod, _, _⟩ := hP; exact hmod) hP)
    have hfinal : final = NKV_CTX := by
      obtain ⟨_, hmod, hle, _⟩ := hinvL
      rcases Nat.lt_or_ge final NKV_CTX with h | h
      · exact absurd h (by simpa using hfin)
      · exact Nat.le_antisymm hle h
    subst final
    obtain ⟨sF, hpost, hO, hM⟩ :=
      aft3PostLoop_eval_seededG Q K V M Out L s₀ sL base BM ND NKV_CTX BN sqm sqk skn skk svk svn som son ROUND_CTX hND sc hMO (fun i j => natSlidingWindowKeepG (s₀.pids 0) BM BN off size i j) seed
        (hinjO (s₀.pids 0) (s₀.pids 1)) (hinjM (s₀.pids 0) (s₀.pids 1)) hinvL
    obtain ⟨hpidsL, _, _, _, _, _, _, _, _, _, _, _, hMptrL, _, hOpL, _, hmemL⟩ := hinvL
    have hframe := aft3PostLoop_frameW M Out L s₀ base BM ND som son ROUND_CTX sL sF hMptrL hOpL hpost
    refine ⟨sF, ?_, ?_, ?_, ?_⟩
    · -- termination under `execR R` (everything cast-free)
      show execR R (attention_fwd_triton3_surface Q K V M Out L sm_scale
        sqz sqh sqm sqk skz skh skn skk svz svh svk svn soz soh som son
        Z H H_KV N_CTX ROUND_CTX NKV_CTX off size 1 1 BM ND BN 1 0 1 0).toAlgKernel s₀ = some sF
      unfold execR
      rw [aft3_body_splitG4, stepStmtsR_append,
        aft3PreLoopG_init0_castFree R Q K V M Out L sm_scale sqz sqh sqm sqk skz skh skn skk svz svh svk svn soz soh som son H H_KV N_CTX ROUND_CTX NKV_CTX off size BM ND BN s₀,
        hpre, Option.bind_some,
        stepStmtsR_cons_some (show stepStmtR R (Stmt.forRange "start_n" 0 NKV_CTX BN (aft3LoopBodyG sm_scale off size BM ND BN)) sp = some sL from by
          rw [stepStmtR_forRange,
            stepForRangeAuxR_castFree R _ (aft3LoopBodyG_castFree R sm_scale off size BM ND BN) "start_n",
            ← stepForRangeAux.forRange_unfold]
          exact hloop),
        aft3PostLoopG_castFree R M Out L BM ND sL]
      exact hpost
    · -- Out readback = the streamed resume-seeded closed form
      intro j _
      have hOj := hO (Lane2D.decode j)
      rw [show base + (s₀.pids 0 * BM + (Lane2D.decode j).1.val) * som + (Lane2D.decode j).2.1.val * son
          = base + (s₀.pids 0 * BM + j.val / ND) * som + (j.val % ND) * son from by
        simp only [Lane2D.decode_row, Lane2D.decode_col]] at hOj
      rw [BlockState.readMemAs_real, hOj, hseed,
        aft3IOqT_eq s₀ Q base sqm sqk BM ND (NKV_CTX / BN) hT x1s (fun t j' => hx1 t j' trivial),
        aft3IOkT_eq s₀ K base skn skk ND BN NKV_CTX (NKV_CTX / BN) hTB hBN x2s (fun t j' => hx2 t j' trivial),
        aft3IOvT_eq s₀ V base svk svn ND BN NKV_CTX (NKV_CTX / BN) hTB hBN x3s (fun t j' => hx3 t j' trivial),
        aft3IOseedT_eq s₀ M Out L base BM ND som son ROUND_CTX (NKV_CTX / BN) hT x4s x5s x6s
          (fun t j' => hx4 t j' trivial) (fun t j' => hx5 t j' trivial)
          (fun t j' => hx6 t j' trivial)]
      unfold attentionFwdTriton3Case4IOOutSpec
      simp [FloatDType.ofReal]
    · -- M readback = the streamed raw finalize
      intro i _
      rw [BlockState.readMemAs_real, hM i, hseed,
        aft3IOqT_eq s₀ Q base sqm sqk BM ND (NKV_CTX / BN) hT x1s (fun t j' => hx1 t j' trivial),
        aft3IOkT_eq s₀ K base skn skk ND BN NKV_CTX (NKV_CTX / BN) hTB hBN x2s (fun t j' => hx2 t j' trivial),
        aft3IOvT_eq s₀ V base svk svn ND BN NKV_CTX (NKV_CTX / BN) hTB hBN x3s (fun t j' => hx3 t j' trivial),
        aft3IOseedT_eq s₀ M Out L base BM ND som son ROUND_CTX (NKV_CTX / BN) hT x4s x5s x6s
          (fun t j' => hx4 t j' trivial) (fun t j' => hx5 t j' trivial)
          (fun t j' => hx6 t j' trivial)]
      unfold attentionFwdTriton3Case4IOMSpec
      simp [FloatDType.ofReal]
    · -- the frame: cells outside the two write windows are untouched
      intro r oo hcond
      obtain ⟨h1, h2⟩ := hcond
      rw [hframe r oo ?_ ?_, hmemL]
      · intro hr i
        exact fun hoo => h2 i trivial hr hoo
      · intro hr idx
        have h := h1 (Lane2D.encode (idx.1, idx.2.1, PUnit.unit)) trivial hr
        simpa [Lane2D.encode_div, Lane2D.encode_mod] using h


end IOFace

end VeriTile.Bench.TritonBenchG.AttentionFwdTriton3
