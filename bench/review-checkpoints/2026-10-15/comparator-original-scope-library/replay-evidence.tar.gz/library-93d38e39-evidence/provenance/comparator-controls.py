import hashlib
import json
import os
from pathlib import Path
import subprocess
import sys
import time

sys.path.insert(0, '/opt/veritile-tools/scripts')
from comparator_common import comparator_command, require_tools, write_config

assert os.getuid() == 2000
comparator = require_tools()
root = Path('/home/judge/comparator-controls')
root.mkdir()
cases = {
    'positive': 'theorem target : True := True.intro\n',
    'changed-statement': 'theorem target : 1 = 1 := rfl\n',
    'sorry': 'theorem target : True := by sorry\n',
    'source-write': 'import Lean\nopen Lean Elab Command\nrun_cmd do\n  liftIO <| IO.FS.writeFile "Challenge.lean" "theorem target : True := True.intro\\n-- tampered\\n"\ntheorem target : True := True.intro\n',
}
results = []
for label, solution in cases.items():
    case = root / label
    case.mkdir()
    (case / 'lean-toolchain').write_text('leanprover/lean4:v4.29.0\n')
    (case / 'lakefile.toml').write_text('name = "controls"\n[[lean_lib]]\nname = "Challenge"\n[[lean_lib]]\nname = "Solution"\n')
    (case / 'lake-manifest.json').write_text(json.dumps({
        'version': '1.1.0', 'packagesDir': '.lake/packages', 'packages': [],
        'name': 'controls', 'lakeDir': '.lake'}))
    (case / '.lake').mkdir()
    challenge = case / 'Challenge.lean'
    challenge.write_text('theorem target : True := True.intro\n')
    before = hashlib.sha256(challenge.read_bytes()).hexdigest()
    (case / 'Solution.lean').write_text(solution)
    config = write_config(case, ['target'], challenge='Challenge', solution='Solution')
    command = comparator_command(case, comparator, config)
    start = time.time()
    with (case / 'comparator.log').open('w') as log:
        proc = subprocess.run(command, cwd=case, stdout=log, stderr=subprocess.STDOUT)
    result = {'case': label, 'argv': command, 'exit': proc.returncode,
              'elapsed': time.time() - start, 'challenge_before_sha256': before,
              'challenge_after_sha256': hashlib.sha256(challenge.read_bytes()).hexdigest()}
    log = (case / 'comparator.log').read_text()
    assert result['challenge_after_sha256'] == before
    if label == 'positive':
        assert proc.returncode == 0, log
    else:
        assert proc.returncode != 0, log
        marker = {'changed-statement': 'theorem statement do not match',
                  'sorry': 'sorryAx', 'source-write': 'permission denied'}[label]
        assert marker.lower() in log.lower(), log
    result['expected_behavior_verified'] = True
    results.append(result)
    print(json.dumps(result), flush=True)
    (root / 'results.json').write_text(json.dumps(results, indent=2) + '\n')
print('All real official comparator controls passed', flush=True)
