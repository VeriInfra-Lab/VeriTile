import ctypes
import hashlib
import json
import os
from pathlib import Path
import platform
import subprocess
import time

root = Path('/opt/veritile-tools')
report = {'uid': os.getuid(), 'kernel': platform.release(), 'started': time.time(), 'checks': []}
assert os.getuid() == 2000
manifest = json.loads((root / 'manifest.json').read_text())
report['media_hashes'] = {name: hashlib.sha256((root / name).read_bytes()).hexdigest() for name in manifest}
assert report['media_hashes'] == manifest
libc = ctypes.CDLL(None, use_errno=True)
report['landlock_abi'] = libc.syscall(444, ctypes.c_void_p(0), ctypes.c_size_t(0), ctypes.c_uint(1))
assert report['landlock_abi'] >= 1

def check(label, command, expected):
    p = subprocess.run(command, capture_output=True, text=True)
    report['checks'].append({'label': label, 'command': command, 'exit': p.returncode,
                             'stdout': p.stdout, 'stderr': p.stderr, 'expected': expected})
    assert p.returncode == expected, report['checks'][-1]

socket_probe = 'import socket; s = socket.socket(socket.AF_UNIX, socket.SOCK_STREAM); s.close()'
check('unrestricted AF_UNIX succeeds', ['python3', '-c', socket_probe], 0)
check('systemd RestrictAddressFamilies denies AF_UNIX',
      ['systemd-run', '--user', '--pipe', '--wait', '--collect',
       '--property=RestrictAddressFamilies=~AF_UNIX', 'python3', '-c', socket_probe], 1)
sentinel = Path('/home/judge/landlock-write-control.txt')
sentinel.write_text('before\n')
write_probe = 'from pathlib import Path; Path("/home/judge/landlock-write-control.txt").write_text("changed\\n")'
check('unrestricted sentinel write succeeds', ['python3', '-c', write_probe], 0)
sentinel.write_text('before\n')
check('Landlock read-only root denies sentinel write',
      ['landrun', '--rox', '/', '/usr/bin/python3', '-c', write_probe], 1)
assert sentinel.read_text() == 'before\n'
check('unchanged official preflight', ['python3', str(root / 'scripts/check_comparator.py'), '--check-tools'], 0)
report['accepted'] = True
report['finished'] = time.time()
Path('/home/judge/isolation-probe.json').write_text(json.dumps(report, indent=2) + '\n')
print(json.dumps(report, indent=2))
