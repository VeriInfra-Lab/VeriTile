from pathlib import Path
import hashlib
import json
import shutil
import tarfile

home = Path('/home/judge')
source = home / 'current-source'
workspace = home / 'current-library-workspace'
evidence = home / 'current-library-evidence'
run = json.loads((evidence / 'run.json').read_text())
assert run.get('accepted') is True, 'Library has not passed'
ready = json.loads((workspace / 'ready.json').read_text())
original_root = Path(ready['logs'])
inputs = json.loads((original_root / 'inputs.json').read_text())
append = '\n[[lean_lib]]\nname = "VeriTileComparator"\nglobs = ["VeriTileComparator.+"]\n'
after = {}
for name, digest in inputs.items():
    data = (workspace / 'project' / name).read_bytes()
    if name == 'lakefile.toml':
        assert data == (source / name).read_bytes() + append.encode()
        data = data[:-len(append.encode())]
    after[name] = hashlib.sha256(data).hexdigest()
    assert after[name] == digest, name
(evidence / 'official-snapshot-source-after.json').write_text(json.dumps(after, indent=2) + '\n')
original_result = Path(run['official_results'][0]['path'])
job = original_result.parent
inventory = json.loads((job / 'targets.json').read_text())
manifest = {}
for line in (source / 'scripts/kernel-manifest.tsv').read_text().splitlines():
    columns = line.split('\t')
    if len(columns) >= 5 and columns[1].startswith('VeriTile/') and columns[4] == 'proven':
        manifest[columns[2]] = columns
assert sorted(manifest) == inventory['theorems']
assert len(inventory['aliases']) == len(inventory['theorems']) == 118
assert len(set(inventory['aliases'])) == 118
mapping = [{'alias': alias, 'theorem': name, 'original_manifest_row': manifest[name]}
           for alias, name in zip(inventory['aliases'], inventory['theorems'])]
(evidence / 'target-mapping.json').write_text(json.dumps(mapping, indent=2) + '\n')
bundle = home / 'current-library-bundle'
bundle.mkdir()
shutil.copytree(evidence, bundle / 'run')
shutil.copytree(job, bundle / 'official-job')
shutil.copyfile(original_root / 'inputs.json', bundle / 'official-inputs.json')
shutil.copyfile(workspace / 'ready.json', bundle / 'official-ready.json')
shutil.copyfile(source / 'scripts/kernel-manifest.tsv', bundle / 'kernel-manifest.tsv')
shutil.copyfile(workspace / 'project/VeriTileComparator/Library.lean', bundle / 'generated-Library.lean')
shutil.copyfile(home / 'current-source-verified.json', bundle / 'guest-source-verified.json')
shutil.copyfile(home / 'library-driver.py', bundle / 'library-driver.py')
files = {p.relative_to(bundle).as_posix(): hashlib.sha256(p.read_bytes()).hexdigest()
         for p in bundle.rglob('*') if p.is_file()}
(bundle / 'collection-receipt.json').write_text(json.dumps({'accepted': True, 'files': files,
    'source_unchanged_except_official_library_registration': True, 'target_count': len(mapping),
    'module_count': len({v[1] for v in manifest.values()}), 'source_manifest_sha256': run['source_manifest_sha256']}, indent=2) + '\n')
out = home / 'current-library-evidence.tar.gz'
with tarfile.open(out, 'w:gz') as tar:
    tar.add(bundle, arcname='current-library-bundle')
print(json.dumps({'archive': str(out), 'sha256': hashlib.sha256(out.read_bytes()).hexdigest(),
                  'target_count': len(mapping), 'official_input_count': len(inputs)}, indent=2))
