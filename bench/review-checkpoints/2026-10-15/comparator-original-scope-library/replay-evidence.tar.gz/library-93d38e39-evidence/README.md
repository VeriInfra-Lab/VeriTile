# Library replay evidence: 118 / 118 PASS

The unchanged official library gate accepted all 118 manifest theorem targets in 8 library modules, bound to commit `93d38e399ac513eb98aa3624d9aeb1c21858757a` on `fp-examples`. Both the official runner and comparator exited 0. Full original logs and receipts are retained under `raw/`.

**Scope:** this is historical library-only evidence. It does not establish acceptance of the six new public entrypoint files, all 30 newly added modules, any later LoRA/matrix batch, or all 183 tasks under full stage/dtype/branch coverage. Those results must be recorded separately. Explicitly registered numerical assumptions remain subject to the project scope policy.

## Command and source binding

```sh
python3 scripts/check_comparator.py --library --workspace /home/judge/current-library-workspace
```

The command ran from `/home/judge/current-source` as nonprivileged UID 2000. Its exact argv, timestamps, original result path and digest are in `raw/run/run.json`. `verification.json` summarizes the independently checked result.

`provenance/current-source-inputs.json` holds all 7,177 frozen source hashes. Its recorded base HEAD predates the commit because the worktree was frozen before commit creation. `provenance/commit-binding.json` binds its exact contents to `93d38e39`; packaging independently re-read and SHA256-checked all 7,177 immutable Git blobs. There are no extra or missing commit paths.

The frozen source was unchanged before and after the run (`raw/run/source-before.json`, `source-after.json`). All 4,303 original official snapshot inputs match the frozen source (`raw/official-inputs.json`). The collector checked the live judge snapshot after execution; the only allowed source edit was the exact unchanged runner's generated `VeriTileComparator` registration appended to its isolated `lakefile.toml`. Normalizing that append yields identical before/after input maps. See `provenance/collect-library.py`.

`raw/run/target-mapping.json` preserves each of the 118 original manifest rows and its generated alias. `raw/official-job/targets.json`, `raw/kernel-manifest.tsv`, and `raw/generated-Library.lean` allow independent scope inspection. `raw/official-job/result.json`, `build.log`, and `comparator.log` are untouched original artifacts.

## Isolation and provenance

The host lacks Landlock support and a systemd user bus; its original failure is recorded in `provenance/host-isolation-unavailable.json`. The official gate instead ran inside a private QEMU TCG Debian 13 VM with Linux `6.12.111+deb13-cloud-amd64`, Landlock ABI 6, systemd user services, and nonprivileged UID 2000. The original official `--check-tools` passed. No host service was installed and no isolation check was bypassed.

The positive controls succeeded; systemd denied AF_UNIX, Landlock denied a sentinel write, and the actual comparator rejected a changed statement, `sorryAx`, and an attempted source write. The original challenge remained unchanged. Full small control inputs and receipts are included in `provenance/controls/`; additional original logs are adjacent.

Tools and frozen input media were mounted read-only. The official runner copied its independent judge cache; it did not share a writable cache with the host. `provenance/current-media-qmp.json` records read-only media configuration; `current-source-receipt.json` identifies the accepted media and explicit exclusions of six unrelated uncommitted LoRA cache files. `tool-provenance.json` and `download-verification.json` identify clean pinned tool sources, binary digests and verified downloads. Unchanged official runner files from the bound commit are in `provenance/official-runner/`.

## Integrity

From this directory run:

```sh
sha256sum --check SHA256SUMS
```

`SHA256SUMS` covers every other bundled file; `artifact-receipt.json` records sizes and hashes for payload files other than itself and `SHA256SUMS`. `raw/collection-receipt.json` is the original guest collection receipt and was independently verified during packaging.

No `.lake` cache, proof binaries, tool binaries, VM images, guest disks, SSH private keys, or credentials are included. A compressed copy of this directory is provided separately for transfer. Preserve this directory unchanged when citing the historical result.
