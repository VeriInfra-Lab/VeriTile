from pathlib import Path
import hashlib
import json
import os
import subprocess
import time

source = Path('/home/judge/current-source')
work = Path('/home/judge/current-library-workspace')
logroot = Path('/home/judge/current-library-evidence')
logroot.mkdir()
receipt = json.loads(Path('/opt/veritile-current/current-source-inputs.json').read_text())
assert os.getuid() == 2000
before = {name: hashlib.sha256((source / name).read_bytes()).hexdigest()
          for name in receipt['files']}
assert before == receipt['files']
(logroot / 'source-before.json').write_text(json.dumps(before, indent=2) + '\n')
argv = ['python3', 'scripts/check_comparator.py', '--library', '--workspace', str(work)]
run = {'argv': argv, 'cwd': str(source), 'uid': os.getuid(), 'parent_pid': os.getpid(),
       'source_manifest_sha256': hashlib.sha256(Path('/opt/veritile-current/current-source-inputs.json').read_bytes()).hexdigest(),
       'started': time.time(), 'source_files': len(before)}
with (logroot / 'official-command.log').open('w') as out:
    child = subprocess.Popen(argv, cwd=source, stdout=out, stderr=subprocess.STDOUT)
    run['child_pid'] = child.pid
    (logroot / 'run.json').write_text(json.dumps(run, indent=2) + '\n')
    code = child.wait()
run['exit'] = code
run['finished'] = time.time()
after = {name: hashlib.sha256((source / name).read_bytes()).hexdigest() for name in before}
(logroot / 'source-after.json').write_text(json.dumps(after, indent=2) + '\n')
run['source_unchanged'] = before == after
original = []
for path in sorted((source / 'Logs').glob('comparator-check-*/*/result.json')):
    original.append({'path': str(path), 'sha256': hashlib.sha256(path.read_bytes()).hexdigest(),
                     'result': json.loads(path.read_text())})
run['official_results'] = original
if (work / 'ready.json').is_file():
    ready = json.loads((work / 'ready.json').read_text())
    inputs = json.loads((Path(ready['logs']) / 'inputs.json').read_text())
    run['official_inputs_match_frozen_source'] = all(before.get(name) == digest for name, digest in inputs.items())
    run['official_input_count'] = len(inputs)
run['accepted'] = code == 0 and run['source_unchanged'] and run.get('official_inputs_match_frozen_source', False) and len(original) == 1 and original[0]['result']['accepted'] is True
(logroot / 'run.json').write_text(json.dumps(run, indent=2) + '\n')
print(json.dumps(run, indent=2), flush=True)
raise SystemExit(0 if run['accepted'] else 1)
