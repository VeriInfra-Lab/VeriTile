import Lean
import bench.tritonbench_g.multinomial_sampling.Proofs.FPWrapper
import bench.tritonbench_g.multinomial_sampling.Proofs.FPSoftware
import VeriTile.Meta.StatementAudit

namespace VeriTile.Bench.TritonBenchG.MultinomialSampling.HostCorrect
open VeriTile.Triton FP.Structural FPValue
noncomputable section

/-- Complete logical grid of the actual source for all four score storage
profiles. Every batch row, partial final block, and untouched memory cell is
accounted for; the reference depends only on launch-initial memory. -/
specification multinomial_grid_backend_correctness
    {α : Type} [Inhabited α] (rest : Algebra α) (P : Primitives α)
    (d : Storage) (p : Parameters) (initial : State α)
    (fresh : Host.FreshOutput p)
    (seeds : ∀ k, k < Host.grid p → SeedDomain p (Host.programState p initial initial k)) :
    ∃ final, Host.run rest P d p initial = some final ∧
      final.mem = Host.expectedMemory P d p initial :=
  Host.launch_correct rest P d p initial fresh seeds

/-- The same complete grid with binary16/bfloat16/binary32/binary64 storage,
concrete Philox and software fp32 operations. Native numerical refinement is
still an explicit deferred obligation. -/
specification multinomial_grid_software_correctness
    (rest : Algebra Word) (d : Storage) (plans : Plans) (p : Parameters)
    (initial : State Word) (fresh : Host.FreshOutput p)
    (seeds : ∀ k, k < Host.grid p → SeedDomain p (Host.programState p initial initial k)) :
    ∃ final, Host.run rest (software d plans) d p initial = some final ∧
      final.mem = Host.expectedMemory (software d plans) d p initial :=
  Host.launch_correct rest (software d plans) d p initial fresh seeds

/-- Both host result shapes, all shape-check branches, default arange/expand,
clone initialization, fixed host blocks, and complete grid execution in the
signed64-index profile. The early return needs neither valid index shape nor
seed values. Other supplied-index dtypes are outside this declaration. -/
specification multinomial_int64_indices_host_correctness
    {α : Type} [Inhabited α] (rest : Algebra α) (P : Primitives α)
    (d : Storage) (p : Parameters) (a : Host.Arguments) (initial : State α)
    (score : a.scoreRank = 2) (nonempty : 0 < p.tokens)
    (index : p.tokens ≠ 1 → a.indexShape.any (fun sh => sh != [p.batches, p.tokens]) = Bool.false)
    (fresh : Host.FreshOutput p)
    (freshDefault : a.indexShape = none →
      p.indices ≠ p.scores ∧ p.indices ≠ p.seeds ∧ p.indices ≠ p.offsets)
    (seeds : p.tokens ≠ 1 → ∀ k, k < Host.grid (Host.wrapperParameters p a) →
      SeedDomain (Host.wrapperParameters p a)
        (Host.programState (Host.wrapperParameters p a)
          (Host.kernelInitial p a initial) (Host.kernelInitial p a initial) k)) :
    ∃ result, Host.invoke rest P d p a initial = some result ∧
      result.state.mem = Host.wrapperExpectedMemory P d p a initial ∧
      result.shape = if p.tokens = 1 then [p.batches, 1] else [p.batches] := by
  have _ := freshDefault
  exact Host.wrapper_correct rest P d p a initial score nonempty index fresh seeds

/-- Token-one returns signed64 zeros with shape B-by-1 before examining the
index argument; no floating or random-number assumption is needed. -/
specification multinomial_single_token_host_correctness
    {α : Type} [Inhabited α] (rest : Algebra α) (P : Primitives α)
    (d : Storage) (p : Parameters) (a : Host.Arguments) (initial : State α)
    (shape : a.scoreRank = 2) (token : p.tokens = 1) :
    Host.invoke rest P d p a initial = some ⟨Host.zeros p initial, [p.batches, 1]⟩ ∧
    (∀ o, o < p.batches → (Host.zeros p initial).mem p.output o = .mk .int 0) ∧
    (∀ r o, (r ≠ p.output ∨ p.batches ≤ o) →
      (Host.zeros p initial).mem r o = initial.mem r o) :=
  Host.single_token rest P d p a initial shape token

#axiomsClean multinomial_grid_backend_correctness
#axiomsClean multinomial_grid_software_correctness
#axiomsClean multinomial_int64_indices_host_correctness
#axiomsClean multinomial_single_token_host_correctness
#guard_msgs (drop info) in
#auditModuleAxioms
end
end VeriTile.Bench.TritonBenchG.MultinomialSampling.HostCorrect

-- ==== external trust audit (appended by bench/audit_trust.sh) ====
#auditModuleAxioms
#auditModuleSpecs


open Lean Elab Command in
run_cmd do
  let env ← getEnv
  -- Enumerate and look up in the same completed kernel environment. The
  -- elaborator's prefix-based lookup can miss realized private match equations
  -- even though they are already present in `env.constants`.
  let kernelEnv := env.toKernelEnv
  let selected : Array Name := #[]
  let mut names : Array Name := #[]
  if selected.isEmpty then
    for (name, info) in kernelEnv.constants.toList do
      if (env.getModuleIdxFor? name).isSome then continue
      if let .thmInfo _ := info then names := names.push name
  else
    names := selected
  names := names.qsort (·.toString < ·.toString)
  let mut aliases : Array String := #[]
  for i in [:names.size] do
    let name := names[i]!
    let some (.thmInfo info) := kernelEnv.find? name
      | throwError "Comparator target is not a theorem: {name}"
    let wrapperName := Name.mkSimple s!"veritile_comparator_target_{i}"
    if env.contains wrapperName then throwError "Reserved comparator target name: {wrapperName}"
    liftCoreM <| addDecl <| .thmDecl {
      name := wrapperName, levelParams := info.levelParams, type := info.type,
      value := mkConst name (info.levelParams.map Level.param)
    }
    aliases := aliases.push wrapperName.toString
  -- Definition-only regression fixtures still run comparator's primitive
  -- checks and kernel replay. Report zero original theorem targets explicitly.
  if aliases.isEmpty then
    let wrapperName := `veritile_comparator_empty_module
    if env.contains wrapperName then throwError "Reserved comparator target name: {wrapperName}"
    liftCoreM <| addDecl <| .thmDecl {
      name := wrapperName, levelParams := [], type := mkConst ``True,
      value := mkConst ``True.intro
    }
    aliases := #[wrapperName.toString]
  let report := Json.mkObj [
    ("theorems", toJson (names.map Name.toString)),
    ("aliases", toJson aliases)
  ]
  liftIO <| IO.FS.writeFile "/home/judge/current-library-workspace/project/.lake/comparator/File_e234427051f999783d3b1070/targets.json" report.compress
