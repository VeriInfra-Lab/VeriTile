import Lean
import bench.tritonbench_g.attention_kernel_aligned.Proofs.FullSourceBehavior
import bench.tritonbench_g.attention_kernel_aligned.Proofs.BfloatRejected
import bench.tritonbench_g.attention_kernel_aligned.Proofs.FPSoftware
import VeriTile.Meta.StatementAudit
namespace VeriTile.Bench.TritonBenchG.AttentionKernelAligned.FullCorrect
open VeriTile.Triton FP.Structural
open Full
open FullFp16
open FPValue (Primitives backend Word External Plans software)
noncomputable section

/-- Original fp16 source with arbitrary N_CTX and every individual source
stride. Full final key/query tiles remain unmasked, including out-of-shape
lanes. Every key iteration and the entire final memory scatter are accounted
for, even when output strides collide. This total-memory source contract does
not assert allocation safety or native execution. The bf16 wrapper branch is
rejected by both the unchanged frontend and the recorded native compiler;
the imported full-source negative regression checks that rejection. -/
specification attention_aligned_all_lengths_backend_correctness
    {α : Type} [Inhabited α] (rest : Algebra α) (P : Primitives α) (p : Parameters)
    (initial : State α) (hBN : 0 < p.blockN) :
    ∃ final, FP.Structural.exec (backend rest P) (source p) initial = some final ∧
      final.mem = (written P p initial).mem ∧
      (∀ r o, (r ≠ p.output ∨ ∀ i : QLane p, o ≠ outputOffset p initial i) →
        final.mem r o = initial.mem r o) := correctness rest P p initial hBN

/-- Binary16 conversions/addition and fp32 scalar arithmetic instantiated on
the same complete source. Valid explicit reduction trees remain checked; dot,
exp2, and arbitrary-real host literal conversion are named external callbacks.
No identity-rounding, alignment, finite-value, or step-correctness premise is
introduced. Native compilation, unchecked memory safety, and host grid
composition remain separate from this per-program value contract. -/
specification attention_aligned_all_lengths_scalar_bit_correctness
    [Inhabited Word] (rest : Algebra Word) (external : External) (plans : Plans)
    (p : Parameters) (initial : State Word) (hBN : 0 < p.blockN) :
    ∃ final, FP.Structural.exec (backend rest (software external plans)) (source p) initial = some final ∧
      final.mem = (written (software external plans) p initial).mem ∧
      (∀ r o, (r ≠ p.output ∨ ∀ i : QLane p, o ≠ outputOffset p initial i) →
        final.mem r o = initial.mem r o) := correctness rest (software external plans) p initial hBN

#axiomsClean attention_aligned_all_lengths_backend_correctness
#axiomsClean attention_aligned_all_lengths_scalar_bit_correctness
#auditModuleAxioms
end
end VeriTile.Bench.TritonBenchG.AttentionKernelAligned.FullCorrect

-- ==== external trust audit (appended by bench/audit_trust.sh) ====
#auditModuleAxioms
#auditModuleSpecs


open Lean Elab Command in
run_cmd do
  let env ← getEnv
  -- Enumerate and look up in the same completed kernel environment. The
  -- elaborator's prefix-based lookup can miss realized private match equations
  -- even though they are already present in `env.constants`.
  let kernelEnv := env.toKernelEnv
  let selected : Array Name := #[]
  let mut names : Array Name := #[]
  if selected.isEmpty then
    for (name, info) in kernelEnv.constants.toList do
      if (env.getModuleIdxFor? name).isSome then continue
      if let .thmInfo _ := info then names := names.push name
  else
    names := selected
  names := names.qsort (·.toString < ·.toString)
  let mut aliases : Array String := #[]
  for i in [:names.size] do
    let name := names[i]!
    let some (.thmInfo info) := kernelEnv.find? name
      | throwError "Comparator target is not a theorem: {name}"
    let wrapperName := Name.mkSimple s!"veritile_comparator_target_{i}"
    if env.contains wrapperName then throwError "Reserved comparator target name: {wrapperName}"
    liftCoreM <| addDecl <| .thmDecl {
      name := wrapperName, levelParams := info.levelParams, type := info.type,
      value := mkConst name (info.levelParams.map Level.param)
    }
    aliases := aliases.push wrapperName.toString
  -- Definition-only regression fixtures still run comparator's primitive
  -- checks and kernel replay. Report zero original theorem targets explicitly.
  if aliases.isEmpty then
    let wrapperName := `veritile_comparator_empty_module
    if env.contains wrapperName then throwError "Reserved comparator target name: {wrapperName}"
    liftCoreM <| addDecl <| .thmDecl {
      name := wrapperName, levelParams := [], type := mkConst ``True,
      value := mkConst ``True.intro
    }
    aliases := #[wrapperName.toString]
  let report := Json.mkObj [
    ("theorems", toJson (names.map Name.toString)),
    ("aliases", toJson aliases)
  ]
  liftIO <| IO.FS.writeFile "/home/judge/current-library-workspace/project/.lake/comparator/File_41dd220ab9011b5028dc7e00/targets.json" report.compress
