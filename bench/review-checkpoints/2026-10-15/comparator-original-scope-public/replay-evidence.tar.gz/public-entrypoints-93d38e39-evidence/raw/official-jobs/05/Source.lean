import Lean
import bench.tritonbench_g.triton_conv2d_fwd.FPCorrect
import bench.tritonbench_g.triton_conv2d_fwd.Proofs.FPDefaultSoftware
import VeriTile.Meta.StatementAudit

/-! Both original constexpr fp16 branches over fp32 input/weight/output storage.
The default false branch has a separately elaborated fp32 dot, with no operand
half cast. The original true branch and its historical contracts are preserved.
Each branch covers the complete triple loop and arbitrary masked-load undef;
no zero-padding, finite-input, single-tile-size or numerical-identity premise
is introduced. Native index-width, compiler fusion and dot-plan correspondence
remain external. Host grid composition and other storage dtypes are separate.
-/
namespace VeriTile.Bench.TritonBenchG.TritonConv2dFwd.BranchesCorrect
open VeriTile.Triton FP.Structural
noncomputable section

/-- Original constexpr specialization, including the wrapper default false. -/
def source (useHalf : Bool) (p : FPValue.Parameters) : ComputeKernel :=
  if useHalf then FPValue.source p else FPDefault.source p

/-- Backend primitives are typed for the selected source operand format. -/
def backend {α : Type} (M : Algebra α) (halfDot : FPValue.Dot α)
    (fullDot : FPDefault.Dot α) (useHalf : Bool) : Algebra α :=
  if useHalf then FPValue.backend M halfDot else FPDefault.backend M fullDot

def expected {α : Type} [Inhabited α] (M : Algebra α) (halfDot : FPValue.Dot α)
    (fullDot : FPDefault.Dot α) (useHalf : Bool) (p : FPValue.Parameters)
    (initial : State α) : FPValue.CIndex p → α :=
  if useHalf then FPValue.outputValue M halfDot p initial
  else FPDefault.outputValue M fullDot p initial

def expectedMemory {α : Type} [Inhabited α] (M : Algebra α) (halfDot : FPValue.Dot α)
    (fullDot : FPDefault.Dot α) (useHalf : Bool) (p : FPValue.Parameters)
    (initial : State α) : RegionName → Nat → Cell α :=
  if useHalf then (FPValue.written M halfDot p initial).mem
  else (FPDefault.written M fullDot p initial).mem

/-- All three source loops and both fp16/tf32 flag choices. Only the original
output-address injectivity condition is needed for pointwise readback. -/
specification all_fp16_branches_backend_correctness
    {α : Type} [Inhabited α] (M : Algebra α) (halfDot : FPValue.Dot α)
    (fullDot : FPDefault.Dot α) (useHalf : Bool) (p : FPValue.Parameters)
    (initial : State α)
    (hw : ∀ i j, FPValue.active p initial i → FPValue.active p initial j →
      FPValue.outputOffset p initial i = FPValue.outputOffset p initial j → i = j) :
    ∃ final, FP.Structural.exec (backend M halfDot fullDot useHalf) (source useHalf p) initial = some final ∧
      final.mem = expectedMemory M halfDot fullDot useHalf p initial ∧
      FPValue.Post p initial final (expected M halfDot fullDot useHalf p initial) := by
  cases useHalf
  · exact FPDefault.correctness M fullDot p initial hw
  · exact FPValue.correctness M halfDot p initial hw

/-- Concrete software arithmetic for each branch: false keeps fp32 operands,
true rounds operands to binary16 before dot. Both use the explicitly defined
ascending dot order and outer fp32 carry additions. Every used callback is
closed, independently of rest; native TF32/fusion binding is not inferred. -/
specification all_fp16_branches_software_correctness
    (rest : Algebra FPValue.Word) (useHalf : Bool) (p : FPValue.Parameters)
    (initial : State FPValue.Word)
    (hw : ∀ i j, FPValue.active p initial i → FPValue.active p initial j →
      FPValue.outputOffset p initial i = FPValue.outputOffset p initial j → i = j) :
    ∃ final, FP.Structural.exec
        (if useHalf then FPValue.backend (FPValue.software rest) FPValue.sequentialDot
         else FPDefault.backend (FPDefault.software rest) FPDefault.sequentialDot)
        (source useHalf p) initial = some final ∧
      FPValue.Post p initial final
        (if useHalf then FPValue.bitOutput p initial else FPDefault.bitOutput p initial) := by
  cases useHalf
  · exact FPDefault.software_correctness rest p initial hw
  · exact FPValue.software_correctness rest p initial hw

#specNonCircular expectedMemory avoiding [source, FP.Structural.exec]
#axiomsClean all_fp16_branches_backend_correctness
#axiomsClean all_fp16_branches_software_correctness
#guard_msgs (drop info) in
#auditModuleAxioms
end
end VeriTile.Bench.TritonBenchG.TritonConv2dFwd.BranchesCorrect

-- ==== external trust audit (appended by bench/audit_trust.sh) ====
#auditModuleAxioms
#auditModuleSpecs


open Lean Elab Command in
run_cmd do
  let env ← getEnv
  -- Enumerate and look up in the same completed kernel environment. The
  -- elaborator's prefix-based lookup can miss realized private match equations
  -- even though they are already present in `env.constants`.
  let kernelEnv := env.toKernelEnv
  let selected : Array Name := #[]
  let mut names : Array Name := #[]
  if selected.isEmpty then
    for (name, info) in kernelEnv.constants.toList do
      if (env.getModuleIdxFor? name).isSome then continue
      if let .thmInfo _ := info then names := names.push name
  else
    names := selected
  names := names.qsort (·.toString < ·.toString)
  let mut aliases : Array String := #[]
  for i in [:names.size] do
    let name := names[i]!
    let some (.thmInfo info) := kernelEnv.find? name
      | throwError "Comparator target is not a theorem: {name}"
    let wrapperName := Name.mkSimple s!"veritile_comparator_target_{i}"
    if env.contains wrapperName then throwError "Reserved comparator target name: {wrapperName}"
    liftCoreM <| addDecl <| .thmDecl {
      name := wrapperName, levelParams := info.levelParams, type := info.type,
      value := mkConst name (info.levelParams.map Level.param)
    }
    aliases := aliases.push wrapperName.toString
  -- Definition-only regression fixtures still run comparator's primitive
  -- checks and kernel replay. Report zero original theorem targets explicitly.
  if aliases.isEmpty then
    let wrapperName := `veritile_comparator_empty_module
    if env.contains wrapperName then throwError "Reserved comparator target name: {wrapperName}"
    liftCoreM <| addDecl <| .thmDecl {
      name := wrapperName, levelParams := [], type := mkConst ``True,
      value := mkConst ``True.intro
    }
    aliases := #[wrapperName.toString]
  let report := Json.mkObj [
    ("theorems", toJson (names.map Name.toString)),
    ("aliases", toJson aliases)
  ]
  liftIO <| IO.FS.writeFile "/home/judge/current-library-workspace/project/.lake/comparator/File_66c6a6ab090387b676c87733/targets.json" report.compress
