import Lean
import bench.tritonbench_g.fp4_to_bf16.Proofs.Host
import VeriTile.Meta.StatementAudit

/-! Complete logical host-grid contract for the original unscaled FP4 wrapper.
The output is freshly allocated bf16 storage with doubled final dimension.
The launch executes the actual admitted kernel, in program-ID order, for the
original ceilDiv(numel,512) grid. This is not a native allocator/concurrency or
arbitrary-storage Python-wrapper refinement theorem. -/
namespace VeriTile.Bench.TritonBenchG.Fp4ToBf16.HostCorrect
open VeriTile.Triton FP.Structural FPValue Host
noncomputable section
local instance : Inhabited Word := ⟨FP.Value.zero .fp32⟩

/-- Read the bf16 payload from the task's tagged structural cell. -/
def readBf16 (c : Cell Word) : FP.Value .bf16 :=
  ⟨(c.read .bf16).bits.truncate 16⟩

private theorem read_expected (h : Input) (initial : State Word) (j : Nat) :
    readBf16 (cell h initial j) = ⟨Bits.expectedBits (nibble h initial j)⟩ := by
  simp only [readBf16, cell, value, embed, Cell.read_same, FP.Value.mk.injEq]
  simpa only [BitVec.setWidth_eq] using
    (BitVec.setWidth_setWidth_of_le (Bits.expectedBits (nibble h initial j)) (by decide : 16 ≤ 32))

/-- Every output of every original BLOCK=512 program has its exact independent
initial-byte value, including tails and both zero signs. The entire memory
frame is retained. PackedInput describes uint8 storage, and fresh is supplied
by the wrapper's new output allocation; no numerical law is assumed. The
shape may have any number of leading dimensions and any element count. -/
specification fp4_to_bf16_host_grid_correctness
    (rest : Algebra Word) (h : Input) (initial : State Word)
    (fresh : h.input ≠ h.output) (typed : PackedInput h initial) :
    ∃ final, Host.run rest h initial = some final ∧
      final.mem = expectedMemory h initial ∧
      h.shape.output.prod = h.shape.input.prod * 2 ∧
      (∀ j, j < h.shape.count * 2 →
        final.mem h.output j = cell h initial j ∧
        (readBf16 (final.mem h.output j)).decode =
          .finite (decide (8 ≤ (nibble h initial j).toNat))
            (Bits.magnitude (nibble h initial j))) ∧
      (∀ r o, (r ≠ h.output ∨ h.shape.count * 2 ≤ o) →
        final.mem r o = initial.mem r o) := by
  refine ⟨prefixState rest h initial (grid h), run_prefix rest h initial (grid h),
    launch_memory rest h initial fresh typed, ?_, ?_, ?_⟩
  · rw [input_numel, output_numel]
  · intro j hj
    have memory := launch_memory rest h initial fresh typed
    have output : (prefixState rest h initial (grid h)).mem h.output j = cell h initial j := by
      rw [memory]
      simp only [expectedMemory, hj, and_self, ↓reduceIte]
    refine ⟨output, ?_⟩
    rw [output, read_expected]
    exact expected_decode h initial j
  · intro r o outside
    rw [launch_memory rest h initial fresh typed]
    have inactive : ¬ (r = h.output ∧ o < h.shape.count * 2) := by
      rcases outside with hr | ho
      · exact fun hi => hr hi.1
      · omega
    simp only [expectedMemory, inactive, ↓reduceIte]

#axiomsClean fp4_to_bf16_host_grid_correctness
#guard_msgs (drop info) in
#auditModuleAxioms
end
end VeriTile.Bench.TritonBenchG.Fp4ToBf16.HostCorrect

-- ==== external trust audit (appended by bench/audit_trust.sh) ====
#auditModuleAxioms
#auditModuleSpecs


open Lean Elab Command in
run_cmd do
  let env ← getEnv
  -- Enumerate and look up in the same completed kernel environment. The
  -- elaborator's prefix-based lookup can miss realized private match equations
  -- even though they are already present in `env.constants`.
  let kernelEnv := env.toKernelEnv
  let selected : Array Name := #[]
  let mut names : Array Name := #[]
  if selected.isEmpty then
    for (name, info) in kernelEnv.constants.toList do
      if (env.getModuleIdxFor? name).isSome then continue
      if let .thmInfo _ := info then names := names.push name
  else
    names := selected
  names := names.qsort (·.toString < ·.toString)
  let mut aliases : Array String := #[]
  for i in [:names.size] do
    let name := names[i]!
    let some (.thmInfo info) := kernelEnv.find? name
      | throwError "Comparator target is not a theorem: {name}"
    let wrapperName := Name.mkSimple s!"veritile_comparator_target_{i}"
    if env.contains wrapperName then throwError "Reserved comparator target name: {wrapperName}"
    liftCoreM <| addDecl <| .thmDecl {
      name := wrapperName, levelParams := info.levelParams, type := info.type,
      value := mkConst name (info.levelParams.map Level.param)
    }
    aliases := aliases.push wrapperName.toString
  -- Definition-only regression fixtures still run comparator's primitive
  -- checks and kernel replay. Report zero original theorem targets explicitly.
  if aliases.isEmpty then
    let wrapperName := `veritile_comparator_empty_module
    if env.contains wrapperName then throwError "Reserved comparator target name: {wrapperName}"
    liftCoreM <| addDecl <| .thmDecl {
      name := wrapperName, levelParams := [], type := mkConst ``True,
      value := mkConst ``True.intro
    }
    aliases := #[wrapperName.toString]
  let report := Json.mkObj [
    ("theorems", toJson (names.map Name.toString)),
    ("aliases", toJson aliases)
  ]
  liftIO <| IO.FS.writeFile "/home/judge/current-library-workspace/project/.lake/comparator/File_0ee09f78b776f17f3b124421/targets.json" report.compress
