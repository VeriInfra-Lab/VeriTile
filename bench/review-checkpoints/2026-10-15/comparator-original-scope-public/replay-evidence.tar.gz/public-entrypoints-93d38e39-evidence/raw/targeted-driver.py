from pathlib import Path
import hashlib
import json
import os
import subprocess
import time

source = Path('/home/judge/current-source')
work = Path('/home/judge/current-library-workspace')
evidence = Path('/home/judge/current-targeted-evidence')
library_receipt = Path('/home/judge/current-library-evidence/run.json')
assert os.getuid() == 2000
while True:
    state = json.loads(library_receipt.read_text())
    if 'accepted' in state:
        assert state['accepted'], 'Library gate did not pass; targeted run was not started'
        break
    time.sleep(15)
evidence.mkdir()
frozen = json.loads(Path('/opt/veritile-current/current-source-inputs.json').read_text())
supplement = json.loads((source / 'bench/review-checkpoints/2026-10-15/original-scope-extensions/catalog-supplement.json').read_text())
tasks = {'fp4_to_bf16', 'multinomial_sampling', 'kcache_copy_triton',
         'triton_conv2d_fwd', 'attention_kernel_aligned'}
files = sorted({declaration['file'] for task in supplement['tasks'] if task['task'] in tasks
                for declaration in task['declarations']})
assert len(files) == 6
for name, expected in frozen['files'].items():
    assert hashlib.sha256((source / name).read_bytes()).hexdigest() == expected, name
result = {'scope': 'six newly added public entrypoint files; not the full 30-module or 183-task gate',
          'files': files, 'started': time.time(), 'runs': []}
(evidence / 'results.json').write_text(json.dumps(result, indent=2) + '\n')
for index, name in enumerate(files):
    command = ['python3', 'scripts/check_comparator.py', '--file', name, '--trust', '--workspace', str(work)]
    record = {'source': name, 'argv': command, 'started': time.time()}
    with (evidence / f'{index:02d}-command.log').open('w') as log:
        child = subprocess.Popen(command, cwd=source, stdout=log, stderr=subprocess.STDOUT)
        record['pid'] = child.pid
        result['current'] = record
        (evidence / 'results.json').write_text(json.dumps(result, indent=2) + '\n')
        record['exit'] = child.wait()
    record['finished'] = time.time()
    reports = []
    for path in (source / 'Logs').glob('comparator-check-*/*/result.json'):
        original = json.loads(path.read_text())
        if original['source'] == name:
            reports.append({'path': str(path), 'sha256': hashlib.sha256(path.read_bytes()).hexdigest(), 'result': original})
    record['official_results'] = reports
    record['accepted'] = record['exit'] == 0 and len(reports) == 1 and reports[0]['result']['accepted'] is True
    result['runs'].append(record)
    del result['current']
    (evidence / 'results.json').write_text(json.dumps(result, indent=2) + '\n')
    if not record['accepted']:
        raise SystemExit(1)
result['source_unchanged'] = all(hashlib.sha256((source / name).read_bytes()).hexdigest() == digest
                                 for name, digest in frozen['files'].items())
result['accepted'] = result['source_unchanged'] and len(result['runs']) == 6 and all(r['accepted'] for r in result['runs'])
result['finished'] = time.time()
(evidence / 'results.json').write_text(json.dumps(result, indent=2) + '\n')
print(json.dumps(result, indent=2), flush=True)
raise SystemExit(0 if result['accepted'] else 1)
