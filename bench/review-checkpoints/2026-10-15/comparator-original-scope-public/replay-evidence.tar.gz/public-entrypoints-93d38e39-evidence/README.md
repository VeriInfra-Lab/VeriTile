# Six public entrypoint replays: PASS

The unchanged official comparator accepted all six public entrypoint files selected from the original-scope supplement at commit `93d38e399ac513eb98aa3624d9aeb1c21858757a`. All 11 registered public declarations are mapped to accepted original theorem inventories. Each run used `--trust`; every original runner exit and comparator exit is 0. `verification.json` provides exact per-file counts, commands, elapsed times and result hashes.

**Scope:** this package proves those six frozen public entrypoint replays only. It does not establish all-30-module acceptance, any later LoRA/matrix/host batch, or completion of all 183 tasks under full stage/dtype/branch coverage. Structural scope gaps and numerical assumptions remain as registered in the frozen catalog. The separate library package passed 118 targets and is identified in `provenance/library-package-delivery.json`.

## Evidence and source binding

Each unchanged command was of the form:

```sh
python3 scripts/check_comparator.py --file FILE --trust --workspace /home/judge/current-library-workspace
```

Runs used the same supported private VM and immutable source snapshot as the completed library gate; the sequential driver starts only after that real library acceptance. `raw/run/results.json` preserves all original result paths and receipts. `raw/official-jobs/00` through `05` preserve complete original source wrappers, inventories, configurations, build logs, comparator logs and results. `raw/target-mapping.json` maps original theorem aliases back to the 11 declarations in the unchanged `raw/catalog-supplement.json`.

`provenance/current-source-inputs.json` lists all 7,177 frozen source hashes. `provenance/commit-binding.json` binds the snapshot, taken before commit creation, to the exact 7,177-file `93d38e39` commit tree. Packaging the library evidence independently re-read every Git blob. The public replay's post-run source map matches that same frozen manifest in full. All 4,303 original official inputs also remain unchanged, allowing only the original runner's exact generated library registration in the isolated judge `lakefile.toml`; the collector normalizes and verifies that append.

The supported guest ran nonprivileged UID 2000 with Linux 6.12.111, Landlock ABI 6, and systemd AF_UNIX restrictions. Tools and frozen input media were read-only; the judge cache was independent. The unchanged official preflight and real positive/negative enforcement controls passed. `provenance/controls/` retains the controls, including rejection of a changed theorem, `sorryAx`, and an attempted source write. No isolation checks or proof source were changed. The original host's missing support and pinned tool/media provenance are recorded alongside.

## Integrity

From this directory run:

```sh
sha256sum --check SHA256SUMS
```

The original guest `raw/collection-receipt.json` was independently verified after transfer. `artifact-receipt.json` hashes all payload files other than itself and `SHA256SUMS`; `SHA256SUMS` includes the artifact receipt. No caches, proof binaries, tool binaries, VM images, guest disks, SSH private keys, or credentials are included.
