from pathlib import Path
import hashlib
import json
import shutil
import tarfile
import time

home = Path('/home/judge')
source = home / 'current-source'
work = home / 'current-library-workspace'
evidence = home / 'current-targeted-evidence'
frozen = json.loads(Path('/opt/veritile-current/current-source-inputs.json').read_text())
while True:
    result = json.loads((evidence / 'results.json').read_text())
    if 'finished' in result or any(not run.get('accepted') for run in result['runs']):
        break
    time.sleep(30)
assert result.get('accepted') is True, 'Public replay incomplete or failed; original evidence retained'
assert result['source_unchanged'] and len(result['runs']) == 6
source_after = {}
for name, digest in frozen['files'].items():
    source_after[name] = hashlib.sha256((source / name).read_bytes()).hexdigest()
    assert source_after[name] == digest, name
ready = json.loads((work / 'ready.json').read_text())
original_logs = Path(ready['logs'])
inputs = json.loads((original_logs / 'inputs.json').read_text())
append = '\n[[lean_lib]]\nname = "VeriTileComparator"\nglobs = ["VeriTileComparator.+"]\n'.encode()
official_after = {}
for name, digest in inputs.items():
    data = (work / 'project' / name).read_bytes()
    if name == 'lakefile.toml':
        assert data == (source / name).read_bytes() + append
        data = data[:-len(append)]
    official_after[name] = hashlib.sha256(data).hexdigest()
    assert official_after[name] == digest == frozen['files'][name], name
supplement_path = 'bench/review-checkpoints/2026-10-15/original-scope-extensions/catalog-supplement.json'
supplement = json.loads((source / supplement_path).read_text())
declarations = {item['file']: [] for task in supplement['tasks'] for item in task['declarations']}
for task in supplement['tasks']:
    for item in task['declarations']:
        declarations[item['file']].append(item)
bundle = home / 'current-targeted-bundle'
assert not bundle.exists()
bundle.mkdir()
shutil.copytree(evidence, bundle / 'run')
(bundle / 'run/source-after.json').write_text(json.dumps(source_after, indent=2) + '\n')
(bundle / 'run/official-snapshot-source-after.json').write_text(json.dumps(official_after, indent=2) + '\n')
shutil.copyfile(original_logs / 'inputs.json', bundle / 'official-inputs.json')
shutil.copyfile(source / supplement_path, bundle / 'catalog-supplement.json')
shutil.copyfile(home / 'targeted-driver.py', bundle / 'targeted-driver.py')
mapping = []
for index, run in enumerate(result['runs']):
    assert run['exit'] == 0 and run['accepted'] and len(run['official_results']) == 1
    report = run['official_results'][0]
    result_path = Path(report['path'])
    assert hashlib.sha256(result_path.read_bytes()).hexdigest() == report['sha256']
    original = json.loads(result_path.read_text())
    assert original['accepted'] and original['comparator_exit'] == 0 and original['source'] == run['source']
    shutil.copytree(result_path.parent, bundle / f'official-jobs/{index:02d}')
    inventory = json.loads((result_path.parent / 'targets.json').read_text())
    assert len(inventory['theorems']) == len(inventory['aliases']) == original['theorem_count']
    for declaration in declarations[run['source']]:
        matches = [name for name in inventory['theorems']
                   if name == declaration['declaration'] or name.endswith('.' + declaration['declaration'])]
        assert len(matches) == 1, (run['source'], declaration['declaration'], inventory)
    for theorem, alias in zip(inventory['theorems'], inventory['aliases']):
        matches = [d for d in declarations[run['source']]
                   if theorem == d['declaration'] or theorem.endswith('.' + d['declaration'])]
        mapping.append({'file': run['source'], 'theorem': theorem, 'alias': alias,
                        'original_job': f'official-jobs/{index:02d}', 'catalog_declarations': matches})
(bundle / 'target-mapping.json').write_text(json.dumps(mapping, indent=2) + '\n')
files = {p.relative_to(bundle).as_posix(): hashlib.sha256(p.read_bytes()).hexdigest()
         for p in bundle.rglob('*') if p.is_file()}
receipt = {'accepted': True, 'scope': result['scope'], 'files': files,
           'target_count': len(mapping), 'entrypoint_files': 6, 'catalog_declaration_count': 11,
           'source_files_unchanged': len(source_after), 'official_inputs_unchanged': len(official_after),
           'source_manifest_sha256': hashlib.sha256(Path('/opt/veritile-current/current-source-inputs.json').read_bytes()).hexdigest()}
(bundle / 'collection-receipt.json').write_text(json.dumps(receipt, indent=2) + '\n')
out = home / 'current-targeted-evidence.tar.gz'
with tarfile.open(out, 'w:gz') as tar:
    tar.add(bundle, arcname='current-targeted-bundle')
print(json.dumps({'archive': str(out), 'sha256': hashlib.sha256(out.read_bytes()).hexdigest(),
                  'target_count': len(mapping), 'official_input_count': len(inputs)}, indent=2), flush=True)
