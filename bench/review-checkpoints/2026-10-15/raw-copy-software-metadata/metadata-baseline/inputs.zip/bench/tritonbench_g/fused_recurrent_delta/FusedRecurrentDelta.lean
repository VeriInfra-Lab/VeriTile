import VeriTile.Triton
import VeriTile.Meta.StatementAudit

/-!
# `fused_recurrent_delta` — genuine delta-rule recurrence correctness

`fused_recurrent_fwd_kernel` is the flash-linear-attention **delta rule**
forward recurrent scan. Program `(i_v, i_k, i_bh)` carries a `[BV, BK]` state
tile `h` across the `0..T` time loop. With `q_t = q[t] · scale`, per step `t`:

* `v_minus[j_v] = Σ_{j_k} h[j_v,j_k] · k_t[j_k]`         (state readout)
* `v_new[j_v]   = v_t[j_v] − v_minus[j_v]`               (the delta; stored
                                                          **in place** into `v`)
* `h[j_v,j_k]  += k_t[j_k] · (β_t[j_v] · v_new[j_v])`    (rank-1 state update)
* `o_t[j_v]     = Σ_{j_k} h[j_v,j_k] · q_t[j_k]`         (readout of the
                                                          *post-update* state)

with an optional `h0` initial-state seed and an optional `ht` final-state
store. `β` is either a per-`(b,h,t)` scalar or a headwise `[.., T, V]` row
(`IS_HEADWISE_BETA`). The companion `fused_recurrent_bwd_kernel` runs a
reverse-time gradient scan producing `dk`/`dv`/`dbeta`, a `tl.debug_barrier()`,
then a forward-time recomputation producing the `dk` correction and `dq`.

## Scope

This file verifies **the Triton kernels themselves** — the per-program
`@triton.jit` bodies (forward and backward). The host launch (grid shape,
`NK = 1` assertion, autograd plumbing, the `dq/dk/dv/dbeta` `.sum(0)`
reductions on the host) is the *trusted boundary*, not a proof obligation
here. Because the program ids are universally quantified, each per-program
statement covers every program of the grid.

## Genuine recurrence spec (NOT a self-reference)

The delta-rule state has no geometric-decay closed form (its transition is
`(I − β_t k_t k_tᵀ)`-shaped), so the specification is the **explicit
standalone recurrence** `deltaState` — a Lean function defined by recursion on
the step count over the *input* regions `k, v, beta, h0`:

```
deltaState 0       = h0-seed (or 0)
deltaState (m+1)   = deltaState m
                     + k_m ⊗ (β_m ⊙ (v_m − (deltaState m) · k_m))
```

This is never a read-back of the kernel's own output (the
`reversed_cumsum_scalar` carry-fold face is the precedent for
recurrence-valued specs). The per-step faces below are each realized against
`deltaState` / its derived forms `vNewClosed` / `outputClosed`.

## Proof architecture

The headline is a flat 11-way conjunction; its `refine` has eleven independent
goals and there is **no implication chain between them** — in particular no
clause discharges another clause's carry hypothesis. Each line below is one
conjunct, in order:

```
fused_recurrent_delta_output_summary_general          ← TOP THEOREM
  1  fused_recurrent_delta_fwd_surface_toAlgorithm_supported     fwd surface lowers
  2  fused_recurrent_delta_bwd_surface_toAlgorithm_supported     bwd surface lowers
  3  fused_recurrent_delta_vnew_step_closed_form         v ← v_m − h·k_m  (vNewClosed m)
  4  fused_recurrent_delta_state_step_closed_form        HOut ← deltaState(m+1)
  5  fused_recurrent_delta_output_step_closed_form       o ← outputClosed m
  6  fused_recurrent_delta_bwd_dk_step_slice_compute_correct              dk row (loop 1)
  7  fused_recurrent_delta_bwd_dv_step_slice_compute_correct              dv row (loop 1)
  8  fused_recurrent_delta_bwd_dbeta_step_slice_headwise_compute_correct  dbeta row
  9  fused_recurrent_delta_bwd_dbeta_step_slice_scalarbeta_compute_correct dbeta scalar
 10  fused_recurrent_delta_bwd_dk_correction_step_sequenced               dk fixup (loop 2)
 11  fused_recurrent_delta_bwd_dq_step_slice_compute_correct              dq row (loop 2)

supporting algebra (used INSIDE clauses 3–5, not extra conjuncts):
  deltaState / deltaState_succ            the standalone recurrence
  stateStepSpec_eq_deltaState_succ        one body advances it, given `hPrev`
  dkCorrClosed                            loop-1 `dk`/`dv` values, sequenced into
                                          clause 10 (via the slice face
                                          `..._dk_correction_step_slice_compute_correct`)
```

## Modeling boundary

Arithmetic is over `ℝ`, not bit-accurate IEEE float; dtype `.to(...)` casts
erase to the identity. `tl.debug_barrier()` is transcribed in place; it is an
intra-program fence and erases to a no-op at the algorithm layer. All four
`tl.constexpr` flags (`USE_INITIAL_STATE`, `STORE_FINAL_STATE`,
`IS_HEADWISE_BETA`, and the backward `USE_DH0`/`USE_DHT`) are modeled and flow
through the surfaces verbatim as `Bool` parameters.

The cross-step folds threading `h` (forward), `d_h` (backward loop 1) and the
recomputed `h` (backward loop 2) are the **trusted loop boundary**, exactly as
in `fused_recurrent_hgrn` / `fused_rwkv6_kernel`: the carried state is
presented to each step face as a materialized buffer (`HPrev`/`HOut`/`DHPrev`),
and under the *assumed* carry invariant `HPrev = deltaState(m)` the forward
loop-body faces realize `vNewClosed(m)`, `deltaState(m+1)` and `outputClosed(m)`
(theorem `stateStepSpec_eq_deltaState_succ`, algebraic core `deltaState_succ`).
No clause discharges another clause's carry invariant, and there is no proven
chaining from one step's output buffer to the next step's input buffer. Two boundary consequences are stated plainly:

* the forward kernel **overwrites `v` in place** (row `t` is rewritten to
  `v_new` at step `t`, after being read); every face's recurrence hypothesis
  and conclusion are evaluated in that face's *own* initial state `s`, and the
  cross-step reconciliation of `deltaState`'s `v`-row references with the
  pristine input rows (which the kernel never re-reads after overwriting) is
  part of the trusted fold;
* the backward kernel reads the *updated* `v` (the stored `v_new` deltas) —
  its faces are genuine over the backward launch's actual input regions, and
  the backward per-step gradient formulas are realized against the
  materialized carried buffers (`DHPrev`, loop-2 `HPrev`) with the reverse /
  forward folds trusted, following the `fused_recurrent_hgrn` backward
  precedent.

Output-offset injectivity side conditions (`BK ≤ K`, `BV ≤ V` for the
`[BV,BK]`/`[BK,BV]` state tiles) are honest structural hypotheses; the Python
regression (`K = BK = 16`, `V = 32`, `BV ∈ {8, 32}`) satisfies them.

**The load masks — closed for the forward chain, still open for the rest.**
Every Python load in both kernels is guarded (`mask_bk` / `mask_bv`,
`other = 0`). The state of play, clause by clause:

* **The whole forward pass — clauses 3, 4 and 5 — is mask-faithful.**
  `fused_recurrent_delta_vnew_step_slice`, both
  `fused_recurrent_delta_state_step_slice_*` and
  `fused_recurrent_delta_output_step_slice` reproduce `mask_kv` on the state
  tile, `mask_bk` on `b_k` / `b_q`, `mask_bv` on `b_v` (and on headwise
  `b_beta`; the scalar `b_beta` is unmasked in Python too), plus the `mask_kv`
  store on the state slices. Their specs are guarded to match — each reduction
  summand is `if active… then … else 0`, which is what Python computes, since
  an out-of-range column reads `0` in *every* factor. These three clauses hold
  for partial tiles and carry **no** full-tile antecedent, and the guard
  propagates into `deltaState`, `vMinusClosed`, `vNewClosed` and `outputClosed`.
* **The backward loop-1 `dk` and `dv` bodies (clauses 6 and 7) are also
  mask-faithful**, with `mask_kv` on `prev`, `mask_bk` on `b_q` / `b_k`,
  `mask_bv` on `b_do` / `b_v` / headwise `b_beta`, and their specs guarded on
  the axis each one reduces over — `activeV` for `dk` (`axis = 1`) and
  `activeK` for `dv` (`axis = 0`).
* **Both `dbeta` bodies (clauses 8 and 9) are mask-faithful too.** The
  headwise one mirrors `dv` exactly. The scalar one carries *two* nested
  reductions — `axis = 0` over the key channels, then a full `tl.sum` over the
  value lanes — so `dbetaScalarStepSpec` is guarded on **both**: `activeK`
  inside and `activeV` outside. Its store stays unmasked, as in Python.
* **Backward loop 2 (clauses 10 and 11) is mask-faithful too**, completing the
  port: the `dk` correction masks `d_k` (`mask_bk`), `d_v` (`mask_bv`) and `h`
  (`mask_kv`); `dq` masks `prev` (`mask_kv`), `b_k` (`mask_bk`) and
  `b_v` / `b_do` / headwise `b_beta` (`mask_bv`). Both reduce `axis = 1`, so
  `dkCorrStepSpec`, `dkCorrClosed` and `dqStepSpec` are `activeV`-guarded.

**No clause of this port carries a full-tile hypothesis any more.** All eleven
hold for partial key and value tiles.

What unblocked clauses 3 and 4 was `Semantics/MaskedReduction.lean`'s
`ite_some_some` (it pushes each `other = 0` carrier's `some` outward so the
existing `@[simp]` `WithBot` lemmas collapse the whole factor tower) together
with the `TileShape.insertAxisIndex` `Fin`-literal normalizations. That
machinery now exists and is proven on this port and on `fused_rwkv6_kernel`;
the remaining clauses are **mechanical work, not a missing capability**, and
this docstring should not be read as claiming otherwise.

## DSL-forced transcription notes (all mechanical, documented per
`review_criteria.md`)

* Python `do` (grad-output pointer) is spelled `do_` (`do` is a Lean keyword);
  the Python loop variables `_` are spelled `_i`.
* DSL pointers are `ℕ`-offsets and do not support `ptr − literal`, so the
  scalar-beta pointer initializations `… + T - 1` (the non-headwise
  `p_beta`/`p_dbeta` forms) are transcribed with the trailing subtraction
  parenthesized into the `ℕ` domain (`… + ($(T) - $(1))`); the groupings
  agree whenever `T ≥ 1`, and for `T = 0` the pointer is never dereferenced
  (the `range(T)` loop is empty). The `(T - 1) * K` / `(T - 1) * V` offsets
  are already parenthesized in the Python and transcribe verbatim.
* The Python conditional increments `p_beta += V if IS_HEADWISE_BETA else 1`
  (and the `p_dbeta` analogue / the conditional `p_beta`/`p_dbeta`/`b_beta`/
  `d_beta` definitions) are transcribed as `if IS_HEADWISE_BETA { … } else
  { … }` DSL gates — the whitelisted constexpr-branch form.

Translation-surface blocker: the Python conditional-expression pointer
increments (`p_beta += V if IS_HEADWISE_BETA else 1` and the `p_dbeta`
analogue) and conditional definitions are spelled as `if IS_HEADWISE_BETA
{ … } else { … }` constexpr gates, one statement per arm — this adds one
`if` to the control-flow count and repeats the `p_beta`/`p_dbeta` lhs once
per arm relative to the Python ternary form. `do` is spelled `do_` (Lean
keyword) and `_` loop variables are spelled `_i`; the scalar-beta `… + T - 1`
pointer initializations are parenthesized into the ℕ domain
(`… + ($(T) - $(1))`). All arms transcribe the Python verbatim otherwise.
-/

namespace VeriTile.Bench.TritonBenchG.FusedRecurrentDelta

open VeriTile.Triton
open scoped VeriTile.Triton.Masked3DTileShapedKernelIO₂

set_option linter.unusedSimpArgs false
set_option linter.unusedVariables false

/-! **★ Main theorem:** `fused_recurrent_delta_output_summary_general` —
shape-general, but scoped to eight single-step **slices** (one of which writes the
internal carry register `HOut`, not a Python tensor), not to the launched
kernels. -/

/-! # ══════════ CORRECT — genuine / dimension-general (review this) ══════════ -/

section Correct_without_Rounding

/-- Faithful transcription of `fused_recurrent_delta.py`'s
`fused_recurrent_fwd_kernel`.

All three `tl.constexpr` flags are `Bool` parameters gating the verbatim
branches; the `IS_HEADWISE_BETA` branches keep the Python `p_beta`/`b_beta`
shapes (`[BV]` row vs scalar). See the module docstring for the three
mechanical transcription notes (`_i` loop variable, `ℕ`-domain grouping of
trailing `- 1`, `if`-gate form of the conditional `p_beta` increment). -/
def fused_recurrent_delta_fwd_surface
    (q k v beta o h0 ht : RegionName)
    (s_qk_h s_vo_h B H T K V BK BV : Nat) (scale : ℝ)
    (USE_INITIAL_STATE STORE_FINAL_STATE IS_HEADWISE_BETA : Bool) :
    ComputeKernel := triton {
  i_v = tl.program_id(0)
  i_k = tl.program_id(1)
  i_bh = tl.program_id(2)
  p_q = q + i_bh * $(s_qk_h) + i_k * $(BK) + tl.arange(0, $(BK))
  p_k = k + i_bh * $(s_qk_h) + i_k * $(BK) + tl.arange(0, $(BK))
  p_v = v + i_bh * $(s_vo_h) + i_v * $(BV) + tl.arange(0, $(BV))
  if IS_HEADWISE_BETA {
    p_beta = beta + i_bh * $(s_vo_h) + i_v * $(BV) + tl.arange(0, $(BV))
  } else {
    p_beta = beta + i_bh * $(T)
  }
  p_o = o + (i_bh + i_k * $(B) * $(H)) * $(s_vo_h) + i_v * $(BV) + tl.arange(0, $(BV))
  mask_bk = (i_k * $(BK) + tl.arange(0, $(BK))) < $(K)
  mask_bv = (i_v * $(BV) + tl.arange(0, $(BV))) < $(V)
  mask_kv = mask_bk[None, :] & mask_bv[:, None]
  h = tl.zeros([$(BV), $(BK)], dtype=tl.float32)
  if USE_INITIAL_STATE {
    p_h0 = h0 + i_bh * $(K) * $(V) +
      (i_k * $(BK) + tl.arange(0, $(BK))[None, :]) * $(V) +
      (i_v * $(BV) + tl.arange(0, $(BV))[:, None])
    h += tl.load(p_h0, mask=mask_kv, other=0).to(tl.float32)
  }
  for _i in range($(0), $(T), $(1)) {
    b_k = tl.load(p_k, mask=mask_bk, other=0).to(tl.float32)
    b_v = tl.load(p_v, mask=mask_bv, other=0).to(tl.float32)
    b_q = tl.load(p_q, mask=mask_bk, other=0).to(tl.float32) * $(scale)
    _v_minus = tl.sum(h * b_k[None, :], axis=1)
    b_v -= _v_minus
    if IS_HEADWISE_BETA {
      b_beta = tl.load(p_beta, mask=mask_bv, other=0).to(tl.float32)
    } else {
      b_beta = tl.load(p_beta).to(tl.float32)
    }
    tl.store(p_v, (b_v).to(p_v.dtype.element_ty), mask=mask_bv)
    b_v *= b_beta
    h += b_k[None, :] * b_v[:, None]
    _o = h * b_q[None, :]
    _o = tl.sum(_o, axis=1)
    tl.store(p_o, (_o).to(p_o.dtype.element_ty), mask=mask_bv)
    p_q += $(K)
    p_k += $(K)
    p_o += $(V)
    p_v += $(V)
    if IS_HEADWISE_BETA {
      p_beta += $(V)
    } else {
      p_beta += $(1)
    }
  }
  if STORE_FINAL_STATE {
    p_ht = ht + i_bh * $(K) * $(V) +
      (i_k * $(BK) + tl.arange(0, $(BK))[None, :]) * $(V) +
      (i_v * $(BV) + tl.arange(0, $(BV))[:, None])
    tl.store(p_ht, (h).to(p_ht.dtype.element_ty), mask=mask_kv)
  }
}

/-- The full delta-rule forward surface lowers to the algorithm layer, for
every flag combination. -/
theorem fused_recurrent_delta_fwd_surface_toAlgorithm_supported
    (q k v beta o h0 ht : RegionName)
    (s_qk_h s_vo_h B H T K V BK BV : Nat) (scale : ℝ)
    (USE_INITIAL_STATE STORE_FINAL_STATE IS_HEADWISE_BETA : Bool) :
    ∃ alg, (fused_recurrent_delta_fwd_surface q k v beta o h0 ht s_qk_h s_vo_h
      B H T K V BK BV scale USE_INITIAL_STATE STORE_FINAL_STATE
      IS_HEADWISE_BETA).toAlgorithm? = Except.ok alg := by
  simp [fused_recurrent_delta_fwd_surface, ComputeExpr.toAlgorithm?,
    ComputeOp.toAlgorithm?]

/-- Faithful transcription of `fused_recurrent_delta.py`'s
`fused_recurrent_bwd_kernel`: the reverse-time `d_h` scan storing
`dk`/`dv`/`dbeta`, the optional `dh0` store, the `tl.debug_barrier()` fence,
then the forward-time recomputation of `h` storing the `dk` correction and
`dq`. `do` is spelled `do_`; see the module docstring for the other two
mechanical notes. -/
def fused_recurrent_delta_bwd_surface
    (q k v beta dht dh0 do_ dq dk dv dbeta h0 : RegionName)
    (s_qk_h s_vo_h NK B H T K V BK BV : Nat) (scale : ℝ)
    (USE_INITIAL_STATE IS_HEADWISE_BETA USE_DH0 USE_DHT : Bool) :
    ComputeKernel := triton {
  i_v = tl.program_id(0)
  i_k = tl.program_id(1)
  i_bh = tl.program_id(2)
  mask_bk = i_k * $(BK) + tl.arange(0, $(BK)) < $(K)
  mask_bv = i_v * $(BV) + tl.arange(0, $(BV)) < $(V)
  p_q = q + i_bh * $(s_qk_h) + i_k * $(BK) + tl.arange(0, $(BK)) + ($(T) - $(1)) * $(K)
  p_k = k + i_bh * $(s_qk_h) + i_k * $(BK) + tl.arange(0, $(BK)) + ($(T) - $(1)) * $(K)
  p_do = do_ + i_bh * $(s_vo_h) + i_v * $(BV) + tl.arange(0, $(BV)) + ($(T) - $(1)) * $(V)
  p_v = v + i_bh * $(s_vo_h) + i_v * $(BV) + tl.arange(0, $(BV)) + ($(T) - $(1)) * $(V)
  if IS_HEADWISE_BETA {
    p_beta = beta + i_bh * $(s_vo_h) + i_v * $(BV) + tl.arange(0, $(BV)) + ($(T) - $(1)) * $(V)
  } else {
    p_beta = beta + i_bh * $(T) + ($(T) - $(1))
  }
  p_dk = dk + (i_bh + i_v * $(B) * $(H)) * $(s_qk_h) + i_k * $(BK) + tl.arange(0, $(BK)) + ($(T) - $(1)) * $(K)
  p_dv = dv + (i_bh + i_k * $(B) * $(H)) * $(s_vo_h) + i_v * $(BV) + tl.arange(0, $(BV)) + ($(T) - $(1)) * $(V)
  if IS_HEADWISE_BETA {
    p_dbeta = dbeta + (i_bh + i_k * $(B) * $(H) + i_v * $(B) * $(H) * $(NK)) * $(s_vo_h) + tl.arange(0, $(BV)) + ($(T) - $(1)) * $(V)
  } else {
    p_dbeta = dbeta + (i_bh + i_v * $(B) * $(H)) * $(T) + ($(T) - $(1))
  }
  d_h = tl.zeros([$(BK), $(BV)], dtype=tl.float32)
  if USE_DHT {
    p_ht = dht + i_bh * $(K) * $(V) +
      (i_k * $(BK) + tl.arange(0, $(BK))[:, None]) * $(V) +
      (i_v * $(BV) + tl.arange(0, $(BV))[None, :])
    d_h += tl.load(p_ht, mask=mask_bk[:, None] & mask_bv[None, :], other=0).to(tl.float32)
  }
  for _i in range($(T)) {
    b_q = tl.load(p_q, mask=mask_bk, other=0).to(tl.float32) * $(scale)
    b_k = tl.load(p_k, mask=mask_bk, other=0).to(tl.float32)
    b_v = tl.load(p_v, mask=mask_bv, other=0).to(tl.float32)
    b_do = tl.load(p_do, mask=mask_bv, other=0).to(tl.float32)
    if IS_HEADWISE_BETA {
      b_beta = tl.load(p_beta, mask=mask_bv, other=0).to(tl.float32)
    } else {
      b_beta = tl.load(p_beta).to(tl.float32)
    }
    d_h += b_q[:, None] * b_do[None, :]
    d_k = tl.sum(d_h * (b_v * b_beta)[None, :], axis=1)
    d_v = tl.sum(d_h * b_k[:, None], axis=0)
    if IS_HEADWISE_BETA {
      d_beta = d_v * b_v
    } else {
      d_beta = tl.sum(d_v * b_v)
    }
    d_v = d_v * b_beta
    tl.store(p_dk, (d_k).to(p_dk.dtype.element_ty), mask=mask_bk)
    tl.store(p_dv, (d_v).to(p_dv.dtype.element_ty), mask=mask_bv)
    if IS_HEADWISE_BETA {
      tl.store(p_dbeta, (d_beta).to(p_dbeta.dtype.element_ty), mask=mask_bv)
    } else {
      tl.store(p_dbeta, (d_beta).to(p_dbeta.dtype.element_ty))
    }
    d_h -= b_k[:, None] * d_v[None, :]
    p_do -= $(V)
    p_q -= $(K)
    p_k -= $(K)
    p_v -= $(V)
    p_dk -= $(K)
    p_dv -= $(V)
    if IS_HEADWISE_BETA {
      p_dbeta -= $(V)
    } else {
      p_dbeta -= $(1)
    }
    if IS_HEADWISE_BETA {
      p_beta -= $(V)
    } else {
      p_beta -= $(1)
    }
  }
  if USE_DH0 {
    p_dh0 = dh0 + i_bh * $(K) * $(V) +
      (i_k * $(BK) + tl.arange(0, $(BK))[:, None]) * $(V) +
      (i_v * $(BV) + tl.arange(0, $(BV))[None, :])
    tl.store(p_dh0, (d_h).to(p_dh0.dtype.element_ty), mask=mask_bk[:, None] & mask_bv[None, :])
  }
  tl.debug_barrier()
  h = tl.zeros([$(BK), $(BV)], dtype=tl.float32)
  p_q = q + i_bh * $(s_qk_h) + i_k * $(BK) + tl.arange(0, $(BK))
  p_k = k + i_bh * $(s_qk_h) + i_k * $(BK) + tl.arange(0, $(BK))
  p_v = v + i_bh * $(s_vo_h) + i_v * $(BV) + tl.arange(0, $(BV))
  if IS_HEADWISE_BETA {
    p_beta = beta + i_bh * $(s_vo_h) + i_v * $(BV) + tl.arange(0, $(BV))
  } else {
    p_beta = beta + i_bh * $(T)
  }
  p_do = do_ + i_bh * $(s_vo_h) + i_v * $(BV) + tl.arange(0, $(BV))
  p_dq = dq + (i_bh + i_v * $(B) * $(H)) * $(s_qk_h) + i_k * $(BK) + tl.arange(0, $(BK))
  p_dv = dv + (i_bh + i_k * $(B) * $(H)) * $(s_vo_h) + i_v * $(BV) + tl.arange(0, $(BV))
  p_dk = dk + (i_bh + i_v * $(B) * $(H)) * $(s_qk_h) + i_k * $(BK) + tl.arange(0, $(BK))
  if USE_INITIAL_STATE {
    mask_kv = mask_bk[:, None] & mask_bv[None, :]
    p_h0 = h0 + i_bh * $(K) * $(V) +
      (i_k * $(BK) + tl.arange(0, $(BK))[:, None]) * $(V) +
      (i_v * $(BV) + tl.arange(0, $(BV))[None, :])
    h += tl.load(p_h0, mask=mask_kv, other=0).to(tl.float32)
  }
  for i in range($(0), $(T), $(1)) {
    d_k = tl.load(p_dk, mask=mask_bk, other=0).to(tl.float32)
    d_v = tl.load(p_dv, mask=mask_bv, other=0).to(tl.float32)
    d_k -= tl.sum(d_v[None, :] * h, axis=1)
    tl.store(p_dk, (d_k).to(p_dk.dtype.element_ty), mask=mask_bk)
    b_k = tl.load(p_k, mask=mask_bk, other=0).to(tl.float32)
    b_v = tl.load(p_v, mask=mask_bv, other=0).to(tl.float32)
    b_do = tl.load(p_do, mask=mask_bv, other=0).to(tl.float32)
    if IS_HEADWISE_BETA {
      b_beta = tl.load(p_beta, mask=mask_bv, other=0).to(tl.float32)
    } else {
      b_beta = tl.load(p_beta).to(tl.float32)
    }
    b_v *= b_beta
    h += b_k[:, None] * b_v[None, :]
    _d_q = h * b_do[None, :]
    d_q = tl.sum(_d_q, axis=1) * $(scale)
    tl.store(p_dq, (d_q).to(p_dq.dtype.element_ty), mask=mask_bk)
    p_k += $(K)
    p_do += $(V)
    p_v += $(V)
    p_dk += $(K)
    p_dv += $(V)
    p_dq += $(K)
    if IS_HEADWISE_BETA {
      p_beta += $(V)
    } else {
      p_beta += $(1)
    }
  }
}

/-- The full delta-rule backward surface — both reverse and forward loops,
the `dh0` branch, and the `tl.debug_barrier()` fence (which erases to a no-op
at the algorithm layer) — lowers to the algorithm layer, for every flag
combination. -/
theorem fused_recurrent_delta_bwd_surface_toAlgorithm_supported
    (q k v beta dht dh0 do_ dq dk dv dbeta h0 : RegionName)
    (s_qk_h s_vo_h NK B H T K V BK BV : Nat) (scale : ℝ)
    (USE_INITIAL_STATE IS_HEADWISE_BETA USE_DH0 USE_DHT : Bool) :
    ∃ alg, (fused_recurrent_delta_bwd_surface q k v beta dht dh0 do_ dq dk dv
      dbeta h0 s_qk_h s_vo_h NK B H T K V BK BV scale USE_INITIAL_STATE
      IS_HEADWISE_BETA USE_DH0 USE_DHT).toAlgorithm? = Except.ok alg := by
  simp [fused_recurrent_delta_bwd_surface, ComputeExpr.toAlgorithm?,
    ComputeOp.toAlgorithm?]

/-! ## Index / offset helpers

`s.pids 0 = i_v`, `s.pids 1 = i_k`, `s.pids 2 = i_bh`. The forward state tile
is `[BV, BK]` (`idx.1` the value axis `j_v`, `idx.2.1` the key axis `j_k`);
the backward carried tiles (`d_h` and the recomputed `h`) are `[BK, BV]`
(`idx.1 = j_k`, `idx.2.1 = j_v`). Both share the flattened row-major state
memory layout `i_bh·K·V + j_k·V + j_v` of `h0`/`ht`. -/

def vIndex (s : BlockState) (BV : Nat) (jv : Fin BV) : Nat :=
  s.pids 0 * BV + jv.val

def kIndex (s : BlockState) (BK : Nat) (jk : Fin BK) : Nat :=
  s.pids 1 * BK + jk.val

/-- Flattened `[BV, BK]` state / `h0` / `ht` address
(row-major `i_bh·K·V + j_k·V + j_v`). -/
def stateOffset (s : BlockState) (K V BK BV : Nat)
    (idx : TileIndex [BV, BK]) : Nat :=
  s.pids 2 * K * V + kIndex s BK idx.2.1 * V + vIndex s BV idx.1

/-- The same flattened state address for the backward `[BK, BV]` tile
orientation (`d_h`, loop-2 `h`). -/
def dhOffset (s : BlockState) (K V BK BV : Nat)
    (idx : TileIndex [BK, BV]) : Nat :=
  s.pids 2 * K * V + kIndex s BK idx.1 * V + vIndex s BV idx.2.1

def activeV (s : BlockState) (V BV : Nat) (jv : Fin BV) : Prop :=
  vIndex s BV jv < V

instance activeVDecidable (s : BlockState) (V BV : Nat) (jv : Fin BV) :
    Decidable (activeV s V BV jv) := by
  unfold activeV; infer_instance

def activeK (s : BlockState) (K BK : Nat) (jk : Fin BK) : Prop :=
  kIndex s BK jk < K

instance activeKDecidable (s : BlockState) (K BK : Nat) (jk : Fin BK) :
    Decidable (activeK s K BK jk) := by
  unfold activeK; infer_instance

/-- Python's `mask_kv` tile predicate (`mask_bk[None, :] & mask_bv[:, None]`). -/
def activeKV (s : BlockState) (K V BK BV : Nat) (idx : TileIndex [BV, BK]) : Prop :=
  activeK s K BK idx.2.1 ∧ activeV s V BV idx.1

instance activeKVDecidable (s : BlockState) (K V BK BV : Nat)
    (idx : TileIndex [BV, BK]) : Decidable (activeKV s K V BK BV idx) := by
  unfold activeKV; infer_instance

/-! ## Genuine input readers (over the *input* regions)

`kVal/vVal` read the kernel's exact block-pointer layouts at time row `t`
through the shared `[T, K]` k-layout (`q`, `k`) and `[T, V]` v-layout (`v`,
`do`, headwise `beta`). `betaVal` selects the headwise v-layout row or the
per-`(b,h,t)` scalar according to `IS_HEADWISE_BETA`. -/

/-- Element `R[i_bh][t, j_k]` of the shared `[T, K]` **k-layout** at time row
`t`, key channel `j_k` (offset `i_bh·s_qk_h + (i_k·BK + j_k) + t·K`). Both `q`
and `k` block pointers use this layout. -/
noncomputable def kVal (s : BlockState) (r : RegionName)
    (s_qk_h K BK : Nat) (t : Nat) (jk : Fin BK) : ℝ :=
  s.readMem r (s.pids 2 * s_qk_h + s.pids 1 * BK + jk.val + t * K)

/-- `q[t][j_k]·scale` — the kernel multiplies the loaded `q` row by `scale`. -/
noncomputable def qVal (s : BlockState) (q : RegionName)
    (s_qk_h K BK : Nat) (scale : ℝ) (t : Nat) (jk : Fin BK) : ℝ :=
  scale * kVal s q s_qk_h K BK t jk

/-- Element `R[i_bh][t, j_v]` of the `[T, V]` **v-layout** at time row `t`,
value channel `j_v` (offset `i_bh·s_vo_h + (i_v·BV + j_v) + t·V`). The `v`,
`do` and headwise-`beta` block pointers use this layout. -/
noncomputable def vVal (s : BlockState) (r : RegionName)
    (s_vo_h V BV : Nat) (t : Nat) (jv : Fin BV) : ℝ :=
  s.readMem r (s.pids 2 * s_vo_h + s.pids 0 * BV + jv.val + t * V)

/-- `β_t[j_v]`: the headwise v-layout row when `IS_HEADWISE_BETA`, else the
per-`(b,h,t)` scalar `beta[i_bh·T + t]` (broadcast over `j_v`). -/
noncomputable def betaVal (s : BlockState) (beta : RegionName)
    (IS_HEADWISE_BETA : Bool) (s_vo_h T V BV : Nat)
    (t : Nat) (jv : Fin BV) : ℝ :=
  if IS_HEADWISE_BETA then
    s.readMem beta (s.pids 2 * s_vo_h + s.pids 0 * BV + jv.val + t * V)
  else
    s.readMem beta (s.pids 2 * T + t)

noncomputable def h0Val (s : BlockState) (h0 : RegionName)
    (K V BK BV : Nat) (idx : TileIndex [BV, BK]) : ℝ :=
  s.readMem h0 (stateOffset s K V BK BV idx)

/-- Seeded initial state `h^(0)`: `h0` if `USE_INITIAL_STATE` else `0`. -/
noncomputable def stateSeed (s : BlockState) (h0 : RegionName)
    (USE_INITIAL_STATE : Bool) (K V BK BV : Nat)
    (idx : TileIndex [BV, BK]) : ℝ :=
  if USE_INITIAL_STATE then h0Val s h0 K V BK BV idx else 0

/-! ## Genuine standalone recurrence spec

`deltaState m` is the delta-rule state after processing time steps
`0, …, m−1`, defined by **recursion on `m`** over the *input* regions
`k, v, beta, h0` — never a read-back of the kernel's own output. The
delta-rule transition has no geometric closed form, so the recurrence itself
is the specification (`reversed_cumsum_scalar` carry-fold precedent). -/

/-- **Genuine delta-rule state recurrence.** Tile element `idx = (j_v, j_k)`:

```
deltaState 0       = stateSeed                    (h0 or 0)
deltaState (m+1)   = deltaState m
                     + k_m[j_k] · (β_m[j_v] · (v_m[j_v] − Σ_{j'_k} deltaState m [j_v,j'_k] · k_m[j'_k]))
```

A standalone specification over the input regions `k, v, beta, h0`. -/
noncomputable def deltaState (s : BlockState) (k v beta h0 : RegionName)
    (IS_HEADWISE_BETA USE_INITIAL_STATE : Bool)
    (s_qk_h s_vo_h T K V BK BV : Nat) :
    Nat → TileIndex [BV, BK] → ℝ
  | 0, idx => stateSeed s h0 USE_INITIAL_STATE K V BK BV idx
  | m + 1, idx =>
    deltaState s k v beta h0 IS_HEADWISE_BETA USE_INITIAL_STATE
        s_qk_h s_vo_h T K V BK BV m idx
      + kVal s k s_qk_h K BK m idx.2.1 *
          (betaVal s beta IS_HEADWISE_BETA s_vo_h T V BV m idx.1 *
            (vVal s v s_vo_h V BV m idx.1
              - ∑ jk : Fin BK,
                  if activeK s K BK jk then
                    deltaState s k v beta h0 IS_HEADWISE_BETA USE_INITIAL_STATE
                        s_qk_h s_vo_h T K V BK BV m (idx.1, jk, PUnit.unit)
                      * kVal s k s_qk_h K BK m jk
                  else 0))

/-- The state readout `v_minus` at step `m`, lane `j_v`:
`Σ_{j_k} deltaState(m)[j_v,j_k] · k_m[j_k]`. -/
noncomputable def vMinusClosed (s : BlockState) (k v beta h0 : RegionName)
    (IS_HEADWISE_BETA USE_INITIAL_STATE : Bool)
    (s_qk_h s_vo_h T K V BK BV : Nat) (m : Nat) (jv : Fin BV) : ℝ :=
  ∑ jk : Fin BK,
    if activeK s K BK jk then
      deltaState s k v beta h0 IS_HEADWISE_BETA USE_INITIAL_STATE
          s_qk_h s_vo_h T K V BK BV m (jv, jk, PUnit.unit)
        * kVal s k s_qk_h K BK m jk
    else 0

/-- **Genuine closed form of the in-place `v` writeback at step `m`**:
the delta `v_new = v_m − v_minus`. -/
noncomputable def vNewClosed (s : BlockState) (k v beta h0 : RegionName)
    (IS_HEADWISE_BETA USE_INITIAL_STATE : Bool)
    (s_qk_h s_vo_h T K V BK BV : Nat) (m : Nat) (jv : Fin BV) : ℝ :=
  vVal s v s_vo_h V BV m jv
    - vMinusClosed s k v beta h0 IS_HEADWISE_BETA USE_INITIAL_STATE
        s_qk_h s_vo_h T K V BK BV m jv

/-- **The delta-rule carry-fold recurrence, unrolled one step**:
`deltaState(m+1) = deltaState(m) + k_m ⊗ (β_m ⊙ v_new(m))`. This is the exact
closed-form counterpart of the Python loop body
`h += b_k[None,:] * (b_beta * (b_v - v_minus))[:,None]`. -/
theorem deltaState_succ (s : BlockState) (k v beta h0 : RegionName)
    (IS_HEADWISE_BETA USE_INITIAL_STATE : Bool)
    (s_qk_h s_vo_h T K V BK BV : Nat) (m : Nat) (idx : TileIndex [BV, BK]) :
    deltaState s k v beta h0 IS_HEADWISE_BETA USE_INITIAL_STATE
        s_qk_h s_vo_h T K V BK BV (m + 1) idx
      = deltaState s k v beta h0 IS_HEADWISE_BETA USE_INITIAL_STATE
            s_qk_h s_vo_h T K V BK BV m idx
        + kVal s k s_qk_h K BK m idx.2.1 *
            (betaVal s beta IS_HEADWISE_BETA s_vo_h T V BV m idx.1 *
              vNewClosed s k v beta h0 IS_HEADWISE_BETA USE_INITIAL_STATE
                s_qk_h s_vo_h T K V BK BV m idx.1) := by
  simp only [deltaState, vNewClosed, vMinusClosed]

/-- **Genuine closed form of output row `m`, lane `j_v`** — the readout of the
*post-update* state:
`o_m[j_v] = Σ_{j_k} deltaState(m+1)[j_v,j_k] · scale·q_m[j_k]`. -/
noncomputable def outputClosed (s : BlockState) (q k v beta h0 : RegionName)
    (IS_HEADWISE_BETA USE_INITIAL_STATE : Bool)
    (s_qk_h s_vo_h T K V BK BV : Nat) (scale : ℝ) (m : Nat) (jv : Fin BV) : ℝ :=
  ∑ jk : Fin BK,
    if activeK s K BK jk then
      deltaState s k v beta h0 IS_HEADWISE_BETA USE_INITIAL_STATE
          s_qk_h s_vo_h T K V BK BV (m + 1) (jv, jk, PUnit.unit)
        * qVal s q s_qk_h K BK scale m jk
    else 0

/-! ## Row offsets of the per-step stores -/

/-- The `v`-layout row address at time `t`, lane `j_v` — shared by the `v`
in-place writeback and the `v`/`do`/headwise-`beta` loads. -/
def vRowOffset (s : BlockState) (t s_vo_h V BV : Nat) (jv : Fin BV) : Nat :=
  s.pids 2 * s_vo_h + s.pids 0 * BV + jv.val + t * V

/-- The masked output address at lane `j_v` for time row `t` — the kernel's
exact `o + (i_bh + i_k·B·H)·s_vo_h + i_v·BV + j_v + t·V` layout (also the
`dv` store layout of the backward kernel). -/
def outOffset (s : BlockState) (t s_vo_h B H V BV : Nat) (jv : Fin BV) : Nat :=
  (s.pids 2 + s.pids 1 * B * H) * s_vo_h + s.pids 0 * BV + jv.val + t * V

/-! ## `v_new` writeback step slice (the in-place delta store)

One loop body's `v` writeback, isolated from the cross-step loop: with the
materialized pre-update state tile `HPrev`, it loads the time-`t` rows of `k`
and `v`, forms `v_minus = Σ_{j_k} HPrev·k_t` and masked-stores the delta
`v_t − v_minus` back into `v` at row `t` (the kernel's in-place update; the
row is read before it is written). -/

def fused_recurrent_delta_vnew_step_slice
    (HPrev k v : RegionName) (t s_qk_h s_vo_h K V BK BV : Nat) :
    ComputeKernel := triton {
  i_v = tl.program_id(0)
  i_k = tl.program_id(1)
  i_bh = tl.program_id(2)
  offs_k = tl.arange(0, $(BK))
  offs_v = tl.arange(0, $(BV))
  mask_bk = (i_k * $(BK) + offs_k) < $(K)
  mask_bv = (i_v * $(BV) + offs_v) < $(V)
  mask_kv = mask_bk[None, :] & mask_bv[:, None]
  prev = tl.load(HPrev + i_bh * $(K) * $(V) +
    (i_k * $(BK) + offs_k[None, :]) * $(V) + (i_v * $(BV) + offs_v[:, None]),
    mask=mask_kv, other=0.0)
  b_k = tl.load(k + i_bh * $(s_qk_h) + i_k * $(BK) + offs_k + $(t) * $(K),
    mask=mask_bk, other=0.0)
  b_v = tl.load(v + i_bh * $(s_vo_h) + i_v * $(BV) + offs_v + $(t) * $(V),
    mask=mask_bv, other=0.0)
  _v_minus = tl.sum(prev * b_k[None, :], axis=1)
  b_v -= _v_minus
  tl.store(v + i_bh * $(s_vo_h) + i_v * $(BV) + offs_v + $(t) * $(V),
    (b_v).to(v.dtype.element_ty), mask=mask_bv)
}

/-- The per-lane spec of one `v_new` writeback, over the *in-range* key channels
(`mask_bk`, i.e. `activeK`):
`v_t[j_v] − Σ_{j_k ∈ mask_bk} HPrev[j_v,j_k] · k_t[j_k]`.

The `activeK` guard mirrors Python's `other = 0` loads: on an out-of-range key
channel both `prev` (via `mask_kv`) and `b_k` (via `mask_bk`) read `0`, so the
column contributes `0 · 0 = 0` to `tl.sum(_, axis = 1)`. -/
noncomputable def vnewStepSpec (s : BlockState) (HPrev k v : RegionName)
    (t s_qk_h s_vo_h K V BK BV : Nat) (jv : Fin BV) : ℝ :=
  s.readMem v (vRowOffset s t s_vo_h V BV jv)
    - ∑ jk : Fin BK,
        if activeK s K BK jk then
          s.readMem HPrev (stateOffset s K V BK BV (jv, jk, PUnit.unit))
            * kVal s k s_qk_h K BK t jk
        else 0

set_option maxHeartbeats 1000000 in
theorem fused_recurrent_delta_vnew_step_slice_correct
    (HPrev k v : RegionName) (t s_qk_h s_vo_h K V BK BV : Nat) (s : BlockState)
    (hOutInj : Function.Injective
      (fun jv : Fin BV => vRowOffset s t s_vo_h V BV jv)) :
    ∀ jv : Fin BV,
      let outAddr := vRowOffset s t s_vo_h V BV jv
      (exec (fused_recurrent_delta_vnew_step_slice HPrev k v
            t s_qk_h s_vo_h K V BK BV) s).map (·.readMem v outAddr)
        = some (if activeV s V BV jv then
            vnewStepSpec s HPrev k v t s_qk_h s_vo_h K V BK BV jv
          else s.readMem v outAddr) := by
  intro jv
  -- The masked loads' `other = 0.0` is an `OfScientific` literal; naming it once
  -- keeps the out-of-range branch inside `ring`'s reach.
  have hzero : (0.0 : ℝ) = 0 := by norm_num
  simp [exec, fused_recurrent_delta_vnew_step_slice, stepStmts, stepStmt,
        evalOp, evalOp.eq_def, Option.bind, Option.map, Tile.bop, Tile.cop,
        Tile.expandDim, Tile.uop, Tile.ptrAdd, Tile.reduceSum, Tile.reduceSumDrop,
        TileShape.axisDim, TileShape.eraseAxis, NumericDType.add, NumericDType.mul,
        NumericDType.sub, ComparableDType.lt, stateOffset, vRowOffset, activeV,
        vIndex, kIndex, TileShape.dropInsertedIndex]
  -- Collapse the guarded `WithBot ℝ` reduction the masked loads produce down to a
  -- plain real sum, exactly as `fused_rwkv6_kernel`'s output slice does.
  simp only [TileShape.insertAxisIndex_one_rank2, MaskedReduction.ite_some_some,
    Option.map₂_some_some, WithBot.sum_someTerm_eq_some, WithBot.unbotD_some]
  let offsetFn : TileIndex [BV] → Nat :=
    fun idx => s.pids 2 * s_vo_h + s.pids 0 * BV + idx.1.val + t * V
  let valueFn : TileIndex [BV] → ℝ :=
    fun idx =>
      (if s.pids 0 * BV + idx.1.val < V then
          s.readMem v (s.pids 2 * s_vo_h + s.pids 0 * BV + idx.1.val + t * V)
        else 0.0)
        - ∑ jk : Fin BK,
            (if s.pids 1 * BK + jk.val < K ∧ s.pids 0 * BV + idx.1.val < V then
                s.readMem HPrev
                  (s.pids 2 * K * V + (s.pids 1 * BK + jk.val) * V +
                    (s.pids 0 * BV + idx.1.val))
              else 0.0) *
              (if s.pids 1 * BK + jk.val < K then
                  s.readMem k (s.pids 2 * s_qk_h + s.pids 1 * BK + jk.val + t * K)
                else 0.0)
  let P : TileIndex [BV] → Prop := fun idx => s.pids 0 * BV + idx.1.val < V
  have hOffsetInj : Function.Injective offsetFn := by
    rintro ⟨a, _⟩ ⟨b, _⟩ hab
    have : vRowOffset s t s_vo_h V BV a = vRowOffset s t s_vo_h V BV b := by
      simpa [offsetFn, vRowOffset] using hab
    obtain rfl : a = b := hOutInj this
    rfl
  change (List.foldl
      (fun (acc : BlockState) idx =>
        if P idx then acc.writeMem v (offsetFn idx) (valueFn idx) else acc)
      _ (TileShape.allIndices [BV])).readMem v (offsetFn (jv, PUnit.unit)) =
    if activeV s V BV jv then
      vnewStepSpec s HPrev k v t s_qk_h s_vo_h K V BK BV jv
    else s.readMem v (offsetFn (jv, PUnit.unit))
  rw [BlockState.scatter_readback_prop_masked_nd _ _ _ _ hOffsetInj (jv, PUnit.unit)]
  by_cases hjv : s.pids 0 * BV + jv.val < V
  · simp only [P, hjv, if_true, activeV, vIndex, valueFn, vnewStepSpec,
      stateOffset, kVal, vVal, vRowOffset, kIndex, vIndex, activeK]
    congr 1
    apply Finset.sum_congr rfl
    intro jk _
    -- In range: every guard is true and the two summands are identical. Out of
    -- range: Python's `other = 0` zeroes both factors, giving `0 · 0 = 0`, which
    -- is exactly the guarded specification's `else 0`.
    by_cases hK : s.pids 1 * BK + jk.val < K
    · simp only [hK, hjv, and_self, if_true, and_true]
    · simp only [hK, if_false, false_and, hzero]
      ring
  · simp only [P, activeV, vIndex, hjv, if_false, BlockState.setReg_readMem]

theorem fused_recurrent_delta_vnew_step_slice_compute_correct
    (HPrev k v : RegionName) (t s_qk_h s_vo_h K V BK BV : Nat) (s : BlockState)
    (hOutInj : Function.Injective
      (fun jv : Fin BV => vRowOffset s t s_vo_h V BV jv)) :
    ComputeCorrect.Realizes_without_Rounding
      (kernel := fused_recurrent_delta_vnew_step_slice HPrev k v
        t s_qk_h s_vo_h K V BK BV)
      (initialState := s)
      (write := ComputeCorrect.WriteMap.writeIf
        (fun jv : Fin BV => activeV s V BV jv)
        (fun jv => (v, vRowOffset s t s_vo_h V BV jv)))
      (expected := fun jv : Fin BV =>
        vnewStepSpec s HPrev k v t s_qk_h s_vo_h K V BK BV jv) := by
  rw [ComputeCorrect.realizes_writeIf_iff]
  apply ComputeKernel.computeCorrect_of_toAlgKernel
  · simp [fused_recurrent_delta_vnew_step_slice, ComputeExpr.toAlgorithm?,
      ComputeOp.toAlgorithm?]
  intro s0 s' hExec hs0
  subst s0
  intro jv hActive
  have h := fused_recurrent_delta_vnew_step_slice_correct HPrev k v
    t s_qk_h s_vo_h K V BK BV s hOutInj jv
  rw [hExec] at h
  simpa [hActive] using Option.some.inj h

/-! ## State-update step slice (the delta-rule carry-fold body)

One loop body's state update, isolated from the cross-step loop: with the
materialized pre-update state tile `HPrev`, it loads the time-`t` rows of
`k`, `v` and `beta`, recomputes `v_minus`, the delta `b_v − v_minus`, the
beta scaling, and stores `HPrev + k_t ⊗ (β_t ⊙ v_new)` into the state buffer
`HOut`. The two `IS_HEADWISE_BETA` compile-time specializations differ in the
`b_beta` load shape (`[BV]` row vs scalar), exactly as in the surface. -/

def fused_recurrent_delta_state_step_slice_headwise
    (HPrev k v beta HOut : RegionName) (t s_qk_h s_vo_h T K V BK BV : Nat) :
    ComputeKernel := triton {
  i_v = tl.program_id(0)
  i_k = tl.program_id(1)
  i_bh = tl.program_id(2)
  offs_k = tl.arange(0, $(BK))
  offs_v = tl.arange(0, $(BV))
  mask_bk = (i_k * $(BK) + offs_k) < $(K)
  mask_bv = (i_v * $(BV) + offs_v) < $(V)
  mask_kv = mask_bk[None, :] & mask_bv[:, None]
  prev = tl.load(HPrev + i_bh * $(K) * $(V) +
    (i_k * $(BK) + offs_k[None, :]) * $(V) + (i_v * $(BV) + offs_v[:, None]),
    mask=mask_kv, other=0.0)
  b_k = tl.load(k + i_bh * $(s_qk_h) + i_k * $(BK) + offs_k + $(t) * $(K),
    mask=mask_bk, other=0.0)
  b_v = tl.load(v + i_bh * $(s_vo_h) + i_v * $(BV) + offs_v + $(t) * $(V),
    mask=mask_bv, other=0.0)
  _v_minus = tl.sum(prev * b_k[None, :], axis=1)
  b_v -= _v_minus
  b_beta = tl.load(beta + i_bh * $(s_vo_h) + i_v * $(BV) + offs_v + $(t) * $(V),
    mask=mask_bv, other=0.0)
  b_v *= b_beta
  acc = prev + b_k[None, :] * b_v[:, None]
  tl.store(HOut + i_bh * $(K) * $(V) +
    (i_k * $(BK) + offs_k[None, :]) * $(V) + (i_v * $(BV) + offs_v[:, None]),
    (acc).to(HOut.dtype.element_ty), mask=mask_kv)
}

def fused_recurrent_delta_state_step_slice_scalarbeta
    (HPrev k v beta HOut : RegionName) (t s_qk_h s_vo_h T K V BK BV : Nat) :
    ComputeKernel := triton {
  i_v = tl.program_id(0)
  i_k = tl.program_id(1)
  i_bh = tl.program_id(2)
  offs_k = tl.arange(0, $(BK))
  offs_v = tl.arange(0, $(BV))
  mask_bk = (i_k * $(BK) + offs_k) < $(K)
  mask_bv = (i_v * $(BV) + offs_v) < $(V)
  mask_kv = mask_bk[None, :] & mask_bv[:, None]
  prev = tl.load(HPrev + i_bh * $(K) * $(V) +
    (i_k * $(BK) + offs_k[None, :]) * $(V) + (i_v * $(BV) + offs_v[:, None]),
    mask=mask_kv, other=0.0)
  b_k = tl.load(k + i_bh * $(s_qk_h) + i_k * $(BK) + offs_k + $(t) * $(K),
    mask=mask_bk, other=0.0)
  b_v = tl.load(v + i_bh * $(s_vo_h) + i_v * $(BV) + offs_v + $(t) * $(V),
    mask=mask_bv, other=0.0)
  _v_minus = tl.sum(prev * b_k[None, :], axis=1)
  b_v -= _v_minus
  b_beta = tl.load(beta + i_bh * $(T) + $(t))
  b_v *= b_beta
  acc = prev + b_k[None, :] * b_v[:, None]
  tl.store(HOut + i_bh * $(K) * $(V) +
    (i_k * $(BK) + offs_k[None, :]) * $(V) + (i_v * $(BV) + offs_v[:, None]),
    (acc).to(HOut.dtype.element_ty), mask=mask_kv)
}

/-- The arithmetic spec of one state-update body (both beta modes, selected
by `IS_HEADWISE_BETA` through `betaVal`):
`HPrev + k_t ⊗ (β_t ⊙ (v_t − Σ_{j_k} HPrev·k_t))`. -/
noncomputable def stateStepSpec (s : BlockState) (HPrev k v beta : RegionName)
    (IS_HEADWISE_BETA : Bool) (t s_qk_h s_vo_h T K V BK BV : Nat)
    (idx : TileIndex [BV, BK]) : ℝ :=
  s.readMem HPrev (stateOffset s K V BK BV idx)
    + kVal s k s_qk_h K BK t idx.2.1 *
        (betaVal s beta IS_HEADWISE_BETA s_vo_h T V BV t idx.1 *
          (vVal s v s_vo_h V BV t idx.1
            - ∑ jk : Fin BK,
                if activeK s K BK jk then
                  s.readMem HPrev (stateOffset s K V BK BV (idx.1, jk, PUnit.unit))
                    * kVal s k s_qk_h K BK t jk
                else 0))

set_option maxHeartbeats 4000000 in
theorem fused_recurrent_delta_state_step_slice_headwise_correct
    (HPrev k v beta HOut : RegionName)
    (t s_qk_h s_vo_h T K V BK BV : Nat) (s : BlockState)
    (hOutInj : Function.Injective
      (fun idx : TileIndex [BV, BK] => stateOffset s K V BK BV idx)) :
    ∀ idx : TileIndex [BV, BK],
      let outAddr := stateOffset s K V BK BV idx
      (exec (fused_recurrent_delta_state_step_slice_headwise HPrev k v beta HOut
            t s_qk_h s_vo_h T K V BK BV) s).map (·.readMem HOut outAddr)
        = some (if activeKV s K V BK BV idx then
            stateStepSpec s HPrev k v beta Bool.true
              t s_qk_h s_vo_h T K V BK BV idx
          else s.readMem HOut outAddr) := by
  intro idx
  have hzero : (0.0 : ℝ) = 0 := by norm_num
  simp [exec, fused_recurrent_delta_state_step_slice_headwise, stepStmts, stepStmt,
        evalOp, evalOp.eq_def, Option.bind, Option.map, Tile.bop, Tile.cop,
        Tile.expandDim, Tile.uop, Tile.ptrAdd, Tile.reduceSum, Tile.reduceSumDrop,
        TileShape.axisDim, TileShape.eraseAxis, NumericDType.add, NumericDType.mul,
        NumericDType.sub, ComparableDType.lt, stateOffset, vRowOffset,
        vIndex, kIndex, TileShape.dropInsertedIndex]
  -- Collapse the guarded `WithBot ℝ` reduction the masked loads produce.
  simp only [TileShape.insertAxisIndex_one_rank2, MaskedReduction.ite_some_some,
    Option.map₂_some_some, WithBot.sum_someTerm_eq_some, WithBot.unbotD_some]
  let offsetFn : TileIndex [BV, BK] → Nat :=
    fun idx => s.pids 2 * K * V +
      (s.pids 1 * BK + idx.2.1.val) * V + (s.pids 0 * BV + idx.1.val)
  let valueFn : TileIndex [BV, BK] → ℝ :=
    fun idx =>
      (if s.pids 1 * BK + idx.2.1.val < K ∧ s.pids 0 * BV + idx.1.val < V then
          s.readMem HPrev
            (s.pids 2 * K * V + (s.pids 1 * BK + idx.2.1.val) * V +
              (s.pids 0 * BV + idx.1.val))
        else 0.0)
        + (if s.pids 1 * BK + idx.2.1.val < K then
              s.readMem k (s.pids 2 * s_qk_h + s.pids 1 * BK + idx.2.1.val + t * K)
            else 0.0) *
            (((if s.pids 0 * BV + idx.1.val < V then
                  s.readMem v (s.pids 2 * s_vo_h + s.pids 0 * BV + idx.1.val + t * V)
                else 0.0)
              - ∑ jk : Fin BK,
                  (if s.pids 1 * BK + jk.val < K ∧ s.pids 0 * BV + idx.1.val < V then
                      s.readMem HPrev
                        (s.pids 2 * K * V + (s.pids 1 * BK + jk.val) * V +
                          (s.pids 0 * BV + idx.1.val))
                    else 0.0) *
                    (if s.pids 1 * BK + jk.val < K then
                        s.readMem k
                          (s.pids 2 * s_qk_h + s.pids 1 * BK + jk.val + t * K)
                      else 0.0)) *
              (if s.pids 0 * BV + idx.1.val < V then
                  s.readMem beta (s.pids 2 * s_vo_h + s.pids 0 * BV + idx.1.val + t * V)
                else 0.0))
  let P : TileIndex [BV, BK] → Prop :=
    fun idx => s.pids 1 * BK + idx.2.1.val < K ∧ s.pids 0 * BV + idx.1.val < V
  have hOffsetInj : Function.Injective offsetFn := by
    simpa [offsetFn, stateOffset, kIndex, vIndex] using hOutInj
  change (List.foldl
      (fun (acc : BlockState) i =>
        if P i then acc.writeMem HOut (offsetFn i) (valueFn i) else acc)
      _ (TileShape.allIndices [BV, BK])).readMem HOut (offsetFn idx) =
    if activeKV s K V BK BV idx then
      stateStepSpec s HPrev k v beta Bool.true t s_qk_h s_vo_h T K V BK BV idx
    else s.readMem HOut (offsetFn idx)
  rw [BlockState.scatter_readback_prop_masked_nd _ _ _ _ hOffsetInj idx]
  by_cases hjk : s.pids 1 * BK + idx.2.1.val < K
  · by_cases hjv : s.pids 0 * BV + idx.1.val < V
    · -- both in range: the outer guards resolve and only the reduction's per-column
      -- guard is left, which `hsum` discharges lane by lane
      have hsum : ∀ jk : Fin BK,
          (if s.pids 1 * BK + jk.val < K ∧ s.pids 0 * BV + idx.1.val < V then
              s.readMem HPrev
                (s.pids 2 * K * V + (s.pids 1 * BK + jk.val) * V +
                  (s.pids 0 * BV + idx.1.val))
            else 0.0) *
            (if s.pids 1 * BK + jk.val < K then
                s.readMem k (s.pids 2 * s_qk_h + s.pids 1 * BK + jk.val + t * K)
              else 0.0)
          = if s.pids 1 * BK + jk.val < K then
              s.readMem HPrev
                  (s.pids 2 * K * V + (s.pids 1 * BK + jk.val) * V +
                    (s.pids 0 * BV + idx.1.val)) *
                s.readMem k (s.pids 2 * s_qk_h + s.pids 1 * BK + jk.val + t * K)
            else 0 := by
        intro jk
        by_cases hK : s.pids 1 * BK + jk.val < K
        · simp only [hK, hjv, and_self, if_true, and_true]
        · simp only [hK, if_false, false_and, hzero]
          ring
      -- `hsum` must fire *before* the outer simp: that simp rewrites `hjv` to
      -- `True` and renormalizes `0.0`, after which `hsum` no longer matches and
      -- the two sides carry syntactically different sums.
      simp only [valueFn, hsum]
      -- `Bool.false_eq_true` / `if_false` resolve `betaVal`'s compile-time flag in
      -- the scalar-beta specialization; the headwise one takes the `ite_true` side.
      simp only [P, activeKV, activeK, activeV, kIndex, vIndex, hjk, hjv,
        and_self, if_true, stateStepSpec, stateOffset, betaVal, kVal,
        vVal, kIndex, vIndex, if_true, ite_true, Bool.false_eq_true, if_false,
        ite_false]
      ring
    · simp only [P, activeKV, activeK, activeV, kIndex, vIndex, hjv, and_false,
        if_false, BlockState.setReg_readMem, offsetFn]
  · simp only [P, activeKV, activeK, activeV, kIndex, vIndex, hjk, false_and,
      if_false, BlockState.setReg_readMem, offsetFn]

set_option maxHeartbeats 4000000 in
theorem fused_recurrent_delta_state_step_slice_scalarbeta_correct
    (HPrev k v beta HOut : RegionName)
    (t s_qk_h s_vo_h T K V BK BV : Nat) (s : BlockState)
    (hOutInj : Function.Injective
      (fun idx : TileIndex [BV, BK] => stateOffset s K V BK BV idx)) :
    ∀ idx : TileIndex [BV, BK],
      let outAddr := stateOffset s K V BK BV idx
      (exec (fused_recurrent_delta_state_step_slice_scalarbeta HPrev k v beta HOut
            t s_qk_h s_vo_h T K V BK BV) s).map (·.readMem HOut outAddr)
        = some (if activeKV s K V BK BV idx then
            stateStepSpec s HPrev k v beta Bool.false
              t s_qk_h s_vo_h T K V BK BV idx
          else s.readMem HOut outAddr) := by
  intro idx
  have hzero : (0.0 : ℝ) = 0 := by norm_num
  simp [exec, fused_recurrent_delta_state_step_slice_scalarbeta, stepStmts, stepStmt,
        evalOp, evalOp.eq_def, Option.bind, Option.map, Tile.bop, Tile.cop,
        Tile.expandDim, Tile.uop, Tile.ptrAdd, Tile.reduceSum, Tile.reduceSumDrop,
        TileShape.axisDim, TileShape.eraseAxis, NumericDType.add, NumericDType.mul,
        NumericDType.sub, ComparableDType.lt, stateOffset, vRowOffset,
        vIndex, kIndex, TileShape.dropInsertedIndex]
  -- Collapse the guarded `WithBot ℝ` reduction the masked loads produce.
  simp only [TileShape.insertAxisIndex_one_rank2, MaskedReduction.ite_some_some,
    Option.map₂_some_some, WithBot.sum_someTerm_eq_some, WithBot.unbotD_some]
  let offsetFn : TileIndex [BV, BK] → Nat :=
    fun idx => s.pids 2 * K * V +
      (s.pids 1 * BK + idx.2.1.val) * V + (s.pids 0 * BV + idx.1.val)
  let valueFn : TileIndex [BV, BK] → ℝ :=
    fun idx =>
      (if s.pids 1 * BK + idx.2.1.val < K ∧ s.pids 0 * BV + idx.1.val < V then
          s.readMem HPrev
            (s.pids 2 * K * V + (s.pids 1 * BK + idx.2.1.val) * V +
              (s.pids 0 * BV + idx.1.val))
        else 0.0)
        + (if s.pids 1 * BK + idx.2.1.val < K then
              s.readMem k (s.pids 2 * s_qk_h + s.pids 1 * BK + idx.2.1.val + t * K)
            else 0.0) *
            (((if s.pids 0 * BV + idx.1.val < V then
                  s.readMem v (s.pids 2 * s_vo_h + s.pids 0 * BV + idx.1.val + t * V)
                else 0.0)
              - ∑ jk : Fin BK,
                  (if s.pids 1 * BK + jk.val < K ∧ s.pids 0 * BV + idx.1.val < V then
                      s.readMem HPrev
                        (s.pids 2 * K * V + (s.pids 1 * BK + jk.val) * V +
                          (s.pids 0 * BV + idx.1.val))
                    else 0.0) *
                    (if s.pids 1 * BK + jk.val < K then
                        s.readMem k
                          (s.pids 2 * s_qk_h + s.pids 1 * BK + jk.val + t * K)
                      else 0.0)) *
              s.readMem beta (s.pids 2 * T + t))
  let P : TileIndex [BV, BK] → Prop :=
    fun idx => s.pids 1 * BK + idx.2.1.val < K ∧ s.pids 0 * BV + idx.1.val < V
  have hOffsetInj : Function.Injective offsetFn := by
    simpa [offsetFn, stateOffset, kIndex, vIndex] using hOutInj
  change (List.foldl
      (fun (acc : BlockState) i =>
        if P i then acc.writeMem HOut (offsetFn i) (valueFn i) else acc)
      _ (TileShape.allIndices [BV, BK])).readMem HOut (offsetFn idx) =
    if activeKV s K V BK BV idx then
      stateStepSpec s HPrev k v beta Bool.false t s_qk_h s_vo_h T K V BK BV idx
    else s.readMem HOut (offsetFn idx)
  rw [BlockState.scatter_readback_prop_masked_nd _ _ _ _ hOffsetInj idx]
  by_cases hjk : s.pids 1 * BK + idx.2.1.val < K
  · by_cases hjv : s.pids 0 * BV + idx.1.val < V
    · -- both in range: the outer guards resolve and only the reduction's per-column
      -- guard is left, which `hsum` discharges lane by lane
      have hsum : ∀ jk : Fin BK,
          (if s.pids 1 * BK + jk.val < K ∧ s.pids 0 * BV + idx.1.val < V then
              s.readMem HPrev
                (s.pids 2 * K * V + (s.pids 1 * BK + jk.val) * V +
                  (s.pids 0 * BV + idx.1.val))
            else 0.0) *
            (if s.pids 1 * BK + jk.val < K then
                s.readMem k (s.pids 2 * s_qk_h + s.pids 1 * BK + jk.val + t * K)
              else 0.0)
          = if s.pids 1 * BK + jk.val < K then
              s.readMem HPrev
                  (s.pids 2 * K * V + (s.pids 1 * BK + jk.val) * V +
                    (s.pids 0 * BV + idx.1.val)) *
                s.readMem k (s.pids 2 * s_qk_h + s.pids 1 * BK + jk.val + t * K)
            else 0 := by
        intro jk
        by_cases hK : s.pids 1 * BK + jk.val < K
        · simp only [hK, hjv, and_self, if_true, and_true]
        · simp only [hK, if_false, false_and, hzero]
          ring
      -- `hsum` must fire *before* the outer simp: that simp rewrites `hjv` to
      -- `True` and renormalizes `0.0`, after which `hsum` no longer matches and
      -- the two sides carry syntactically different sums.
      simp only [valueFn, hsum]
      -- `Bool.false_eq_true` / `if_false` resolve `betaVal`'s compile-time flag in
      -- the scalar-beta specialization; the headwise one takes the `ite_true` side.
      simp only [P, activeKV, activeK, activeV, kIndex, vIndex, hjk, hjv,
        and_self, if_true, stateStepSpec, stateOffset, betaVal, kVal,
        vVal, kIndex, vIndex, if_true, ite_true, Bool.false_eq_true, if_false,
        ite_false]
      ring
    · simp only [P, activeKV, activeK, activeV, kIndex, vIndex, hjv, and_false,
        if_false, BlockState.setReg_readMem, offsetFn]
  · simp only [P, activeKV, activeK, activeV, kIndex, vIndex, hjk, false_and,
      if_false, BlockState.setReg_readMem, offsetFn]

theorem fused_recurrent_delta_state_step_slice_headwise_compute_correct
    (HPrev k v beta HOut : RegionName)
    (t s_qk_h s_vo_h T K V BK BV : Nat) (s : BlockState)
    (hOutInj : Function.Injective
      (fun idx : TileIndex [BV, BK] => stateOffset s K V BK BV idx)) :
    ComputeCorrect.Realizes_without_Rounding
      (kernel := fused_recurrent_delta_state_step_slice_headwise HPrev k v beta
        HOut t s_qk_h s_vo_h T K V BK BV)
      (initialState := s)
      (write := ComputeCorrect.WriteMap.writeIf
        (fun idx : TileIndex [BV, BK] => activeKV s K V BK BV idx)
        (fun idx => (HOut, stateOffset s K V BK BV idx)))
      (expected := fun idx =>
        stateStepSpec s HPrev k v beta Bool.true t s_qk_h s_vo_h T K V BK BV idx) := by
  rw [ComputeCorrect.realizes_writeIf_iff]
  apply ComputeKernel.computeCorrect_of_toAlgKernel
  · simp [fused_recurrent_delta_state_step_slice_headwise,
      ComputeExpr.toAlgorithm?, ComputeOp.toAlgorithm?]
  intro s0 s' hExec hs0
  subst s0
  intro idx hActive
  have h := fused_recurrent_delta_state_step_slice_headwise_correct HPrev k v beta
    HOut t s_qk_h s_vo_h T K V BK BV s hOutInj idx
  rw [hExec] at h
  simpa [hActive] using Option.some.inj h

theorem fused_recurrent_delta_state_step_slice_scalarbeta_compute_correct
    (HPrev k v beta HOut : RegionName)
    (t s_qk_h s_vo_h T K V BK BV : Nat) (s : BlockState)
    (hOutInj : Function.Injective
      (fun idx : TileIndex [BV, BK] => stateOffset s K V BK BV idx)) :
    ComputeCorrect.Realizes_without_Rounding
      (kernel := fused_recurrent_delta_state_step_slice_scalarbeta HPrev k v beta
        HOut t s_qk_h s_vo_h T K V BK BV)
      (initialState := s)
      (write := ComputeCorrect.WriteMap.writeIf
        (fun idx : TileIndex [BV, BK] => activeKV s K V BK BV idx)
        (fun idx => (HOut, stateOffset s K V BK BV idx)))
      (expected := fun idx =>
        stateStepSpec s HPrev k v beta Bool.false t s_qk_h s_vo_h T K V BK BV idx) := by
  rw [ComputeCorrect.realizes_writeIf_iff]
  apply ComputeKernel.computeCorrect_of_toAlgKernel
  · simp [fused_recurrent_delta_state_step_slice_scalarbeta,
      ComputeExpr.toAlgorithm?, ComputeOp.toAlgorithm?]
  intro s0 s' hExec hs0
  subst s0
  intro idx hActive
  have h := fused_recurrent_delta_state_step_slice_scalarbeta_correct HPrev k v beta
    HOut t s_qk_h s_vo_h T K V BK BV s hOutInj idx
  rw [hExec] at h
  simpa [hActive] using Option.some.inj h

/-! ## Cross-step carry fold — the `range(0, T)` loop, threaded through memory

The step face above assumes the carry invariant `HPrev = deltaState(m)` at its
own `m`. This section discharges that assumption for all but the first step: the
state slices are run as a `CarryFold.execChain` whose carry-in and carry-out
region are literally the same name `C`, leaving a single hypothesis about the
**initial** buffer.

Honesty limits, the same ones `VeriTile.Triton.CarryFold` states and
`fused_rwkv6_kernel` carries:

* the carry travels through a **memory region**, one launch per step. Python
  keeps `h` in a *register* across `range(0, T)`; that object is still not
  modeled anywhere in this file;
* the fold covers the **state** recurrence only. The `v_new` writeback and the
  output row write `v` and `o`, not `C`, so they are not stages of this chain.
  In particular this fold does **not** model the in-place `v` overwrite:
  `deltaState` reads the pristine `v` rows and expresses the delta in closed
  form, which is exactly what a chain of state slices — none of which writes
  `v` — computes;
* `hSeed` is an assumption about the caller's buffer, not a theorem. -/

/-- One state step leaves everything outside the carry region alone: it writes
only `HOut`, and a `writeMem` scatter touches neither the program ids nor any
other region. (`headwise` specialization.) -/
theorem fused_recurrent_delta_state_step_frame_headwise
    (C k v beta : RegionName) (m s_qk_h s_vo_h T K V BK BV : Nat)
    (u u' : BlockState)
    (hExec : exec (fused_recurrent_delta_state_step_slice_headwise C k v beta C
      m s_qk_h s_vo_h T K V BK BV) u = some u') :
    u'.pids = u.pids ∧ ∀ r, r ≠ C → ∀ o, u'.mem r o = u.mem r o := by
  simp [exec, fused_recurrent_delta_state_step_slice_headwise, stepStmts, stepStmt,
        evalOp, evalOp.eq_def, Option.bind, Option.map, Tile.bop, Tile.cop,
        Tile.expandDim, Tile.uop, Tile.ptrAdd, Tile.reduceSum, Tile.reduceSumDrop,
        TileShape.axisDim, TileShape.eraseAxis, NumericDType.add, NumericDType.mul,
        NumericDType.sub, ComparableDType.lt, TileShape.dropInsertedIndex] at hExec
  rw [← hExec]
  refine ⟨?_, ?_⟩
  · rw [BlockState.foldl_writeMem_prop_masked_pids]
    simp
  · intro r hr o
    rw [BlockState.foldl_writeMem_prop_masked_mem_preserve_other_region _ _ _ _ r hr o]
    simp

/-- One state step leaves everything outside the carry region alone: it writes
only `HOut`, and a `writeMem` scatter touches neither the program ids nor any
other region. (`scalarbeta` specialization.) -/
theorem fused_recurrent_delta_state_step_frame_scalarbeta
    (C k v beta : RegionName) (m s_qk_h s_vo_h T K V BK BV : Nat)
    (u u' : BlockState)
    (hExec : exec (fused_recurrent_delta_state_step_slice_scalarbeta C k v beta C
      m s_qk_h s_vo_h T K V BK BV) u = some u') :
    u'.pids = u.pids ∧ ∀ r, r ≠ C → ∀ o, u'.mem r o = u.mem r o := by
  simp [exec, fused_recurrent_delta_state_step_slice_scalarbeta, stepStmts, stepStmt,
        evalOp, evalOp.eq_def, Option.bind, Option.map, Tile.bop, Tile.cop,
        Tile.expandDim, Tile.uop, Tile.ptrAdd, Tile.reduceSum, Tile.reduceSumDrop,
        TileShape.axisDim, TileShape.eraseAxis, NumericDType.add, NumericDType.mul,
        NumericDType.sub, ComparableDType.lt, TileShape.dropInsertedIndex] at hExec
  rw [← hExec]
  refine ⟨?_, ?_⟩
  · rw [BlockState.foldl_writeMem_prop_masked_pids]
    simp
  · intro r hr o
    rw [BlockState.foldl_writeMem_prop_masked_mem_preserve_other_region _ _ _ _ r hr o]
    simp

/-- Address congruence: `stateOffset` reads the state only through `pids`. -/
theorem stateOffset_congr (s u : BlockState) (K V BK BV : Nat)
    (h : u.pids = s.pids) (idx : TileIndex [BV, BK]) :
    stateOffset u K V BK BV idx = stateOffset s K V BK BV idx := by
  unfold stateOffset kIndex vIndex; rw [h]

/-- Mask congruence: `activeKV` reads the state only through `pids`. -/
theorem activeKV_congr (s u : BlockState) (K V BK BV : Nat)
    (h : u.pids = s.pids) (idx : TileIndex [BV, BK]) :
    activeKV u K V BK BV idx = activeKV s K V BK BV idx := by
  unfold activeKV activeK activeV kIndex vIndex; rw [h]

/-- `stateStepSpec` transported to a state `u` agreeing with the reference state
`s` on `pids` and on the three **input** regions it reads. The carry region `C`
is deliberately *not* transported: its content at `u` is what the fold's
invariant supplies. This is what forces the `k`/`v`/`beta ≠ C` side conditions
on the fold below. -/
theorem stateStepSpec_transport
    (s u : BlockState) (C k v beta : RegionName) (IS_HEADWISE_BETA : Bool)
    (m s_qk_h s_vo_h T K V BK BV : Nat)
    (hpids : u.pids = s.pids)
    (hk : ∀ o, u.readMem k o = s.readMem k o)
    (hv : ∀ o, u.readMem v o = s.readMem v o)
    (hbeta : ∀ o, u.readMem beta o = s.readMem beta o)
    (idx : TileIndex [BV, BK]) :
    stateStepSpec u C k v beta IS_HEADWISE_BETA m s_qk_h s_vo_h T K V BK BV idx
      = u.readMem C (stateOffset s K V BK BV idx)
        + kVal s k s_qk_h K BK m idx.2.1 *
            (betaVal s beta IS_HEADWISE_BETA s_vo_h T V BV m idx.1 *
              (vVal s v s_vo_h V BV m idx.1
                - ∑ jk : Fin BK,
                    if activeK s K BK jk then
                      u.readMem C (stateOffset s K V BK BV (idx.1, jk, PUnit.unit))
                        * kVal s k s_qk_h K BK m jk
                    else 0)) := by
  -- `simp only`, not `unfold` + `rw`: the readback offsets differ per operand
  -- (headwise vs scalar `beta`, and the reduction's own lane), so a single `rw`
  -- pass leaves some of them behind, and unfolding `activeK` reintroduces a
  -- `kIndex u` that must then be rewritten again.
  simp only [stateStepSpec, betaVal, kVal, vVal, stateOffset, kIndex, vIndex,
    activeK, hpids, hk, hv, hbeta]

/-- **Cross-step carry fold for the delta-rule state recurrence (genuine).**

Running `T` state slices as a chain through the shared carry region `C`, the
final buffer holds the genuine closed form `deltaState(T)` on every write-active
lane, and the chain leaves everything outside `C` untouched.

What is *no longer* assumed is the point: the step face assumes
`HPrev = deltaState(m)` at its own `m`, so a `T`-step story needed `T`
assumptions with nothing identifying one step's output buffer with the next
step's input buffer. Here there is **one**, `hSeed`, and the identification is
structural — the same region name is both the slice's `HPrev` and its `HOut`.

Hypotheses, all necessary:

* `hkC` / `hvC` / `hbetaC` — the three input regions are distinct from the carry
  region, forced by `stateStepSpec_transport`;
* `hInj` — state-address injectivity, as in the step face;
* `hSeed` — the initial buffer holds `deltaState(0) = stateSeed` on write-active
  lanes. Nothing is claimed on the rest: a masked step never writes them, so the
  invariant could not be maintained there anyway, which is why the fold runs at
  the subtype of write-active lanes;
* `hRun` — the chain runs to completion (postcondition style).

This says nothing about the launched `fused_recurrent_delta_fwd_surface`, which
keeps `h` in a register across its own `Stmt.forRange`. -/
theorem fused_recurrent_delta_state_carry_fold
    (C k v beta h0 : RegionName) (IS_HEADWISE_BETA USE_INITIAL_STATE : Bool)
    (s_qk_h s_vo_h T K V BK BV : Nat) (s sFinal : BlockState)
    (hkC : k ≠ C) (hvC : v ≠ C) (hbetaC : beta ≠ C)
    (hInj : Function.Injective
      (fun idx : TileIndex [BV, BK] => stateOffset s K V BK BV idx))
    (hSeed : ∀ idx : TileIndex [BV, BK], activeKV s K V BK BV idx →
      s.readMem C (stateOffset s K V BK BV idx)
        = stateSeed s h0 USE_INITIAL_STATE K V BK BV idx)
    (hRun : execChain (foldStages
        (fun j => if IS_HEADWISE_BETA then
            fused_recurrent_delta_state_step_slice_headwise C k v beta C
              j s_qk_h s_vo_h T K V BK BV
          else
            fused_recurrent_delta_state_step_slice_scalarbeta C k v beta C
              j s_qk_h s_vo_h T K V BK BV) T) s = some sFinal) :
    AgreeOutsideRegion C s sFinal ∧
    ∀ idx : TileIndex [BV, BK], activeKV s K V BK BV idx →
      sFinal.readMem C (stateOffset s K V BK BV idx)
        = deltaState s k v beta h0 IS_HEADWISE_BETA USE_INITIAL_STATE
            s_qk_h s_vo_h T K V BK BV T idx := by
  have key := carryFold_execChain
    (ι := {idx : TileIndex [BV, BK] // activeKV s K V BK BV idx})
    (step := fun j => if IS_HEADWISE_BETA then
        fused_recurrent_delta_state_step_slice_headwise C k v beta C
          j s_qk_h s_vo_h T K V BK BV
      else
        fused_recurrent_delta_state_step_slice_scalarbeta C k v beta C
          j s_qk_h s_vo_h T K V BK BV)
    (C := C)
    (addr := fun i => stateOffset s K V BK BV i.val)
    (val := fun j i =>
      deltaState s k v beta h0 IS_HEADWISE_BETA USE_INITIAL_STATE
        s_qk_h s_vo_h T K V BK BV j i.val)
    (n := T) (s := s) (sFinal := sFinal)
    (fun i => by simpa [deltaState] using hSeed i.val i.property)
    (fun j _hj t t' hAgree hInv hExec => by
      have hpidsR : t.resetRegs.pids = s.pids := by
        rw [BlockState.resetRegs_pids]; exact hAgree.pids
      have hframe : t'.pids = t.resetRegs.pids ∧
          ∀ r, r ≠ C → ∀ o, t'.mem r o = t.resetRegs.mem r o := by
        cases hb : IS_HEADWISE_BETA
        · exact fused_recurrent_delta_state_step_frame_scalarbeta C k v beta
            j s_qk_h s_vo_h T K V BK BV t.resetRegs t' (by simp only [hb] at hExec; simpa using hExec)
        · exact fused_recurrent_delta_state_step_frame_headwise C k v beta
            j s_qk_h s_vo_h T K V BK BV t.resetRegs t' (by simp only [hb] at hExec; simpa using hExec)
      obtain ⟨hp', hm'⟩ := hframe
      have hAgree' : AgreeOutsideRegion C s t' :=
        ⟨by rw [hp', BlockState.resetRegs_pids]; exact hAgree.pids,
         by
           intro r hr o
           rw [hm' r hr o, BlockState.resetRegs_mem]
           exact hAgree.mem r hr o⟩
      refine ⟨hAgree', ?_⟩
      intro i
      show t'.readMem C (stateOffset s K V BK BV i.val)
        = deltaState s k v beta h0 IS_HEADWISE_BETA USE_INITIAL_STATE
            s_qk_h s_vo_h T K V BK BV (j + 1) i.val
      have hInjT : Function.Injective
          (fun idx : TileIndex [BV, BK] => stateOffset t.resetRegs K V BK BV idx) := by
        intro a b hab
        exact hInj (by simpa [stateOffset_congr s t.resetRegs K V BK BV hpidsR] using hab)
      have hcorr : t'.readMem C (stateOffset s K V BK BV i.val)
          = stateStepSpec t.resetRegs C k v beta IS_HEADWISE_BETA
              j s_qk_h s_vo_h T K V BK BV i.val := by
        cases hb : IS_HEADWISE_BETA
        · have h := fused_recurrent_delta_state_step_slice_scalarbeta_correct C k v beta C
            j s_qk_h s_vo_h T K V BK BV t.resetRegs hInjT i.val
          -- restate `hExec` in the *same spelling* the step face uses; the flag
          -- branch leaves it as a coerced `if`-selected kernel, which no `rw`
          -- inside `h` can match
          have hE : exec (fused_recurrent_delta_state_step_slice_scalarbeta C k v beta C
              j s_qk_h s_vo_h T K V BK BV) t.resetRegs = some t' := by
            simpa [hb] using hExec
          rw [hE] at h
          have h2 := Option.some.inj h
          simp only [stateOffset_congr s t.resetRegs K V BK BV hpidsR,
            activeKV_congr s t.resetRegs K V BK BV hpidsR, i.property, if_true] at h2
          exact h2
        · have h := fused_recurrent_delta_state_step_slice_headwise_correct C k v beta C
            j s_qk_h s_vo_h T K V BK BV t.resetRegs hInjT i.val
          -- restate `hExec` in the *same spelling* the step face uses; the flag
          -- branch leaves it as a coerced `if`-selected kernel, which no `rw`
          -- inside `h` can match
          have hE : exec (fused_recurrent_delta_state_step_slice_headwise C k v beta C
              j s_qk_h s_vo_h T K V BK BV) t.resetRegs = some t' := by
            simpa [hb] using hExec
          rw [hE] at h
          have h2 := Option.some.inj h
          simp only [stateOffset_congr s t.resetRegs K V BK BV hpidsR,
            activeKV_congr s t.resetRegs K V BK BV hpidsR, i.property, if_true] at h2
          exact h2
      rw [hcorr, stateStepSpec_transport s t.resetRegs C k v beta IS_HEADWISE_BETA
        j s_qk_h s_vo_h T K V BK BV hpidsR
        (fun o => by rw [BlockState.resetRegs_readMem]; exact hAgree.readMem k hkC o)
        (fun o => by rw [BlockState.resetRegs_readMem]; exact hAgree.readMem v hvC o)
        (fun o => by rw [BlockState.resetRegs_readMem]; exact hAgree.readMem beta hbetaC o)
        i.val]
      have hOuter : t.resetRegs.readMem C (stateOffset s K V BK BV i.val)
          = deltaState s k v beta h0 IS_HEADWISE_BETA USE_INITIAL_STATE
              s_qk_h s_vo_h T K V BK BV j i.val := by
        rw [BlockState.resetRegs_readMem]; exact hInv i
      have hSum : ∀ jk : Fin BK,
          (if activeK s K BK jk then
              t.resetRegs.readMem C
                  (stateOffset s K V BK BV (i.val.1, jk, PUnit.unit)) *
                kVal s k s_qk_h K BK j jk
            else 0)
          = if activeK s K BK jk then
              deltaState s k v beta h0 IS_HEADWISE_BETA USE_INITIAL_STATE
                  s_qk_h s_vo_h T K V BK BV j (i.val.1, jk, PUnit.unit) *
                kVal s k s_qk_h K BK j jk
            else 0 := by
        intro jk
        split_ifs with hk
        · rw [BlockState.resetRegs_readMem]
          -- the reduced lane is itself write-active: its key channel is in range
          -- by the guard, and its value channel is `i`'s, which is active
          exact congrArg (· * kVal s k s_qk_h K BK j jk)
            (hInv ⟨(i.val.1, jk, PUnit.unit), ⟨hk, i.property.2⟩⟩)
        · rfl
      rw [hOuter]
      simp only [hSum]
      simp only [deltaState])
    hRun
  exact ⟨key.1, fun idx hidx => key.2 ⟨idx, hidx⟩⟩

/-! ## Output-readout step slice (the per-step `o_t` store)

One loop body's output store, isolated from the cross-step loop. The delta
rule reads out the **post-update** state, so this face consumes a materialized
post-update tile `HNext`: it loads `HNext` and the scaled `q_t` row, reduces
over the key axis and masked-stores the `[BV]` row into `o` at time row `t`.

`HNext` holding `deltaState(m+1)` is an *assumption* wherever this face is used
(the headline's `hNext`). The state-update face proves `deltaState(m+1)` about
the state *after executing* its own slice; nothing in this file sequences that
post-state into this face's pre-state. -/

def fused_recurrent_delta_output_step_slice
    (HNext q o : RegionName) (t s_qk_h s_vo_h B H K V BK BV : Nat) (scale : ℝ) :
    ComputeKernel := triton {
  i_v = tl.program_id(0)
  i_k = tl.program_id(1)
  i_bh = tl.program_id(2)
  offs_k = tl.arange(0, $(BK))
  offs_v = tl.arange(0, $(BV))
  mask_bk = (i_k * $(BK) + offs_k) < $(K)
  mask_bv = (i_v * $(BV) + offs_v) < $(V)
  mask_kv = mask_bk[None, :] & mask_bv[:, None]
  prev = tl.load(HNext + i_bh * $(K) * $(V) +
    (i_k * $(BK) + offs_k[None, :]) * $(V) + (i_v * $(BV) + offs_v[:, None]),
    mask=mask_kv, other=0.0)
  b_q = tl.load(q + i_bh * $(s_qk_h) + i_k * $(BK) + offs_k + $(t) * $(K),
    mask=mask_bk, other=0.0) * $(scale)
  _o = prev * b_q[None, :]
  _o = tl.sum(_o, axis=1)
  tl.store(o + (i_bh + i_k * $(B) * $(H)) * $(s_vo_h) + i_v * $(BV) + offs_v +
    $(t) * $(V), (_o).to(o.dtype.element_ty), mask=mask_bv)
}

/-- The per-lane spec of one output store, reading the *post-update*
materialized state `HNext`:
`o_t[j_v] = Σ_{j_k} HNext[j_v,j_k] · scale·q_t[j_k]`. -/
noncomputable def outputStepSpec (s : BlockState) (HNext q : RegionName)
    (t s_qk_h K V BK BV : Nat) (scale : ℝ) (jv : Fin BV) : ℝ :=
  ∑ jk : Fin BK,
    if activeK s K BK jk then
      s.readMem HNext (stateOffset s K V BK BV (jv, jk, PUnit.unit))
        * qVal s q s_qk_h K BK scale t jk
    else 0

set_option maxHeartbeats 1000000 in
theorem fused_recurrent_delta_output_step_slice_correct
    (HNext q o : RegionName)
    (t s_qk_h s_vo_h B H K V BK BV : Nat) (scale : ℝ) (s : BlockState)
    (hOutInj : Function.Injective
      (fun jv : Fin BV => outOffset s t s_vo_h B H V BV jv)) :
    ∀ jv : Fin BV,
      let outAddr := outOffset s t s_vo_h B H V BV jv
      (exec (fused_recurrent_delta_output_step_slice HNext q o
            t s_qk_h s_vo_h B H K V BK BV scale) s).map (·.readMem o outAddr)
        = some (if activeV s V BV jv then
            outputStepSpec s HNext q t s_qk_h K V BK BV scale jv
          else s.readMem o outAddr) := by
  intro jv
  have hzero : (0.0 : ℝ) = 0 := by norm_num
  simp [exec, fused_recurrent_delta_output_step_slice, stepStmts, stepStmt,
        evalOp, evalOp.eq_def, Option.bind, Option.map, Tile.bop, Tile.cop,
        Tile.expandDim, Tile.uop, Tile.ptrAdd, Tile.reduceSum, Tile.reduceSumDrop,
        TileShape.axisDim, TileShape.eraseAxis, NumericDType.add, NumericDType.mul,
        ComparableDType.lt, stateOffset, outOffset, activeV, vIndex, kIndex,
        TileShape.dropInsertedIndex]
  -- Collapse the guarded `WithBot ℝ` reduction the masked loads produce.
  simp only [TileShape.insertAxisIndex_one_rank2, MaskedReduction.ite_some_some,
    Option.map₂_some_some, WithBot.sum_someTerm_eq_some, WithBot.unbotD_some]
  let offsetFn : TileIndex [BV] → Nat :=
    fun idx => (s.pids 2 + s.pids 1 * B * H) * s_vo_h + s.pids 0 * BV +
      idx.1.val + t * V
  let valueFn : TileIndex [BV] → ℝ :=
    fun idx =>
      ∑ jk : Fin BK,
        (if s.pids 1 * BK + jk.val < K ∧ s.pids 0 * BV + idx.1.val < V then
            s.readMem HNext
              (s.pids 2 * K * V + (s.pids 1 * BK + jk.val) * V +
                (s.pids 0 * BV + idx.1.val))
          else 0.0) *
          ((if s.pids 1 * BK + jk.val < K then
                s.readMem q (s.pids 2 * s_qk_h + s.pids 1 * BK + jk.val + t * K)
              else 0.0) * scale)
  let P : TileIndex [BV] → Prop := fun idx => s.pids 0 * BV + idx.1.val < V
  have hOffsetInj : Function.Injective offsetFn := by
    rintro ⟨a, _⟩ ⟨b, _⟩ hab
    have : outOffset s t s_vo_h B H V BV a = outOffset s t s_vo_h B H V BV b := by
      simpa [offsetFn, outOffset] using hab
    obtain rfl : a = b := hOutInj this
    rfl
  change (List.foldl
      (fun (acc : BlockState) idx =>
        if P idx then acc.writeMem o (offsetFn idx) (valueFn idx) else acc)
      _ (TileShape.allIndices [BV])).readMem o (offsetFn (jv, PUnit.unit)) =
    if activeV s V BV jv then
      outputStepSpec s HNext q t s_qk_h K V BK BV scale jv
    else s.readMem o (offsetFn (jv, PUnit.unit))
  rw [BlockState.scatter_readback_prop_masked_nd _ _ _ _ hOffsetInj (jv, PUnit.unit)]
  by_cases hjv : s.pids 0 * BV + jv.val < V
  · simp only [P, hjv, if_true, activeV, vIndex, valueFn, outputStepSpec,
      stateOffset, kVal, qVal, kIndex, vIndex, activeK, and_true]
    apply Finset.sum_congr rfl
    intro jk _
    -- In range the two summands agree up to `ring`; out of range Python's
    -- `other = 0` zeroes both `prev` and `b_q`, giving `0 · (0 · scale) = 0`.
    by_cases hK : s.pids 1 * BK + jk.val < K
    · simp only [hK, if_true]
      ring
    · simp only [hK, if_false, hzero]
      ring
  · simp only [P, activeV, vIndex, hjv, if_false, BlockState.setReg_readMem]

theorem fused_recurrent_delta_output_step_slice_compute_correct
    (HNext q o : RegionName)
    (t s_qk_h s_vo_h B H K V BK BV : Nat) (scale : ℝ) (s : BlockState)
    (hOutInj : Function.Injective
      (fun jv : Fin BV => outOffset s t s_vo_h B H V BV jv)) :
    ComputeCorrect.Realizes_without_Rounding
      (kernel := fused_recurrent_delta_output_step_slice HNext q o
        t s_qk_h s_vo_h B H K V BK BV scale)
      (initialState := s)
      (write := ComputeCorrect.WriteMap.writeIf
        (fun jv : Fin BV => activeV s V BV jv)
        (fun jv => (o, outOffset s t s_vo_h B H V BV jv)))
      (expected := fun jv : Fin BV =>
        outputStepSpec s HNext q t s_qk_h K V BK BV scale jv) := by
  rw [ComputeCorrect.realizes_writeIf_iff]
  apply ComputeKernel.computeCorrect_of_toAlgKernel
  · simp [fused_recurrent_delta_output_step_slice, ComputeExpr.toAlgorithm?,
      ComputeOp.toAlgorithm?]
  intro s0 s' hExec hs0
  subst s0
  intro jv hActive
  have h := fused_recurrent_delta_output_step_slice_correct HNext q o
    t s_qk_h s_vo_h B H K V BK BV scale s hOutInj jv
  rw [hExec] at h
  simpa [hActive] using Option.some.inj h

/-! ## Genuine closed-form step realizations (the forward carry-fold)

The cross-step fold over `range(0, T)` threading `h` is the trusted boundary;
each *step face* is realized against the genuine recurrence `deltaState` /
its derived forms over the input regions `q, k, v, beta, h0`. -/

/-- **`v_new` step realizes the genuine delta.** If `HPrev` holds
`deltaState(m)`, the per-lane `v` writeback value equals `vNewClosed(m)`. -/
theorem vnewStepSpec_eq_vNewClosed
    (s : BlockState) (HPrev k v beta h0 : RegionName)
    (IS_HEADWISE_BETA USE_INITIAL_STATE : Bool)
    (m s_qk_h s_vo_h T K V BK BV : Nat)
    (hPrev : ∀ idx : TileIndex [BV, BK],
      s.readMem HPrev (stateOffset s K V BK BV idx)
        = deltaState s k v beta h0 IS_HEADWISE_BETA USE_INITIAL_STATE
            s_qk_h s_vo_h T K V BK BV m idx)
    (jv : Fin BV) :
    vnewStepSpec s HPrev k v m s_qk_h s_vo_h K V BK BV jv
      = vNewClosed s k v beta h0 IS_HEADWISE_BETA USE_INITIAL_STATE
          s_qk_h s_vo_h T K V BK BV m jv := by
  unfold vnewStepSpec vNewClosed vMinusClosed vVal vRowOffset
  congr 1
  apply Finset.sum_congr rfl
  intro jk _
  split_ifs with hK
  · rw [hPrev]
  · rfl

/-- **State carry-fold step (genuine).** If `HPrev` holds `deltaState(m)`,
then one loop body — `stateStepSpec`, i.e.
`HPrev + k_m ⊗ (β_m ⊙ (v_m − HPrev·k_m))` — produces exactly the genuine
`(m+1)`-step folded state `deltaState(m+1)`. -/
theorem stateStepSpec_eq_deltaState_succ
    (s : BlockState) (HPrev k v beta h0 : RegionName)
    (IS_HEADWISE_BETA USE_INITIAL_STATE : Bool)
    (m s_qk_h s_vo_h T K V BK BV : Nat)
    (hPrev : ∀ idx : TileIndex [BV, BK],
      s.readMem HPrev (stateOffset s K V BK BV idx)
        = deltaState s k v beta h0 IS_HEADWISE_BETA USE_INITIAL_STATE
            s_qk_h s_vo_h T K V BK BV m idx)
    (idx : TileIndex [BV, BK]) :
    stateStepSpec s HPrev k v beta IS_HEADWISE_BETA m s_qk_h s_vo_h T K V BK BV idx
      = deltaState s k v beta h0 IS_HEADWISE_BETA USE_INITIAL_STATE
          s_qk_h s_vo_h T K V BK BV (m + 1) idx := by
  have hsum :
      (∑ jk : Fin BK,
          if activeK s K BK jk then
            s.readMem HPrev (stateOffset s K V BK BV (idx.1, jk, PUnit.unit))
              * kVal s k s_qk_h K BK m jk
          else 0)
        = ∑ jk : Fin BK,
            if activeK s K BK jk then
              deltaState s k v beta h0 IS_HEADWISE_BETA USE_INITIAL_STATE
                  s_qk_h s_vo_h T K V BK BV m (idx.1, jk, PUnit.unit)
                * kVal s k s_qk_h K BK m jk
            else 0 := by
    apply Finset.sum_congr rfl
    intro jk _
    split_ifs with hK
    · rw [hPrev]
    · rfl
  rw [deltaState_succ]
  unfold stateStepSpec vNewClosed vMinusClosed
  rw [hPrev idx, hsum]

/-- **Output step realizes the genuine closed form.** If `HNext` holds the
post-update state `deltaState(m+1)`, the output reduction equals
`outputClosed(m)`. -/
theorem outputStepSpec_eq_outputClosed
    (s : BlockState) (HNext q k v beta h0 : RegionName)
    (IS_HEADWISE_BETA USE_INITIAL_STATE : Bool)
    (m s_qk_h s_vo_h T K V BK BV : Nat) (scale : ℝ)
    (hNext : ∀ idx : TileIndex [BV, BK],
      s.readMem HNext (stateOffset s K V BK BV idx)
        = deltaState s k v beta h0 IS_HEADWISE_BETA USE_INITIAL_STATE
            s_qk_h s_vo_h T K V BK BV (m + 1) idx)
    (jv : Fin BV) :
    outputStepSpec s HNext q m s_qk_h K V BK BV scale jv
      = outputClosed s q k v beta h0 IS_HEADWISE_BETA USE_INITIAL_STATE
          s_qk_h s_vo_h T K V BK BV scale m jv := by
  unfold outputStepSpec outputClosed
  apply Finset.sum_congr rfl
  intro jk _
  split_ifs with hK
  · rw [hNext]
  · rfl

/-- **Genuine `v_new` writeback.** One `v` writeback body, with the
materialized pre-update state `HPrev = deltaState(m)`, realizes the genuine
delta `vNewClosed(m)` (masked) into `v` at time row `m` — the kernel's
in-place update. -/
theorem fused_recurrent_delta_vnew_step_closed_form
    (HPrev k v beta h0 : RegionName)
    (IS_HEADWISE_BETA USE_INITIAL_STATE : Bool)
    (m s_qk_h s_vo_h T K V BK BV : Nat) (s : BlockState)
    (hOutInj : Function.Injective
      (fun jv : Fin BV => vRowOffset s m s_vo_h V BV jv))
    (hPrev : ∀ idx : TileIndex [BV, BK],
      s.readMem HPrev (stateOffset s K V BK BV idx)
        = deltaState s k v beta h0 IS_HEADWISE_BETA USE_INITIAL_STATE
            s_qk_h s_vo_h T K V BK BV m idx) :
    ComputeCorrect.Realizes_without_Rounding
      (kernel := fused_recurrent_delta_vnew_step_slice HPrev k v
        m s_qk_h s_vo_h K V BK BV)
      (initialState := s)
      (write := ComputeCorrect.WriteMap.writeIf
        (fun jv : Fin BV => activeV s V BV jv)
        (fun jv => (v, vRowOffset s m s_vo_h V BV jv)))
      (expected := fun jv : Fin BV =>
        vNewClosed s k v beta h0 IS_HEADWISE_BETA USE_INITIAL_STATE
          s_qk_h s_vo_h T K V BK BV m jv) := by
  have h := fused_recurrent_delta_vnew_step_slice_compute_correct HPrev k v
    m s_qk_h s_vo_h K V BK BV s hOutInj
  have hcong : (fun jv : Fin BV =>
      vnewStepSpec s HPrev k v m s_qk_h s_vo_h K V BK BV jv)
      = (fun jv : Fin BV =>
        vNewClosed s k v beta h0 IS_HEADWISE_BETA USE_INITIAL_STATE
          s_qk_h s_vo_h T K V BK BV m jv) := by
    funext jv
    exact vnewStepSpec_eq_vNewClosed s HPrev k v beta h0 IS_HEADWISE_BETA
      USE_INITIAL_STATE m s_qk_h s_vo_h T K V BK BV hPrev jv
  rwa [hcong] at h

/-- **Genuine state carry-fold step.** One state-update body — the
`IS_HEADWISE_BETA` specialization selected by the flag, exactly as the
constexpr selects the compiled kernel — with the materialized pre-update
state `HPrev = deltaState(m)`, realizes the genuine `(m+1)`-step folded state
`deltaState(m+1)` into the state buffer. -/
theorem fused_recurrent_delta_state_step_closed_form
    (HPrev k v beta h0 HOut : RegionName)
    (IS_HEADWISE_BETA USE_INITIAL_STATE : Bool)
    (m s_qk_h s_vo_h T K V BK BV : Nat) (s : BlockState)
    (hOutInj : Function.Injective
      (fun idx : TileIndex [BV, BK] => stateOffset s K V BK BV idx))
    (hPrev : ∀ idx : TileIndex [BV, BK],
      s.readMem HPrev (stateOffset s K V BK BV idx)
        = deltaState s k v beta h0 IS_HEADWISE_BETA USE_INITIAL_STATE
            s_qk_h s_vo_h T K V BK BV m idx) :
    ComputeCorrect.Realizes_without_Rounding
      (kernel := if IS_HEADWISE_BETA then
          fused_recurrent_delta_state_step_slice_headwise HPrev k v beta HOut
            m s_qk_h s_vo_h T K V BK BV
        else
          fused_recurrent_delta_state_step_slice_scalarbeta HPrev k v beta HOut
            m s_qk_h s_vo_h T K V BK BV)
      (initialState := s)
      (write := ComputeCorrect.WriteMap.writeIf
        (fun idx : TileIndex [BV, BK] => activeKV s K V BK BV idx)
        (fun idx => (HOut, stateOffset s K V BK BV idx)))
      (expected := fun idx =>
        deltaState s k v beta h0 IS_HEADWISE_BETA USE_INITIAL_STATE
          s_qk_h s_vo_h T K V BK BV (m + 1) idx) := by
  have hcong : (fun idx : TileIndex [BV, BK] =>
      stateStepSpec s HPrev k v beta IS_HEADWISE_BETA m s_qk_h s_vo_h T K V BK BV idx)
      = (fun idx : TileIndex [BV, BK] =>
        deltaState s k v beta h0 IS_HEADWISE_BETA USE_INITIAL_STATE
          s_qk_h s_vo_h T K V BK BV (m + 1) idx) := by
    funext idx
    exact stateStepSpec_eq_deltaState_succ s HPrev k v beta h0 IS_HEADWISE_BETA
      USE_INITIAL_STATE m s_qk_h s_vo_h T K V BK BV hPrev idx
  cases IS_HEADWISE_BETA
  · -- IS_HEADWISE_BETA = false
    have h := fused_recurrent_delta_state_step_slice_scalarbeta_compute_correct
      HPrev k v beta HOut m s_qk_h s_vo_h T K V BK BV s hOutInj
    rw [hcong] at h
    simpa using h
  · -- IS_HEADWISE_BETA = true
    have h := fused_recurrent_delta_state_step_slice_headwise_compute_correct
      HPrev k v beta HOut m s_qk_h s_vo_h T K V BK BV s hOutInj
    rw [hcong] at h
    simpa using h

/-- **Genuine output step.** One output body, with the materialized
post-update state `HNext = deltaState(m+1)`, realizes the genuine
`outputClosed(m)` (the key-axis readout of the post-update state) into the
output row. -/
theorem fused_recurrent_delta_output_step_closed_form
    (HNext q k v beta h0 o : RegionName)
    (IS_HEADWISE_BETA USE_INITIAL_STATE : Bool)
    (m s_qk_h s_vo_h B H T K V BK BV : Nat) (scale : ℝ) (s : BlockState)
    (hOutInj : Function.Injective
      (fun jv : Fin BV => outOffset s m s_vo_h B H V BV jv))
    (hNext : ∀ idx : TileIndex [BV, BK],
      s.readMem HNext (stateOffset s K V BK BV idx)
        = deltaState s k v beta h0 IS_HEADWISE_BETA USE_INITIAL_STATE
            s_qk_h s_vo_h T K V BK BV (m + 1) idx) :
    ComputeCorrect.Realizes_without_Rounding
      (kernel := fused_recurrent_delta_output_step_slice HNext q o
        m s_qk_h s_vo_h B H K V BK BV scale)
      (initialState := s)
      (write := ComputeCorrect.WriteMap.writeIf
        (fun jv : Fin BV => activeV s V BV jv)
        (fun jv => (o, outOffset s m s_vo_h B H V BV jv)))
      (expected := fun jv : Fin BV =>
        outputClosed s q k v beta h0 IS_HEADWISE_BETA USE_INITIAL_STATE
          s_qk_h s_vo_h T K V BK BV scale m jv) := by
  have h := fused_recurrent_delta_output_step_slice_compute_correct HNext q o
    m s_qk_h s_vo_h B H K V BK BV scale s hOutInj
  have hcong : (fun jv : Fin BV =>
      outputStepSpec s HNext q m s_qk_h K V BK BV scale jv)
      = (fun jv : Fin BV =>
        outputClosed s q k v beta h0 IS_HEADWISE_BETA USE_INITIAL_STATE
          s_qk_h s_vo_h T K V BK BV scale m jv) := by
    funext jv
    exact outputStepSpec_eq_outputClosed s HNext q k v beta h0 IS_HEADWISE_BETA
      USE_INITIAL_STATE m s_qk_h s_vo_h T K V BK BV scale hNext jv
  rwa [hcong] at h

/-! ## Backward per-step gradient faces (loop 1 / loop 2 bodies)

The backward kernel carries `d_h : [BK, BV]` through the reverse-time loop
and a recomputed `h : [BK, BV]` through the forward-time loop; both folds are
the trusted boundary (`fused_recurrent_hgrn` backward precedent), with the
carried state presented as materialized buffers `DHPrev` / `HPrev`. Each face
below realizes the genuine per-step gradient formula over those buffers and
the backward launch's input rows. NOTE: by the time the backward kernel runs,
region `v` holds the forward kernel's stored deltas `v_new` — the `vVal v`
reads below are the backward kernel's actual `b_v` inputs. -/

/-- The `dk`/`dq` store row address at time `t`, lane `j_k` — the kernel's
`(i_bh + i_v·B·H)·s_qk_h + i_k·BK + j_k + t·K` layout. -/
def dkRowOffset (s : BlockState) (t s_qk_h B H K BK : Nat) (jk : Fin BK) : Nat :=
  (s.pids 2 + s.pids 0 * B * H) * s_qk_h + s.pids 1 * BK + jk.val + t * K

/-- The headwise `dbeta` store row address at time `t`, lane `j_v` — the
kernel's `(i_bh + i_k·B·H + i_v·B·H·NK)·s_vo_h + j_v + t·V` layout (a plain
`tl.arange(0, BV)`, with no `i_v·BV` term, exactly as in the Python). -/
def dbetaRowOffset (s : BlockState) (t s_vo_h B H NK V BV : Nat)
    (jv : Fin BV) : Nat :=
  (s.pids 2 + s.pids 1 * B * H + s.pids 0 * B * H * NK) * s_vo_h + jv.val + t * V

/-- The scalar `dbeta` store address at time `t` — the kernel's
`(i_bh + i_v·B·H)·T + t` layout. -/
def dbetaScalarOffset (s : BlockState) (t T B H : Nat) : Nat :=
  (s.pids 2 + s.pids 0 * B * H) * T + t

def fused_recurrent_delta_bwd_dk_step_slice_headwise
    (DHPrev q do_ v beta dk : RegionName)
    (t s_qk_h s_vo_h B H T K V BK BV : Nat) (scale : ℝ) :
    ComputeKernel := triton {
  i_v = tl.program_id(0)
  i_k = tl.program_id(1)
  i_bh = tl.program_id(2)
  offs_k = tl.arange(0, $(BK))
  offs_v = tl.arange(0, $(BV))
  mask_bk = (i_k * $(BK) + offs_k) < $(K)
  mask_bv = (i_v * $(BV) + offs_v) < $(V)
  mask_kv = mask_bk[:, None] & mask_bv[None, :]
  prev = tl.load(DHPrev + i_bh * $(K) * $(V) +
    (i_k * $(BK) + offs_k[:, None]) * $(V) + (i_v * $(BV) + offs_v[None, :]),
    mask=mask_kv, other=0.0)
  b_q = tl.load(q + i_bh * $(s_qk_h) + i_k * $(BK) + offs_k + $(t) * $(K),
    mask=mask_bk, other=0.0) * $(scale)
  b_do = tl.load(do_ + i_bh * $(s_vo_h) + i_v * $(BV) + offs_v + $(t) * $(V),
    mask=mask_bv, other=0.0)
  b_v = tl.load(v + i_bh * $(s_vo_h) + i_v * $(BV) + offs_v + $(t) * $(V),
    mask=mask_bv, other=0.0)
  b_beta = tl.load(beta + i_bh * $(s_vo_h) + i_v * $(BV) + offs_v + $(t) * $(V),
    mask=mask_bv, other=0.0)
  d_h = prev + b_q[:, None] * b_do[None, :]
  d_k = tl.sum(d_h * (b_v * b_beta)[None, :], axis=1)
  tl.store(dk + (i_bh + i_v * $(B) * $(H)) * $(s_qk_h) + i_k * $(BK) + offs_k +
    $(t) * $(K), (d_k).to(dk.dtype.element_ty), mask=mask_bk)
}

def fused_recurrent_delta_bwd_dk_step_slice_scalarbeta
    (DHPrev q do_ v beta dk : RegionName)
    (t s_qk_h s_vo_h B H T K V BK BV : Nat) (scale : ℝ) :
    ComputeKernel := triton {
  i_v = tl.program_id(0)
  i_k = tl.program_id(1)
  i_bh = tl.program_id(2)
  offs_k = tl.arange(0, $(BK))
  offs_v = tl.arange(0, $(BV))
  mask_bk = (i_k * $(BK) + offs_k) < $(K)
  mask_bv = (i_v * $(BV) + offs_v) < $(V)
  mask_kv = mask_bk[:, None] & mask_bv[None, :]
  prev = tl.load(DHPrev + i_bh * $(K) * $(V) +
    (i_k * $(BK) + offs_k[:, None]) * $(V) + (i_v * $(BV) + offs_v[None, :]),
    mask=mask_kv, other=0.0)
  b_q = tl.load(q + i_bh * $(s_qk_h) + i_k * $(BK) + offs_k + $(t) * $(K),
    mask=mask_bk, other=0.0) * $(scale)
  b_do = tl.load(do_ + i_bh * $(s_vo_h) + i_v * $(BV) + offs_v + $(t) * $(V),
    mask=mask_bv, other=0.0)
  b_v = tl.load(v + i_bh * $(s_vo_h) + i_v * $(BV) + offs_v + $(t) * $(V),
    mask=mask_bv, other=0.0)
  b_beta = tl.load(beta + i_bh * $(T) + $(t))
  d_h = prev + b_q[:, None] * b_do[None, :]
  d_k = tl.sum(d_h * (b_v * b_beta)[None, :], axis=1)
  tl.store(dk + (i_bh + i_v * $(B) * $(H)) * $(s_qk_h) + i_k * $(BK) + offs_k +
    $(t) * $(K), (d_k).to(dk.dtype.element_ty), mask=mask_bk)
}

/-- The genuine per-lane `dk` step formula (loop 1, both beta modes):
`dk_t[j_k] = Σ_{j_v} (DHPrev + scale·q_t ⊗ do_t)[j_k,j_v] · (v_t[j_v]·β_t[j_v])`. -/
noncomputable def dkStepSpec (s : BlockState) (DHPrev q do_ v beta : RegionName)
    (IS_HEADWISE_BETA : Bool) (t s_qk_h s_vo_h T K V BK BV : Nat) (scale : ℝ)
    (jk : Fin BK) : ℝ :=
  ∑ jv : Fin BV,
    if activeV s V BV jv then
      (s.readMem DHPrev (dhOffset s K V BK BV (jk, jv, PUnit.unit))
          + qVal s q s_qk_h K BK scale t jk * vVal s do_ s_vo_h V BV t jv)
        * (vVal s v s_vo_h V BV t jv *
            betaVal s beta IS_HEADWISE_BETA s_vo_h T V BV t jv)
    else 0

set_option maxHeartbeats 4000000 in
theorem fused_recurrent_delta_bwd_dk_step_slice_headwise_correct
    (DHPrev q do_ v beta dk : RegionName)
    (t s_qk_h s_vo_h B H T K V BK BV : Nat) (scale : ℝ) (s : BlockState)
    (hOutInj : Function.Injective
      (fun jk : Fin BK => dkRowOffset s t s_qk_h B H K BK jk)) :
    ∀ jk : Fin BK,
      let outAddr := dkRowOffset s t s_qk_h B H K BK jk
      (exec (fused_recurrent_delta_bwd_dk_step_slice_headwise DHPrev q do_ v beta dk
            t s_qk_h s_vo_h B H T K V BK BV scale) s).map (·.readMem dk outAddr)
        = some (if activeK s K BK jk then
            dkStepSpec s DHPrev q do_ v beta Bool.true
              t s_qk_h s_vo_h T K V BK BV scale jk
          else s.readMem dk outAddr) := by
  intro jk
  have hzero : (0.0 : ℝ) = 0 := by norm_num
  simp [exec, fused_recurrent_delta_bwd_dk_step_slice_headwise, stepStmts, stepStmt,
        evalOp, evalOp.eq_def, Option.bind, Option.map, Tile.bop, Tile.cop,
        Tile.expandDim, Tile.uop, Tile.ptrAdd, Tile.reduceSum, Tile.reduceSumDrop,
        TileShape.axisDim, TileShape.eraseAxis, NumericDType.add, NumericDType.mul,
        ComparableDType.lt, dhOffset, dkRowOffset, activeK, vIndex, kIndex,
        TileShape.dropInsertedIndex]
  simp only [TileShape.insertAxisIndex_one_rank2, MaskedReduction.ite_some_some,
    Option.map₂_some_some, WithBot.sum_someTerm_eq_some, WithBot.unbotD_some]
  let offsetFn : TileIndex [BK] → Nat :=
    fun idx => (s.pids 2 + s.pids 0 * B * H) * s_qk_h + s.pids 1 * BK +
      idx.1.val + t * K
  let valueFn : TileIndex [BK] → ℝ :=
    fun idx =>
      ∑ jv : Fin BV,
        ((if s.pids 1 * BK + idx.1.val < K ∧ s.pids 0 * BV + jv.val < V then
              s.readMem DHPrev
                (s.pids 2 * K * V + (s.pids 1 * BK + idx.1.val) * V +
                  (s.pids 0 * BV + jv.val))
            else 0.0)
          + (if s.pids 1 * BK + idx.1.val < K then
                s.readMem q (s.pids 2 * s_qk_h + s.pids 1 * BK + idx.1.val + t * K)
              else 0.0) *
              scale *
              (if s.pids 0 * BV + jv.val < V then
                  s.readMem do_ (s.pids 2 * s_vo_h + s.pids 0 * BV + jv.val + t * V)
                else 0.0)) *
        ((if s.pids 0 * BV + jv.val < V then
              s.readMem v (s.pids 2 * s_vo_h + s.pids 0 * BV + jv.val + t * V)
            else 0.0) *
          (if s.pids 0 * BV + jv.val < V then
              s.readMem beta (s.pids 2 * s_vo_h + s.pids 0 * BV + jv.val + t * V)
            else 0.0))
  let P : TileIndex [BK] → Prop := fun idx => s.pids 1 * BK + idx.1.val < K
  have hOffsetInj : Function.Injective offsetFn := by
    rintro ⟨a, _⟩ ⟨b, _⟩ hab
    have : dkRowOffset s t s_qk_h B H K BK a = dkRowOffset s t s_qk_h B H K BK b := by
      simpa [offsetFn, dkRowOffset] using hab
    obtain rfl : a = b := hOutInj this
    rfl
  change (List.foldl
      (fun (acc : BlockState) idx =>
        if P idx then acc.writeMem dk (offsetFn idx) (valueFn idx) else acc)
      _ (TileShape.allIndices [BK])).readMem dk (offsetFn (jk, PUnit.unit)) =
    if activeK s K BK jk then
      dkStepSpec s DHPrev q do_ v beta Bool.true t s_qk_h s_vo_h T K V BK BV scale jk
    else s.readMem dk (offsetFn (jk, PUnit.unit))
  rw [BlockState.scatter_readback_prop_masked_nd _ _ _ _ hOffsetInj (jk, PUnit.unit)]
  by_cases hjk : s.pids 1 * BK + jk.val < K
  · simp only [P, hjk, if_true, activeK, kIndex, valueFn, dkStepSpec, dhOffset,
      betaVal, kVal, qVal, vVal, kIndex, vIndex, activeV, if_true, ite_true,
      true_and]
    apply Finset.sum_congr rfl
    intro jv _
    -- In range the two summands agree up to `ring`; out of range Python's
    -- `other = 0` zeroes `prev`, `b_do`, `b_v` (and headwise `b_beta`), so the
    -- column contributes `(0 + q·scale·0)·(0·β) = 0`.
    by_cases hV : s.pids 0 * BV + jv.val < V
    · simp only [hV, if_true]
      ring
    · simp only [hV, if_false, hzero]
      ring
  · simp only [P, activeK, kIndex, hjk, if_false, BlockState.setReg_readMem]

set_option maxHeartbeats 4000000 in
theorem fused_recurrent_delta_bwd_dk_step_slice_scalarbeta_correct
    (DHPrev q do_ v beta dk : RegionName)
    (t s_qk_h s_vo_h B H T K V BK BV : Nat) (scale : ℝ) (s : BlockState)
    (hOutInj : Function.Injective
      (fun jk : Fin BK => dkRowOffset s t s_qk_h B H K BK jk)) :
    ∀ jk : Fin BK,
      let outAddr := dkRowOffset s t s_qk_h B H K BK jk
      (exec (fused_recurrent_delta_bwd_dk_step_slice_scalarbeta DHPrev q do_ v beta dk
            t s_qk_h s_vo_h B H T K V BK BV scale) s).map (·.readMem dk outAddr)
        = some (if activeK s K BK jk then
            dkStepSpec s DHPrev q do_ v beta Bool.false
              t s_qk_h s_vo_h T K V BK BV scale jk
          else s.readMem dk outAddr) := by
  intro jk
  have hzero : (0.0 : ℝ) = 0 := by norm_num
  simp [exec, fused_recurrent_delta_bwd_dk_step_slice_scalarbeta, stepStmts, stepStmt,
        evalOp, evalOp.eq_def, Option.bind, Option.map, Tile.bop, Tile.cop,
        Tile.expandDim, Tile.uop, Tile.ptrAdd, Tile.reduceSum, Tile.reduceSumDrop,
        TileShape.axisDim, TileShape.eraseAxis, NumericDType.add, NumericDType.mul,
        ComparableDType.lt, dhOffset, dkRowOffset, activeK, vIndex, kIndex,
        TileShape.dropInsertedIndex]
  simp only [TileShape.insertAxisIndex_one_rank2, MaskedReduction.ite_some_some,
    Option.map₂_some_some, WithBot.sum_someTerm_eq_some, WithBot.unbotD_some]
  let offsetFn : TileIndex [BK] → Nat :=
    fun idx => (s.pids 2 + s.pids 0 * B * H) * s_qk_h + s.pids 1 * BK +
      idx.1.val + t * K
  let valueFn : TileIndex [BK] → ℝ :=
    fun idx =>
      ∑ jv : Fin BV,
        ((if s.pids 1 * BK + idx.1.val < K ∧ s.pids 0 * BV + jv.val < V then
              s.readMem DHPrev
                (s.pids 2 * K * V + (s.pids 1 * BK + idx.1.val) * V +
                  (s.pids 0 * BV + jv.val))
            else 0.0)
          + (if s.pids 1 * BK + idx.1.val < K then
                s.readMem q (s.pids 2 * s_qk_h + s.pids 1 * BK + idx.1.val + t * K)
              else 0.0) *
              scale *
              (if s.pids 0 * BV + jv.val < V then
                  s.readMem do_ (s.pids 2 * s_vo_h + s.pids 0 * BV + jv.val + t * V)
                else 0.0)) *
        ((if s.pids 0 * BV + jv.val < V then
              s.readMem v (s.pids 2 * s_vo_h + s.pids 0 * BV + jv.val + t * V)
            else 0.0) *
          s.readMem beta (s.pids 2 * T + t))
  let P : TileIndex [BK] → Prop := fun idx => s.pids 1 * BK + idx.1.val < K
  have hOffsetInj : Function.Injective offsetFn := by
    rintro ⟨a, _⟩ ⟨b, _⟩ hab
    have : dkRowOffset s t s_qk_h B H K BK a = dkRowOffset s t s_qk_h B H K BK b := by
      simpa [offsetFn, dkRowOffset] using hab
    obtain rfl : a = b := hOutInj this
    rfl
  change (List.foldl
      (fun (acc : BlockState) idx =>
        if P idx then acc.writeMem dk (offsetFn idx) (valueFn idx) else acc)
      _ (TileShape.allIndices [BK])).readMem dk (offsetFn (jk, PUnit.unit)) =
    if activeK s K BK jk then
      dkStepSpec s DHPrev q do_ v beta Bool.false t s_qk_h s_vo_h T K V BK BV scale jk
    else s.readMem dk (offsetFn (jk, PUnit.unit))
  rw [BlockState.scatter_readback_prop_masked_nd _ _ _ _ hOffsetInj (jk, PUnit.unit)]
  by_cases hjk : s.pids 1 * BK + jk.val < K
  · simp only [P, hjk, if_true, activeK, kIndex, valueFn, dkStepSpec, dhOffset,
      betaVal, kVal, qVal, vVal, kIndex, vIndex, activeV, Bool.false_eq_true,
      ite_false, if_false, true_and]
    apply Finset.sum_congr rfl
    intro jv _
    -- In range the two summands agree up to `ring`; out of range Python's
    -- `other = 0` zeroes `prev`, `b_do`, `b_v` (and headwise `b_beta`), so the
    -- column contributes `(0 + q·scale·0)·(0·β) = 0`.
    by_cases hV : s.pids 0 * BV + jv.val < V
    · simp only [hV, if_true]
      ring
    · simp only [hV, if_false, hzero]
      ring
  · simp only [P, activeK, kIndex, hjk, if_false, BlockState.setReg_readMem]

/-- **Genuine `dk` step (loop 1).** The `IS_HEADWISE_BETA` specialization
selected by the flag realizes `dkStepSpec` (masked) into `dk` at time row `t`. -/
theorem fused_recurrent_delta_bwd_dk_step_slice_compute_correct
    (DHPrev q do_ v beta dk : RegionName) (IS_HEADWISE_BETA : Bool)
    (t s_qk_h s_vo_h B H T K V BK BV : Nat) (scale : ℝ) (s : BlockState)
    (hOutInj : Function.Injective
      (fun jk : Fin BK => dkRowOffset s t s_qk_h B H K BK jk)) :
    ComputeCorrect.Realizes_without_Rounding
      (kernel := if IS_HEADWISE_BETA then
          fused_recurrent_delta_bwd_dk_step_slice_headwise DHPrev q do_ v beta dk
            t s_qk_h s_vo_h B H T K V BK BV scale
        else
          fused_recurrent_delta_bwd_dk_step_slice_scalarbeta DHPrev q do_ v beta dk
            t s_qk_h s_vo_h B H T K V BK BV scale)
      (initialState := s)
      (write := ComputeCorrect.WriteMap.writeIf
        (fun jk : Fin BK => activeK s K BK jk)
        (fun jk => (dk, dkRowOffset s t s_qk_h B H K BK jk)))
      (expected := fun jk : Fin BK =>
        dkStepSpec s DHPrev q do_ v beta IS_HEADWISE_BETA
          t s_qk_h s_vo_h T K V BK BV scale jk) := by
  cases IS_HEADWISE_BETA
  · -- IS_HEADWISE_BETA = false
    simp only [Bool.false_eq_true, if_false]
    rw [ComputeCorrect.realizes_writeIf_iff]
    apply ComputeKernel.computeCorrect_of_toAlgKernel
    · simp [fused_recurrent_delta_bwd_dk_step_slice_scalarbeta,
        ComputeExpr.toAlgorithm?, ComputeOp.toAlgorithm?]
    intro s0 s' hExec hs0
    subst s0
    intro jk hActive
    have h := fused_recurrent_delta_bwd_dk_step_slice_scalarbeta_correct DHPrev q
      do_ v beta dk t s_qk_h s_vo_h B H T K V BK BV scale s hOutInj jk
    rw [hExec] at h
    simpa [hActive] using Option.some.inj h
  · -- IS_HEADWISE_BETA = true
    simp only [if_true]
    rw [ComputeCorrect.realizes_writeIf_iff]
    apply ComputeKernel.computeCorrect_of_toAlgKernel
    · simp [fused_recurrent_delta_bwd_dk_step_slice_headwise,
        ComputeExpr.toAlgorithm?, ComputeOp.toAlgorithm?]
    intro s0 s' hExec hs0
    subst s0
    intro jk hActive
    have h := fused_recurrent_delta_bwd_dk_step_slice_headwise_correct DHPrev q
      do_ v beta dk t s_qk_h s_vo_h B H T K V BK BV scale s hOutInj jk
    rw [hExec] at h
    simpa [hActive] using Option.some.inj h

def fused_recurrent_delta_bwd_dv_step_slice_headwise
    (DHPrev q do_ k beta dv : RegionName)
    (t s_qk_h s_vo_h B H T K V BK BV : Nat) (scale : ℝ) :
    ComputeKernel := triton {
  i_v = tl.program_id(0)
  i_k = tl.program_id(1)
  i_bh = tl.program_id(2)
  offs_k = tl.arange(0, $(BK))
  offs_v = tl.arange(0, $(BV))
  mask_bk = (i_k * $(BK) + offs_k) < $(K)
  mask_bv = (i_v * $(BV) + offs_v) < $(V)
  mask_kv = mask_bk[:, None] & mask_bv[None, :]
  prev = tl.load(DHPrev + i_bh * $(K) * $(V) +
    (i_k * $(BK) + offs_k[:, None]) * $(V) + (i_v * $(BV) + offs_v[None, :]),
    mask=mask_kv, other=0.0)
  b_q = tl.load(q + i_bh * $(s_qk_h) + i_k * $(BK) + offs_k + $(t) * $(K),
    mask=mask_bk, other=0.0) * $(scale)
  b_do = tl.load(do_ + i_bh * $(s_vo_h) + i_v * $(BV) + offs_v + $(t) * $(V),
    mask=mask_bv, other=0.0)
  b_k = tl.load(k + i_bh * $(s_qk_h) + i_k * $(BK) + offs_k + $(t) * $(K),
    mask=mask_bk, other=0.0)
  b_beta = tl.load(beta + i_bh * $(s_vo_h) + i_v * $(BV) + offs_v + $(t) * $(V),
    mask=mask_bv, other=0.0)
  d_h = prev + b_q[:, None] * b_do[None, :]
  d_v = tl.sum(d_h * b_k[:, None], axis=0)
  d_v = d_v * b_beta
  tl.store(dv + (i_bh + i_k * $(B) * $(H)) * $(s_vo_h) + i_v * $(BV) + offs_v +
    $(t) * $(V), (d_v).to(dv.dtype.element_ty), mask=mask_bv)
}

def fused_recurrent_delta_bwd_dv_step_slice_scalarbeta
    (DHPrev q do_ k beta dv : RegionName)
    (t s_qk_h s_vo_h B H T K V BK BV : Nat) (scale : ℝ) :
    ComputeKernel := triton {
  i_v = tl.program_id(0)
  i_k = tl.program_id(1)
  i_bh = tl.program_id(2)
  offs_k = tl.arange(0, $(BK))
  offs_v = tl.arange(0, $(BV))
  mask_bk = (i_k * $(BK) + offs_k) < $(K)
  mask_bv = (i_v * $(BV) + offs_v) < $(V)
  mask_kv = mask_bk[:, None] & mask_bv[None, :]
  prev = tl.load(DHPrev + i_bh * $(K) * $(V) +
    (i_k * $(BK) + offs_k[:, None]) * $(V) + (i_v * $(BV) + offs_v[None, :]),
    mask=mask_kv, other=0.0)
  b_q = tl.load(q + i_bh * $(s_qk_h) + i_k * $(BK) + offs_k + $(t) * $(K),
    mask=mask_bk, other=0.0) * $(scale)
  b_do = tl.load(do_ + i_bh * $(s_vo_h) + i_v * $(BV) + offs_v + $(t) * $(V),
    mask=mask_bv, other=0.0)
  b_k = tl.load(k + i_bh * $(s_qk_h) + i_k * $(BK) + offs_k + $(t) * $(K),
    mask=mask_bk, other=0.0)
  b_beta = tl.load(beta + i_bh * $(T) + $(t))
  d_h = prev + b_q[:, None] * b_do[None, :]
  d_v = tl.sum(d_h * b_k[:, None], axis=0)
  d_v = d_v * b_beta
  tl.store(dv + (i_bh + i_k * $(B) * $(H)) * $(s_vo_h) + i_v * $(BV) + offs_v +
    $(t) * $(V), (d_v).to(dv.dtype.element_ty), mask=mask_bv)
}

/-- The genuine per-lane `dv` step formula (loop 1, both beta modes):
`dv_t[j_v] = (Σ_{j_k} (DHPrev + scale·q_t ⊗ do_t)[j_k,j_v] · k_t[j_k]) · β_t[j_v]`. -/
noncomputable def dvStepSpec (s : BlockState) (DHPrev q do_ k beta : RegionName)
    (IS_HEADWISE_BETA : Bool) (t s_qk_h s_vo_h T K V BK BV : Nat) (scale : ℝ)
    (jv : Fin BV) : ℝ :=
  (∑ jk : Fin BK,
      if activeK s K BK jk then
        (s.readMem DHPrev (dhOffset s K V BK BV (jk, jv, PUnit.unit))
            + qVal s q s_qk_h K BK scale t jk * vVal s do_ s_vo_h V BV t jv)
          * kVal s k s_qk_h K BK t jk
      else 0)
    * betaVal s beta IS_HEADWISE_BETA s_vo_h T V BV t jv

set_option maxHeartbeats 4000000 in
theorem fused_recurrent_delta_bwd_dv_step_slice_headwise_correct
    (DHPrev q do_ k beta dv : RegionName)
    (t s_qk_h s_vo_h B H T K V BK BV : Nat) (scale : ℝ) (s : BlockState)
    (hOutInj : Function.Injective
      (fun jv : Fin BV => outOffset s t s_vo_h B H V BV jv)) :
    ∀ jv : Fin BV,
      let outAddr := outOffset s t s_vo_h B H V BV jv
      (exec (fused_recurrent_delta_bwd_dv_step_slice_headwise DHPrev q do_ k beta dv
            t s_qk_h s_vo_h B H T K V BK BV scale) s).map (·.readMem dv outAddr)
        = some (if activeV s V BV jv then
            dvStepSpec s DHPrev q do_ k beta Bool.true
              t s_qk_h s_vo_h T K V BK BV scale jv
          else s.readMem dv outAddr) := by
  intro jv
  have hzero : (0.0 : ℝ) = 0 := by norm_num
  simp [exec, fused_recurrent_delta_bwd_dv_step_slice_headwise, stepStmts, stepStmt,
        evalOp, evalOp.eq_def, Option.bind, Option.map, Tile.bop, Tile.cop,
        Tile.expandDim, Tile.uop, Tile.ptrAdd, Tile.reduceSum, Tile.reduceSumDrop,
        TileShape.axisDim, TileShape.eraseAxis, NumericDType.add, NumericDType.mul,
        ComparableDType.lt, dhOffset, outOffset, activeV, vIndex, kIndex,
        TileShape.dropInsertedIndex]
  -- `tl.sum(_, axis = 0)` here, so the *zero*-axis `insertAxisIndex` spelling.
  simp only [TileShape.insertAxisIndex_zero_rank2, MaskedReduction.ite_some_some,
    Option.map₂_some_some, WithBot.sum_someTerm_eq_some, WithBot.unbotD_some]
  let offsetFn : TileIndex [BV] → Nat :=
    fun idx => (s.pids 2 + s.pids 1 * B * H) * s_vo_h + s.pids 0 * BV +
      idx.1.val + t * V
  let valueFn : TileIndex [BV] → ℝ :=
    fun idx =>
      (∑ jk : Fin BK,
        ((if s.pids 1 * BK + jk.val < K ∧ s.pids 0 * BV + idx.1.val < V then
              s.readMem DHPrev
                (s.pids 2 * K * V + (s.pids 1 * BK + jk.val) * V +
                  (s.pids 0 * BV + idx.1.val))
            else 0.0)
          + (if s.pids 1 * BK + jk.val < K then
                s.readMem q (s.pids 2 * s_qk_h + s.pids 1 * BK + jk.val + t * K)
              else 0.0) *
              scale *
              (if s.pids 0 * BV + idx.1.val < V then
                  s.readMem do_ (s.pids 2 * s_vo_h + s.pids 0 * BV + idx.1.val + t * V)
                else 0.0)) *
        (if s.pids 1 * BK + jk.val < K then
            s.readMem k (s.pids 2 * s_qk_h + s.pids 1 * BK + jk.val + t * K)
          else 0.0)) *
      (if s.pids 0 * BV + idx.1.val < V then
          s.readMem beta (s.pids 2 * s_vo_h + s.pids 0 * BV + idx.1.val + t * V)
        else 0.0)
  let P : TileIndex [BV] → Prop := fun idx => s.pids 0 * BV + idx.1.val < V
  have hOffsetInj : Function.Injective offsetFn := by
    rintro ⟨a, _⟩ ⟨b, _⟩ hab
    have : outOffset s t s_vo_h B H V BV a = outOffset s t s_vo_h B H V BV b := by
      simpa [offsetFn, outOffset] using hab
    obtain rfl : a = b := hOutInj this
    rfl
  change (List.foldl
      (fun (acc : BlockState) idx =>
        if P idx then acc.writeMem dv (offsetFn idx) (valueFn idx) else acc)
      _ (TileShape.allIndices [BV])).readMem dv (offsetFn (jv, PUnit.unit)) =
    if activeV s V BV jv then
      dvStepSpec s DHPrev q do_ k beta Bool.true t s_qk_h s_vo_h T K V BK BV scale jv
    else s.readMem dv (offsetFn (jv, PUnit.unit))
  rw [BlockState.scatter_readback_prop_masked_nd _ _ _ _ hOffsetInj (jv, PUnit.unit)]
  by_cases hjv : s.pids 0 * BV + jv.val < V
  · simp only [P, hjv, if_true, activeV, vIndex, valueFn, dvStepSpec, dhOffset,
      betaVal, kVal, qVal, vVal, kIndex, vIndex, activeK, if_true, ite_true,
      and_true]
    congr 1
    apply Finset.sum_congr rfl
    intro jk _
    -- In range the two summands agree up to `ring`; out of range Python's
    -- `other = 0` zeroes `prev`, `b_q` and `b_k`, so the column contributes
    -- `(0 + 0·scale·do)·0 = 0`.
    by_cases hK : s.pids 1 * BK + jk.val < K
    · simp only [hK, if_true]
      ring
    · simp only [hK, if_false, hzero]
      ring
  · simp only [P, activeV, vIndex, hjv, if_false, BlockState.setReg_readMem]

set_option maxHeartbeats 4000000 in
theorem fused_recurrent_delta_bwd_dv_step_slice_scalarbeta_correct
    (DHPrev q do_ k beta dv : RegionName)
    (t s_qk_h s_vo_h B H T K V BK BV : Nat) (scale : ℝ) (s : BlockState)
    (hOutInj : Function.Injective
      (fun jv : Fin BV => outOffset s t s_vo_h B H V BV jv)) :
    ∀ jv : Fin BV,
      let outAddr := outOffset s t s_vo_h B H V BV jv
      (exec (fused_recurrent_delta_bwd_dv_step_slice_scalarbeta DHPrev q do_ k beta dv
            t s_qk_h s_vo_h B H T K V BK BV scale) s).map (·.readMem dv outAddr)
        = some (if activeV s V BV jv then
            dvStepSpec s DHPrev q do_ k beta Bool.false
              t s_qk_h s_vo_h T K V BK BV scale jv
          else s.readMem dv outAddr) := by
  intro jv
  have hzero : (0.0 : ℝ) = 0 := by norm_num
  simp [exec, fused_recurrent_delta_bwd_dv_step_slice_scalarbeta, stepStmts, stepStmt,
        evalOp, evalOp.eq_def, Option.bind, Option.map, Tile.bop, Tile.cop,
        Tile.expandDim, Tile.uop, Tile.ptrAdd, Tile.reduceSum, Tile.reduceSumDrop,
        TileShape.axisDim, TileShape.eraseAxis, NumericDType.add, NumericDType.mul,
        ComparableDType.lt, dhOffset, outOffset, activeV, vIndex, kIndex,
        TileShape.dropInsertedIndex]
  -- `tl.sum(_, axis = 0)` here, so the *zero*-axis `insertAxisIndex` spelling.
  simp only [TileShape.insertAxisIndex_zero_rank2, MaskedReduction.ite_some_some,
    Option.map₂_some_some, WithBot.sum_someTerm_eq_some, WithBot.unbotD_some]
  let offsetFn : TileIndex [BV] → Nat :=
    fun idx => (s.pids 2 + s.pids 1 * B * H) * s_vo_h + s.pids 0 * BV +
      idx.1.val + t * V
  let valueFn : TileIndex [BV] → ℝ :=
    fun idx =>
      (∑ jk : Fin BK,
        ((if s.pids 1 * BK + jk.val < K ∧ s.pids 0 * BV + idx.1.val < V then
              s.readMem DHPrev
                (s.pids 2 * K * V + (s.pids 1 * BK + jk.val) * V +
                  (s.pids 0 * BV + idx.1.val))
            else 0.0)
          + (if s.pids 1 * BK + jk.val < K then
                s.readMem q (s.pids 2 * s_qk_h + s.pids 1 * BK + jk.val + t * K)
              else 0.0) *
              scale *
              (if s.pids 0 * BV + idx.1.val < V then
                  s.readMem do_ (s.pids 2 * s_vo_h + s.pids 0 * BV + idx.1.val + t * V)
                else 0.0)) *
        (if s.pids 1 * BK + jk.val < K then
            s.readMem k (s.pids 2 * s_qk_h + s.pids 1 * BK + jk.val + t * K)
          else 0.0)) *
      s.readMem beta (s.pids 2 * T + t)
  let P : TileIndex [BV] → Prop := fun idx => s.pids 0 * BV + idx.1.val < V
  have hOffsetInj : Function.Injective offsetFn := by
    rintro ⟨a, _⟩ ⟨b, _⟩ hab
    have : outOffset s t s_vo_h B H V BV a = outOffset s t s_vo_h B H V BV b := by
      simpa [offsetFn, outOffset] using hab
    obtain rfl : a = b := hOutInj this
    rfl
  change (List.foldl
      (fun (acc : BlockState) idx =>
        if P idx then acc.writeMem dv (offsetFn idx) (valueFn idx) else acc)
      _ (TileShape.allIndices [BV])).readMem dv (offsetFn (jv, PUnit.unit)) =
    if activeV s V BV jv then
      dvStepSpec s DHPrev q do_ k beta Bool.false t s_qk_h s_vo_h T K V BK BV scale jv
    else s.readMem dv (offsetFn (jv, PUnit.unit))
  rw [BlockState.scatter_readback_prop_masked_nd _ _ _ _ hOffsetInj (jv, PUnit.unit)]
  by_cases hjv : s.pids 0 * BV + jv.val < V
  · simp only [P, hjv, if_true, activeV, vIndex, valueFn, dvStepSpec, dhOffset,
      betaVal, kVal, qVal, vVal, kIndex, vIndex, activeK, Bool.false_eq_true,
      ite_false, if_false, and_true]
    congr 1
    apply Finset.sum_congr rfl
    intro jk _
    -- In range the two summands agree up to `ring`; out of range Python's
    -- `other = 0` zeroes `prev`, `b_q` and `b_k`, so the column contributes
    -- `(0 + 0·scale·do)·0 = 0`.
    by_cases hK : s.pids 1 * BK + jk.val < K
    · simp only [hK, if_true]
      ring
    · simp only [hK, if_false, hzero]
      ring
  · simp only [P, activeV, vIndex, hjv, if_false, BlockState.setReg_readMem]

/-- **Genuine `dv` step (loop 1).** The `IS_HEADWISE_BETA` specialization
selected by the flag realizes `dvStepSpec` (masked) into `dv` at time row `t`. -/
theorem fused_recurrent_delta_bwd_dv_step_slice_compute_correct
    (DHPrev q do_ k beta dv : RegionName) (IS_HEADWISE_BETA : Bool)
    (t s_qk_h s_vo_h B H T K V BK BV : Nat) (scale : ℝ) (s : BlockState)
    (hOutInj : Function.Injective
      (fun jv : Fin BV => outOffset s t s_vo_h B H V BV jv)) :
    ComputeCorrect.Realizes_without_Rounding
      (kernel := if IS_HEADWISE_BETA then
          fused_recurrent_delta_bwd_dv_step_slice_headwise DHPrev q do_ k beta dv
            t s_qk_h s_vo_h B H T K V BK BV scale
        else
          fused_recurrent_delta_bwd_dv_step_slice_scalarbeta DHPrev q do_ k beta dv
            t s_qk_h s_vo_h B H T K V BK BV scale)
      (initialState := s)
      (write := ComputeCorrect.WriteMap.writeIf
        (fun jv : Fin BV => activeV s V BV jv)
        (fun jv => (dv, outOffset s t s_vo_h B H V BV jv)))
      (expected := fun jv : Fin BV =>
        dvStepSpec s DHPrev q do_ k beta IS_HEADWISE_BETA
          t s_qk_h s_vo_h T K V BK BV scale jv) := by
  cases IS_HEADWISE_BETA
  · -- IS_HEADWISE_BETA = false
    simp only [Bool.false_eq_true, if_false]
    rw [ComputeCorrect.realizes_writeIf_iff]
    apply ComputeKernel.computeCorrect_of_toAlgKernel
    · simp [fused_recurrent_delta_bwd_dv_step_slice_scalarbeta,
        ComputeExpr.toAlgorithm?, ComputeOp.toAlgorithm?]
    intro s0 s' hExec hs0
    subst s0
    intro jv hActive
    have h := fused_recurrent_delta_bwd_dv_step_slice_scalarbeta_correct DHPrev q
      do_ k beta dv t s_qk_h s_vo_h B H T K V BK BV scale s hOutInj jv
    rw [hExec] at h
    simpa [hActive] using Option.some.inj h
  · -- IS_HEADWISE_BETA = true
    simp only [if_true]
    rw [ComputeCorrect.realizes_writeIf_iff]
    apply ComputeKernel.computeCorrect_of_toAlgKernel
    · simp [fused_recurrent_delta_bwd_dv_step_slice_headwise,
        ComputeExpr.toAlgorithm?, ComputeOp.toAlgorithm?]
    intro s0 s' hExec hs0
    subst s0
    intro jv hActive
    have h := fused_recurrent_delta_bwd_dv_step_slice_headwise_correct DHPrev q
      do_ k beta dv t s_qk_h s_vo_h B H T K V BK BV scale s hOutInj jv
    rw [hExec] at h
    simpa [hActive] using Option.some.inj h

def fused_recurrent_delta_bwd_dbeta_step_slice_headwise
    (DHPrev q do_ k v dbeta : RegionName)
    (t s_qk_h s_vo_h NK B H T K V BK BV : Nat) (scale : ℝ) :
    ComputeKernel := triton {
  i_v = tl.program_id(0)
  i_k = tl.program_id(1)
  i_bh = tl.program_id(2)
  offs_k = tl.arange(0, $(BK))
  offs_v = tl.arange(0, $(BV))
  mask_bk = (i_k * $(BK) + offs_k) < $(K)
  mask_bv = (i_v * $(BV) + offs_v) < $(V)
  mask_kv = mask_bk[:, None] & mask_bv[None, :]
  prev = tl.load(DHPrev + i_bh * $(K) * $(V) +
    (i_k * $(BK) + offs_k[:, None]) * $(V) + (i_v * $(BV) + offs_v[None, :]),
    mask=mask_kv, other=0.0)
  b_q = tl.load(q + i_bh * $(s_qk_h) + i_k * $(BK) + offs_k + $(t) * $(K),
    mask=mask_bk, other=0.0) * $(scale)
  b_do = tl.load(do_ + i_bh * $(s_vo_h) + i_v * $(BV) + offs_v + $(t) * $(V),
    mask=mask_bv, other=0.0)
  b_k = tl.load(k + i_bh * $(s_qk_h) + i_k * $(BK) + offs_k + $(t) * $(K),
    mask=mask_bk, other=0.0)
  b_v = tl.load(v + i_bh * $(s_vo_h) + i_v * $(BV) + offs_v + $(t) * $(V),
    mask=mask_bv, other=0.0)
  d_h = prev + b_q[:, None] * b_do[None, :]
  d_v = tl.sum(d_h * b_k[:, None], axis=0)
  d_beta = d_v * b_v
  tl.store(dbeta + (i_bh + i_k * $(B) * $(H) + i_v * $(B) * $(H) * $(NK)) * $(s_vo_h) +
    offs_v + $(t) * $(V), (d_beta).to(dbeta.dtype.element_ty), mask=mask_bv)
}

def fused_recurrent_delta_bwd_dbeta_step_slice_scalarbeta
    (DHPrev q do_ k v dbeta : RegionName)
    (t s_qk_h s_vo_h B H T K V BK BV : Nat) (scale : ℝ) :
    ComputeKernel := triton {
  i_v = tl.program_id(0)
  i_k = tl.program_id(1)
  i_bh = tl.program_id(2)
  offs_k = tl.arange(0, $(BK))
  offs_v = tl.arange(0, $(BV))
  mask_bk = (i_k * $(BK) + offs_k) < $(K)
  mask_bv = (i_v * $(BV) + offs_v) < $(V)
  mask_kv = mask_bk[:, None] & mask_bv[None, :]
  prev = tl.load(DHPrev + i_bh * $(K) * $(V) +
    (i_k * $(BK) + offs_k[:, None]) * $(V) + (i_v * $(BV) + offs_v[None, :]),
    mask=mask_kv, other=0.0)
  b_q = tl.load(q + i_bh * $(s_qk_h) + i_k * $(BK) + offs_k + $(t) * $(K),
    mask=mask_bk, other=0.0) * $(scale)
  b_do = tl.load(do_ + i_bh * $(s_vo_h) + i_v * $(BV) + offs_v + $(t) * $(V),
    mask=mask_bv, other=0.0)
  b_k = tl.load(k + i_bh * $(s_qk_h) + i_k * $(BK) + offs_k + $(t) * $(K),
    mask=mask_bk, other=0.0)
  b_v = tl.load(v + i_bh * $(s_vo_h) + i_v * $(BV) + offs_v + $(t) * $(V),
    mask=mask_bv, other=0.0)
  d_h = prev + b_q[:, None] * b_do[None, :]
  d_v = tl.sum(d_h * b_k[:, None], axis=0)
  d_beta = tl.sum(d_v * b_v)
  tl.store(dbeta + (i_bh + i_v * $(B) * $(H)) * $(T) + $(t),
    (d_beta).to(dbeta.dtype.element_ty))
}

/-- The genuine per-lane headwise `dbeta` step formula (loop 1):
`dbeta_t[j_v] = (Σ_{j_k} (DHPrev + scale·q_t ⊗ do_t)[j_k,j_v] · k_t[j_k]) · v_t[j_v]`
(the *pre-beta* `d_v`, as in the Python). -/
noncomputable def dbetaStepSpec (s : BlockState) (DHPrev q do_ k v : RegionName)
    (t s_qk_h s_vo_h K V BK BV : Nat) (scale : ℝ) (jv : Fin BV) : ℝ :=
  (∑ jk : Fin BK,
      if activeK s K BK jk then
        (s.readMem DHPrev (dhOffset s K V BK BV (jk, jv, PUnit.unit))
            + qVal s q s_qk_h K BK scale t jk * vVal s do_ s_vo_h V BV t jv)
          * kVal s k s_qk_h K BK t jk
      else 0)
    * vVal s v s_vo_h V BV t jv

/-- The genuine scalar `dbeta` step formula (loop 1):
`dbeta_t = Σ_{j_v} d_v[j_v] · v_t[j_v]` (the full `tl.sum` reduction). -/
noncomputable def dbetaScalarStepSpec (s : BlockState) (DHPrev q do_ k v : RegionName)
    (t s_qk_h s_vo_h K V BK BV : Nat) (scale : ℝ) : ℝ :=
  ∑ jv : Fin BV,
    if activeV s V BV jv then
      dbetaStepSpec s DHPrev q do_ k v t s_qk_h s_vo_h K V BK BV scale jv
    else 0

set_option maxHeartbeats 4000000 in
theorem fused_recurrent_delta_bwd_dbeta_step_slice_headwise_correct
    (DHPrev q do_ k v dbeta : RegionName)
    (t s_qk_h s_vo_h NK B H T K V BK BV : Nat) (scale : ℝ) (s : BlockState)
    (hOutInj : Function.Injective
      (fun jv : Fin BV => dbetaRowOffset s t s_vo_h B H NK V BV jv)) :
    ∀ jv : Fin BV,
      let outAddr := dbetaRowOffset s t s_vo_h B H NK V BV jv
      (exec (fused_recurrent_delta_bwd_dbeta_step_slice_headwise DHPrev q do_ k v dbeta
            t s_qk_h s_vo_h NK B H T K V BK BV scale) s).map (·.readMem dbeta outAddr)
        = some (if activeV s V BV jv then
            dbetaStepSpec s DHPrev q do_ k v t s_qk_h s_vo_h K V BK BV scale jv
          else s.readMem dbeta outAddr) := by
  intro jv
  have hzero : (0.0 : ℝ) = 0 := by norm_num
  simp [exec, fused_recurrent_delta_bwd_dbeta_step_slice_headwise, stepStmts, stepStmt,
        evalOp, evalOp.eq_def, Option.bind, Option.map, Tile.bop, Tile.cop,
        Tile.expandDim, Tile.uop, Tile.ptrAdd, Tile.reduceSum, Tile.reduceSumDrop,
        TileShape.axisDim, TileShape.eraseAxis, NumericDType.add, NumericDType.mul,
        ComparableDType.lt, dhOffset, dbetaRowOffset, activeV, vIndex, kIndex,
        TileShape.dropInsertedIndex]
  simp only [TileShape.insertAxisIndex_zero_rank2, MaskedReduction.ite_some_some,
    Option.map₂_some_some, WithBot.sum_someTerm_eq_some, WithBot.unbotD_some]
  let offsetFn : TileIndex [BV] → Nat :=
    fun idx => (s.pids 2 + s.pids 1 * B * H + s.pids 0 * B * H * NK) * s_vo_h +
      idx.1.val + t * V
  let valueFn : TileIndex [BV] → ℝ :=
    fun idx =>
      (∑ jk : Fin BK,
        ((if s.pids 1 * BK + jk.val < K ∧ s.pids 0 * BV + idx.1.val < V then
              s.readMem DHPrev
                (s.pids 2 * K * V + (s.pids 1 * BK + jk.val) * V +
                  (s.pids 0 * BV + idx.1.val))
            else 0.0)
          + (if s.pids 1 * BK + jk.val < K then
                s.readMem q (s.pids 2 * s_qk_h + s.pids 1 * BK + jk.val + t * K)
              else 0.0) *
              scale *
              (if s.pids 0 * BV + idx.1.val < V then
                  s.readMem do_ (s.pids 2 * s_vo_h + s.pids 0 * BV + idx.1.val + t * V)
                else 0.0)) *
        (if s.pids 1 * BK + jk.val < K then
            s.readMem k (s.pids 2 * s_qk_h + s.pids 1 * BK + jk.val + t * K)
          else 0.0)) *
      (if s.pids 0 * BV + idx.1.val < V then
          s.readMem v (s.pids 2 * s_vo_h + s.pids 0 * BV + idx.1.val + t * V)
        else 0.0)
  let P : TileIndex [BV] → Prop := fun idx => s.pids 0 * BV + idx.1.val < V
  have hOffsetInj : Function.Injective offsetFn := by
    rintro ⟨a, _⟩ ⟨b, _⟩ hab
    have : dbetaRowOffset s t s_vo_h B H NK V BV a
        = dbetaRowOffset s t s_vo_h B H NK V BV b := by
      simpa [offsetFn, dbetaRowOffset] using hab
    obtain rfl : a = b := hOutInj this
    rfl
  change (List.foldl
      (fun (acc : BlockState) idx =>
        if P idx then acc.writeMem dbeta (offsetFn idx) (valueFn idx) else acc)
      _ (TileShape.allIndices [BV])).readMem dbeta (offsetFn (jv, PUnit.unit)) =
    if activeV s V BV jv then
      dbetaStepSpec s DHPrev q do_ k v t s_qk_h s_vo_h K V BK BV scale jv
    else s.readMem dbeta (offsetFn (jv, PUnit.unit))
  rw [BlockState.scatter_readback_prop_masked_nd _ _ _ _ hOffsetInj (jv, PUnit.unit)]
  by_cases hjv : s.pids 0 * BV + jv.val < V
  · simp only [P, hjv, if_true, activeV, vIndex, valueFn, dbetaStepSpec, dhOffset,
      kVal, qVal, vVal, kIndex, vIndex, activeK, and_true]
    congr 1
    apply Finset.sum_congr rfl
    intro jk _
    -- In range the two summands agree up to `ring`; out of range Python's
    -- `other = 0` zeroes `prev`, `b_q` and `b_k`.
    by_cases hK : s.pids 1 * BK + jk.val < K
    · simp only [hK, if_true]
      ring
    · simp only [hK, if_false, hzero]
      ring
  · simp only [P, activeV, vIndex, hjv, if_false, BlockState.setReg_readMem]

set_option maxHeartbeats 4000000 in
theorem fused_recurrent_delta_bwd_dbeta_step_slice_scalarbeta_correct
    (DHPrev q do_ k v dbeta : RegionName)
    (t s_qk_h s_vo_h B H T K V BK BV : Nat) (scale : ℝ) (s : BlockState) :
    (exec (fused_recurrent_delta_bwd_dbeta_step_slice_scalarbeta DHPrev q do_ k v dbeta
          t s_qk_h s_vo_h B H T K V BK BV scale) s).map
        (·.readMem dbeta (dbetaScalarOffset s t T B H))
      = some (dbetaScalarStepSpec s DHPrev q do_ k v
          t s_qk_h s_vo_h K V BK BV scale) := by
  have hzero : (0.0 : ℝ) = 0 := by norm_num
  simp [exec, fused_recurrent_delta_bwd_dbeta_step_slice_scalarbeta, stepStmts,
        stepStmt, evalOp, evalOp.eq_def, Option.bind, Option.map, Tile.bop, Tile.cop,
        Tile.expandDim, Tile.uop, Tile.ptrAdd, Tile.reduceSum, Tile.reduceSumDrop,
        TileShape.axisDim, TileShape.eraseAxis, NumericDType.add, NumericDType.mul,
        ComparableDType.lt, dhOffset, dbetaScalarOffset, vIndex, kIndex,
        TileShape.dropInsertedIndex, BlockState.writeMem_readMem]
  -- Two nested reductions: `axis = 0` over the key channels, then a full
  -- `tl.sum` over the value lanes. Both carriers collapse the same way.
  simp only [TileShape.insertAxisIndex_zero_rank2, MaskedReduction.ite_some_some,
    Option.map₂_some_some, WithBot.sum_someTerm_eq_some, WithBot.unbotD_some]
  -- The remaining `insertAxisIndex` lane atoms are `rfl`-reducible; `change`
  -- normalizes them by definitional equality.
  change (∑ jv : Fin BV,
      (∑ jk : Fin BK,
          ((if s.pids 1 * BK + jk.val < K ∧ s.pids 0 * BV + jv.val < V then
                s.readMem DHPrev
                  (s.pids 2 * K * V + (s.pids 1 * BK + jk.val) * V +
                    (s.pids 0 * BV + jv.val))
              else 0.0)
            + (if s.pids 1 * BK + jk.val < K then
                  s.readMem q (s.pids 2 * s_qk_h + s.pids 1 * BK + jk.val + t * K)
                else 0.0) *
                scale *
                (if s.pids 0 * BV + jv.val < V then
                    s.readMem do_ (s.pids 2 * s_vo_h + s.pids 0 * BV + jv.val + t * V)
                  else 0.0)) *
          (if s.pids 1 * BK + jk.val < K then
              s.readMem k (s.pids 2 * s_qk_h + s.pids 1 * BK + jk.val + t * K)
            else 0.0)) *
      (if s.pids 0 * BV + jv.val < V then
          s.readMem v (s.pids 2 * s_vo_h + s.pids 0 * BV + jv.val + t * V)
        else 0.0))
    = dbetaScalarStepSpec s DHPrev q do_ k v t s_qk_h s_vo_h K V BK BV scale
  simp only [dbetaScalarStepSpec, dbetaStepSpec, dhOffset, kVal, qVal, vVal,
    kIndex, vIndex, activeV, activeK]
  apply Finset.sum_congr rfl
  intro jv _
  by_cases hV : s.pids 0 * BV + jv.val < V
  · simp only [hV, if_true, and_true]
    congr 1
    apply Finset.sum_congr rfl
    intro jk _
    by_cases hK : s.pids 1 * BK + jk.val < K
    · simp only [hK, if_true]
      ring
    · simp only [hK, if_false, hzero]
      ring
  · -- an out-of-range value lane: `b_v` is `0`, so the whole column vanishes
    simp only [hV, if_false, and_false, hzero]
    ring

/-- **Genuine headwise `dbeta` step (loop 1)** — realizes `dbetaStepSpec`
(masked) into the headwise `dbeta` row at time `t`. -/
theorem fused_recurrent_delta_bwd_dbeta_step_slice_headwise_compute_correct
    (DHPrev q do_ k v dbeta : RegionName)
    (t s_qk_h s_vo_h NK B H T K V BK BV : Nat) (scale : ℝ) (s : BlockState)
    (hOutInj : Function.Injective
      (fun jv : Fin BV => dbetaRowOffset s t s_vo_h B H NK V BV jv)) :
    ComputeCorrect.Realizes_without_Rounding
      (kernel := fused_recurrent_delta_bwd_dbeta_step_slice_headwise DHPrev q do_ k v
        dbeta t s_qk_h s_vo_h NK B H T K V BK BV scale)
      (initialState := s)
      (write := ComputeCorrect.WriteMap.writeIf
        (fun jv : Fin BV => activeV s V BV jv)
        (fun jv => (dbeta, dbetaRowOffset s t s_vo_h B H NK V BV jv)))
      (expected := fun jv : Fin BV =>
        dbetaStepSpec s DHPrev q do_ k v t s_qk_h s_vo_h K V BK BV scale jv) := by
  rw [ComputeCorrect.realizes_writeIf_iff]
  apply ComputeKernel.computeCorrect_of_toAlgKernel
  · simp [fused_recurrent_delta_bwd_dbeta_step_slice_headwise,
      ComputeExpr.toAlgorithm?, ComputeOp.toAlgorithm?]
  intro s0 s' hExec hs0
  subst s0
  intro jv hActive
  have h := fused_recurrent_delta_bwd_dbeta_step_slice_headwise_correct DHPrev q
    do_ k v dbeta t s_qk_h s_vo_h NK B H T K V BK BV scale s hOutInj jv
  rw [hExec] at h
  simpa [hActive] using Option.some.inj h

/-- **Genuine scalar `dbeta` step (loop 1)** — realizes the full-reduction
`dbetaScalarStepSpec` into the scalar `dbeta` cell at time `t`. -/
theorem fused_recurrent_delta_bwd_dbeta_step_slice_scalarbeta_compute_correct
    (DHPrev q do_ k v dbeta : RegionName)
    (t s_qk_h s_vo_h B H T K V BK BV : Nat) (scale : ℝ) (s : BlockState) :
    ComputeCorrect.Realizes_without_Rounding
      (kernel := fused_recurrent_delta_bwd_dbeta_step_slice_scalarbeta DHPrev q do_ k v
        dbeta t s_qk_h s_vo_h B H T K V BK BV scale)
      (initialState := s)
      (write := fun _ : PUnit => some (dbeta, dbetaScalarOffset s t T B H))
      (expected := fun _ =>
        dbetaScalarStepSpec s DHPrev q do_ k v t s_qk_h s_vo_h K V BK BV scale) := by
  apply ComputeKernel.computeCorrect_of_toAlgKernel
  · simp [fused_recurrent_delta_bwd_dbeta_step_slice_scalarbeta,
      ComputeExpr.toAlgorithm?, ComputeOp.toAlgorithm?]
  intro s0 s' hExec hs0
  subst s0
  intro _
  have h := fused_recurrent_delta_bwd_dbeta_step_slice_scalarbeta_correct DHPrev q
    do_ k v dbeta t s_qk_h s_vo_h B H T K V BK BV scale s
  rw [hExec] at h
  exact Option.some.inj h

/-! ### Loop-2 faces: the `dk` correction and `dq` -/

def fused_recurrent_delta_bwd_dk_correction_step_slice
    (HPrev dv dk : RegionName) (t s_qk_h s_vo_h B H K V BK BV : Nat) :
    ComputeKernel := triton {
  i_v = tl.program_id(0)
  i_k = tl.program_id(1)
  i_bh = tl.program_id(2)
  offs_k = tl.arange(0, $(BK))
  offs_v = tl.arange(0, $(BV))
  mask_bk = (i_k * $(BK) + offs_k) < $(K)
  mask_bv = (i_v * $(BV) + offs_v) < $(V)
  mask_kv = mask_bk[:, None] & mask_bv[None, :]
  d_k = tl.load(dk + (i_bh + i_v * $(B) * $(H)) * $(s_qk_h) + i_k * $(BK) + offs_k +
    $(t) * $(K), mask=mask_bk, other=0.0)
  d_v = tl.load(dv + (i_bh + i_k * $(B) * $(H)) * $(s_vo_h) + i_v * $(BV) + offs_v +
    $(t) * $(V), mask=mask_bv, other=0.0)
  h = tl.load(HPrev + i_bh * $(K) * $(V) +
    (i_k * $(BK) + offs_k[:, None]) * $(V) + (i_v * $(BV) + offs_v[None, :]),
    mask=mask_kv, other=0.0)
  d_k -= tl.sum(d_v[None, :] * h, axis=1)
  tl.store(dk + (i_bh + i_v * $(B) * $(H)) * $(s_qk_h) + i_k * $(BK) + offs_k +
    $(t) * $(K), (d_k).to(dk.dtype.element_ty), mask=mask_bk)
}

/-- The genuine per-lane loop-2 `dk` correction formula: the loop-1 `dk` row
minus the readout of the recomputed *pre-update* state,
`dk_t[j_k] − Σ_{j_v} dv_t[j_v] · HPrev[j_k,j_v]`. Both the `dk` and `dv` rows
are the loop-1 stores (this face rewrites `dk` at the same address it reads,
after the read — the final memory value of the `dk` row). -/
noncomputable def dkCorrStepSpec (s : BlockState) (HPrev dv dk : RegionName)
    (t s_qk_h s_vo_h B H K V BK BV : Nat) (jk : Fin BK) : ℝ :=
  s.readMem dk (dkRowOffset s t s_qk_h B H K BK jk)
    - ∑ jv : Fin BV,
        if activeV s V BV jv then
          s.readMem dv (outOffset s t s_vo_h B H V BV jv)
            * s.readMem HPrev (dhOffset s K V BK BV (jk, jv, PUnit.unit))
        else 0

set_option maxHeartbeats 4000000 in
theorem fused_recurrent_delta_bwd_dk_correction_step_slice_correct
    (HPrev dv dk : RegionName)
    (t s_qk_h s_vo_h B H K V BK BV : Nat) (s : BlockState)
    (hOutInj : Function.Injective
      (fun jk : Fin BK => dkRowOffset s t s_qk_h B H K BK jk)) :
    ∀ jk : Fin BK,
      let outAddr := dkRowOffset s t s_qk_h B H K BK jk
      (exec (fused_recurrent_delta_bwd_dk_correction_step_slice HPrev dv dk
            t s_qk_h s_vo_h B H K V BK BV) s).map (·.readMem dk outAddr)
        = some (if activeK s K BK jk then
            dkCorrStepSpec s HPrev dv dk t s_qk_h s_vo_h B H K V BK BV jk
          else s.readMem dk outAddr) := by
  intro jk
  have hzero : (0.0 : ℝ) = 0 := by norm_num
  simp [exec, fused_recurrent_delta_bwd_dk_correction_step_slice, stepStmts, stepStmt,
        evalOp, evalOp.eq_def, Option.bind, Option.map, Tile.bop, Tile.cop,
        Tile.expandDim, Tile.uop, Tile.ptrAdd, Tile.reduceSum, Tile.reduceSumDrop,
        TileShape.axisDim, TileShape.eraseAxis, NumericDType.add, NumericDType.mul,
        NumericDType.sub, ComparableDType.lt, dhOffset, dkRowOffset, outOffset,
        activeK, vIndex, kIndex, TileShape.dropInsertedIndex]
  simp only [TileShape.insertAxisIndex_one_rank2, MaskedReduction.ite_some_some,
    Option.map₂_some_some, WithBot.sum_someTerm_eq_some, WithBot.unbotD_some]
  let offsetFn : TileIndex [BK] → Nat :=
    fun idx => (s.pids 2 + s.pids 0 * B * H) * s_qk_h + s.pids 1 * BK +
      idx.1.val + t * K
  let valueFn : TileIndex [BK] → ℝ :=
    fun idx =>
      (if s.pids 1 * BK + idx.1.val < K then
          s.readMem dk ((s.pids 2 + s.pids 0 * B * H) * s_qk_h + s.pids 1 * BK +
            idx.1.val + t * K)
        else 0.0)
        - ∑ jv : Fin BV,
            (if s.pids 0 * BV + jv.val < V then
                s.readMem dv ((s.pids 2 + s.pids 1 * B * H) * s_vo_h + s.pids 0 * BV +
                  jv.val + t * V)
              else 0.0) *
              (if s.pids 1 * BK + idx.1.val < K ∧ s.pids 0 * BV + jv.val < V then
                  s.readMem HPrev
                    (s.pids 2 * K * V + (s.pids 1 * BK + idx.1.val) * V +
                      (s.pids 0 * BV + jv.val))
                else 0.0)
  let P : TileIndex [BK] → Prop := fun idx => s.pids 1 * BK + idx.1.val < K
  have hOffsetInj : Function.Injective offsetFn := by
    rintro ⟨a, _⟩ ⟨b, _⟩ hab
    have : dkRowOffset s t s_qk_h B H K BK a = dkRowOffset s t s_qk_h B H K BK b := by
      simpa [offsetFn, dkRowOffset] using hab
    obtain rfl : a = b := hOutInj this
    rfl
  change (List.foldl
      (fun (acc : BlockState) idx =>
        if P idx then acc.writeMem dk (offsetFn idx) (valueFn idx) else acc)
      _ (TileShape.allIndices [BK])).readMem dk (offsetFn (jk, PUnit.unit)) =
    if activeK s K BK jk then
      dkCorrStepSpec s HPrev dv dk t s_qk_h s_vo_h B H K V BK BV jk
    else s.readMem dk (offsetFn (jk, PUnit.unit))
  rw [BlockState.scatter_readback_prop_masked_nd _ _ _ _ hOffsetInj (jk, PUnit.unit)]
  by_cases hjk : s.pids 1 * BK + jk.val < K
  · simp only [P, hjk, if_true, activeK, kIndex, valueFn, dkCorrStepSpec, dhOffset,
      dkRowOffset, outOffset, kIndex, vIndex, activeV, true_and]
    congr 1
    apply Finset.sum_congr rfl
    intro jv _
    by_cases hV : s.pids 0 * BV + jv.val < V
    · simp only [hV, if_true]
    · simp only [hV, if_false, hzero]
      ring
  · simp only [P, activeK, kIndex, hjk, if_false, BlockState.setReg_readMem]

/-- **Genuine loop-2 `dk` correction step** — realizes `dkCorrStepSpec`
(masked) into `dk` at time row `t` (the in-place fixup; the row is read
before it is written). -/
theorem fused_recurrent_delta_bwd_dk_correction_step_slice_compute_correct
    (HPrev dv dk : RegionName)
    (t s_qk_h s_vo_h B H K V BK BV : Nat) (s : BlockState)
    (hOutInj : Function.Injective
      (fun jk : Fin BK => dkRowOffset s t s_qk_h B H K BK jk)) :
    ComputeCorrect.Realizes_without_Rounding
      (kernel := fused_recurrent_delta_bwd_dk_correction_step_slice HPrev dv dk
        t s_qk_h s_vo_h B H K V BK BV)
      (initialState := s)
      (write := ComputeCorrect.WriteMap.writeIf
        (fun jk : Fin BK => activeK s K BK jk)
        (fun jk => (dk, dkRowOffset s t s_qk_h B H K BK jk)))
      (expected := fun jk : Fin BK =>
        dkCorrStepSpec s HPrev dv dk t s_qk_h s_vo_h B H K V BK BV jk) := by
  rw [ComputeCorrect.realizes_writeIf_iff]
  apply ComputeKernel.computeCorrect_of_toAlgKernel
  · simp [fused_recurrent_delta_bwd_dk_correction_step_slice,
      ComputeExpr.toAlgorithm?, ComputeOp.toAlgorithm?]
  intro s0 s' hExec hs0
  subst s0
  intro jk hActive
  have h := fused_recurrent_delta_bwd_dk_correction_step_slice_correct HPrev dv dk
    t s_qk_h s_vo_h B H K V BK BV s hOutInj jk
  rw [hExec] at h
  simpa [hActive] using Option.some.inj h

/-! ### Sequencing the loop-2 `dk` correction onto the loop-1 stores

`dkCorrStepSpec` above is stated *relative to whatever the `dk`/`dv` rows hold*
when the correction body runs. In the Python kernel those rows hold exactly what
loop 1 stored: after the `tl.debug_barrier()` the pointers `p_dk`/`p_dv` are
re-initialized to row `0` of the same `dk`/`dv` layouts loop 1 wrote (loop 1
walked them backwards from row `T-1`), so at time row `t` loop 2 reloads loop 1's
`d_k`/`d_v` cells — `dkRowOffset s t` and `outOffset s t` in both loops. The
face below states that sequencing explicitly instead of leaving the two reads
unconstrained: given loop 1's stored values, the final memory value of the `dk`
row is a formula over the backward inputs and the two materialized carries. -/

/-- **The sequenced loop-2 `dk` correction**: loop 1's `dk` row minus the
recomputed-state readout of loop 1's `dv` row,
`dkStepSpec_t[j_k] − Σ_{j_v} dvStepSpec_t[j_v] · HRec[j_k,j_v]`. A formula over
the backward-launch inputs and the two materialized carries (`DHPrev`, `HRec`) —
no unconstrained read of the kernel's own output rows. -/
noncomputable def dkCorrClosed (s : BlockState)
    (DHPrev HRec q do_ k v beta : RegionName) (IS_HEADWISE_BETA : Bool)
    (t s_qk_h s_vo_h T K V BK BV : Nat) (scale : ℝ) (jk : Fin BK) : ℝ :=
  dkStepSpec s DHPrev q do_ v beta IS_HEADWISE_BETA
      t s_qk_h s_vo_h T K V BK BV scale jk
    - ∑ jv : Fin BV,
        if activeV s V BV jv then
          dvStepSpec s DHPrev q do_ k beta IS_HEADWISE_BETA
              t s_qk_h s_vo_h T K V BK BV scale jv
            * s.readMem HRec (dhOffset s K V BK BV (jk, jv, PUnit.unit))
        else 0

/-- **Genuine sequenced loop-2 `dk` correction step.** Under the two
loop-1-stored-value hypotheses (Python's two-loop structure: loop 2 reloads the
rows loop 1 wrote — see the section note), the correction body realizes
`dkCorrClosed`, i.e. the *final* memory value of the `dk` row expressed through
the loop-1 `dk`/`dv` step formulas rather than through unconstrained reads. -/
theorem fused_recurrent_delta_bwd_dk_correction_step_sequenced
    (DHPrev HRec q do_ k v beta dk dv : RegionName) (IS_HEADWISE_BETA : Bool)
    (t s_qk_h s_vo_h B H T K V BK BV : Nat) (scale : ℝ) (s : BlockState)
    (hOutInj : Function.Injective
      (fun jk : Fin BK => dkRowOffset s t s_qk_h B H K BK jk))
    -- forced by loop 1's `tl.store(p_dk, d_k, mask=mask_bk)` at this very row
    (hDk : ∀ jk : Fin BK,
      s.readMem dk (dkRowOffset s t s_qk_h B H K BK jk)
        = dkStepSpec s DHPrev q do_ v beta IS_HEADWISE_BETA
            t s_qk_h s_vo_h T K V BK BV scale jk)
    -- forced by loop 1's `tl.store(p_dv, d_v, mask=mask_bv)` at this very row
    (hDv : ∀ jv : Fin BV,
      s.readMem dv (outOffset s t s_vo_h B H V BV jv)
        = dvStepSpec s DHPrev q do_ k beta IS_HEADWISE_BETA
            t s_qk_h s_vo_h T K V BK BV scale jv) :
    ComputeCorrect.Realizes_without_Rounding
      (kernel := fused_recurrent_delta_bwd_dk_correction_step_slice HRec dv dk
        t s_qk_h s_vo_h B H K V BK BV)
      (initialState := s)
      (write := ComputeCorrect.WriteMap.writeIf
        (fun jk : Fin BK => activeK s K BK jk)
        (fun jk => (dk, dkRowOffset s t s_qk_h B H K BK jk)))
      (expected := fun jk : Fin BK =>
        dkCorrClosed s DHPrev HRec q do_ k v beta IS_HEADWISE_BETA
          t s_qk_h s_vo_h T K V BK BV scale jk) := by
  have h := fused_recurrent_delta_bwd_dk_correction_step_slice_compute_correct
    HRec dv dk t s_qk_h s_vo_h B H K V BK BV s hOutInj
  have hcong : (fun jk : Fin BK =>
      dkCorrStepSpec s HRec dv dk t s_qk_h s_vo_h B H K V BK BV jk)
      = (fun jk : Fin BK =>
        dkCorrClosed s DHPrev HRec q do_ k v beta IS_HEADWISE_BETA
          t s_qk_h s_vo_h T K V BK BV scale jk) := by
    funext jk
    unfold dkCorrStepSpec dkCorrClosed
    rw [hDk jk]
    congr 1
    apply Finset.sum_congr rfl
    intro jv _
    split_ifs with hV
    · rw [hDv jv]
    · rfl
  rwa [hcong] at h

def fused_recurrent_delta_bwd_dq_step_slice_headwise
    (HPrev k v beta do_ dq : RegionName)
    (t s_qk_h s_vo_h B H T K V BK BV : Nat) (scale : ℝ) :
    ComputeKernel := triton {
  i_v = tl.program_id(0)
  i_k = tl.program_id(1)
  i_bh = tl.program_id(2)
  offs_k = tl.arange(0, $(BK))
  offs_v = tl.arange(0, $(BV))
  mask_bk = (i_k * $(BK) + offs_k) < $(K)
  mask_bv = (i_v * $(BV) + offs_v) < $(V)
  mask_kv = mask_bk[:, None] & mask_bv[None, :]
  prev = tl.load(HPrev + i_bh * $(K) * $(V) +
    (i_k * $(BK) + offs_k[:, None]) * $(V) + (i_v * $(BV) + offs_v[None, :]),
    mask=mask_kv, other=0.0)
  b_k = tl.load(k + i_bh * $(s_qk_h) + i_k * $(BK) + offs_k + $(t) * $(K),
    mask=mask_bk, other=0.0)
  b_v = tl.load(v + i_bh * $(s_vo_h) + i_v * $(BV) + offs_v + $(t) * $(V),
    mask=mask_bv, other=0.0)
  b_do = tl.load(do_ + i_bh * $(s_vo_h) + i_v * $(BV) + offs_v + $(t) * $(V),
    mask=mask_bv, other=0.0)
  b_beta = tl.load(beta + i_bh * $(s_vo_h) + i_v * $(BV) + offs_v + $(t) * $(V),
    mask=mask_bv, other=0.0)
  b_v *= b_beta
  h = prev + b_k[:, None] * b_v[None, :]
  _d_q = h * b_do[None, :]
  d_q = tl.sum(_d_q, axis=1) * $(scale)
  tl.store(dq + (i_bh + i_v * $(B) * $(H)) * $(s_qk_h) + i_k * $(BK) + offs_k +
    $(t) * $(K), (d_q).to(dq.dtype.element_ty), mask=mask_bk)
}

def fused_recurrent_delta_bwd_dq_step_slice_scalarbeta
    (HPrev k v beta do_ dq : RegionName)
    (t s_qk_h s_vo_h B H T K V BK BV : Nat) (scale : ℝ) :
    ComputeKernel := triton {
  i_v = tl.program_id(0)
  i_k = tl.program_id(1)
  i_bh = tl.program_id(2)
  offs_k = tl.arange(0, $(BK))
  offs_v = tl.arange(0, $(BV))
  mask_bk = (i_k * $(BK) + offs_k) < $(K)
  mask_bv = (i_v * $(BV) + offs_v) < $(V)
  mask_kv = mask_bk[:, None] & mask_bv[None, :]
  prev = tl.load(HPrev + i_bh * $(K) * $(V) +
    (i_k * $(BK) + offs_k[:, None]) * $(V) + (i_v * $(BV) + offs_v[None, :]),
    mask=mask_kv, other=0.0)
  b_k = tl.load(k + i_bh * $(s_qk_h) + i_k * $(BK) + offs_k + $(t) * $(K),
    mask=mask_bk, other=0.0)
  b_v = tl.load(v + i_bh * $(s_vo_h) + i_v * $(BV) + offs_v + $(t) * $(V),
    mask=mask_bv, other=0.0)
  b_do = tl.load(do_ + i_bh * $(s_vo_h) + i_v * $(BV) + offs_v + $(t) * $(V),
    mask=mask_bv, other=0.0)
  b_beta = tl.load(beta + i_bh * $(T) + $(t))
  b_v *= b_beta
  h = prev + b_k[:, None] * b_v[None, :]
  _d_q = h * b_do[None, :]
  d_q = tl.sum(_d_q, axis=1) * $(scale)
  tl.store(dq + (i_bh + i_v * $(B) * $(H)) * $(s_qk_h) + i_k * $(BK) + offs_k +
    $(t) * $(K), (d_q).to(dq.dtype.element_ty), mask=mask_bk)
}

/-- The genuine per-lane `dq` step formula (loop 2, both beta modes), reading
the recomputed *post-update* state built from the materialized `HPrev`:
`dq_t[j_k] = (Σ_{j_v} (HPrev[j_k,j_v] + k_t[j_k]·(v_t[j_v]·β_t[j_v])) · do_t[j_v]) · scale`
(recall `v` here holds the forward pass's stored deltas `v_new`). -/
noncomputable def dqStepSpec (s : BlockState) (HPrev k v beta do_ : RegionName)
    (IS_HEADWISE_BETA : Bool) (t s_qk_h s_vo_h T K V BK BV : Nat) (scale : ℝ)
    (jk : Fin BK) : ℝ :=
  (∑ jv : Fin BV,
      if activeV s V BV jv then
        (s.readMem HPrev (dhOffset s K V BK BV (jk, jv, PUnit.unit))
            + kVal s k s_qk_h K BK t jk *
                (vVal s v s_vo_h V BV t jv *
                  betaVal s beta IS_HEADWISE_BETA s_vo_h T V BV t jv))
          * vVal s do_ s_vo_h V BV t jv
      else 0)
    * scale

set_option maxHeartbeats 4000000 in
theorem fused_recurrent_delta_bwd_dq_step_slice_headwise_correct
    (HPrev k v beta do_ dq : RegionName)
    (t s_qk_h s_vo_h B H T K V BK BV : Nat) (scale : ℝ) (s : BlockState)
    (hOutInj : Function.Injective
      (fun jk : Fin BK => dkRowOffset s t s_qk_h B H K BK jk)) :
    ∀ jk : Fin BK,
      let outAddr := dkRowOffset s t s_qk_h B H K BK jk
      (exec (fused_recurrent_delta_bwd_dq_step_slice_headwise HPrev k v beta do_ dq
            t s_qk_h s_vo_h B H T K V BK BV scale) s).map (·.readMem dq outAddr)
        = some (if activeK s K BK jk then
            dqStepSpec s HPrev k v beta do_ Bool.true
              t s_qk_h s_vo_h T K V BK BV scale jk
          else s.readMem dq outAddr) := by
  intro jk
  have hzero : (0.0 : ℝ) = 0 := by norm_num
  simp [exec, fused_recurrent_delta_bwd_dq_step_slice_headwise, stepStmts, stepStmt,
        evalOp, evalOp.eq_def, Option.bind, Option.map, Tile.bop, Tile.cop,
        Tile.expandDim, Tile.uop, Tile.ptrAdd, Tile.reduceSum, Tile.reduceSumDrop,
        TileShape.axisDim, TileShape.eraseAxis, NumericDType.add, NumericDType.mul,
        ComparableDType.lt, dhOffset, dkRowOffset, activeK, vIndex, kIndex,
        TileShape.dropInsertedIndex]
  simp only [TileShape.insertAxisIndex_one_rank2, MaskedReduction.ite_some_some,
    Option.map₂_some_some, WithBot.sum_someTerm_eq_some, WithBot.unbotD_some]
  let offsetFn : TileIndex [BK] → Nat :=
    fun idx => (s.pids 2 + s.pids 0 * B * H) * s_qk_h + s.pids 1 * BK +
      idx.1.val + t * K
  let valueFn : TileIndex [BK] → ℝ :=
    fun idx =>
      (∑ jv : Fin BV,
        ((if s.pids 1 * BK + idx.1.val < K ∧ s.pids 0 * BV + jv.val < V then
              s.readMem HPrev
                (s.pids 2 * K * V + (s.pids 1 * BK + idx.1.val) * V +
                  (s.pids 0 * BV + jv.val))
            else 0.0)
          + (if s.pids 1 * BK + idx.1.val < K then
                s.readMem k (s.pids 2 * s_qk_h + s.pids 1 * BK + idx.1.val + t * K)
              else 0.0) *
              ((if s.pids 0 * BV + jv.val < V then
                    s.readMem v (s.pids 2 * s_vo_h + s.pids 0 * BV + jv.val + t * V)
                  else 0.0) *
                (if s.pids 0 * BV + jv.val < V then
                    s.readMem beta (s.pids 2 * s_vo_h + s.pids 0 * BV + jv.val + t * V)
                  else 0.0))) *
        (if s.pids 0 * BV + jv.val < V then
            s.readMem do_ (s.pids 2 * s_vo_h + s.pids 0 * BV + jv.val + t * V)
          else 0.0)) * scale
  let P : TileIndex [BK] → Prop := fun idx => s.pids 1 * BK + idx.1.val < K
  have hOffsetInj : Function.Injective offsetFn := by
    rintro ⟨a, _⟩ ⟨b, _⟩ hab
    have : dkRowOffset s t s_qk_h B H K BK a = dkRowOffset s t s_qk_h B H K BK b := by
      simpa [offsetFn, dkRowOffset] using hab
    obtain rfl : a = b := hOutInj this
    rfl
  change (List.foldl
      (fun (acc : BlockState) idx =>
        if P idx then acc.writeMem dq (offsetFn idx) (valueFn idx) else acc)
      _ (TileShape.allIndices [BK])).readMem dq (offsetFn (jk, PUnit.unit)) =
    if activeK s K BK jk then
      dqStepSpec s HPrev k v beta do_ Bool.true t s_qk_h s_vo_h T K V BK BV scale jk
    else s.readMem dq (offsetFn (jk, PUnit.unit))
  rw [BlockState.scatter_readback_prop_masked_nd _ _ _ _ hOffsetInj (jk, PUnit.unit)]
  by_cases hjk : s.pids 1 * BK + jk.val < K
  · simp only [P, hjk, if_true, activeK, kIndex, valueFn, dqStepSpec, dhOffset,
      betaVal, kVal, vVal, kIndex, vIndex, activeV, if_true, ite_true, true_and]
    congr 1
    apply Finset.sum_congr rfl
    intro jv _
    by_cases hV : s.pids 0 * BV + jv.val < V
    · simp only [hV, if_true]
    · simp only [hV, if_false, hzero]
      ring
  · simp only [P, activeK, kIndex, hjk, if_false, BlockState.setReg_readMem]

set_option maxHeartbeats 4000000 in
theorem fused_recurrent_delta_bwd_dq_step_slice_scalarbeta_correct
    (HPrev k v beta do_ dq : RegionName)
    (t s_qk_h s_vo_h B H T K V BK BV : Nat) (scale : ℝ) (s : BlockState)
    (hOutInj : Function.Injective
      (fun jk : Fin BK => dkRowOffset s t s_qk_h B H K BK jk)) :
    ∀ jk : Fin BK,
      let outAddr := dkRowOffset s t s_qk_h B H K BK jk
      (exec (fused_recurrent_delta_bwd_dq_step_slice_scalarbeta HPrev k v beta do_ dq
            t s_qk_h s_vo_h B H T K V BK BV scale) s).map (·.readMem dq outAddr)
        = some (if activeK s K BK jk then
            dqStepSpec s HPrev k v beta do_ Bool.false
              t s_qk_h s_vo_h T K V BK BV scale jk
          else s.readMem dq outAddr) := by
  intro jk
  have hzero : (0.0 : ℝ) = 0 := by norm_num
  simp [exec, fused_recurrent_delta_bwd_dq_step_slice_scalarbeta, stepStmts, stepStmt,
        evalOp, evalOp.eq_def, Option.bind, Option.map, Tile.bop, Tile.cop,
        Tile.expandDim, Tile.uop, Tile.ptrAdd, Tile.reduceSum, Tile.reduceSumDrop,
        TileShape.axisDim, TileShape.eraseAxis, NumericDType.add, NumericDType.mul,
        ComparableDType.lt, dhOffset, dkRowOffset, activeK, vIndex, kIndex,
        TileShape.dropInsertedIndex]
  simp only [TileShape.insertAxisIndex_one_rank2, MaskedReduction.ite_some_some,
    Option.map₂_some_some, WithBot.sum_someTerm_eq_some, WithBot.unbotD_some]
  let offsetFn : TileIndex [BK] → Nat :=
    fun idx => (s.pids 2 + s.pids 0 * B * H) * s_qk_h + s.pids 1 * BK +
      idx.1.val + t * K
  let valueFn : TileIndex [BK] → ℝ :=
    fun idx =>
      (∑ jv : Fin BV,
        ((if s.pids 1 * BK + idx.1.val < K ∧ s.pids 0 * BV + jv.val < V then
              s.readMem HPrev
                (s.pids 2 * K * V + (s.pids 1 * BK + idx.1.val) * V +
                  (s.pids 0 * BV + jv.val))
            else 0.0)
          + (if s.pids 1 * BK + idx.1.val < K then
                s.readMem k (s.pids 2 * s_qk_h + s.pids 1 * BK + idx.1.val + t * K)
              else 0.0) *
              ((if s.pids 0 * BV + jv.val < V then
                    s.readMem v (s.pids 2 * s_vo_h + s.pids 0 * BV + jv.val + t * V)
                  else 0.0) *
                s.readMem beta (s.pids 2 * T + t))) *
        (if s.pids 0 * BV + jv.val < V then
            s.readMem do_ (s.pids 2 * s_vo_h + s.pids 0 * BV + jv.val + t * V)
          else 0.0)) * scale
  let P : TileIndex [BK] → Prop := fun idx => s.pids 1 * BK + idx.1.val < K
  have hOffsetInj : Function.Injective offsetFn := by
    rintro ⟨a, _⟩ ⟨b, _⟩ hab
    have : dkRowOffset s t s_qk_h B H K BK a = dkRowOffset s t s_qk_h B H K BK b := by
      simpa [offsetFn, dkRowOffset] using hab
    obtain rfl : a = b := hOutInj this
    rfl
  change (List.foldl
      (fun (acc : BlockState) idx =>
        if P idx then acc.writeMem dq (offsetFn idx) (valueFn idx) else acc)
      _ (TileShape.allIndices [BK])).readMem dq (offsetFn (jk, PUnit.unit)) =
    if activeK s K BK jk then
      dqStepSpec s HPrev k v beta do_ Bool.false t s_qk_h s_vo_h T K V BK BV scale jk
    else s.readMem dq (offsetFn (jk, PUnit.unit))
  rw [BlockState.scatter_readback_prop_masked_nd _ _ _ _ hOffsetInj (jk, PUnit.unit)]
  by_cases hjk : s.pids 1 * BK + jk.val < K
  · simp only [P, hjk, if_true, activeK, kIndex, valueFn, dqStepSpec, dhOffset,
      betaVal, kVal, vVal, kIndex, vIndex, activeV, Bool.false_eq_true, ite_false,
      if_false, true_and]
    congr 1
    apply Finset.sum_congr rfl
    intro jv _
    by_cases hV : s.pids 0 * BV + jv.val < V
    · simp only [hV, if_true]
    · simp only [hV, if_false, hzero]
      ring
  · simp only [P, activeK, kIndex, hjk, if_false, BlockState.setReg_readMem]

/-- **Genuine `dq` step (loop 2).** The `IS_HEADWISE_BETA` specialization
selected by the flag realizes `dqStepSpec` (masked) into `dq` at time row `t`. -/
theorem fused_recurrent_delta_bwd_dq_step_slice_compute_correct
    (HPrev k v beta do_ dq : RegionName) (IS_HEADWISE_BETA : Bool)
    (t s_qk_h s_vo_h B H T K V BK BV : Nat) (scale : ℝ) (s : BlockState)
    (hOutInj : Function.Injective
      (fun jk : Fin BK => dkRowOffset s t s_qk_h B H K BK jk)) :
    ComputeCorrect.Realizes_without_Rounding
      (kernel := if IS_HEADWISE_BETA then
          fused_recurrent_delta_bwd_dq_step_slice_headwise HPrev k v beta do_ dq
            t s_qk_h s_vo_h B H T K V BK BV scale
        else
          fused_recurrent_delta_bwd_dq_step_slice_scalarbeta HPrev k v beta do_ dq
            t s_qk_h s_vo_h B H T K V BK BV scale)
      (initialState := s)
      (write := ComputeCorrect.WriteMap.writeIf
        (fun jk : Fin BK => activeK s K BK jk)
        (fun jk => (dq, dkRowOffset s t s_qk_h B H K BK jk)))
      (expected := fun jk : Fin BK =>
        dqStepSpec s HPrev k v beta do_ IS_HEADWISE_BETA
          t s_qk_h s_vo_h T K V BK BV scale jk) := by
  cases IS_HEADWISE_BETA
  · -- IS_HEADWISE_BETA = false
    simp only [Bool.false_eq_true, if_false]
    rw [ComputeCorrect.realizes_writeIf_iff]
    apply ComputeKernel.computeCorrect_of_toAlgKernel
    · simp [fused_recurrent_delta_bwd_dq_step_slice_scalarbeta,
        ComputeExpr.toAlgorithm?, ComputeOp.toAlgorithm?]
    intro s0 s' hExec hs0
    subst s0
    intro jk hActive
    have h := fused_recurrent_delta_bwd_dq_step_slice_scalarbeta_correct HPrev k v
      beta do_ dq t s_qk_h s_vo_h B H T K V BK BV scale s hOutInj jk
    rw [hExec] at h
    simpa [hActive] using Option.some.inj h
  · -- IS_HEADWISE_BETA = true
    simp only [if_true]
    rw [ComputeCorrect.realizes_writeIf_iff]
    apply ComputeKernel.computeCorrect_of_toAlgKernel
    · simp [fused_recurrent_delta_bwd_dq_step_slice_headwise,
        ComputeExpr.toAlgorithm?, ComputeOp.toAlgorithm?]
    intro s0 s' hExec hs0
    subst s0
    intro jk hActive
    have h := fused_recurrent_delta_bwd_dq_step_slice_headwise_correct HPrev k v
      beta do_ dq t s_qk_h s_vo_h B H T K V BK BV scale s hOutInj jk
    rw [hExec] at h
    simpa [hActive] using Option.some.inj h

/-! ## Offset-injectivity side conditions (dimension-general)

The flattened state address `i_bh·K·V + j_k·V + j_v` is injective on the
`[BV, BK]` (and `[BK, BV]`) tile whenever the tile fits the logical extents
(`BV ≤ V`, `BK ≤ K`): `j_v` occupies the low `V`-digit and `j_k·V` the next, a
faithful mixed-radix encoding. All per-time row addresses are injective in
their lane unconditionally (the lane is an additive term). The Python
regression (`K = BK = 16`, `V = 32`, `BV ∈ {8, 32}`) satisfies them. -/

/-- **Dimension-general** state / `h0` / `ht` address injectivity on the
forward `[BV, BK]` tile, given the tile fits (`BV ≤ V`, `BK ≤ K`). -/
theorem fused_recurrent_delta_state_offset_injective_general
    (s : BlockState) (K V BK BV : Nat) (hBV : BV ≤ V) (hBK : BK ≤ K) :
    Function.Injective (fun idx : TileIndex [BV, BK] => stateOffset s K V BK BV idx) := by
  rintro ⟨⟨av, hav⟩, ⟨ak, hak⟩, _⟩ ⟨⟨bv, hbv⟩, ⟨bk, hbk⟩, _⟩ h
  simp [stateOffset, vIndex, kIndex] at h
  have havV : av < V := lt_of_lt_of_le hav hBV
  have hbvV : bv < V := lt_of_lt_of_le hbv hBV
  have hVpos : 0 < V := lt_of_le_of_lt (Nat.zero_le _) havV
  have hcore : (s.pids 1 * BK + ak) * V + av = (s.pids 1 * BK + bk) * V + bv := by
    omega
  have hv : av = bv := by
    have ha : ((s.pids 1 * BK + ak) * V + av) % V = av % V := by
      rw [Nat.add_comm, Nat.mul_comm, Nat.add_mul_mod_self_left]
    have hb : ((s.pids 1 * BK + bk) * V + bv) % V = bv % V := by
      rw [Nat.add_comm, Nat.mul_comm, Nat.add_mul_mod_self_left]
    have hmod : ((s.pids 1 * BK + ak) * V + av) % V
        = ((s.pids 1 * BK + bk) * V + bv) % V := by rw [hcore]
    rwa [ha, hb, Nat.mod_eq_of_lt havV, Nat.mod_eq_of_lt hbvV] at hmod
  have hk : ak = bk := by
    subst hv
    have hmul : (s.pids 1 * BK + ak) * V = (s.pids 1 * BK + bk) * V := by omega
    have := Nat.eq_of_mul_eq_mul_right hVpos hmul
    omega
  subst hv; subst hk; rfl

/-- **Dimension-general** state address injectivity on the backward `[BK, BV]`
tile, given the tile fits (`BV ≤ V`, `BK ≤ K`). -/
theorem fused_recurrent_delta_dh_offset_injective_general
    (s : BlockState) (K V BK BV : Nat) (hBV : BV ≤ V) (hBK : BK ≤ K) :
    Function.Injective (fun idx : TileIndex [BK, BV] => dhOffset s K V BK BV idx) := by
  rintro ⟨⟨ak, hak⟩, ⟨av, hav⟩, _⟩ ⟨⟨bk, hbk⟩, ⟨bv, hbv⟩, _⟩ h
  simp [dhOffset, vIndex, kIndex] at h
  have havV : av < V := lt_of_lt_of_le hav hBV
  have hbvV : bv < V := lt_of_lt_of_le hbv hBV
  have hVpos : 0 < V := lt_of_le_of_lt (Nat.zero_le _) havV
  have hcore : (s.pids 1 * BK + ak) * V + av = (s.pids 1 * BK + bk) * V + bv := by
    omega
  have hv : av = bv := by
    have ha : ((s.pids 1 * BK + ak) * V + av) % V = av % V := by
      rw [Nat.add_comm, Nat.mul_comm, Nat.add_mul_mod_self_left]
    have hb : ((s.pids 1 * BK + bk) * V + bv) % V = bv % V := by
      rw [Nat.add_comm, Nat.mul_comm, Nat.add_mul_mod_self_left]
    have hmod : ((s.pids 1 * BK + ak) * V + av) % V
        = ((s.pids 1 * BK + bk) * V + bv) % V := by rw [hcore]
    rwa [ha, hb, Nat.mod_eq_of_lt havV, Nat.mod_eq_of_lt hbvV] at hmod
  have hk : ak = bk := by
    subst hv
    have hmul : (s.pids 1 * BK + ak) * V = (s.pids 1 * BK + bk) * V := by omega
    have := Nat.eq_of_mul_eq_mul_right hVpos hmul
    omega
  subst hv; subst hk; rfl

/-- **Dimension-general** `v`-row address injectivity (unconditional: the lane
is an additive term). -/
theorem fused_recurrent_delta_v_row_offset_injective_general
    (s : BlockState) (t s_vo_h V BV : Nat) :
    Function.Injective (fun jv : Fin BV => vRowOffset s t s_vo_h V BV jv) := by
  intro a b h
  apply Fin.ext
  simp [vRowOffset] at h
  omega

/-- **Dimension-general** `o`/`dv` row address injectivity (unconditional). -/
theorem fused_recurrent_delta_out_offset_injective_general
    (s : BlockState) (t s_vo_h B H V BV : Nat) :
    Function.Injective (fun jv : Fin BV => outOffset s t s_vo_h B H V BV jv) := by
  intro a b h
  apply Fin.ext
  simp [outOffset] at h
  omega

/-- **Dimension-general** `dk`/`dq` row address injectivity (unconditional). -/
theorem fused_recurrent_delta_dk_row_offset_injective_general
    (s : BlockState) (t s_qk_h B H K BK : Nat) :
    Function.Injective (fun jk : Fin BK => dkRowOffset s t s_qk_h B H K BK jk) := by
  intro a b h
  apply Fin.ext
  simp [dkRowOffset] at h
  omega

/-- **Dimension-general** headwise `dbeta` row address injectivity
(unconditional). -/
theorem fused_recurrent_delta_dbeta_row_offset_injective_general
    (s : BlockState) (t s_vo_h B H NK V BV : Nat) :
    Function.Injective (fun jv : Fin BV => dbetaRowOffset s t s_vo_h B H NK V BV jv) := by
  intro a b h
  apply Fin.ext
  simp [dbetaRowOffset] at h
  omega

/-! ### ════════ ★ MAIN THEOREM ★ ════════

**SCOPE — this is a claim about eight hand-cut single-step slices, not about the
launched kernels.** The launched surfaces appear only in clauses 1 and 2, which
say nothing more than "they lower to the algorithm layer". Clause 4 writes `HOut`,
a **fiction region** modelling the carried state register `h`, not a Python
tensor. Neither cross-step fold is modeled, and the `STORE_FINAL_STATE` writeback
has no face.

**Genuine, shape-general delta-rule step summary.** Parameterized
over the symbolic head strides `s_qk_h s_vo_h`, grid extents `NK B H T`,
key/value extents `K V`, tile sizes `BK BV`, the real `scale`, the step index
`m`, the final time `T`, and **all** compile-time flags (`IS_HEADWISE_BETA`,
`USE_INITIAL_STATE`, `STORE_FINAL_STATE`, `USE_DH0`, `USE_DHT`). It bundles
every stored output of both kernels, each realized against the genuine
standalone recurrence `deltaState` / the genuine per-step gradient formulas —
never a read-back of the kernel's own output:

1. the full **forward surface** lowers to the algorithm layer (all flags);
2. the full **backward surface** (both loops, `tl.debug_barrier()`, all
   flags) lowers to the algorithm layer;
3. one forward **`v_new` writeback** realizes the genuine delta
   `vNewClosed(m)` (masked), given the carry invariant
   `HPrev = deltaState(m)`;
4. one forward **state-update** body (the `IS_HEADWISE_BETA` specialization
   selected by the flag) realizes `deltaState(m+1)` — the delta-rule
   carry-fold — given `HPrev = deltaState(m)`;
5. one forward **output** body realizes `outputClosed(m)` (the key-axis
   readout of the *post-update* state), given `HNext = deltaState(m+1)`;
6. one backward loop-1 **`dk`** body (flag-selected) realizes the genuine
   `dkStepSpec` over the materialized reverse-carry `DHPrev` and input rows;
7. one backward loop-1 **`dv`** body (flag-selected) realizes `dvStepSpec`;
8. one backward loop-1 headwise **`dbeta`** body realizes `dbetaStepSpec`;
9. one backward loop-1 scalar **`dbeta`** body realizes the full-reduction
   `dbetaScalarStepSpec` (scalar cell);
10. one backward loop-2 **`dk` correction** body, *sequenced onto the loop-1
    stores*: under the two clause-local hypotheses that the `dk`/`dv` rows still
    hold clause 6's and clause 7's values (which is what Python's two-loop
    structure does — loop 2 re-walks the same `dk`/`dv` addresses forward after
    the `tl.debug_barrier()`), the in-place fixup realizes `dkCorrClosed`
    = `dkStepSpec − Σ_{j_v} dvStepSpec · HRec`, the final memory value of the
    `dk` row expressed through the loop-1 formulas rather than through
    unconstrained reads of the kernel's own output rows;
11. one backward loop-2 **`dq`** body (flag-selected) realizes `dqStepSpec`.

Clause 10 is why clause 6 and clause 10 are consistent rather than two
unrelated values for one `dk` cell: they are `Realizes` facts about *different*
slices run from the same initial state (loop 1's body and loop 2's body), and
clause 10 now names the loop-1 value it starts from instead of reading `dk` at
its own write address with nothing said about it.

The `STORE_FINAL_STATE` writeback has **no** conjunct: its face was a masked
memcpy (load address `HFinal + i_bh·K·V + offs_k·V + offs_v`, store address
`ht + …` — identical under the same mask) whose entire content was the
assumption `HFinal = deltaState(T)`, so it has been deleted rather than
presented as a result about `ht`.

Side conditions. Structural: `BV ≤ V`, `BK ≤ K` (the state tile fits the logical
extents, giving state-address injectivity); all row-address injectivities are
unconditional. There are **no** scope-fixing hypotheses left: every
slice in this file masks exactly where Python masks, and every specification is
guarded to match, so all eleven clauses hold for partial tiles. **Load-bearing:** `hPrev` and `hNext` are *assumptions* and they
carry the entire forward recurrence; every clause mentioning `deltaState`,
`vNewClosed` or `outputClosed` holds only under them.

**They are not self-propagating, and clause 4 does not discharge `hNext`.**
Clause 4 concludes about the state *after executing* the state-step slice, while
`hNext` constrains region `HOut` in the *initial* state `s` of the output slice;
sequencing one slice's post-state into the next slice's pre-state is not modeled.
(`HOut` is at least now the same region in both clauses — previously clause 4
wrote `HOut` while clause 5 read a separate `HNext` with nothing relating them, so
`deltaState(m+1)` was proved into a region nothing read and independently assumed
for the region that was read.) The cross-step folds threading `h`, `d_h` and the
recomputed `h` are not modeled (carried state presented as materialized buffers;
see the module docstring, including the in-place-`v` consequence).

By the time the backward kernel runs, region `v` holds the forward pass's stored
deltas `v_new` — the backward faces are genuine over the backward launch's actual
inputs. -/
specification fused_recurrent_delta_output_summary_general
    (q k v beta o h0 ht dht dh0 do_ dq dk dv dbeta : RegionName)
    (HPrev HOut DHPrev HRec : RegionName)
    (IS_HEADWISE_BETA USE_INITIAL_STATE STORE_FINAL_STATE USE_DH0 USE_DHT : Bool)
    (m s_qk_h s_vo_h NK B H T K V BK BV : Nat) (scale : ℝ) (s : BlockState)
    (hBV : BV ≤ V) (hBK : BK ≤ K)
    (hPrev : ∀ idx : TileIndex [BV, BK],
      s.readMem HPrev (stateOffset s K V BK BV idx)
        = deltaState s k v beta h0 IS_HEADWISE_BETA USE_INITIAL_STATE
            s_qk_h s_vo_h T K V BK BV m idx)
    -- the post-update carry buffer is the SAME region clause 4 stores into;
    -- this hypothesis is NOT discharged by clause 4 (see the docstring)
    (hNext : ∀ idx : TileIndex [BV, BK],
      s.readMem HOut (stateOffset s K V BK BV idx)
        = deltaState s k v beta h0 IS_HEADWISE_BETA USE_INITIAL_STATE
            s_qk_h s_vo_h T K V BK BV (m + 1) idx) :
    -- (1) the full forward surface lowers to the algorithm layer
    (∃ alg, (fused_recurrent_delta_fwd_surface q k v beta o h0 ht s_qk_h s_vo_h
      B H T K V BK BV scale USE_INITIAL_STATE STORE_FINAL_STATE
      IS_HEADWISE_BETA).toAlgorithm? = Except.ok alg) ∧
    -- (2) the full backward surface lowers to the algorithm layer
    (∃ alg, (fused_recurrent_delta_bwd_surface q k v beta dht dh0 do_ dq dk dv
      dbeta h0 s_qk_h s_vo_h NK B H T K V BK BV scale USE_INITIAL_STATE
      IS_HEADWISE_BETA USE_DH0 USE_DHT).toAlgorithm? = Except.ok alg) ∧
    -- (3) the `v_new` writeback realizes the genuine delta `vNewClosed(m)`
    (ComputeCorrect.Realizes_without_Rounding
      (kernel := fused_recurrent_delta_vnew_step_slice HPrev k v
        m s_qk_h s_vo_h K V BK BV)
      (initialState := s)
      (write := ComputeCorrect.WriteMap.writeIf
        (fun jv : Fin BV => activeV s V BV jv)
        (fun jv => (v, vRowOffset s m s_vo_h V BV jv)))
      (expected := fun jv : Fin BV =>
        vNewClosed s k v beta h0 IS_HEADWISE_BETA USE_INITIAL_STATE
          s_qk_h s_vo_h T K V BK BV m jv)) ∧
    -- (4) the state-update body realizes the genuine `deltaState(m+1)`
    (ComputeCorrect.Realizes_without_Rounding
      (kernel := if IS_HEADWISE_BETA then
          fused_recurrent_delta_state_step_slice_headwise HPrev k v beta HOut
            m s_qk_h s_vo_h T K V BK BV
        else
          fused_recurrent_delta_state_step_slice_scalarbeta HPrev k v beta HOut
            m s_qk_h s_vo_h T K V BK BV)
      (initialState := s)
      (write := ComputeCorrect.WriteMap.writeIf
        (fun idx : TileIndex [BV, BK] => activeKV s K V BK BV idx)
        (fun idx => (HOut, stateOffset s K V BK BV idx)))
      (expected := fun idx =>
        deltaState s k v beta h0 IS_HEADWISE_BETA USE_INITIAL_STATE
          s_qk_h s_vo_h T K V BK BV (m + 1) idx)) ∧
    -- (5) the output body realizes the genuine `outputClosed(m)` — mask-faithful,
    --     so it holds for partial tiles and carries no full-tile antecedent
    (ComputeCorrect.Realizes_without_Rounding
      (kernel := fused_recurrent_delta_output_step_slice HOut q o
        m s_qk_h s_vo_h B H K V BK BV scale)
      (initialState := s)
      (write := ComputeCorrect.WriteMap.writeIf
        (fun jv : Fin BV => activeV s V BV jv)
        (fun jv => (o, outOffset s m s_vo_h B H V BV jv)))
      (expected := fun jv : Fin BV =>
        outputClosed s q k v beta h0 IS_HEADWISE_BETA USE_INITIAL_STATE
          s_qk_h s_vo_h T K V BK BV scale m jv)) ∧
    -- (6) the backward loop-1 `dk` body realizes the genuine `dkStepSpec` —
    --     mask-faithful, so no full-tile antecedent
    (ComputeCorrect.Realizes_without_Rounding
      (kernel := if IS_HEADWISE_BETA then
          fused_recurrent_delta_bwd_dk_step_slice_headwise DHPrev q do_ v beta dk
            m s_qk_h s_vo_h B H T K V BK BV scale
        else
          fused_recurrent_delta_bwd_dk_step_slice_scalarbeta DHPrev q do_ v beta dk
            m s_qk_h s_vo_h B H T K V BK BV scale)
      (initialState := s)
      (write := ComputeCorrect.WriteMap.writeIf
        (fun jk : Fin BK => activeK s K BK jk)
        (fun jk => (dk, dkRowOffset s m s_qk_h B H K BK jk)))
      (expected := fun jk : Fin BK =>
        dkStepSpec s DHPrev q do_ v beta IS_HEADWISE_BETA
          m s_qk_h s_vo_h T K V BK BV scale jk)) ∧
    -- (7) the backward loop-1 `dv` body realizes the genuine `dvStepSpec` —
    --     mask-faithful, so no full-tile antecedent
    (ComputeCorrect.Realizes_without_Rounding
      (kernel := if IS_HEADWISE_BETA then
          fused_recurrent_delta_bwd_dv_step_slice_headwise DHPrev q do_ k beta dv
            m s_qk_h s_vo_h B H T K V BK BV scale
        else
          fused_recurrent_delta_bwd_dv_step_slice_scalarbeta DHPrev q do_ k beta dv
            m s_qk_h s_vo_h B H T K V BK BV scale)
      (initialState := s)
      (write := ComputeCorrect.WriteMap.writeIf
        (fun jv : Fin BV => activeV s V BV jv)
        (fun jv => (dv, outOffset s m s_vo_h B H V BV jv)))
      (expected := fun jv : Fin BV =>
        dvStepSpec s DHPrev q do_ k beta IS_HEADWISE_BETA
          m s_qk_h s_vo_h T K V BK BV scale jv)) ∧
    -- (8) the backward loop-1 headwise `dbeta` body realizes `dbetaStepSpec` —
    --     mask-faithful, so no full-tile antecedent
    (ComputeCorrect.Realizes_without_Rounding
      (kernel := fused_recurrent_delta_bwd_dbeta_step_slice_headwise DHPrev q do_ k v
        dbeta m s_qk_h s_vo_h NK B H T K V BK BV scale)
      (initialState := s)
      (write := ComputeCorrect.WriteMap.writeIf
        (fun jv : Fin BV => activeV s V BV jv)
        (fun jv => (dbeta, dbetaRowOffset s m s_vo_h B H NK V BV jv)))
      (expected := fun jv : Fin BV =>
        dbetaStepSpec s DHPrev q do_ k v m s_qk_h s_vo_h K V BK BV scale jv)) ∧
    -- (9) the backward loop-1 scalar `dbeta` body realizes `dbetaScalarStepSpec`
    --     — mask-faithful (guarded on both nested reductions)
    (ComputeCorrect.Realizes_without_Rounding
      (kernel := fused_recurrent_delta_bwd_dbeta_step_slice_scalarbeta DHPrev q do_ k v
        dbeta m s_qk_h s_vo_h B H T K V BK BV scale)
      (initialState := s)
      (write := fun _ : PUnit => some (dbeta, dbetaScalarOffset s m T B H))
      (expected := fun _ =>
        dbetaScalarStepSpec s DHPrev q do_ k v m s_qk_h s_vo_h K V BK BV scale)) ∧
    -- (10) the backward loop-2 `dk` correction body, **sequenced onto the loop-1
    --      stores**: given that the `dk`/`dv` rows still hold what clauses 6 and 7
    --      put there, the final `dk` row is `dkCorrClosed`
    ((∀ jk : Fin BK,
        s.readMem dk (dkRowOffset s m s_qk_h B H K BK jk)
          = dkStepSpec s DHPrev q do_ v beta IS_HEADWISE_BETA
              m s_qk_h s_vo_h T K V BK BV scale jk) →
      (∀ jv : Fin BV,
        s.readMem dv (outOffset s m s_vo_h B H V BV jv)
          = dvStepSpec s DHPrev q do_ k beta IS_HEADWISE_BETA
              m s_qk_h s_vo_h T K V BK BV scale jv) →
      ComputeCorrect.Realizes_without_Rounding
        (kernel := fused_recurrent_delta_bwd_dk_correction_step_slice HRec dv dk
          m s_qk_h s_vo_h B H K V BK BV)
        (initialState := s)
        (write := ComputeCorrect.WriteMap.writeIf
          (fun jk : Fin BK => activeK s K BK jk)
          (fun jk => (dk, dkRowOffset s m s_qk_h B H K BK jk)))
        (expected := fun jk : Fin BK =>
          dkCorrClosed s DHPrev HRec q do_ k v beta IS_HEADWISE_BETA
            m s_qk_h s_vo_h T K V BK BV scale jk)) ∧
    -- (11) the backward loop-2 `dq` body realizes the genuine `dqStepSpec` —
    --     mask-faithful, so no full-tile antecedent
    (ComputeCorrect.Realizes_without_Rounding
      (kernel := if IS_HEADWISE_BETA then
          fused_recurrent_delta_bwd_dq_step_slice_headwise HRec k v beta do_ dq
            m s_qk_h s_vo_h B H T K V BK BV scale
        else
          fused_recurrent_delta_bwd_dq_step_slice_scalarbeta HRec k v beta do_ dq
            m s_qk_h s_vo_h B H T K V BK BV scale)
      (initialState := s)
      (write := ComputeCorrect.WriteMap.writeIf
        (fun jk : Fin BK => activeK s K BK jk)
        (fun jk => (dq, dkRowOffset s m s_qk_h B H K BK jk)))
      (expected := fun jk : Fin BK =>
        dqStepSpec s HRec k v beta do_ IS_HEADWISE_BETA
          m s_qk_h s_vo_h T K V BK BV scale jk)) := by
  have hStateInj := fused_recurrent_delta_state_offset_injective_general
    s K V BK BV hBV hBK
  have hVRowInj := fused_recurrent_delta_v_row_offset_injective_general
    s m s_vo_h V BV
  have hOutInj := fused_recurrent_delta_out_offset_injective_general
    s m s_vo_h B H V BV
  have hDkInj := fused_recurrent_delta_dk_row_offset_injective_general
    s m s_qk_h B H K BK
  have hDbetaInj := fused_recurrent_delta_dbeta_row_offset_injective_general
    s m s_vo_h B H NK V BV
  refine ⟨?_, ?_, ?_, ?_, ?_, ?_, ?_, ?_, ?_, ?_, ?_⟩
  · exact fused_recurrent_delta_fwd_surface_toAlgorithm_supported q k v beta o
      h0 ht s_qk_h s_vo_h B H T K V BK BV scale USE_INITIAL_STATE
      STORE_FINAL_STATE IS_HEADWISE_BETA
  · exact fused_recurrent_delta_bwd_surface_toAlgorithm_supported q k v beta
      dht dh0 do_ dq dk dv dbeta h0 s_qk_h s_vo_h NK B H T K V BK BV scale
      USE_INITIAL_STATE IS_HEADWISE_BETA USE_DH0 USE_DHT
  · exact fused_recurrent_delta_vnew_step_closed_form HPrev k v beta h0
      IS_HEADWISE_BETA USE_INITIAL_STATE m s_qk_h s_vo_h T K V BK BV s
      hVRowInj hPrev
  · exact fused_recurrent_delta_state_step_closed_form HPrev k v beta h0 HOut
      IS_HEADWISE_BETA USE_INITIAL_STATE m s_qk_h s_vo_h T K V BK BV s
      hStateInj hPrev
  · exact fused_recurrent_delta_output_step_closed_form HOut q k v beta h0 o
      IS_HEADWISE_BETA USE_INITIAL_STATE m s_qk_h s_vo_h B H T K V BK BV scale
      s hOutInj hNext
  · exact fused_recurrent_delta_bwd_dk_step_slice_compute_correct DHPrev q do_
      v beta dk IS_HEADWISE_BETA m s_qk_h s_vo_h B H T K V BK BV scale s hDkInj
  · exact fused_recurrent_delta_bwd_dv_step_slice_compute_correct DHPrev q do_
      k beta dv IS_HEADWISE_BETA m s_qk_h s_vo_h B H T K V BK BV scale s hOutInj
  · exact fused_recurrent_delta_bwd_dbeta_step_slice_headwise_compute_correct
      DHPrev q do_ k v dbeta m s_qk_h s_vo_h NK B H T K V BK BV scale s hDbetaInj
  · exact fused_recurrent_delta_bwd_dbeta_step_slice_scalarbeta_compute_correct
      DHPrev q do_ k v dbeta m s_qk_h s_vo_h B H T K V BK BV scale s
  · intro hDkRow hDvRow
    exact fused_recurrent_delta_bwd_dk_correction_step_sequenced DHPrev HRec q do_
      k v beta dk dv IS_HEADWISE_BETA m s_qk_h s_vo_h B H T K V BK BV scale s
      hDkInj hDkRow hDvRow
  · exact fused_recurrent_delta_bwd_dq_step_slice_compute_correct HRec k v
      beta do_ dq IS_HEADWISE_BETA m s_qk_h s_vo_h B H T K V BK BV scale s hDkInj

end Correct_without_Rounding

/-! ## ════════ `⊨` IO face for the output step ════════

One loop body's output store is a **contraction**: it reads the `[BV, BK]` state
tile `HNext` and the `[BK]` time-`t` row of `q`, and writes the `[BV]` time-`t`
row of `o`, all addressed off the three program axes `(i_v, i_k, i_bh)`. That is
`Masked3DTileShapedKernelIO₂`'s shape — per-channel tile shapes, three axes — with
the `tl.sum(_, axis = 1)` living entirely inside the spec function. -/

section IOFace

set_option maxHeartbeats 1000000 in
theorem outputStep_flattenOk (HNext q o : RegionName)
    (t s_qk_h s_vo_h B H K V BK BV : Nat) (scale : ℝ) :
    ((fused_recurrent_delta_output_step_slice HNext q o t s_qk_h s_vo_h B H K V
      BK BV scale).toAlgKernel).FlattenOk := by
  unfold Kernel.FlattenOk
  simp [fused_recurrent_delta_output_step_slice, ComputeKernel.toAlgKernel,
    ComputeExpr.toAlgorithm?, ComputeOp.toAlgorithm?, StmtList.FlattenOk,
    Stmt.FlattenOk, Op.FlattenOk]
  and_intros <;> simp [Op.FlattenOk.eq_def]

set_option maxHeartbeats 1000000 in
theorem outputStep_terminates (HNext q o : RegionName)
    (t s_qk_h s_vo_h B H K V BK BV : Nat) (scale : ℝ) (s : BlockState) :
    ∃ s1, exec (fused_recurrent_delta_output_step_slice HNext q o t s_qk_h s_vo_h
      B H K V BK BV scale) s = some s1 := by
  simp [exec, fused_recurrent_delta_output_step_slice, stepStmts, stepStmt,
    evalOp, evalOp.eq_def, ComputeExpr.toAlgorithm?, ComputeOp.toAlgorithm?,
    Option.bind, Option.map, Tile.bop, Tile.cop, Tile.expandDim, Tile.ptrAdd,
    Tile.uop, NumericDType.add, NumericDType.mul, ComparableDType.lt,
    FloatDType.cast, TileShape.dropInsertedIndex]

set_option maxHeartbeats 1000000 in
theorem outputStep_frame (HNext q o : RegionName)
    (t s_qk_h s_vo_h B H K V BK BV : Nat) (scale : ℝ) (s s' : BlockState)
    (hExec : exec (fused_recurrent_delta_output_step_slice HNext q o t s_qk_h
      s_vo_h B H K V BK BV scale) s = some s') :
    ∀ (r : RegionName) (n : Nat),
      (r ≠ o ∨ ∀ jv : Fin BV, activeV s V BV jv →
        n ≠ outOffset s t s_vo_h B H V BV jv) →
      s'.mem r n = s.mem r n := by
  intro r n hcond
  simp only [activeV, vIndex, outOffset] at hcond
  simp [exec, fused_recurrent_delta_output_step_slice, stepStmts, stepStmt,
    evalOp, evalOp.eq_def, ComputeExpr.toAlgorithm?, ComputeOp.toAlgorithm?,
    Option.bind, Option.map, Tile.bop, Tile.cop, Tile.expandDim, Tile.ptrAdd,
    Tile.uop, NumericDType.add, NumericDType.mul, ComparableDType.lt,
    FloatDType.cast, TileShape.dropInsertedIndex] at hExec
  subst hExec
  rw [foldl_writeMem_frame (region := o)
    (fun i : TileIndex [BV] =>
      (s.pids 2 + s.pids 1 * B * H) * s_vo_h + s.pids 0 * BV + i.1.val + t * V)
    _ (fun i : TileIndex [BV] => s.pids 0 * BV + i.1.val < V) r n
    (TileShape.allIndices [BV]) ?_]
  · simp
  · rcases hcond with h | h
    · exact Or.inl h
    · exact Or.inr fun idx _ hidx => Ne.symm (h idx.1 hidx)

set_option maxHeartbeats 1000000 in
theorem outputStep_traceSafe (HNext q o : RegionName)
    (t s_qk_h s_vo_h B H K V BK BV : Nat) (scale : ℝ)
    (bounds : RegionBounds) (s : BlockState)
    (hstate : ∀ idx : TileIndex [BV, BK], activeKV s K V BK BV idx →
      stateOffset s K V BK BV idx < bounds HNext)
    (hq : ∀ jk : Fin BK, activeK s K BK jk →
      s.pids 2 * s_qk_h + s.pids 1 * BK + jk.val + t * K < bounds q)
    (hout : ∀ jv : Fin BV, activeV s V BV jv →
      outOffset s t s_vo_h B H V BV jv < bounds o) :
    ((fused_recurrent_delta_output_step_slice HNext q o t s_qk_h s_vo_h B H K V
      BK BV scale).toAlgKernel).TraceSafe bounds s := by
  simp only [activeKV, activeK, activeV, kIndex, vIndex, stateOffset,
    outOffset] at hstate hq hout
  simp [Kernel.TraceSafe, fused_recurrent_delta_output_step_slice,
    ComputeKernel.toAlgKernel, ComputeExpr.toAlgorithm?,
    ComputeOp.toAlgorithm?, Stmt.TraceSafeList, Stmt.TraceSafe, Op.SafeAt,
    MaskOpt.SafeAt, MaskOpt.Active, MaskOpt.MemorySafe, MemAccess.SafeAt,
    MemAccess.MemorySafe, memAccessMemorySafe, MemAccess.ActiveAddressSafe,
    memAccessActiveAddressSafe, Op.PointerAddressesSafeOn, Op.MemorySafe,
    stepStmts, stepStmt, evalOp, evalOp.eq_def, Option.bind, Option.map,
    Tile.bop, Tile.cop, Tile.expandDim, Tile.ptrAdd, Tile.uop, NumericDType.add,
    NumericDType.mul, ComparableDType.lt, FloatDType.cast,
    TileShape.dropInsertedIndex]
  and_intros
  all_goals try exact fun a b h1 h2 => hstate (a, b, PUnit.unit) ⟨h1, h2⟩
  all_goals try exact fun a h => hq a h
  all_goals try exact fun a h => hout a h
  all_goals simp [Op.SafeAt.eq_def]

set_option maxHeartbeats 1000000 in
/-- Region-model run of the output store. -/
theorem outputStep_region_run (HNext q o : RegionName)
    (t s_qk_h s_vo_h B H K V BK BV : Nat) (scale : ℝ) (s₀ : BlockState)
    (hOutInj : Function.Injective
      (fun jv : Fin BV => outOffset s₀ t s_vo_h B H V BV jv))
    (xs : TileIndex [BV, BK] → ℝ) (ys : TileIndex [BK] → ℝ)
    (hx : ∀ idx : TileIndex [BV, BK], activeKV s₀ K V BK BV idx →
      s₀.readMem HNext (stateOffset s₀ K V BK BV idx) = xs idx)
    (hy : ∀ jk : TileIndex [BK], activeK s₀ K BK jk.1 →
      s₀.readMem q (s₀.pids 2 * s_qk_h + s₀.pids 1 * BK + jk.1.val + t * K)
        = ys jk) :
    ∃ s1, exec (fused_recurrent_delta_output_step_slice HNext q o t s_qk_h s_vo_h
        B H K V BK BV scale) s₀ = some s1
      ∧ (∀ jv : TileIndex [BV], activeV s₀ V BV jv.1 →
          s1.readMem o (outOffset s₀ t s_vo_h B H V BV jv.1)
            = ∑ jk : Fin BK,
                if s₀.pids 1 * BK + jk.val < K then
                  xs (jv.1, jk, PUnit.unit) * (scale * ys (jk, PUnit.unit))
                else 0)
      ∧ (∀ (r : RegionName) (n : Nat),
          (r ≠ o ∨ ∀ jv : Fin BV, activeV s₀ V BV jv →
            n ≠ outOffset s₀ t s_vo_h B H V BV jv) →
          s1.mem r n = s₀.mem r n) := by
  obtain ⟨s1, hexec⟩ := outputStep_terminates HNext q o t s_qk_h s_vo_h B H K V
    BK BV scale s₀
  refine ⟨s1, hexec, ?_, outputStep_frame HNext q o t s_qk_h s_vo_h B H K V BK BV
    scale s₀ s1 hexec⟩
  intro jv hact
  have h := fused_recurrent_delta_output_step_slice_correct HNext q o t s_qk_h
    s_vo_h B H K V BK BV scale s₀ hOutInj jv.1
  have hval : s1.readMem o (outOffset s₀ t s_vo_h B H V BV jv.1)
      = if activeV s₀ V BV jv.1 then
          outputStepSpec s₀ HNext q t s_qk_h K V BK BV scale jv.1
        else s₀.readMem o (outOffset s₀ t s_vo_h B H V BV jv.1) := by
    simpa [hexec] using h
  rw [hval, if_pos hact, outputStepSpec]
  refine Finset.sum_congr rfl fun jk _ => ?_
  by_cases hk : activeK s₀ K BK jk
  · rw [if_pos hk, if_pos (by simpa [activeK, kIndex] using hk),
      hx (jv.1, jk, PUnit.unit) ⟨hk, hact⟩, qVal, kVal,
      hy (jk, PUnit.unit) hk]
  · rw [if_neg hk, if_neg (by simpa [activeK, kIndex] using hk)]

/-- IO signature of the output store: the `[BV, BK]` state tile and the `[BK]`
`q` row contract into the `[BV]` `o` row. -/
noncomputable def outputStepIO (HNext q o : RegionName)
    (t s_qk_h s_vo_h B H K V BK BV : Nat) :
    Masked3DTileShapedKernelIO₂ where
  kernel := fused_recurrent_delta_output_step_slice HNext q o t s_qk_h s_vo_h B H
    K V BK BV 1
  in1 := HNext
  in2 := q
  out := o
  shape1 := [BV, BK]
  shape2 := [BK]
  shapeOut := [BV]
  read1 := fun p₀ p₁ p₂ idx =>
    p₂ * K * V + (p₁ * BK + idx.2.1.val) * V + (p₀ * BV + idx.1.val)
  read2 := fun _p₀ p₁ p₂ jk => p₂ * s_qk_h + p₁ * BK + jk.1.val + t * K
  write := fun p₀ p₁ p₂ jv =>
    (p₂ + p₁ * B * H) * s_vo_h + p₀ * BV + jv.1.val + t * V
  mask1 := fun p₀ p₁ _p₂ idx =>
    p₁ * BK + idx.2.1.val < K ∧ p₀ * BV + idx.1.val < V
  mask2 := fun _p₀ p₁ _p₂ jk => p₁ * BK + jk.1.val < K
  writeMask := fun p₀ _p₁ _p₂ jv => p₀ * BV + jv.1.val < V

/-! ### ════════ ★ MAIN THEOREM ★ ════════ -/

/-- **The headline on the IO surface** for `fused_recurrent_delta_rule.py`'s
output store: for every disjoint flat placement of `HNext` / `q` / `o`, every
program coordinate whose active lanes are in bounds, and every launch state whose
`HNext` state tile holds `xs` and whose `q` row holds `ys` on their active lanes,
the kernel terminates, every write-active lane of the `o` row holds the guarded
contraction `Σ_{j_k} ⟦i_k·BK + j_k < K⟧ · xs[j_v, j_k] · ys[j_k]`, and every other
memory cell is unchanged.

The `mask_bk` guard inside the sum is not a proof convenience: it is what Python's
`other = 0` loads do, and dropping it would make the face false for partial key
tiles. Dimension-general in `K`, `V`, `BK`, `BV`, `B`, `H` and the strides; stated
at `scale = 1`, where the kernel's `b_q = tl.load(...) * scale` is the loaded row
itself — the general-`scale` face is the same statement with `ys` scaled, already
carried by `fused_recurrent_delta_output_step_slice_correct`. Honest
side-condition: output-address injectivity at every program coordinate. -/
specification fused_recurrent_delta_output_step_io_correctness
    (HNext q o : RegionName) (t s_qk_h s_vo_h B H K V BK BV : Nat)
    (hOutInj : ∀ p₀ p₁ p₂ : Nat, Function.Injective
      (fun jv : Fin BV =>
        (p₂ + p₁ * B * H) * s_vo_h + p₀ * BV + jv.val + t * V)) :
    outputStepIO HNext q o t s_qk_h s_vo_h B H K V BK BV
      ⊨ fun _p₀ p₁ xs ys jv =>
          ∑ jk : Fin BK,
            if p₁ * BK + jk.val < K then
              xs (jv.1, jk, PUnit.unit) * ys (jk, PUnit.unit)
            else 0 := by
  refine Masked3DTileShapedKernelIO₂.Implements.intro _ ?_ ?_ ?_
  · exact outputStep_flattenOk HNext q o t s_qk_h s_vo_h B H K V BK BV 1
  · intro bounds s h1 h2 h3
    exact outputStep_traceSafe HNext q o t s_qk_h s_vo_h B H K V BK BV 1 bounds s
      (fun idx hact => h1 idx hact) (fun jk hact => h2 (jk, PUnit.unit) hact)
      (fun jv hact => h3 (jv, PUnit.unit) hact)
  · intro s₀ xs ys hx hy
    have h := outputStep_region_run HNext q o t s_qk_h s_vo_h B H K V BK BV 1 s₀
      (by
        have := hOutInj (s₀.pids 0) (s₀.pids 1) (s₀.pids 2)
        simpa [outOffset] using this) xs ys
      (fun idx hact => hx idx hact) (fun jk hact => hy jk hact)
    obtain ⟨s1, hexec, hval, hframe⟩ := h
    refine ⟨s1, hexec, fun jv hact => ?_, fun r n hc => hframe r n ?_⟩
    · refine (hval jv hact).trans (Finset.sum_congr rfl fun jk _ => ?_)
      by_cases hk : s₀.pids 1 * BK + jk.val < K
      · rw [if_pos hk, if_pos hk, one_mul]
      · rw [if_neg hk, if_neg hk]
    · rcases hc with hr | hn
      · exact Or.inl hr
      · exact Or.inr fun jv hact => hn (jv, PUnit.unit) hact

end IOFace

end VeriTile.Bench.TritonBenchG.FusedRecurrentDelta


#auditModuleAxioms
